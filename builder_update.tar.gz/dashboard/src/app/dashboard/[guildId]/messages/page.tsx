'use client';

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Code, Type, Palette, Layout, Sparkles, Hash, Send, FileText, Eye, Copy, Download, User, MessageSquare, Settings, Info, Calendar, Clock, Smile, ExternalLink, MousePointer2, ListFilter, ShieldCheck, ChevronRight, Activity, Check, Terminal, ArrowDown, Zap, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';
import { parseColor } from '@/lib/utils';

interface EmbedField {
  name: string;
  value: string;
  inline: boolean;
}

interface ButtonData {
  style: 'PRIMARY' | 'SECONDARY' | 'SUCCESS' | 'DANGER' | 'LINK';
  label: string;
  url?: string;
  custom_id?: string;
  emoji?: string;
  disabled: boolean;
}

interface SelectOption {
  label: string;
  value: string;
  description?: string;
  emoji?: string;
  default: boolean;
}

interface SelectMenu {
  custom_id: string;
  placeholder: string;
  options: SelectOption[];
  disabled: boolean;
}

interface EmbedData {
  content: string;
  title: string;
  description: string;
  url: string;
  color: string;
  timestamp: boolean;
  footer: { text: string; icon_url: string; };
  thumbnail: { url: string; };
  image: { url: string; };
  author: { name: string; url: string; icon_url: string; };
  fields: EmbedField[];
  buttons: ButtonData[];
  selectMenus: SelectMenu[];
  ephemeral: boolean;
  isV2: boolean;
}

const TABS = ['Body', 'Author', 'Footer', 'Images', 'Fields', 'Interactive', 'Assets', 'JSON'];

const BUTTON_STYLES = [
  { id: 'PRIMARY', label: 'Blurple', color: 'bg-[#5865F2]' },
  { id: 'SECONDARY', label: 'Grey', color: 'bg-[#4e5058]' },
  { id: 'SUCCESS', label: 'Green', color: 'bg-[#248046]' },
  { id: 'DANGER', label: 'Red', color: 'bg-[#da373c]' },
  { id: 'LINK', label: 'Link', color: 'bg-zinc-700' },
];

const VARIABLES = [
  { group: 'User', items: [
    { name: '{user}', desc: 'User#Tag' },
    { name: '{user.id}', desc: 'User ID' },
    { name: '{user.name}', desc: 'Username' },
    { name: '{user.mention}', desc: 'User mention' },
  ]},
  { group: 'Server', items: [
    { name: '{server}', desc: 'Server Name' },
    { name: '{server.id}', desc: 'Server ID' },
    { name: '{server.member_count}', desc: 'Member Count' },
  ]},
];

export default function MessagesPage() {
  const { guildId } = useParams();
  const [activeTab, setActiveTab] = useState('Body');
  const [embed, setEmbed] = useState<EmbedData>({
    content: '',
    title: '',
    description: '',
    url: '',
    color: '#ffffff',
    timestamp: false,
    footer: { text: '', icon_url: '' },
    thumbnail: { url: '' },
    image: { url: '' },
    author: { name: '', url: '', icon_url: '' },
    fields: [],
    buttons: [],
    selectMenus: [],
    ephemeral: false,
    isV2: false
  });

  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  const [emojis, setEmojis] = useState<{id: string, name: string, animated: boolean}[]>([]);
  const [selectedChannel, setSelectedChannel] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });
  const [savedEmbeds, setSavedEmbeds] = useState<any[]>([]);
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [saveTag, setSaveTag] = useState('');
  const [roles, setRoles] = useState<any[]>([]);
  const [actionModalOpen, setActionModalOpen] = useState(false);
  const [editingComponent, setEditingComponent] = useState<any>(null);
  const [componentLogic, setComponentLogic] = useState<any[]>([]);

  useEffect(() => {
    if (!guildId) return;
    fetch(`/api/guild/${guildId}/roles`).then(r => r.json()).then(setRoles).catch(() => {});
    fetch(`/api/guild/${guildId}/embeds`).then(r => r.json()).then(setSavedEmbeds);
  }, [guildId]);

  const saveEmbed = async () => {
     if (!saveName || !saveTag) return;
     try {
        const res = await fetch(`/api/guild/${guildId}/embeds`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ name: saveName, tag: saveTag, data: embed })
        });
        if (res.ok) {
           setStatusMsg({ text: 'Protocol template archived successfully', type: 'success' });
           setSaveModalOpen(false);
           // Refresh list
           fetch(`/api/guild/${guildId}/embeds`).then(r => r.json()).then(setSavedEmbeds);
        } else {
           const err = await res.text();
           setStatusMsg({ text: `Archive Error: ${err}`, type: 'error' });
        }
     } catch (e) {
        setStatusMsg({ text: 'Critical link failure during archival', type: 'error' });
     }
  };

  const loadEmbed = (data: any) => {
     try {
        const parsed = JSON.parse(data);
        setEmbed(parsed);
        setStatusMsg({ text: 'Protocol template loaded', type: 'info' });
        setTimeout(() => setStatusMsg({ text: '', type: '' }), 2000);
     } catch (e) {
        setStatusMsg({ text: 'Corruption detected in protocol template', type: 'error' });
     }
  };

  const deleteEmbed = async (tag: string) => {
     if (!confirm('Are you sure you want to purge this protocol template?')) return;
     await fetch(`/api/guild/${guildId}/embeds?tag=${tag}`, { method: 'DELETE' });
     setSavedEmbeds(savedEmbeds.filter(e => e.tag !== tag));
  };

  const openActionBuilder = async (comp: any) => {
     setEditingComponent(comp);
     const cid = comp.custom_id || comp.customId;
     try {
        const res = await fetch(`/api/guild/${guildId}/actions?customId=${cid}`);
        if (res.ok) {
           const data = await res.json();
           setComponentLogic(data ? JSON.parse(data.logic) : []);
        } else {
           setComponentLogic([]);
        }
     } catch (e) {
        setComponentLogic([]);
     }
     setActionModalOpen(true);
  };

  const saveActionLogic = async () => {
     if (!editingComponent) return;
     const cid = editingComponent.custom_id || editingComponent.customId;
     try {
        await fetch(`/api/guild/${guildId}/actions`, {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ customId: cid, logic: componentLogic })
        });
        setStatusMsg({ text: 'Neural logic synchronized', type: 'success' });
        setActionModalOpen(false);
     } catch (e) {
        setStatusMsg({ text: 'Logic sync failed', type: 'error' });
     }
  };

  useEffect(() => {
    if (!guildId) return;
    
    setIsLoading(true);
    // Fetch Channels & Emojis in parallel
    Promise.all([
      fetch(`/api/guild/${guildId}/channels`).then(r => r.json()),
      fetch(`/api/guild/${guildId}/emojis`).then(r => r.json())
    ]).then(([channelData, emojiData]) => {
      setChannels(channelData.filter((c: any) => c.type === 0 || c.type === 5));
      setEmojis(emojiData);
    }).catch(console.error)
    .finally(() => setIsLoading(false));
  }, [guildId]);

  const addField = () => {
    if (embed.fields.length < 25) {
      setEmbed({ ...embed, fields: [...embed.fields, { name: '', value: '', inline: false }] });
    }
  };

  const removeField = (index: number) => {
    const newFields = [...embed.fields];
    newFields.splice(index, 1);
    setEmbed({ ...embed, fields: newFields });
  };

  const addButton = () => {
    if (embed.buttons.length < 5) {
      setEmbed({ ...embed, buttons: [...embed.buttons, { style: 'PRIMARY', label: 'New Button', custom_id: `btn_${Date.now()}`, disabled: false }] });
    }
  };

  const removeButton = (index: number) => {
    const newButtons = [...embed.buttons];
    newButtons.splice(index, 1);
    setEmbed({ ...embed, buttons: newButtons });
  };

  const updateField = (index: number, key: string, value: any) => {
    const newFields = [...embed.fields];
    (newFields[index] as any)[key] = value;
    setEmbed({ ...embed, fields: newFields });
  };

  const addSelectMenu = () => {
    if (embed.selectMenus.length < 1) {
      setEmbed({ ...embed, selectMenus: [{ custom_id: `select_${Date.now()}`, placeholder: 'Select an option...', options: [], disabled: false }] });
    }
  };

  const addSelectOption = (menuIdx: number) => {
    const newMenus = [...embed.selectMenus];
    if (newMenus[menuIdx].options.length < 25) {
      newMenus[menuIdx].options.push({ label: 'Option', value: 'value', default: false });
      setEmbed({ ...embed, selectMenus: newMenus });
    }
  };

  const handleDispatch = async () => {
    if (!selectedChannel) return;
    setIsSending(true);
    setStatusMsg({ text: 'Dispatching message...', type: 'info' });
    
    try {
      const colorInt = parseColor(embed.color);
      
      // Standard Payload
      let finalPayload: any = {
        content: embed.content || undefined,
        embeds: [],
        components: []
      };

      if (!embed.isV2) {
        // --- V1 Standard Embed ---
        const cleanEmbed = {
          title: embed.title || undefined,
          description: embed.description || undefined,
          url: embed.url || undefined,
          color: colorInt,
          fields: embed.fields.length > 0 ? embed.fields : undefined,
          image: embed.image.url ? { url: embed.image.url } : undefined,
          thumbnail: embed.thumbnail.url ? { url: embed.thumbnail.url } : undefined,
          author: embed.author.name ? embed.author : undefined,
          footer: embed.footer.text ? embed.footer : undefined,
          timestamp: embed.timestamp ? new Date().toISOString() : undefined
        };
        finalPayload.embeds = [cleanEmbed];
      } else {
        // --- V2 Container Layout (Type 17) ---
        const banner = embed.image.url;
        const thumbnail = embed.thumbnail.url;
        const primaryContent = (embed.title ? `### ${embed.title}\n` : "") + (embed.description || "");

        const container: any = {
          type: 17,
          accent_color: colorInt,
          components: []
        };

        if (banner) {
          container.components.push({
            type: 12,
            items: [{ media: { url: banner } }]
          });
        }

        if (thumbnail) {
          container.components.push({
            type: 9,
            components: [{ type: 10, content: primaryContent || "\u200b" }],
            accessory: { type: 11, media: { url: thumbnail } }
          });
        } else if (primaryContent) {
          container.components.push({ type: 10, content: primaryContent });
        }

        if (embed.fields.length > 0) {
          container.components.push({
            type: 10,
            content: embed.fields.map(f => `**${f.name}**: ${f.value}`).join("\n")
          });
        }

        if (embed.footer.text) {
          container.components.push({ type: 10, content: `-# ${embed.footer.text}` });
        }

        finalPayload.components.push(container);
        finalPayload.flags = embed.ephemeral ? (1 << 6 | 1 << 12) : (1 << 12); // Ephemeral | IsComponentsV2
      }

      // --- Map Components (Buttons & Selects) ---
      // For V1, these go in standard ActionRows. For V2, they can stay in the same container or separate rows.
      // V2Helper puts them in the same container. I'll follow that for V2.
      
      const componentRows: any[] = [];
      
      // Buttons (Max 5 per row)
      if (embed.buttons.length > 0) {
        for (let i = 0; i < embed.buttons.length; i += 5) {
          const chunk = embed.buttons.slice(i, i + 5);
          const row = {
            type: 1,
            components: chunk.map(btn => {
              const discordBtn: any = {
                type: 2,
                style: btn.style === 'PRIMARY' ? 1 : 
                       btn.style === 'SECONDARY' ? 2 : 
                       btn.style === 'SUCCESS' ? 3 : 
                       btn.style === 'DANGER' ? 4 : 5,
                label: btn.label,
                disabled: btn.disabled
              };
              
              if (btn.style === 'LINK') discordBtn.url = btn.url;
              else discordBtn.custom_id = btn.custom_id;

              if (btn.emoji) {
                const match = btn.emoji.match(/<a?:(\w+):(\d+)>/);
                if (match) discordBtn.emoji = { name: match[1], id: match[2], animated: btn.emoji.startsWith('<a:') };
                else discordBtn.emoji = { name: btn.emoji };
              }
              
              return discordBtn;
            })
          };
          
          if (embed.isV2) (finalPayload.components[0] as any).components.push(row);
          else componentRows.push(row);
        }
      }

      // Select Menu (1 per row)
      if (embed.selectMenus.length > 0) {
        embed.selectMenus.forEach(menu => {
          const row = {
            type: 1,
            components: [{
              type: 3,
              custom_id: menu.custom_id,
              placeholder: menu.placeholder,
              disabled: menu.disabled,
              options: menu.options.map(opt => {
                const discordOpt: any = {
                  label: opt.label,
                  value: opt.value,
                  description: opt.description,
                  default: opt.default
                };
                if (opt.emoji) {
                   const match = opt.emoji.match(/<a?:(\w+):(\d+)>/);
                   if (match) discordOpt.emoji = { name: match[1], id: match[2], animated: opt.emoji.startsWith('<a:') };
                   else discordOpt.emoji = { name: opt.emoji };
                }
                return discordOpt;
              })
            }]
          };
          if (embed.isV2) (finalPayload.components[0] as any).components.push(row);
          else componentRows.push(row);
        });
      }

      if (!embed.isV2) {
        finalPayload.components = componentRows;
        if (embed.ephemeral) finalPayload.flags = 1 << 6; // Ephemeral
      }

      const res = await fetch(`/api/guild/${guildId}/dispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          channelId: selectedChannel,
          payload: finalPayload
        })
      });

      if (res.ok) {
        setStatusMsg({ text: 'Message delivered successfully.', type: 'success' });
        setTimeout(() => setStatusMsg({ text: '', type: '' }), 5000);
      } else {
        throw new Error('Delivery failed');
      }
    } catch (err) {
      console.error(err);
      setStatusMsg({ text: 'Error: Message delivery failed.', type: 'error' });
    } finally {
      setIsSending(false);
    }
  };

  const copyScript = () => {
    const script = JSON.stringify({
      content: embed.content,
      embeds: [{
        title: embed.title,
        description: embed.description,
        color: parseInt(embed.color.replace('#', ''), 16),
        footer: embed.footer.text ? embed.footer : undefined,
        author: embed.author.name ? embed.author : undefined,
        image: embed.image.url ? embed.image : undefined,
        thumbnail: embed.thumbnail.url ? embed.thumbnail : undefined,
        fields: embed.fields.length ? embed.fields : undefined,
        timestamp: embed.timestamp ? new Date().toISOString() : undefined
      }]
    }, null, 2);
    navigator.clipboard.writeText(script);
    setStatusMsg({ text: 'Script copied to clipboard', type: 'success' });
    setTimeout(() => setStatusMsg({ text: '', type: '' }), 3000);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (isLoading) {
    return (
      <main className="p-8 max-w-[1600px] mx-auto space-y-10 relative z-10">
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.03] animate-pulse" />
            <div className="space-y-2">
              <div className="h-6 w-48 bg-white/[0.03] rounded-lg animate-pulse" />
              <div className="h-4 w-64 bg-white/[0.01] rounded-lg animate-pulse" />
            </div>
          </div>
          <div className="flex gap-4">
            <div className="h-12 w-32 bg-white/[0.03] rounded-xl animate-pulse" />
            <div className="h-12 w-32 bg-white/[0.03] rounded-xl animate-pulse" />
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div className="xl:col-span-3 space-y-10">
            <div className="h-[400px] w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
            <div className="h-[600px] w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
          <div className="space-y-8">
             <div className="h-[500px] w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="p-8 max-w-[1600px] mx-auto space-y-10 relative z-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-fuchsia-500/20 to-pink-500/20 border border-fuchsia-500/20 flex items-center justify-center">
            <Layout className="w-6 h-6 text-fuchsia-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight uppercase">Embed Architect</h1>
            <p className="text-white/50 text-sm mt-1 uppercase tracking-wider font-bold">Construct high-fidelity interactive protocols.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <button 
             onClick={copyScript}
             className="px-5 py-3 rounded-xl bg-white/5 border border-white/5 text-white/40 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 hover:bg-white/10 hover:text-white transition-all"
           >
              <Code className="w-3.5 h-3.5" /> Export JSON
           </button>
           <button 
             onClick={() => setSaveModalOpen(true)}
             className="px-5 py-3 rounded-xl bg-white text-black text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 hover:bg-zinc-200 transition-all shadow-xl"
           >
              <Download className="w-3.5 h-3.5" /> Save Template
           </button>
           <div className="px-4 py-3 rounded-xl bg-fuchsia-500/10 border border-fuchsia-500/20 text-fuchsia-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> Engine v2.0-Alpha
           </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 xl:grid-cols-4 gap-8"
      >
        <div className="xl:col-span-3 space-y-10">
           {/* CHANNEL & BODY SECTOR */}
           <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                 <SurgicalDropdown 
                    label="Holographic Target"
                    options={channels}
                    value={selectedChannel}
                    onChange={setSelectedChannel}
                    placeholder="Select deployment core..."
                    icon={<Hash className="w-3.5 h-3.5" />}
                 />
                 
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] px-1">Privacy Protocol</label>
                    <button 
                      onClick={() => setEmbed({...embed, ephemeral: !embed.ephemeral})}
                      className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${embed.ephemeral ? 'bg-fuchsia-500/10 border-fuchsia-500/20 text-white' : 'bg-transparent border-white/5 text-white/30'}`}
                    >
                       <span className="text-[11px] font-bold uppercase tracking-widest pl-2">Ephemeral Mode (Hidden)</span>
                       <div className={`w-10 h-5 rounded-full relative transition-colors ${embed.ephemeral ? 'bg-fuchsia-500' : 'bg-white/10'}`}>
                          <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${embed.ephemeral ? 'left-6 bg-white' : 'left-1 bg-white/20'}`} />
                       </div>
                    </button>
                 </div>
              </div>

              <div className="space-y-4">
                 <div className="flex justify-between items-center px-1">
                    <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Manifest Content</label>
                    <span className="text-[9px] text-white/10 font-bold uppercase tracking-widest">{embed.content.length}/2000 Units</span>
                 </div>
                 <textarea 
                    className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-[15px] text-white placeholder:text-white/5 outline-none focus:border-white/10 transition-all resize-none min-h-[120px] font-medium leading-relaxed shadow-inner"
                    placeholder="Message content above the embed structure..."
                    value={embed.content}
                    onChange={(e) => setEmbed({...embed, content: e.target.value})}
                 />
              </div>

              <div className="space-y-6 pt-6 border-t border-white/5">
                 <div className="flex flex-wrap gap-2">
                    {TABS.map(tab => (
                       <button 
                         key={tab} 
                         onClick={() => setActiveTab(tab)}
                         className={`px-6 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${
                           activeTab === tab 
                             ? 'bg-white text-black border-white shadow-xl scale-105' 
                             : 'text-white/20 hover:text-white/40 hover:bg-white/5 border-transparent'
                         }`}
                       >
                          {tab}
                       </button>
                    ))}
                 </div>

                  </div>
                  <div className="min-h-[400px] bg-white/[0.01] border border-white/5 p-8 rounded-[24px]">
                     <AnimatePresence mode="wait">
                       <motion.div
                         key={activeTab}
                         initial={{ opacity: 0, y: 10 }}
                         animate={{ opacity: 1, y: 0 }}
                         exit={{ opacity: 0, y: -10 }}
                         transition={{ duration: 0.2 }}
                         className="space-y-8"
                       >
                          {activeTab === 'Main' && (
                             <div className="space-y-10">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                   <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8">
                                      <div className="flex items-center gap-3 text-white/20">
                                         <Type className="w-4 h-4" />
                                         <span className="text-[10px] font-black uppercase tracking-widest">Identity Header</span>
                                      </div>
                                      <div className="space-y-6">
                                         <div className="space-y-3">
                                            <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Protocol Name (Title)</label>
                                            <input type="text" value={embed.title} onChange={(e) => setEmbed({...embed, title: e.target.value})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[18px] text-white font-bold outline-none focus:border-white/10 transition-all shadow-inner" placeholder="Encryption Key..." />
                                         </div>
                                         <div className="space-y-3">
                                            <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Destination Link (URL)</label>
                                            <input type="text" value={embed.url} onChange={(e) => setEmbed({...embed, url: e.target.value})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" placeholder="https://..." />
                                         </div>
                                      </div>
                                   </div>
                                   <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8">
                                      <div className="flex items-center gap-3 text-white/20">
                                         <User className="w-4 h-4" />
                                         <span className="text-[10px] font-black uppercase tracking-widest">Origin Source</span>
                                      </div>
                                      <div className="space-y-6">
                                         <div className="space-y-3">
                                            <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Source Handle (Author)</label>
                                            <input type="text" value={embed.author.name} onChange={(e) => setEmbed({...embed, author: {...embed.author, name: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/10" placeholder="Author name..." />
                                         </div>
                                         <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Icon (URL)</label>
                                               <input type="text" value={embed.author.icon_url} onChange={(e) => setEmbed({...embed, author: {...embed.author, icon_url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" />
                                            </div>
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Link (URL)</label>
                                               <input type="text" value={embed.author.url} onChange={(e) => setEmbed({...embed, author: {...embed.author, url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" />
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                                <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8">
                                   <div className="flex justify-between items-center">
                                      <div className="flex items-center gap-3 text-white/20">
                                         <FileText className="w-4 h-4" />
                                         <span className="text-[10px] font-black uppercase tracking-widest">Neural Description</span>
                                      </div>
                                      <div className="flex items-center gap-4">
                                         <div className="w-8 h-8 rounded-full border border-white/5 overflow-hidden shadow-inner">
                                            <input type="color" value={embed.color} onChange={(e) => setEmbed({...embed, color: e.target.value})} className="w-12 h-12 -translate-x-2 -translate-y-2 cursor-pointer" />
                                         </div>
                                         <span className="text-[10px] font-mono text-white/20 uppercase tracking-widest">{embed.color}</span>
                                      </div>
                                   </div>
                                   <textarea value={embed.description} onChange={(e) => setEmbed({...embed, description: e.target.value})} className="w-full bg-white/[0.02] border border-white/5 p-8 rounded-[32px] text-[15px] text-white/80 outline-none focus:border-white/10 min-h-[200px] leading-relaxed resize-none shadow-inner" placeholder="Markdown supported neural sequence..." />
                                </div>
                             </div>
                          )}

                          {activeTab === 'Footer' && (
                             <div className="space-y-8">
                                <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8">
                                   <div className="flex items-center gap-3 text-white/20">
                                      <Terminal className="w-4 h-4" />
                                      <span className="text-[10px] font-black uppercase tracking-widest">Terminal Output</span>
                                   </div>
                                   <div className="space-y-8">
                                      <div className="space-y-3">
                                         <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Terminal Text</label>
                                         <input type="text" value={embed.footer.text} onChange={(e) => setEmbed({...embed, footer: {...embed.footer, text: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/10" placeholder="Footer text..." />
                                      </div>
                                      <div className="space-y-3">
                                         <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Icon Vector (URL)</label>
                                         <input type="text" value={embed.footer.icon_url} onChange={(e) => setEmbed({...embed, footer: {...embed.footer, icon_url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" placeholder="https://..." />
                                      </div>
                                      <div onClick={() => setEmbed({...embed, timestamp: !embed.timestamp})} className="flex items-center gap-4 p-5 rounded-2xl bg-white/[0.02] border border-white/5 cursor-pointer hover:bg-white/[0.04] transition-all">
                                         <div className={'w-10 h-5 rounded-full relative transition-all ' + (embed.timestamp ? 'bg-fuchsia-500' : 'bg-white/10')}>
                                            <div className={'absolute top-1 w-3 h-3 rounded-full transition-all ' + (embed.timestamp ? 'left-6 bg-white' : 'left-1 bg-white/20')} />
                                         </div>
                                         <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Temporal Stamp (Timestamp)</span>
                                      </div>
                                   </div>
                                </div>
                             </div>
                          )}

                          {activeTab === 'Images' && (
                             <div className="space-y-10">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                   <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-6">
                                      <div className="flex items-center gap-3 text-white/20">
                                         <Palette className="w-4 h-4" />
                                         <span className="text-[10px] font-black uppercase tracking-widest">Primary Visual</span>
                                      </div>
                                      <input type="text" value={embed.image.url} onChange={(e) => setEmbed({...embed, image: {url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" placeholder="Main image URL..." />
                                      {embed.image.url && <img src={embed.image.url} className="w-full h-32 object-cover rounded-2xl border border-white/5 opacity-40 hover:opacity-100 transition-all" />}
                                   </div>
                                   <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-6">
                                      <div className="flex items-center gap-3 text-white/20">
                                         <Layout className="w-4 h-4" />
                                         <span className="text-[10px] font-black uppercase tracking-widest">Thumbnail Vector</span>
                                      </div>
                                      <input type="text" value={embed.thumbnail.url} onChange={(e) => setEmbed({...embed, thumbnail: {url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10" placeholder="Thumbnail URL..." />
                                      {embed.thumbnail.url && <img src={embed.thumbnail.url} className="w-20 h-20 object-cover rounded-2xl border border-white/5 opacity-40 hover:opacity-100 transition-all" />}
                                   </div>
                                </div>
                             </div>
                          )}

                          {activeTab === 'Fields' && (
                             <div className="space-y-8">
                                <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                   <div>
                                      <h4 className="text-[11px] font-black uppercase text-white tracking-widest">Data Fields</h4>
                                      <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest mt-0.5">Organized informational blocks</p>
                                   </div>
                                   <button onClick={addField} className="px-6 py-3 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl">
                                      Inject Field
                                   </button>
                                </div>
                                <div className="grid grid-cols-1 gap-6 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                                   <AnimatePresence mode="popLayout">
                                      {embed.fields.map((field, i) => (
                                         <motion.div layout initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} key={i} className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8 relative group border-l-4 border-l-white/5 shadow-inner">
                                            <button onClick={() => removeField(i)} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                               <div className="space-y-3">
                                                  <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Field Key</label>
                                                  <input type="text" value={field.name} onChange={(e) => { const nf = [...embed.fields]; nf[i].name = e.target.value; setEmbed({...embed, fields: nf}); }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[14px] text-white font-bold outline-none focus:border-white/10" />
                                               </div>
                                               <div className="flex items-end pb-2">
                                                  <label className="flex items-center gap-3 cursor-pointer group/inline">
                                                     <div onClick={() => { const nf = [...embed.fields]; nf[i].inline = !nf[i].inline; setEmbed({...embed, fields: nf}); }} className={'w-10 h-5 rounded-full relative transition-all ' + (field.inline ? 'bg-fuchsia-500' : 'bg-white/10')}>
                                                        <div className={'absolute top-1 w-3 h-3 rounded-full transition-all ' + (field.inline ? 'left-6 bg-white' : 'left-1 bg-white/20')} />
                                                     </div>
                                                     <span className="text-[10px] font-black text-white/20 uppercase tracking-widest group-hover/inline:text-white/40 transition-colors">Inline Protocol</span>
                                                  </label>
                                               </div>
                                            </div>
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Field Value</label>
                                               <textarea value={field.value} onChange={(e) => { const nf = [...embed.fields]; nf[i].value = e.target.value; setEmbed({...embed, fields: nf}); }} className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-[24px] text-[14px] text-white/80 outline-none focus:border-white/10 min-h-[120px] resize-none" />
                                            </div>
                                         </motion.div>
                                      ))}
                                   </AnimatePresence>
                                </div>
                             </div>
                          )}

                          {activeTab === 'Interactive' && (
                              <div className="space-y-12">
                                 <div className="space-y-6">
                                    <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                       <div>
                                          <h4 className="text-[11px] font-black uppercase text-white tracking-widest">Interactive Buttons</h4>
                                          <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest mt-0.5">CTA components with neural logic</p>
                                       </div>
                                       <button onClick={addButton} className="px-6 py-3 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl">
                                          Inject Button
                                       </button>
                                    </div>
                                    <div className="grid grid-cols-1 gap-6 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                                       <AnimatePresence mode="popLayout">
                                          {embed.buttons.map((btn, i) => (
                                             <motion.div layout initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} key={i} className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-8 relative group border-l-4 border-l-white/5 shadow-inner">
                                                <button onClick={() => removeButton(i)} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                                   <div className="space-y-3">
                                                      <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Button Label</label>
                                                      <input type="text" value={btn.label} onChange={(e) => {
                                                         const nb = [...embed.buttons]; nb[i].label = e.target.value; setEmbed({...embed, buttons: nb});
                                                      }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[14px] text-white font-bold outline-none focus:border-white/10" />
                                                   </div>
                                                   <div className="space-y-3">
                                                      <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">{btn.style === 'LINK' ? 'Destination Core (URL)' : 'Neural Action ID'}</label>
                                                      <input type="text" placeholder={btn.style === 'LINK' ? 'https://...' : 'action_protocol_01'} value={btn.style === 'LINK' ? btn.url : btn.custom_id} onChange={(e) => {
                                                         const nb = [...embed.buttons]; 
                                                         if (btn.style === 'LINK') nb[i].url = e.target.value;
                                                         else nb[i].custom_id = e.target.value;
                                                         setEmbed({...embed, buttons: nb});
                                                      }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10 shadow-inner" />
                                                   </div>
                                                </div>
                                                <div className="space-y-6">
                                                    <div className="grid grid-cols-1 gap-6">
                                                       <div className="space-y-3">
                                                          <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Visual Emoji</label>
                                                          <input type="text" value={btn.emoji || ''} onChange={(e) => {
                                                             const nb = [...embed.buttons]; nb[i].emoji = e.target.value; setEmbed({...embed, buttons: nb});
                                                          }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-[12px] text-white/60 outline-none focus:border-white/10 font-mono" placeholder="🔍 Vector code..." />
                                                       </div>
                                                       <div className="space-y-3">
                                                          <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Protocol Visual Style</label>
                                                          <div className="flex gap-2">
                                                             {BUTTON_STYLES.map(s => (
                                                                <button 
                                                                  key={s.id} 
                                                                  onClick={() => {
                                                                     const nb = [...embed.buttons]; nb[i].style = s.id as any; setEmbed({...embed, buttons: nb});
                                                                  }}
                                                                  className={'flex-1 h-12 rounded-xl transition-all border flex items-center justify-center ' + (btn.style === s.id ? 'bg-white/10 border-white/30 scale-105 shadow-xl' : 'bg-transparent border-white/5 opacity-40 hover:opacity-100 hover:bg-white/5')}
                                                                >
                                                                   <div className={'w-3.5 h-3.5 rounded-full ' + s.color + ' shadow-lg'} />
                                                                </button>
                                                             ))}
                                                          </div>
                                                       </div>
                                                    </div>
                                                </div>
                                                {btn.style !== 'LINK' && (
                                                   <div className="pt-2">
                                                      <button 
                                                        onClick={() => openActionBuilder(btn)}
                                                        className="w-full py-4 bg-fuchsia-500/10 border border-fuchsia-500/20 rounded-2xl text-[10px] font-black uppercase text-fuchsia-400 tracking-[0.2em] hover:bg-fuchsia-500/20 transition-all flex items-center justify-center gap-3"
                                                      >
                                                         <Zap className="w-3.5 h-3.5" /> Bind Neural Logic
                                                      </button>
                                                   </div>
                                                )}
                                             </motion.div>
                                          ))}
                                       </AnimatePresence>
                                    </div>
                                 </div>

                                 {/* Select Menus Section */}
                                 <div className="space-y-6">
                                    <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                       <div>
                                          <h4 className="text-[11px] font-black uppercase text-white tracking-widest">Select Menus</h4>
                                          <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest mt-0.5">Decision matrices with multi-choice flows</p>
                                       </div>
                                       {embed.selectMenus.length === 0 && (
                                          <button onClick={addSelectMenu} className="px-6 py-3 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl">
                                             Inject Menu
                                          </button>
                                       )}
                                    </div>
                                    {embed.selectMenus.map((menu, mIdx) => (
                                       <div key={mIdx} className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-12 relative group border-l-4 border-l-white/5 shadow-inner">
                                          <button onClick={() => { const nm = [...embed.selectMenus]; nm.splice(mIdx, 1); setEmbed({...embed, selectMenus: nm}); }} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                             <div className="space-y-3">
                                                <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Holographic Placeholder</label>
                                                <input value={menu.placeholder} onChange={(e) => { const nm = [...embed.selectMenus]; nm[mIdx].placeholder = e.target.value; setEmbed({...embed, selectMenus: nm}); }} className="w-full bg-white/[0.02] border border-white/5 p-4.5 rounded-xl text-[14px] text-white font-bold outline-none focus:border-white/10 shadow-inner" />
                                             </div>
                                             <div className="space-y-3">
                                                <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Neural Action ID</label>
                                                <input value={menu.custom_id} onChange={(e) => { const nm = [...embed.selectMenus]; nm[mIdx].custom_id = e.target.value; setEmbed({...embed, selectMenus: nm}); }} className="w-full bg-white/[0.02] border border-white/5 p-4.5 rounded-xl text-[12px] font-mono text-white/40 outline-none focus:border-white/10 shadow-inner" />
                                             </div>
                                          </div>
                                          <div className="space-y-8 pt-10 border-t border-white/5">
                                             <div className="flex justify-between items-center bg-white/[0.02] p-5 rounded-2xl border border-white/5 shadow-inner">
                                                <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">Decision Nodes</span>
                                                <button onClick={() => addSelectOption(mIdx)} className="text-[9px] font-black text-white hover:text-white/40 uppercase tracking-widest transition-all">+ Inject Option</button>
                                             </div>
                                             <div className="grid grid-cols-1 gap-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
                                                <AnimatePresence mode="popLayout">
                                                   {menu.options.map((opt, oIdx) => (
                                                      <motion.div layout initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} key={oIdx} className="flex gap-4 items-center bg-white/[0.01] p-5 rounded-2xl border border-white/5 group/opt hover:bg-white/[0.02] transition-all shadow-inner">
                                                         <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[10px] font-black text-white/20">{oIdx + 1}</div>
                                                         <input value={opt.label} onChange={(e) => { const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].label = e.target.value; setEmbed({...embed, selectMenus: nm}); }} placeholder="Label" className="flex-1 bg-transparent border-none outline-none text-[13px] font-bold text-white uppercase tracking-wider" />
                                                         <input value={opt.emoji || ''} onChange={(e) => { const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].emoji = e.target.value; setEmbed({...embed, selectMenus: nm}); }} placeholder="Emoji" className="w-24 bg-white/5 px-4 py-2.5 rounded-xl text-[10px] font-mono text-white/40 outline-none border border-white/5" />
                                                         <input value={opt.value} onChange={(e) => { const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].value = e.target.value; setEmbed({...embed, selectMenus: nm}); }} placeholder="Value" className="w-24 bg-white/5 px-4 py-2.5 rounded-xl text-[10px] font-mono text-white/40 outline-none border border-white/5" />
                                                         <button onClick={() => { const nm = [...embed.selectMenus]; nm[mIdx].options.splice(oIdx, 1); setEmbed({...embed, selectMenus: nm}); }} className="text-white/10 hover:text-red-500 transition-all opacity-0 group-hover/opt:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                                      </motion.div>
                                                   ))}
                                                </AnimatePresence>
                                             </div>
                                          </div>
                                          <div className="pt-8 border-t border-white/5">
                                             <button onClick={() => openActionBuilder(menu)} className="w-full py-4 bg-fuchsia-500/10 border border-fuchsia-500/20 rounded-2xl text-[10px] font-black uppercase text-fuchsia-400 tracking-[0.2em] hover:bg-fuchsia-500/20 transition-all flex items-center justify-center gap-3">
                                                <Zap className="w-3.5 h-3.5" /> Bind Neural Logic
                                             </button>
                                          </div>
                                       </div>
                                    ))}
                                 </div>
                              </div>
                          )}

                          {activeTab === 'Assets' && (
                             <div className="space-y-8">
                                <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-8">
                                   <div className="flex items-center gap-4 text-white/20">
                                      <Plus className="w-4 h-4" />
                                      <h4 className="text-[11px] font-black uppercase text-white tracking-widest">Neural File Assets</h4>
                                   </div>
                                   <div className="space-y-6">
                                      <div className="p-10 border-2 border-dashed border-white/5 rounded-[32px] flex flex-col items-center justify-center gap-4 hover:border-white/10 transition-all group cursor-pointer">
                                         <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center group-hover:scale-110 transition-all">
                                            <Download className="w-6 h-6 text-white/20" />
                                         </div>
                                         <div className="text-center">
                                            <div className="text-[10px] font-black text-white uppercase tracking-widest">Upload Local Asset</div>
                                            <div className="text-[9px] text-white/20 font-bold uppercase mt-1">Images, Gifs or JSON archives</div>
                                         </div>
                                      </div>
                                      <div className="grid grid-cols-1 gap-3">
                                         <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] px-1">Remote Asset URL</label>
                                         <div className="flex gap-4">
                                            <input type="text" placeholder="https://..." className="flex-1 bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/10" id="asset-url-input" />
                                            <button onClick={() => {
                                               const url = document.getElementById('asset-url-input').value;
                                               if (url) {
                                                  setEmbed({...embed, files: [...embed.files, url]});
                                                  document.getElementById('asset-url-input').value = '';
                                               }
                                            }} className="px-8 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-zinc-200">Attach</button>
                                         </div>
                                      </div>
                                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                         {embed.files.map((f, i) => (
                                            <div key={i} className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl relative group overflow-hidden">
                                               <button onClick={() => {
                                                  const nf = [...embed.files]; nf.splice(i, 1); setEmbed({...embed, files: nf});
                                               }} className="absolute top-2 right-2 z-20 p-1.5 bg-black/60 rounded-lg text-white/40 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                                                  <Trash2 className="w-3 h-3" />
                                               </button>
                                               <img src={f} className="w-full h-32 object-cover rounded-xl opacity-60 group-hover:opacity-100 transition-all" />
                                            </div>
                                         ))}
                                      </div>
                                   </div>
                                </div>

                                <div 
                                   onClick={() => setEmbed({...embed, isV2: !embed.isV2})}
                                   className={'p-10 rounded-[32px] border transition-all cursor-pointer ' + (embed.isV2 ? 'bg-fuchsia-500/5 border-fuchsia-500/20 shadow-2xl' : 'bg-white/[0.01] border-white/5 hover:bg-white/[0.02]')}
                                >
                                   <div className="flex justify-between items-center gap-10">
                                      <div className="space-y-2">
                                         <h4 className={'text-[12px] font-black uppercase tracking-[0.2em] transition-colors ' + (embed.isV2 ? 'text-white' : 'text-white/40')}>V2 High-Fidelity Engine (CV2)</h4>
                                         <p className="text-[10px] text-white/20 font-bold leading-relaxed uppercase tracking-widest max-w-sm mt-2">Experimental Section containers for modern UI.</p>
                                      </div>
                                      <div className={'w-14 h-7 rounded-full relative transition-all shadow-xl ' + (embed.isV2 ? 'bg-fuchsia-500' : 'bg-white/10')}>
                                         <div className={'absolute top-1 w-5 h-5 rounded-full transition-all ' + (embed.isV2 ? 'left-8 bg-white shadow-lg' : 'left-1 bg-white/40')} />
                                      </div>
                                   </div>
                                </div>
                             </div>
                          )}

                          {activeTab === 'JSON' && (
                             <div className="space-y-6 h-full">
                                <div className="flex justify-between items-center px-1">
                                   <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Raw Manifest Data</label>
                                   <button onClick={() => {
                                      navigator.clipboard.writeText(JSON.stringify(embed, null, 2));
                                      setStatusMsg({ text: 'Manifest copied to neural chip', type: 'success' });
                                   }} className="text-[9px] font-black text-white/40 hover:text-white uppercase tracking-widest transition-all flex items-center gap-2">
                                      <Copy className="w-3 h-3" /> Copy Raw
                                   </button>
                                </div>
                                <textarea 
                                   className="w-full bg-black/40 border border-white/5 rounded-[32px] p-8 text-[12px] font-mono text-fuchsia-400 outline-none focus:border-fuchsia-500/30 transition-all min-h-[500px] leading-relaxed custom-scrollbar shadow-inner"
                                   value={JSON.stringify(embed, null, 2)}
                                   onChange={(e) => {
                                      try {
                                         const parsed = JSON.parse(e.target.value);
                                         setEmbed(parsed);
                                      } catch (err) {}
                                   }}
                                />
                             </div>
                          )}
                       
                    
                 

                        </motion.div>
                     </AnimatePresence>
                  </div>
               </motion.section>
            </div>

        {/* SIDEBAR: ARCHIVES, PREVIEW & DISPATCH */}
        <div className="space-y-10">
            <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-8 backdrop-blur-sm shadow-2xl overflow-hidden relative">
               <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-white/20">
                     <Copy className="w-4 h-4" />
                     <span className="text-[10px] font-black uppercase tracking-[0.4em]">Archived Protocols</span>
                  </div>
               </div>

               <div className="grid grid-cols-1 gap-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {savedEmbeds.map((e, i) => (
                     <div key={i} className="group/item flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-all">
                        <div className="space-y-1 cursor-pointer flex-1" onClick={() => loadEmbed(e.data)}>
                           <div className="text-[11px] font-black text-white uppercase tracking-wider">{e.name}</div>
                           <div className="text-[9px] font-mono text-white/20 tracking-widest">{"{"}{e.tag}{"}"}</div>
                        </div>
                        <button onClick={() => deleteEmbed(e.tag)} className="p-2 text-white/5 hover:text-red-500 opacity-0 group-hover/item:opacity-100 transition-all">
                           <Trash2 className="w-3.5 h-3.5" />
                        </button>
                     </div>
                  ))}
               </div>
            </div>
           <motion.section variants={item} className="bg-gradient-to-br from-fuchsia-500/10 to-pink-500/10 border border-fuchsia-500/20 p-8 rounded-[32px] space-y-6">
              <div className="flex items-center gap-3 px-1">
                 <Send className="w-4 h-4 text-fuchsia-400" />
                 <span className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em]">Deployment Status</span>
              </div>
              
              <button 
                onClick={handleDispatch}
                disabled={!selectedChannel || isSending}
                className={`w-full py-5 rounded-2xl flex items-center justify-center gap-3 text-[11px] font-black uppercase tracking-[0.3em] transition-all shadow-2xl ${selectedChannel ? 'bg-white text-black hover:bg-zinc-200' : 'bg-white/5 text-white/10 border border-white/5 cursor-not-allowed'}`}
              >
                 {isSending ? <Sparkles className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                 {isSending ? "Syncing..." : "Initiate Dispatch"}
              </button>

              <AnimatePresence>
                 {statusMsg.text && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`text-[10px] font-black uppercase tracking-widest text-center ${statusMsg.type === 'error' ? 'text-red-500' : statusMsg.type === 'success' ? 'text-emerald-500' : 'text-fuchsia-400'}`}
                    >
                       {statusMsg.text}
                    </motion.div>
                 )}
              </AnimatePresence>
           </motion.section>

           <motion.div variants={item} className="space-y-6">
              <div className="flex items-center gap-3 px-2">
                 <Eye className="w-4 h-4 text-white/20" />
                 <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Holographic Preview</span>
              </div>

              <div className="bg-[#08090a] rounded-[40px] p-8 border border-white/5 shadow-2xl overflow-hidden relative group">
                 <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-all pointer-events-none" />
                 <div className="space-y-6 relative z-10">


                          {embed.description && (
                             <p className="text-[14px] text-[#dbdee1] font-medium leading-relaxed whitespace-pre-wrap selection:bg-white/10">{embed.description}</p>
                          )}

                          {embed.fields.length > 0 && (
                             <div className="grid grid-cols-12 gap-y-5 gap-x-4 pt-3">
                                {embed.fields.map((f, i) => (
                                   <div key={i} className={`${f.inline ? 'col-span-4' : 'col-span-12'} space-y-1.5`}>
                                      <div className="text-[14px] font-bold text-white tracking-tight">{f.name || '\u200b'}</div>
                                      <div className="text-[14px] text-[#dbdee1] font-medium whitespace-pre-wrap leading-relaxed">{f.value || '\u200b'}</div>
                                   </div>
                                ))}
                             </div>
                          )}

                          {embed.image.url && (
                             <div className="mt-4 rounded-[12px] overflow-hidden border border-white/5 shadow-2xl bg-black/20">
                                <img src={embed.image.url} className="w-full object-cover max-h-[400px] hover:scale-[1.02] transition-transform duration-700" alt="" />
                             </div>
                          )}

                          {embed.thumbnail.url && (
                             <div className="absolute top-5 right-5 w-20 h-20 rounded-[12px] overflow-hidden border border-white/5 shadow-2xl shrink-0 group-hover/embed:rotate-1 transition-transform duration-700">
                                <img src={embed.thumbnail.url} className="w-full h-full object-cover" alt="" />
                             </div>
                          )}

                          {(embed.footer.text || embed.timestamp) && (
                             <div className="flex items-center gap-3 pt-3 border-t border-white/[0.03]">
                                {embed.footer.icon_url && <img src={embed.footer.icon_url} className="w-5 h-5 rounded-full object-cover grayscale opacity-50" alt="" />}
                                <div className="text-[11px] text-white/20 font-black uppercase tracking-widest flex items-center gap-2">
                                   {embed.footer.text}
                                   {embed.footer.text && embed.timestamp && <span className="w-1 h-1 rounded-full bg-white/10" />}
                                   {embed.timestamp && `Today at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                                </div>
                             </div>
                          )}


                    {/* Interactive Preview Items */}
                    <div className="space-y-3 max-w-[520px]">
                       {embed.selectMenus.map((m, i) => (
                          <div key={i} className="bg-[#2b2d31] border border-black/20 rounded-[4px] p-3 flex justify-between items-center text-[#dbdee1] text-[14px] select-none hover:bg-[#35373c] transition-all cursor-pointer group shadow-sm border-b-[2px]">
                             <span className="font-medium">{m.placeholder}</span>
                             <ChevronRight className="w-4 h-4 opacity-20 group-hover:rotate-90 group-hover:opacity-60 transition-all" />
                          </div>
                       ))}
                       {embed.buttons.length > 0 && (
                          <div className="flex flex-wrap gap-2 pt-1">
                             {embed.buttons.map((b, i) => (
                                <div key={i} className={`px-4 py-2 rounded-[3px] text-white font-bold text-[14px] flex items-center gap-2 shadow-lg transition-all hover:brightness-125 active:scale-[0.98] cursor-pointer select-none ${
                                   b.style === 'PRIMARY' ? 'bg-[#5865F2]' : 
                                   b.style === 'SECONDARY' ? 'bg-[#4e5058]' :
                                   b.style === 'SUCCESS' ? 'bg-[#248046]' :
                                   b.style === 'DANGER' ? 'bg-[#da373c]' : 'bg-[#4e5058]'
                                }`}>
                                   {b.style === 'LINK' && <ExternalLink className="w-3.5 h-3.5 opacity-60" />}
                                   {b.emoji && (
                                      <span className="shrink-0">
                                         {b.emoji.match(/<a?:\w+:\d+>/) ? (
                                            <img 
                                               src={`https://cdn.discordapp.com/emojis/${b.emoji.match(/\d+/)?.[0]}.${b.emoji.startsWith('<a:') ? 'gif' : 'webp'}?size=44`} 
                                               className="w-4 h-4 object-contain" 
                                               alt="" 
                                            />
                                         ) : b.emoji}
                                      </span>
                                   )}
                                   {b.label}
                                </div>
                             ))}
                          </div>
                       )}
                    </div>
                 </div>
              </div>
            </motion.div>

           <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-6 backdrop-blur-sm shadow-2xl">
              <div className="flex items-center gap-4 text-white/20">
                 <Sparkles className="w-4 h-4" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Composer Telemetry</span>
              </div>
              <div className="grid grid-cols-2 gap-6">
                 <div className="p-5 bg-white/[0.02] border border-white/5 rounded-[24px] space-y-2">
                    <div className="text-[10px] font-black text-white/10 uppercase tracking-widest">Payload Weight</div>
                    <div className="text-[14px] font-black text-white uppercase tracking-tighter">~0.85 KB</div>
                 </div>
                 <div className="p-5 bg-white/[0.02] border border-white/5 rounded-[24px] space-y-2">
                    <div className="text-[10px] font-black text-white/10 uppercase tracking-widest">Components</div>
                    <div className="text-[14px] font-black text-white uppercase tracking-tighter">{embed.fields.length + embed.buttons.length + embed.selectMenus.length} / 50</div>
                 </div>
              </div>
           </div>
        </div>
      </motion.div>

      {/* Persistence Notifications */}
      <AnimatePresence>
         {statusMsg.text && (
            <motion.div 
               initial={{ opacity: 0, scale: 0.95 }} 
               animate={{ opacity: 1, scale: 1 }} 
               exit={{ opacity: 0, scale: 0.95 }}
               className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[2000]"
            >
               <div className={`px-10 py-5 rounded-3xl border backdrop-blur-3xl shadow-[0_40px_80px_rgba(0,0,0,0.4)] flex items-center gap-5 ${
                  statusMsg.type === 'error' ? 'bg-red-500/10 border-red-500/20 text-red-500' : 
                  statusMsg.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' : 
                  'bg-white/5 border-white/10 text-white'
               }`}>
                  {statusMsg.type === 'success' ? <ShieldCheck className="w-5 h-5 shadow-emerald-500" /> : <Info className="w-5 h-5" />}
                  <span className="text-[11px] font-black uppercase tracking-[0.2em]">{statusMsg.text}</span>
               </div>
            </motion.div>
         )}
      </AnimatePresence>
      <AnimatePresence>
         {saveModalOpen && (
            <div className="fixed inset-0 z-[3000] flex items-center justify-center p-6">
               <motion.div 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  onClick={() => setSaveModalOpen(false)}
                  className="absolute inset-0 bg-black/80 backdrop-blur-xl"
               />
               <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 20 }} 
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  className="relative w-full max-w-lg bg-[#0a0a0a] border border-white/10 rounded-[40px] p-12 space-y-10 shadow-[0_50px_100px_rgba(0,0,0,0.8)]"
               >
                  <div className="space-y-2">
                     <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Archive Protocol</h3>
                     <p className="text-[11px] text-white/30 font-bold uppercase tracking-[0.2em]">Secure this configuration into the neural vault.</p>
                  </div>

                  <div className="space-y-8">
                     <div className="space-y-3">
                        <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] px-1">Display Name</label>
                        <input 
                           type="text" value={saveName} onChange={(e) => setSaveName(e.target.value)}
                           className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-bold tracking-tight"
                           placeholder="e.g. Welcome Message V2"
                        />
                     </div>
                     <div className="space-y-3">
                        <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] px-1">Neural Tag (Placeholder)</label>
                        <div className="relative">
                           <div className="absolute left-5 top-1/2 -translate-y-1/2 text-white/20 font-mono">{"{"}</div>
                           <input 
                              type="text" value={saveTag} onChange={(e) => setSaveTag(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                              className="w-full bg-white/[0.02] border border-white/5 p-5 pl-10 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-mono text-[13px]"
                              placeholder="welcome_embed"
                           />
                           <div className="absolute right-5 top-1/2 -translate-y-1/2 text-white/20 font-mono">{"}"}</div>
                        </div>
                     </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                     <button 
                        onClick={() => setSaveModalOpen(false)}
                        className="flex-1 py-5 rounded-2xl border border-white/5 text-[10px] font-black text-white/20 uppercase tracking-[0.3em] hover:bg-white/5 transition-all"
                     >
                        Abort
                     </button>
                     <button 
                        onClick={saveEmbed}
                        className="flex-[2] py-5 rounded-2xl bg-white text-black text-[10px] font-black uppercase tracking-[0.3em] hover:bg-zinc-200 transition-all shadow-2xl"
                     >
                        Confirm Archival
                     </button>
                  </div>
               </motion.div>
            </div>
         )}
      </AnimatePresence>

      {/* Action Builder Modal */}
      <AnimatePresence>
         {actionModalOpen && (
            <div className="fixed inset-0 z-[3001] flex items-center justify-center p-6">
               <motion.div 
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  onClick={() => setActionModalOpen(false)}
                  className="absolute inset-0 bg-black/90 backdrop-blur-2xl"
               />
               <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 20 }} 
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 20 }}
                  className="relative w-full max-w-4xl bg-[#0a0a0a] border border-white/10 rounded-[48px] p-12 space-y-10 shadow-2xl flex flex-col max-h-[90vh]"
               >
                  <div className="flex justify-between items-start">
                     <div className="space-y-2">
                        <div className="flex items-center gap-3">
                           <Zap className="w-5 h-5 text-fuchsia-500" />
                           <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Action Flow Matrix</h3>
                        </div>
                        <p className="text-[11px] text-white/30 font-bold uppercase tracking-[0.2em]">Configuring logic for <span className="text-white">{"{"}{editingComponent?.custom_id || editingComponent?.customId}{"}"}</span></p>
                     </div>
                     <button onClick={() => setActionModalOpen(false)} className="p-4 hover:bg-white/5 rounded-full transition-all text-white/20 hover:text-white">
                        <X className="w-6 h-6" />
                     </button>
                  </div>

                  <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar space-y-8">
                     {componentLogic.map((action, idx) => (
                        <div key={idx} className="relative group/action">
                           <div className="absolute -left-6 top-1/2 -translate-y-1/2 w-1 h-12 bg-white/5 group-hover/action:bg-fuchsia-500/40 transition-all rounded-full" />
                           <div className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-6 relative">
                              <div className="flex justify-between items-center">
                                 <div className="flex items-center gap-4">
                                    <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[10px] font-black text-white/20">{idx + 1}</div>
                                    <select 
                                       value={action.type}
                                       onChange={(e) => {
                                          const nl = [...componentLogic]; nl[idx].type = e.target.value; setComponentLogic(nl);
                                       }}
                                       className="bg-transparent text-white font-black uppercase tracking-widest text-[11px] outline-none border-b border-white/10 pb-1 focus:border-fuchsia-500 transition-all cursor-pointer"
                                    >
                                       <option value="SendMessage">Direct Message</option>
                                       <option value="ShowEmbed">Invoke Archive</option>
                                       <option value="AddRole">Assign Role</option>
                                       <option value="RemoveRole">Revoke Role</option>
                                       <option value="ToggleRole">Switch Role</option>
                                       <option value="Wait">Temporal Delay</option>
                                       <option value="Check">Condition Check</option>
                                    </select>
                                 </div>
                                 <button onClick={() => setComponentLogic(componentLogic.filter((_, i) => i !== idx))} className="p-2 text-white/5 hover:text-red-500 transition-all">
                                    <Trash2 className="w-4 h-4" />
                                 </button>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                 {(action.type === 'AddRole' || action.type === 'RemoveRole' || action.type === 'ToggleRole' || action.type === 'Check') && (
                                    <div className="space-y-3">
                                       <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Target Protocol (Role)</label>
                                       <select 
                                          value={action.roleId}
                                          onChange={(e) => {
                                             const nl = [...componentLogic]; nl[idx].roleId = e.target.value; setComponentLogic(nl);
                                          }}
                                          className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/20 transition-all font-bold"
                                       >
                                          <option value="">Select Role...</option>
                                          {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                                       </select>
                                    </div>
                                 )}

                                 {action.type === 'SendMessage' && (
                                    <div className="space-y-3 md:col-span-2">
                                       <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Neural Output (Text)</label>
                                       <textarea 
                                          value={action.content}
                                          onChange={(e) => {
                                             const nl = [...componentLogic]; nl[idx].content = e.target.value; setComponentLogic(nl);
                                          }}
                                          className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-medium min-h-[100px]"
                                          placeholder="Enter response text... Supports {user}, {server} etc."
                                       />
                                    </div>
                                 )}

                                 {action.type === 'ShowEmbed' && (
                                    <div className="space-y-3">
                                       <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Neural Tag (Archive)</label>
                                       <select 
                                          value={action.embedId}
                                          onChange={(e) => {
                                             const nl = [...componentLogic]; nl[idx].embedId = e.target.value; setComponentLogic(nl);
                                          }}
                                          className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/20 transition-all font-bold"
                                       >
                                          <option value="">Select Archive...</option>
                                          {savedEmbeds.map(e => <option key={e.tag} value={e.tag}>{e.name} ({"{"}{e.tag}{"}"})</option>)}
                                       </select>
                                    </div>
                                 )}

                                 {action.type === 'Wait' && (
                                    <div className="space-y-3">
                                       <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Delay Vector (Seconds)</label>
                                       <input 
                                          type="number" value={action.seconds}
                                          onChange={(e) => {
                                             const nl = [...componentLogic]; nl[idx].seconds = parseInt(e.target.value); setComponentLogic(nl);
                                          }}
                                          className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-white outline-none focus:border-white/20 transition-all font-bold"
                                       />
                                    </div>
                                 )}

                                 <div className="flex items-center gap-3">
                                    <div 
                                       onClick={() => {
                                          const nl = [...componentLogic]; nl[idx].ephemeral = !nl[idx].ephemeral; setComponentLogic(nl);
                                       }}
                                       className={`w-12 h-6 rounded-full relative transition-all cursor-pointer ${action.ephemeral ? 'bg-fuchsia-500' : 'bg-white/10'}`}
                                    >
                                       <div className={`absolute top-1 w-4 h-4 rounded-full transition-all ${action.ephemeral ? 'left-7 bg-white' : 'left-1 bg-white/40'}`} />
                                    </div>
                                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Discrete Dispatch (Ephemeral)</span>
                                 </div>
                              </div>
                           </div>
                           {idx < componentLogic.length - 1 && (
                              <div className="flex justify-center py-2 opacity-20">
                                 <ArrowDown className="w-4 h-4" />
                              </div>
                           )}
                        </div>
                     ))}

                     <button 
                        onClick={() => setComponentLogic([...componentLogic, { type: 'SendMessage', content: '', ephemeral: true }])}
                        className="w-full py-8 border-2 border-dashed border-white/5 rounded-[32px] text-[10px] font-black uppercase text-white/20 tracking-[0.4em] hover:border-white/10 hover:text-white/40 transition-all flex items-center justify-center gap-4"
                     >
                        <Plus className="w-5 h-5" /> Append Protocol Action
                     </button>
                  </div>

                  <div className="flex gap-4 pt-6 border-t border-white/5">
                     <button 
                        onClick={() => setActionModalOpen(false)}
                        className="flex-1 py-5 rounded-2xl border border-white/5 text-[10px] font-black text-white/20 uppercase tracking-[0.3em] hover:bg-white/5 transition-all"
                     >
                        Discard
                     </button>
                     <button 
                        onClick={saveActionLogic}
                        className="flex-[2] py-5 rounded-2xl bg-fuchsia-500 text-white text-[10px] font-black uppercase tracking-[0.3em] hover:bg-fuchsia-600 transition-all shadow-2xl shadow-fuchsia-500/20"
                     >
                        Synchronize Flow
                     </button>
                  </div>
               </motion.div>
            </div>
         )}
      </AnimatePresence>
    </main>
  );
}
