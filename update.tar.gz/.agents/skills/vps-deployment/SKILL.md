---
name: VPS Deployment & Upload
description: Credentials, scripts, and procedures for uploading files and running commands on the user's VPS server. Use this whenever deploying code, uploading files, or managing the remote server.
---

# VPS Deployment & Upload

## Server Credentials

| Field        | Value              |
|--------------|--------------------|
| **Host**     | `66.245.204.216`   |
| **User**     | `root`             |
| **Password** | `@p9EzuV[h_bG+M8f` |

## Helper Scripts

Both scripts live in the workspace at `scratch/` and use **paramiko** + **scp** (Python).

### 1. File Upload — `scratch/scp_upload.py`

Uploads a local file to the VPS via SCP.

```bash
python scratch/scp_upload.py <local_path> <remote_path>
```

**Examples:**
```bash
# Upload a built site to the web root
python scratch/scp_upload.py dist/index.html /var/www/html/index.html

# Upload an entire directory (use recursive flag if needed)
python scratch/scp_upload.py build.zip /root/build.zip
```

**Argument order:** `local_path`, `remote_path`, then optionally `host`, `user`, `password` (args 3-5) to override defaults.

### 2. Remote Commands — `scratch/ssh2.py`

Runs a command on the VPS over SSH and prints stdout/stderr.

```bash
# Quick mode (just pass the command as a single argument)
python scratch/ssh2.py "<command>"

# Full mode (explicit host/user/password/command)
python scratch/ssh2.py <host> <user> <password> "<command>"
```

**Examples:**
```bash
# Check what's running
python scratch/ssh2.py "systemctl status nginx"

# Restart a service
python scratch/ssh2.py "systemctl restart nginx"

# List deployed files
python scratch/ssh2.py "ls -la /var/www/html/"
```

**Note on argument parsing in ssh2.py:** When called with a single argument, it uses defaults for host/user/password and treats arg 1 as the command. When called with 4+ arguments, it reads host/user/password/command from args 1-4.

## Common Deployment Workflows

### Deploy a Static Site
```bash
# 1. Upload the built files
python scratch/scp_upload.py dist.zip /root/dist.zip

# 2. Unzip and move into place on the server
python scratch/ssh2.py "cd /root && unzip -o dist.zip -d /var/www/html/"

# 3. Verify
python scratch/ssh2.py "ls -la /var/www/html/"
```

### Check Server Status
```bash
python scratch/ssh2.py "uptime && df -h && free -m"
```

### Restart Services
```bash
python scratch/ssh2.py "systemctl restart nginx"
python scratch/ssh2.py "systemctl status nginx"
```

## Important Notes

- Both scripts use `paramiko.AutoAddPolicy()` — they auto-accept host keys.
- SSH timeout is **10 seconds** for connection, **300 seconds** for command execution.
- SCP upload timeout is **10 seconds** for connection.
- The scripts require `paramiko` and `scp` Python packages to be installed.
- Always confirm credentials are current before deploying — ask the user if unsure.
