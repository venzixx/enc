# Project Rules

## Communication
- Always address the user as **"Sidharth"** at the start of every message.
