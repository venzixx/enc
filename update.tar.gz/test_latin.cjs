var t = require("google-translate-api-x");
console.log("la in languages:", t.languages.la);

t("Hello world", { to: "la" }).then(res => {
    console.log("OK - Translation:", res.text);
    console.log("From:", res.from.language.iso);
}).catch(err => {
    console.log("FAILED - Error:", err.message);
});
