"use client";

import React, { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { 
    LayoutGrid, 
    Globe, 
    Link2, 
    Package, 
    Megaphone, 
    ArrowUpRight, 
    MapPin
} from 'lucide-react';
import Navbar from '@/components/Navbar';

const InstagramIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
        <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"></path>
        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
    </svg>
);

const TwitterIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
        <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path>
    </svg>
);

const LinkedinIcon = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
        <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"></path>
        <circle cx="4" cy="4" r="2"></circle>
    </svg>
);

export default function LandingPage() {
    return (
        <div className="min-h-screen bg-[#030303] text-[#ebebeb] overflow-x-hidden selection:bg-blue-600 selection:text-white relative z-20">
            <style dangerouslySetInnerHTML={{ __html: `
                @font-face {
                    font-family: 'Satoshi';
                    src: url('https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/uploads/4aed2f49-a476-436f-bae8-f31aa18f46fa/1767920861040-60c1c779/Satoshi-Variable.woff2') format('woff2');
                    font-weight: 300 900;
                    font-display: swap;
                    font-style: normal;
                }

                :root {
                    --font-satoshi: 'Satoshi', 'Inter', sans-serif;
                }

                .satoshi-font {
                    font-family: var(--font-satoshi);
                }

                .glass-nav {
                    background: rgba(10, 10, 15, 0.8);
                    backdrop-filter: blur(12px);
                    border: 1px solid rgba(255, 255, 255, 0.06);
                }

                .hero-text {
                    font-size: 16vw;
                    line-height: 0.9;
                    letter-spacing: -0.05em;
                }

                @media (min-width: 640px) {
                    .hero-text {
                        font-size: 13vw;
                    }
                }

                @keyframes float {
                    0%, 100 { transform: translateY(0); }
                    50% { transform: translateY(-8px); }
                }

                .animate-float {
                    animation: float 5s ease-in-out infinite;
                }

                /* Hide scrollbar for Chrome, Safari and Opera */
                .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                }
                /* Hide scrollbar for IE, Edge and Firefox */
                .scrollbar-hide {
                    -ms-overflow-style: none;  /* IE and Edge */
                    scrollbar-width: none;  /* Firefox */
                }
            `}} />

            {/* Hero Section */}
            <header className="relative h-screen w-full flex flex-col items-center justify-center">
                <div className="absolute inset-0 z-0 pointer-events-none">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#0f172a_0%,_#030303_70%)] opacity-30"></div>
                </div>

                <div className="relative z-10 select-none">
                    <h1 className="hero-text font-black text-center satoshi-font uppercase tracking-tighter bg-gradient-to-b from-white via-slate-300 to-blue-400 bg-clip-text text-transparent">
                        /enc
                    </h1>
                </div>

                {/* Bottom UI Overlays */}
                <div className="absolute bottom-28 md:bottom-12 left-8 md:left-12 flex items-center gap-5 group">
                    <p className="text-xs md:text-sm font-medium leading-tight text-[#888888] group-hover:text-white transition-colors satoshi-font">
                        Securing the future,<br />today.
                    </p>
                </div>

                <div className="absolute bottom-28 md:bottom-12 right-8 md:right-12 text-right satoshi-font">
                    <a href="mailto:support@encl.asia" className="text-white font-medium hover:text-blue-400 transition-colors border-b border-white hover:border-blue-400 pb-1 text-sm tracking-wide">
                        support@encl.asia
                    </a>
                </div>
            </header>

            {/* Benefits Section */}
            <section className="py-32 px-6 md:px-12 max-w-7xl mx-auto satoshi-font">
                <div className="flex items-center gap-3 mb-10">
                    <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                    <span className="text-[10px] font-bold tracking-[0.3em] text-[#666] uppercase">Why configure slow when you can move fast?</span>
                </div>

                <h2 className="text-4xl md:text-7xl font-medium leading-[1.05] tracking-tight text-white max-w-5xl mb-24">
                    Clean, customizable settings that help you <span className="text-[#666]">protect your server</span> and grow your community.
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Benefit Card 1 */}
                    <div className="bg-[#0b0b0f] rounded-[2.5rem] p-12 min-h-[420px] md:min-h-[520px] flex flex-col justify-between relative overflow-hidden group hover:bg-[#0e0e15] transition-all duration-500 border border-white/[0.02]">
                        <div className="absolute top-10 right-10 bg-[#12121a] text-[10px] font-bold px-4 py-2 rounded-full uppercase tracking-widest text-[#888] border border-white/5">
                            Sovereign Control
                        </div>
                        
                        <div className="mt-auto">
                            <h3 className="text-5xl md:text-7xl font-semibold tracking-tighter mb-2 text-white">
                                Start faster.
                            </h3>
                            <h3 className="text-5xl md:text-7xl font-semibold tracking-tighter text-[#334155] group-hover:text-[#475569] transition-colors">
                                Protect sooner.
                            </h3>
                        </div>
                    </div>

                    {/* Benefit Card 2 */}
                    <div className="bg-gradient-to-br from-[#020617] via-[#0f172a] to-[#1e293b] rounded-[2.5rem] p-6 md:p-12 min-h-[420px] md:min-h-[520px] flex items-center justify-center relative overflow-hidden group border border-white/[0.04]">
                        {/* Browser Mockup */}
                        <div className="w-full max-w-md bg-[#050508] rounded-2xl shadow-2xl overflow-hidden transform group-hover:scale-[1.03] transition-transform duration-700 ease-out border border-white/10">
                            <div className="bg-[#0a0a0f] px-4 py-3 border-b border-white/[0.06] flex items-center gap-2">
                                <div className="w-2.5 h-2.5 rounded-full bg-blue-500/40"></div>
                                <div className="w-2.5 h-2.5 rounded-full bg-slate-500/40"></div>
                                <div className="w-2.5 h-2.5 rounded-full bg-white/20"></div>
                                <div className="ml-4 h-3 w-36 bg-white/5 rounded-full"></div>
                            </div>
                            <div className="aspect-[4/3] bg-black relative overflow-hidden">
                                <img src="/dashboard_preview.png" alt="Dashboard preview" className="w-full h-full object-cover opacity-80" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                                <div className="absolute bottom-6 left-6 text-white z-10">
                                    <div className="text-[10px] font-bold uppercase tracking-widest mb-1 text-blue-400">Enc Nexus</div>
                                    <div className="text-lg font-bold">Administrative Dashboard</div>
                                </div>
                            </div>
                        </div>
                        <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    </div>
                </div>
            </section>

            {/* Selected Features */}
            <section id="features" className="py-32 px-6 md:px-12 max-w-7xl mx-auto satoshi-font">
                <div className="flex justify-between items-end mb-20 border-b border-[#222] pb-10">
                    <h2 className="text-xs font-bold tracking-[0.4em] uppercase text-blue-400">Selected Modules</h2>
                    <span className="hidden md:block text-[#444] text-xs font-medium uppercase tracking-widest">Volume 01 &mdash; 2026</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-32">
                    
                    {/* Feature 1 */}
                    <article className="group cursor-pointer">
                        <div className="aspect-[4/3] overflow-hidden bg-[#09090d] rounded-sm relative border border-white/[0.02]">
                            <img src="/automod_feature.png" alt="Automod" className="w-full h-full object-cover opacity-50 group-hover:opacity-85 group-hover:scale-105 transition-all duration-700" />
                        </div>
                        <div className="mt-8 flex justify-between items-start">
                            <div>
                                <h3 className="text-3xl font-bold tracking-tight mb-2 group-hover:text-blue-400 transition-colors uppercase">AUTOMOD</h3>
                                <p className="text-[#666] text-[10px] font-bold uppercase tracking-[0.2em]">Anti-Link / Whitelist / Protection</p>
                            </div>
                            <div className="p-3 rounded-full border border-[#222] group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent transition-all duration-300">
                                <ArrowUpRight className="w-6 h-6" />
                            </div>
                        </div>
                    </article>

                    {/* Feature 2 */}
                    <article className="group cursor-pointer md:mt-24">
                        <div className="aspect-[4/3] overflow-hidden bg-[#09090d] rounded-sm relative border border-white/[0.02]">
                            <img src="/antinuke_feature.png" alt="Antinuke" className="w-full h-full object-cover opacity-50 group-hover:opacity-85 group-hover:scale-105 transition-all duration-700" />
                        </div>
                        <div className="mt-8 flex justify-between items-start">
                            <div>
                                <h3 className="text-3xl font-bold tracking-tight mb-2 group-hover:text-blue-400 transition-colors uppercase">ANTINUKE</h3>
                                <p className="text-[#666] text-[10px] font-bold uppercase tracking-[0.2em]">Bot Blocker / Dev Lock / Log Alerts</p>
                            </div>
                            <div className="p-3 rounded-full border border-[#222] group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent transition-all duration-300">
                                <ArrowUpRight className="w-6 h-6" />
                            </div>
                        </div>
                    </article>

                    {/* Feature 3 */}
                    <article className="group cursor-pointer">
                        <div className="aspect-[4/3] overflow-hidden bg-[#09090d] rounded-sm relative border border-white/[0.02]">
                            <img src="/utility_feature.png" alt="Utility" className="w-full h-full object-cover opacity-50 group-hover:opacity-85 group-hover:scale-105 transition-all duration-700" />
                        </div>
                        <div className="mt-8 flex justify-between items-start">
                            <div>
                                <h3 className="text-3xl font-bold tracking-tight mb-2 group-hover:text-blue-400 transition-colors uppercase">UTILITY</h3>
                                <p className="text-[#666] text-[10px] font-bold uppercase tracking-[0.2em]">Role Management / Icons / Countdown Timers</p>
                            </div>
                            <div className="p-3 rounded-full border border-[#222] group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent transition-all duration-300">
                                <ArrowUpRight className="w-6 h-6" />
                            </div>
                        </div>
                    </article>

                    {/* Feature 4 */}
                    <article className="group cursor-pointer md:mt-24">
                        <div className="aspect-[4/3] overflow-hidden bg-[#09090d] rounded-sm relative border border-white/[0.02]">
                            <img src="/leveling_feature.png" alt="Leveling" className="w-full h-full object-cover opacity-50 group-hover:opacity-85 group-hover:scale-105 transition-all duration-700" />
                        </div>
                        <div className="mt-8 flex justify-between items-start">
                            <div>
                                <h3 className="text-3xl font-bold tracking-tight mb-2 group-hover:text-blue-400 transition-colors uppercase">ENGAGEMENT</h3>
                                <p className="text-[#666] text-[10px] font-bold uppercase tracking-[0.2em]">Leveling / Custom Rank Cards / Streak Tiers</p>
                            </div>
                            <div className="p-3 rounded-full border border-[#222] group-hover:bg-blue-600 group-hover:text-white group-hover:border-transparent transition-all duration-300">
                                <ArrowUpRight className="w-6 h-6" />
                            </div>
                        </div>
                    </article>

                </div>
            </section>

            {/* CTA / Footer Section */}
            <footer id="contact" className="relative pt-48 pb-32 px-6 md:px-12 border-t border-[#12121a] satoshi-font">
                <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-end gap-16">
                    
                    <div className="flex-1">
                        <h2 className="text-[14vw] md:text-[10vw] leading-[0.85] font-black tracking-tighter text-white mb-12 select-none uppercase">
                            INVITE<br />NOW.
                        </h2>
                        <div className="flex flex-col gap-6">
                            <a href="https://discord.com/oauth2/authorize?client_id=1493482964246593556&permissions=8&scope=bot%20applications.commands" target="_blank" rel="noopener noreferrer" className="text-3xl md:text-4xl font-semibold hover:text-blue-400 transition-all w-fit">
                                Invite Bot
                            </a>
                            <p className="text-[#666] flex items-center gap-2">
                                <MapPin className="w-4 h-4" />
                                Powering discord servers globally.
                            </p>
                        </div>
                    </div>

                    <div className="flex gap-4 md:mb-6">
                        <a href="#" className="w-14 h-14 border border-[#222] rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all hover:-translate-y-2">
                            <InstagramIcon />
                        </a>
                        <a href="#" className="w-14 h-14 border border-[#222] rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all hover:-translate-y-2">
                            <TwitterIcon />
                        </a>
                        <a href="#" className="w-14 h-14 border border-[#222] rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all hover:-translate-y-2">
                            <LinkedinIcon />
                        </a>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto mt-40 pt-10 border-t border-[#111] flex flex-col md:flex-row justify-between text-[#333] text-[10px] font-bold uppercase tracking-widest">
                    <p>&copy; 2026 Enc Bot. All rights reserved.</p>
                    <div className="flex gap-10 mt-6 md:mt-0">
                        <a href="/privacy" className="hover:text-[#666] transition-colors">Privacy Policy</a>
                        <a href="/termsofservice" className="hover:text-[#666] transition-colors">Terms of Service</a>
                    </div>
                </div>
            </footer>

        </div>
    );
}
