"use client";

import React, { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  size: number;
  opacity: number;
  twinkleSpeed: number;
  twinkleDir: number;
  layer: number;
}

export default function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const starsRef = useRef<Star[]>([]);
  const mouseRef = useRef({ x: 0, y: 0, tX: 0, tY: 0 });
  const isMovingRef = useRef(false);
  const rafRef = useRef<number>(0);
  const mouseTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const frameCountRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initStars();
    };

    const initStars = () => {
      const stars: Star[] = [];
      // Distant tiny stars only - as requested
      for (let i = 0; i < 220; i++) {
        stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: 0.4 + Math.random() * 0.4,
          opacity: 0.05 + Math.random() * 0.1,
          twinkleSpeed: 0.0005 + Math.random() * 0.001,
          twinkleDir: 1,
          layer: 1,
        });
      }
      starsRef.current = stars;
    };

    const handleMouseMove = (e: MouseEvent) => {
      isMovingRef.current = true;
      mouseRef.current.tX = (e.clientX - window.innerWidth / 2) / (window.innerWidth / 2);
      mouseRef.current.tY = (e.clientY - window.innerHeight / 2) / (window.innerHeight / 2);

      if (mouseTimeoutRef.current) clearTimeout(mouseTimeoutRef.current);
      mouseTimeoutRef.current = setTimeout(() => {
        isMovingRef.current = false;
      }, 150);
    };

    const draw = () => {
      if (!ctx || !canvas) return;

      frameCountRef.current++;

      // When idle, only render every 3rd frame (twinkling is slow enough)
      if (!isMovingRef.current && frameCountRef.current % 3 !== 0) {
        rafRef.current = requestAnimationFrame(draw);
        return;
      }

      if (isMovingRef.current) {
        mouseRef.current.x += (mouseRef.current.tX - mouseRef.current.x) * 0.05;
        mouseRef.current.y += (mouseRef.current.tY - mouseRef.current.y) * 0.05;
      }

      ctx.fillStyle = "#050508";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const { x: mX, y: mY } = mouseRef.current;

      // Render stars
      starsRef.current.forEach((star) => {
        // Subtle twinkling
        star.opacity += star.twinkleSpeed * star.twinkleDir;
        if (star.opacity > 0.4 || star.opacity < 0.05) star.twinkleDir *= -1;

        const pFactor = 8; // Consistent gentle parallax
        const sX = star.x + mX * pFactor;
        const sY = star.y + mY * pFactor;

        ctx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
        ctx.beginPath();
        ctx.arc(sX, sY, star.size, 0, Math.PI * 2);
        ctx.fill();
      });

      rafRef.current = requestAnimationFrame(draw);
    };

    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    resize();
    rafRef.current = requestAnimationFrame(draw);

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouseMove);
      if (mouseTimeoutRef.current) clearTimeout(mouseTimeoutRef.current);
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-[-1] pointer-events-none"
      style={{ willChange: "transform", transform: "translateZ(0)" }}
    />
  );
}
