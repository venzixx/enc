"use client";

import React, { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ShieldAlert, Settings2, ExternalLink, Zap,
  Plus, ShieldCheck, Lock, Search, LayoutGrid, Activity,
  ChevronRight, ArrowRight, Server, Database, RefreshCw
} from "lucide-react";
import { motion as m, AnimatePresence } from "framer-motion";
import Starfield from "@/components/Starfield";
import GridBackground from "@/components/GridBackground";
import { getDiscordAsset } from "@/lib/utils";

interface Guild {
  id: string;
  name: string;
  icon: string | null;
  banner: string | null;
  owner: boolean;
  permissions: string;
}

interface DashboardContentProps {
  session: any;
  activeGuilds: Guild[];
  availableGuilds: Guild[];
}

export default function DashboardContent({ session, activeGuilds, availableGuilds }: DashboardContentProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [searchQuery, setSearchQuery] = useState("");

  const handleRefresh = () => {
    startTransition(() => {
      router.refresh();
    });
  };

  const filteredActive = activeGuilds.filter(g => 
    g.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredAvailable = availableGuilds.filter(g => 
    g.name.toLowerCase().includes(searchQuery.toLowerCase())
  ).slice(0, 16);

  return (
    <main className="relative min-h-screen bg-[#050508] text-white font-sans overflow-x-hidden selection:bg-white selection:text-black">
      <Starfield />
      <GridBackground />

      <div className="relative z-10 pt-48 pb-32 px-6 md:px-12">
        <div className="max-w-[1400px] mx-auto space-y-24">
          
          {/* ── PREMIUM HEADER ── */}
          <div className="flex flex-col items-center text-center space-y-8">
            <m.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/[0.03] border border-white/10 shadow-[0_0_50px_rgba(255,255,255,0.02)]"
            >
              <div className="relative">
                <div className="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_15px_white] animate-pulse" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/60">Neural Uplink Authorized</span>
            </m.div>

            <m.h1 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="text-7xl md:text-[9rem] font-black uppercase tracking-tighter leading-[0.75] text-transparent bg-clip-text bg-gradient-to-b from-white via-white to-white/5"
            >
              SERVER SELECT<span className="text-white/10 italic font-medium">.</span>
            </m.h1>

            <m.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="w-full max-w-2xl relative group"
            >
                <div className="absolute inset-0 bg-white/[0.01] blur-2xl rounded-full" />
                <div className="relative flex items-center bg-white/[0.02] border border-white/10 rounded-[2rem] px-8 py-5 transition-all duration-500 focus-within:border-white/30 focus-within:bg-white/[0.04]">
                    <Search className="w-5 h-5 text-white/20" />
                    <input 
                        type="text"
                        placeholder="FILTER ACTIVE NODES..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-transparent border-none outline-none pl-6 text-white placeholder:text-white/10 font-black text-[11px] tracking-[0.3em] uppercase"
                    />
                    <button
                        onClick={handleRefresh}
                        disabled={isPending}
                        className="p-2 rounded-xl text-white/25 hover:text-white hover:bg-white/5 disabled:opacity-50 transition-all duration-300 mr-2 flex items-center justify-center"
                        title="REFRESH NODES"
                    >
                        <RefreshCw className={`w-4 h-4 ${isPending ? 'animate-spin' : ''}`} />
                    </button>
                    <div className="hidden sm:flex items-center gap-4 pl-6 border-l border-white/5">
                        <span className="text-[9px] font-black text-white/20 uppercase tracking-widest whitespace-nowrap">
                            {filteredActive.length + filteredAvailable.length} Total Nodes
                        </span>
                    </div>
                </div>
            </m.div>
          </div>

          {/* ── ACTIVE CONNECTIONS ── */}
          <section className="space-y-10">
              <m.div 
                 initial={{ opacity: 0, x: -20 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 viewport={{ once: true }}
                 transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                 className="flex items-center gap-6"
              >
                 <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-white/40 shadow-inner group/icon">
                     <Activity className="w-5 h-5 group-hover/icon:text-white transition-colors duration-500" />
                 </div>
                 <div className="flex flex-col">
                    <h2 className="text-[12px] font-black text-white uppercase tracking-[0.8em] leading-none">Active Neural Links</h2>
                    <p className="text-[8px] text-white/10 font-bold uppercase tracking-[0.4em] mt-2">Authenticated encrypted channels</p>
                 </div>
                 <div className="h-px flex-1 bg-gradient-to-r from-white/10 via-white/5 to-transparent ml-4" />
              </m.div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               <AnimatePresence mode="popLayout">
                 {filteredActive.map((guild, idx) => (
                    <m.div
                      key={guild.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9, y: 30 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.8, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] }}
                    >
                      <Link 
                        href={`/dashboard/${guild.id}`}
                        className="group relative block h-[320px] rounded-[3.5rem] overflow-hidden border border-white/[0.05] hover:border-white/20 transition-all duration-700 bg-[#0a0a0c] shadow-2xl"
                      >
                        {/* Interactive Glow */}
                        <div className="absolute -inset-1 bg-gradient-to-r from-blue-500/0 via-white/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-2xl pointer-events-none" />

                        {/* Banner Layer */}
                        <div className="absolute inset-0 z-0">
                          {guild.banner ? (
                            <img 
                              src={getDiscordAsset('banner', guild.id, guild.banner, 600) || ""}
                              alt="" 
                              className="w-full h-full object-cover opacity-10 group-hover:opacity-40 transition-all duration-1000 scale-110 group-hover:scale-100 grayscale group-hover:grayscale-0"
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-white/[0.02] to-transparent opacity-40 group-hover:opacity-60 transition-opacity duration-700" />
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-[#050508] via-[#050508]/80 to-transparent" />
                        </div>

                        {/* Content Layer */}
                        <div className="absolute inset-0 z-10 p-10 flex flex-col justify-end gap-8">
                           <div className="flex items-center gap-8">
                              <div className="relative group/avatar">
                                 {guild.icon ? (
                                   <div className="relative">
                                      <div className="absolute -inset-4 bg-white/5 rounded-full blur-2xl opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-700" />
                                      <img 
                                        src={getDiscordAsset('icon', guild.id, guild.icon) || ""}
                                        className="w-24 h-24 rounded-[2.5rem] border border-white/10 shadow-2xl scale-100 group-hover:scale-110 transition-transform duration-700 object-cover relative z-10"
                                        alt={guild.name}
                                      />
                                   </div>
                                 ) : (
                                   <div className="w-24 h-24 rounded-[2.5rem] bg-white/[0.03] border border-white/5 flex items-center justify-center font-black text-3xl text-white/10 uppercase relative z-10">
                                     {guild.name.charAt(0)}
                                   </div>
                                 )}
                                 <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-[#0a0a0c] border-4 border-[#0a0a0c] flex items-center justify-center z-20">
                                     <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_15px_#34d399]" />
                                 </div>
                              </div>

                              <div className="flex-1 min-w-0">
                                 <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em] mb-2 group-hover:text-white/40 transition-colors">Protocol: {guild.id.slice(0, 8)}</div>
                                 <h3 className="text-3xl font-black text-white truncate tracking-tighter uppercase mb-2 group-hover:translate-x-2 transition-transform duration-700">{guild.name}</h3>
                                 <div className="flex items-center gap-3">
                                    <span className="px-4 py-1.5 rounded-xl bg-white/[0.03] text-white/40 text-[9px] font-black uppercase tracking-widest border border-white/5 group-hover:bg-white group-hover:text-black transition-all duration-500 shadow-inner">
                                       {guild.owner ? "NEXUS PRIME" : "EXECUTIVE"}
                                    </span>
                                 </div>
                              </div>
                           </div>

                           <div className="pt-8 border-t border-white/[0.03] flex items-center justify-between">
                               <div className="flex flex-col gap-1">
                                  <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Neural Interface</span>
                                  <span className="text-[9px] font-bold text-white/5 uppercase tracking-widest">v4.0.2 Stable</span>
                               </div>
                               <div className="w-14 h-14 rounded-full bg-white/[0.02] border border-white/5 flex items-center justify-center text-white/20 group-hover:bg-white group-hover:text-black transition-all duration-700 group-hover:rotate-45">
                                 <ArrowRight className="w-6 h-6" />
                               </div>
                           </div>
                        </div>
                      </Link>
                    </m.div>
                 ))}
               </AnimatePresence>
             </div>
          </section>

          {/* ── AVAILABLE INTEGRATIONS ── */}
          <section className="space-y-12">
             <m.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="flex items-center gap-6"
             >
                <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent to-white/5" />
                <div className="flex flex-col items-center gap-4">
                   <div className="text-[12px] font-black text-white/20 uppercase tracking-[0.6em]">Potential Integration Nodes</div>
                   <div className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/40 animate-pulse" />
                      <div className="text-[9px] text-white/5 font-black uppercase tracking-[0.4em]">Administrator privileges detected</div>
                   </div>
                </div>
                <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent to-white/5" />
             </m.div>

             <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
                {filteredAvailable.map((guild, idx) => (
                  <m.div 
                    key={guild.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="bg-[#0a0a0c] border border-white/[0.03] rounded-[3rem] p-10 flex flex-col gap-10 group hover:bg-white/[0.02] hover:border-white/10 transition-all duration-700 relative overflow-hidden"
                  >
                     <div className="absolute -inset-1 bg-gradient-to-br from-blue-500/0 via-white/[0.01] to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-2xl" />

                     <div className="flex items-center justify-between relative z-10">
                        <div className="relative group/avatar">
                            <div className="absolute -inset-4 bg-white/5 rounded-full blur-xl opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-700" />
                            {guild.icon ? (
                                <img 
                                src={getDiscordAsset('icon', guild.id, guild.icon) || ""}
                                className="w-16 h-16 rounded-[1.5rem] grayscale group-hover:grayscale-0 group-hover:rotate-6 transition-all duration-700 border border-white/5 relative z-10 shadow-2xl"
                                alt={guild.name}
                                />
                            ) : (
                                <div className="w-16 h-16 rounded-[1.5rem] bg-white/[0.03] flex items-center justify-center text-lg font-black text-white/10 uppercase relative z-10 border border-white/5">
                                {guild.name.slice(0, 2)}
                                </div>
                            )}
                        </div>
                        
                        <Link 
                         href={`https://discord.com/api/oauth2/authorize?client_id=1493482964246593556&permissions=8&scope=bot%20applications.commands&guild_id=${guild.id}`}
                         target="_blank"
                         className="w-14 h-14 bg-white/[0.03] rounded-2xl flex items-center justify-center text-white/20 hover:bg-white hover:text-black transition-all duration-700 group-hover:scale-110 shadow-inner border border-white/5 group-hover:border-white group-hover:rotate-90"
                        >
                          <Plus className="w-7 h-7" />
                        </Link>
                     </div>

                     <div className="space-y-4 relative z-10 pt-4 border-t border-white/[0.02]">
                        <h3 className="text-lg font-black text-white/30 truncate group-hover:text-white transition-all duration-500 uppercase tracking-tighter group-hover:translate-x-2">{guild.name}</h3>
                        <div className="flex items-center gap-3">
                           <div className="px-3 py-1 rounded-lg bg-white/[0.02] border border-white/5 text-[8px] font-black text-white/10 uppercase tracking-widest group-hover:text-white/40 transition-colors">
                              OFFLINE NODE
                           </div>
                        </div>
                     </div>
                  </m.div>
                ))}
             </div>
          </section>
        </div>
      </div>

      {/* ── PREMIUM FOOTER ── */}
      <footer className="relative z-10 py-16 px-12 border-t border-white/[0.03] flex flex-col md:flex-row justify-between items-center gap-12 bg-[#050508]/80 backdrop-blur-3xl">
        <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex items-center gap-4 text-[10px] font-black text-white/10 uppercase tracking-[0.4em]">
                <div className="relative">
                    <div className="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_15px_white] animate-pulse" />
                    <div className="absolute inset-0 w-2.5 h-2.5 rounded-full bg-white animate-ping opacity-20" />
                </div>
                Security Protocol: 128-Bit Encryption Active
            </div>
            <div className="h-4 w-px bg-white/5 hidden md:block" />
            <div className="flex items-center gap-3 text-[10px] font-black text-white/10 uppercase tracking-[0.2em]">
                <Server className="w-4 h-4" /> Cloud Node: US-EAST-01
            </div>
        </div>

        <div className="flex items-center gap-6">
            <div className="flex flex-col items-end gap-1">
                <span className="text-[8px] font-black text-white/10 uppercase tracking-widest">Operator Identity</span>
                <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">{session.user.name}</span>
            </div>
            <div className="w-12 h-12 rounded-full border border-white/10 p-1">
                <img src={session.user.image} className="w-full h-full rounded-full grayscale opacity-80" alt="" />
            </div>
        </div>
      </footer>
    </main>
  );
}
