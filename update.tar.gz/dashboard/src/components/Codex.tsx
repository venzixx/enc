"use client";

import React, { useState, useEffect, useMemo } from "react";
import { motion as m, AnimatePresence } from "framer-motion";
import { 
  Search, ChevronRight, Zap, Music, 
  Shield, Users, Gamepad2, 
  Terminal, Info, Settings, Copy,
  Activity, Cpu, X, Box, LayoutGrid
} from "lucide-react";

interface Command {
  name: string;
  category: string;
  description: string;
  usage: string;
  examples: string[];
  aliases?: string[];
  cooldown?: number;
  subcommands?: { name: string; description: string }[];
}

interface CommandCategory {
  name: string;
  count: number;
  commands: Command[];
  icon: React.ReactNode;
}

const categoryIcons: { [key: string]: React.ReactNode } = {
  all: <LayoutGrid className="w-4 h-4" />,
  config: <Zap className="w-4 h-4" />,
  music: <Music className="w-4 h-4" />,
  moderation: <Shield className="w-4 h-4" />,
  utility: <Users className="w-4 h-4" />,
  fun: <Gamepad2 className="w-4 h-4" />,
};

export default function Codex() {
  const [categories, setCategories] = useState<CommandCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [activeCommand, setActiveCommand] = useState<Command | null>(null);

  useEffect(() => {
    const fetchCommands = async () => {
      try {
        const response = await fetch("/api/commands", { cache: "no-store" });
        if (!response.ok) throw new Error("Failed to fetch commands");
        const data = await response.json();

        if (data.categories && Array.isArray(data.categories)) {
          const mappedCategories: CommandCategory[] = data.categories.map((cat: any) => ({
            name: cat.name,
            count: cat.count,
            commands: cat.commands || [],
            icon: categoryIcons[cat.name.toLowerCase()] || <Cpu className="w-4 h-4" />,
          }));
          
          // Add "All" category
          const allCommands = mappedCategories.flatMap(c => c.commands);
          const allCategory: CommandCategory = {
            name: "All",
            count: allCommands.length,
            commands: allCommands,
            icon: categoryIcons.all
          };

          setCategories([allCategory, ...mappedCategories]);
          setSelectedCategory("All");
        }
      } catch (error) {
        console.error("Failed to load commands:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCommands();
  }, []);

  const selectedCat = categories.find((c) => c.name === selectedCategory);
  
  const filteredCommands = useMemo(() => {
    return (selectedCat?.commands || []).filter(
      (cmd) =>
        cmd.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cmd.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cmd.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [selectedCat, searchQuery]);

  return (
    <section className="pb-32 px-6 md:px-12 bg-transparent relative satoshi-font">
      <div className="max-w-[1400px] mx-auto relative z-10 flex flex-col gap-12">
        
        {/* Navigation & Search Row */}
        <div className="flex flex-col gap-10 border-b border-white/[0.03] pb-12">
            
            {/* Category Navigation (Horizontal) */}
            <div className="flex flex-col items-center gap-6">
                <div className="text-[10px] font-black uppercase tracking-[0.6em] text-white/10">Operational Sectors</div>
                <div className="flex flex-wrap justify-center gap-3">
                    {categories.map((cat) => (
                      <button
                        key={cat.name}
                        onClick={() => setSelectedCategory(cat.name)}
                        className={`group relative flex items-center gap-3 px-6 py-3 rounded-2xl transition-all duration-500 border ${
                          selectedCategory === cat.name 
                            ? "bg-white border-white text-black shadow-[0_15px_40px_rgba(255,255,255,0.15)]" 
                            : "bg-[#0b0b0f] border-white/[0.02] hover:border-white/10 text-white/40"
                        }`}
                      >
                        <span className={`transition-colors ${selectedCategory === cat.name ? "text-black" : "text-white/20 group-hover:text-white"}`}>
                          {cat.icon}
                        </span>
                        <span className="text-[11px] font-black uppercase tracking-[0.2em]">
                          {cat.name}
                        </span>
                        <span className={`text-[8px] font-bold ${selectedCategory === cat.name ? "text-black/40" : "text-white/10"}`}>
                           {cat.count}
                        </span>
                      </button>
                    ))}
                </div>
            </div>

            {/* Search Bar - Centered */}
            <div className="w-full max-w-[600px] mx-auto relative group">
                <div className="relative flex items-center bg-[#0b0b0f] border border-white/[0.02] rounded-2xl px-6 py-4 transition-all duration-500 focus-within:border-white/20 focus-within:bg-[#0e0e15]">
                    <Search className="w-4 h-4 text-white/40" />
                    <input 
                        type="text"
                        placeholder="SEARCH COMMAND PROTOCOLS..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-transparent border-none outline-none pl-4 text-white placeholder:text-white/10 font-black text-[10px] tracking-[0.2em]"
                    />
                    <div className="px-3 py-1 bg-white/5 rounded-lg text-[8px] font-black text-white/20 uppercase tracking-widest hidden sm:block">
                        {filteredCommands.length} Results
                    </div>
                </div>
            </div>
        </div>

        {/* Main Grid Interface */}
        <main className="w-full">
            <AnimatePresence mode="wait">
                {loading ? (
                    <m.div 
                        key="load" 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                    >
                        {[...Array(6)].map((_, i) => (
                            <div key={i} className="bg-[#0b0b0f] border border-white/[0.02] p-10 rounded-[2.5rem] animate-pulse">
                                <div className="flex items-center justify-between mb-8">
                                    <div className="w-12 h-12 rounded-2xl bg-white/5" />
                                    <div className="w-20 h-5 bg-white/5 rounded-full" />
                                </div>
                                <div className="space-y-4">
                                    <div className="w-2/3 h-8 bg-white/5 rounded-lg" />
                                    <div className="w-full h-12 bg-white/5 rounded-lg" />
                                </div>
                                <div className="pt-8 mt-4 border-t border-white/[0.03] flex justify-between">
                                    <div className="w-24 h-3 bg-white/5 rounded-full" />
                                    <div className="w-4 h-4 bg-white/5 rounded-full" />
                                </div>
                            </div>
                        ))}
                    </m.div>
                ) : filteredCommands.length > 0 ? (
                    <m.div 
                        key={`${selectedCategory}-${searchQuery}`}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                    >
                        {filteredCommands.map((cmd, idx) => (
                          <CommandCard 
                            key={`${cmd.name}-${idx}`} 
                            cmd={cmd} 
                            idx={idx} 
                            onClick={() => setActiveCommand(cmd)}
                          />
                        ))}
                    </m.div>
                ) : (
                    <m.div key="none" className="py-40 text-center opacity-10">
                        <Box className="w-16 h-16 mx-auto mb-6 opacity-20" />
                        <div className="text-sm font-black uppercase tracking-[0.5em]">No commands found in this sector.</div>
                    </m.div>
                )}
            </AnimatePresence>
        </main>
      </div>

      {/* Command Detail Overlay/Modal */}
      <AnimatePresence>
        {activeCommand && (
          <CommandDetail 
            cmd={activeCommand} 
            onClose={() => setActiveCommand(null)} 
          />
        )}
      </AnimatePresence>
    </section>
  );
}

function CommandCard({ cmd, idx, onClick }: { cmd: Command, idx: number, onClick: () => void }) {
  return (
    <m.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: Math.min(idx * 0.05, 0.3), ease: [0.16, 1, 0.3, 1] }}
      onClick={onClick}
      className="group relative bg-[#0b0b0f] border border-white/[0.02] p-10 rounded-[2.5rem] cursor-pointer hover:bg-[#0e0e15] hover:border-white/10 transition-all duration-500 hover:-translate-y-2"
    >
        <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-500">
                    <Terminal className="w-5 h-5" />
                </div>
                <div className="px-3 py-1 bg-white/5 rounded-full border border-white/5 text-[9px] font-black text-white/20 uppercase tracking-widest">
                    {cmd.category}
                </div>
            </div>

            <div className="space-y-2">
                <h3 className="text-xl font-black text-white uppercase tracking-tighter">
                    /{cmd.name}
                </h3>
                <p className="text-xs text-white/30 font-medium leading-relaxed line-clamp-2 group-hover:text-white/50 transition-colors">
                    {cmd.description}
                </p>
            </div>

            <div className="pt-4 flex items-center justify-between border-t border-white/[0.03]">
                <div className="flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-white/20" />
                    <span className="text-[9px] font-black text-white/20 uppercase tracking-[0.2em]">View Protocol</span>
                </div>
                <ChevronRight className="w-4 h-4 text-white/10 group-hover:text-white transition-all group-hover:translate-x-1" />
            </div>
        </div>
    </m.div>
  );
}

function CommandDetail({ cmd, onClose }: { cmd: Command, onClose: () => void }) {
  return (
    <m.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[200] flex items-center justify-center p-6 md:p-12"
    >
        <m.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/90 backdrop-blur-2xl" 
        />

        <m.div
            initial={{ opacity: 0, scale: 0.9, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 40 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-[900px] bg-[#080808] border border-white/10 rounded-[3rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.8)]"
        >
            {/* Header / Close Button */}
            <div className="absolute top-8 right-8 z-10">
                <button 
                    onClick={onClose}
                    className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:bg-white hover:text-black transition-all active:scale-90"
                >
                    <X className="w-5 h-5" />
                </button>
            </div>

            <div className="p-10 md:p-16 flex flex-col gap-12 max-h-[85vh] overflow-y-auto scrollbar-hide">
                
                {/* Title & Category */}
                <div className="flex flex-col gap-4">
                    <div className="flex items-center gap-3 text-white/20 font-black text-[10px] uppercase tracking-[0.4em]">
                        <Activity className="w-4 h-4" /> Operational Command Manifest
                    </div>
                    <div className="flex flex-wrap items-end gap-6">
                        <h2 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-none">
                            /{cmd.name}
                        </h2>
                        {cmd.aliases && cmd.aliases.length > 0 && (
                            <div className="flex gap-2 mb-2">
                                {cmd.aliases.map(alias => (
                                    <span key={alias} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black text-white/40 uppercase tracking-widest">
                                        {alias}
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>
                    <p className="text-lg text-white/60 font-medium leading-relaxed max-w-2xl mt-4">
                        {cmd.description}
                    </p>
                </div>

                {/* Sub-Protocols Grid */}
                {cmd.subcommands && cmd.subcommands.length > 0 && (
                    <div className="space-y-6">
                        <div className="flex items-center gap-3">
                            <Box className="w-4 h-4 text-white/20" />
                            <span className="text-[11px] font-black uppercase tracking-[0.4em] text-white/40">Sub-Protocols</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {cmd.subcommands.map((sub, i) => (
                                <div key={i} className="p-8 bg-white/[0.03] border border-white/[0.05] rounded-3xl group/sub hover:bg-white/[0.05] hover:border-white/20 transition-all duration-500">
                                    <div className="text-white font-black text-sm uppercase tracking-widest mb-2">
                                        <span className="text-white/20 mr-2">/</span>{sub.name}
                                    </div>
                                    <p className="text-[11px] text-white/30 font-medium leading-relaxed">
                                        {sub.description}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* Technical Execution Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-12 border-t border-white/5">
                    <div className="space-y-6">
                        <div className="space-y-4">
                            <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Syntax Specification</div>
                            <div className="relative group/syntax">
                                <div className="bg-black p-6 rounded-[2rem] border border-white/10 font-mono text-sm text-white/90">
                                    <code className="font-bold tracking-tight">/{cmd.usage || cmd.name}</code>
                                </div>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(`/${cmd.usage || cmd.name}`); }}
                                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-white/20 opacity-0 group-hover/syntax:opacity-100 transition-all hover:bg-white hover:text-black"
                                >
                                    <Copy className="w-4 h-4" />
                                </button>
                            </div>
                        </div>

                        {cmd.examples && cmd.examples.length > 0 && (
                            <div className="space-y-4">
                                <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Execution Examples</div>
                                <div className="flex flex-wrap gap-2">
                                    {cmd.examples.map((ex, i) => (
                                        <div key={i} className="px-4 py-3 bg-white/[0.02] border border-white/5 rounded-xl font-mono text-[10px] text-white/40">
                                            /{ex}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="space-y-8">
                        <div className="space-y-4">
                            <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Operational Parameters</div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2rem]">
                                    <span className="text-[8px] font-black text-white/20 uppercase tracking-widest block mb-2">Cooldown</span>
                                    <span className="text-sm font-black text-white uppercase tracking-tighter">{cmd.cooldown || 3} SECONDS</span>
                                </div>
                                <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[2rem]">
                                    <span className="text-[8px] font-black text-white/20 uppercase tracking-widest block mb-2">Category</span>
                                    <span className="text-sm font-black text-white uppercase tracking-tighter">{cmd.category}</span>
                                </div>
                            </div>
                        </div>

                        <div className="p-8 bg-white/[0.02] rounded-[2rem] border border-white/5 flex items-center gap-6">
                            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white/20">
                                <Shield className="w-5 h-5" />
                            </div>
                            <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-black text-white uppercase tracking-widest">Protocol Verified</span>
                                <span className="text-[9px] text-white/20 font-medium uppercase tracking-widest">Standard Enc Security Core v4.0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </m.div>
    </m.div>
  );
}
