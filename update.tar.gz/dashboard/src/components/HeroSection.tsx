"use client";

import React, { useRef, useEffect, useState } from 'react';
import { motion, useScroll, useTransform, useMotionValue, useSpring } from 'framer-motion';
import { useSession, signIn } from 'next-auth/react';

// ── UTILITIES ────────────────────────────────────────────────────────────────
function useMouseParallax() {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 60, damping: 20 });
  const springY = useSpring(y, { stiffness: 60, damping: 20 });

  useEffect(() => {
    const move = (e: MouseEvent) => {
      x.set((e.clientX / window.innerWidth - 0.5) * 40);
      y.set((e.clientY / window.innerHeight - 0.5) * 40);
    };
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, [x, y]);

  return { springX, springY };
}

function useScramble(target: string, trigger: boolean) {
  const [display, setDisplay] = useState(target);
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%";
  useEffect(() => {
    if (!trigger) return;
    let iter = 0;
    const interval = setInterval(() => {
      setDisplay(
        target.split("").map((c, i) => {
          if (c === " ") return " ";
          if (i < iter) return target[i];
          return chars[Math.floor(Math.random() * chars.length)];
        }).join("")
      );
      iter += 0.5;
      if (iter >= target.length) clearInterval(interval);
    }, 30);
    return () => clearInterval(interval);
  }, [trigger]);
  return display;
}

const ScrambledUnderline = () => (
  <svg 
    className="absolute -bottom-2 left-0 w-full h-4 pointer-events-none opacity-80" 
    viewBox="0 0 300 20" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="underline-grad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
        <stop offset="50%" stopColor="#FFFFFF" stopOpacity="1" />
        <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
      </linearGradient>
    </defs>
    <path 
      d="M5 15Q50 5 150 15T295 10" 
      stroke="url(#underline-grad)" 
      strokeWidth="3" 
      strokeLinecap="round"
      style={{ filter: 'drop-shadow(0 0 10px rgba(255,255,255,0.5))' }}
    />
  </svg>
);

export default function HeroSection({ stats }: { stats: { guilds: number, users: number, uptime: number } }) {
  const sectionRef = useRef<HTMLElement>(null);
  const { springX, springY } = useMouseParallax();
  const [ready, setReady] = useState(false);
  useEffect(() => { setTimeout(() => setReady(true), 400); }, []);

  const { data: session } = useSession();
  const scramble1 = useScramble("ENC NEXUS", ready);

  return (
    <section ref={sectionRef} className="min-h-screen relative flex flex-col items-center justify-center overflow-hidden bg-black/0">

      {/* Ambient glow orbs */}
      <motion.div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(ellipse, rgba(255,255,255,0.06) 0%, transparent 70%)",
          x: springX, y: springY
        }}
      />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

      <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-6xl mx-auto w-full pt-32">

        {/* Pill badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="mb-12 flex items-center gap-2.5 px-4 py-2 rounded-full border border-white/20 bg-white/5"
        >
          <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
          <span className="text-white text-[10px] font-black uppercase tracking-[0.3em]">The future of Discord is here</span>
        </motion.div>

        {/* Main headline */}
        <div className="overflow-hidden mb-6 flex items-center justify-center pb-4 min-h-[120px] md:min-h-[200px]">
          <motion.div
            initial={{ y: "110%" }}
            animate={{ y: 0 }}
            transition={{ delay: 0.5, duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <h1
              className="font-bold text-transparent bg-clip-text bg-gradient-to-br from-white via-neutral-400 to-neutral-800 leading-tight tracking-tight relative inline-block pb-4"
              style={{
                fontSize: "clamp(4rem, 14vw, 11rem)",
                filter: 'drop-shadow(0 0 30px rgba(255,255,255,0.2))'
              }}
            >

              
              {scramble1}
              <ScrambledUnderline />
            </h1>
          </motion.div>
        </div>

        {/* Sub-tagline */}
        <div className="overflow-hidden mb-6">
          <motion.div
            initial={{ y: "110%" }}
            animate={{ y: 0 }}
            transition={{ delay: 0.7, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <p
              className="font-light uppercase tracking-[0.4em]"
              style={{ fontSize: "clamp(0.75rem, 2vw, 1rem)", color: "rgba(255,255,255,0.35)" }}
            >
              Management · Analytics · Elite Security
            </p>
          </motion.div>
        </div>

        {/* Accent rule */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 1.1, duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="w-24 h-px bg-white mb-10 origin-center"
        />

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 1 }}
          className="max-w-xl text-center mb-16"
          style={{ fontSize: "clamp(1rem, 2vw, 1.2rem)", color: "rgba(255,255,255,0.5)", lineHeight: 1.7, fontWeight: 300 }}
        >
          One protocol for the next generation of communities. Built for those who demand more.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.8 }}
          className="flex flex-col sm:flex-row items-center gap-6"
        >
          <motion.button
            whileHover={{ scale: 1.03, boxShadow: "0 0 40px rgba(255,255,255,0.3)" }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              if (session) window.location.href = '/dashboard';
              else window.location.href = '/auth/signin';
            }}
            className="group relative px-10 py-4 bg-white text-black font-black text-[11px] tracking-[0.2em] uppercase rounded-full overflow-hidden"
          >
            <span className="relative z-10">{session ? "Enter The Nexus" : "Get Started"}</span>
            <motion.div
              className="absolute inset-0 bg-white"
              initial={{ x: "-100%" }}
              whileHover={{ x: 0 }}
              transition={{ duration: 0.3 }}
            />
          </motion.button>
          <a href="/docs" className="group flex items-center gap-2 text-white/30 hover:text-white transition-colors text-[11px] font-bold tracking-[0.3em] uppercase">
            <span>Documentation</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </a>
        </motion.div>

        {/* Floating stat pills */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          className="mt-24 flex flex-wrap justify-center gap-4"
        >
          {[[stats.guilds > 0 ? (stats.guilds >= 1000 ? (stats.guilds / 1000).toFixed(0) + "K+" : stats.guilds) : "0", "Servers"], 
            [stats.users > 0 ? (stats.users >= 1000000 ? (stats.users / 1000000).toFixed(1) + "M+" : (stats.users >= 1000 ? (stats.users / 1000).toFixed(0) + "K+" : stats.users)) : "0", "Members"], 
            [stats.uptime > 0 ? stats.uptime + "%" : "99.9%", "Uptime"]].map(([val, label]) => (
            <div key={label} className="px-5 py-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] flex items-center gap-3">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70 font-black text-sm">{val}</span>
              <span className="text-white/30 text-[10px] font-bold uppercase tracking-widest">{label}</span>
            </div>
          ))}
        </motion.div>
      </div>


    </section>
  );
}
