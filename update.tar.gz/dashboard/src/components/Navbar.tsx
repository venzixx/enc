"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import { 
    LayoutGrid, 
    Globe, 
    Link2, 
    Package, 
    Megaphone,
    LogOut,
    User,
    ChevronDown
} from 'lucide-react';

export default function Navbar() {
    const { data: session } = useSession();
    const pathname = usePathname();
    const [scrolled, setScrolled] = useState(false);
    const [botInfo, setBotInfo] = useState<{ name: string; avatar: string }>({ name: 'Enc', avatar: '' });
    const [profileOpen, setProfileOpen] = useState(false);
    const profileRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        fetch('/api/bot/info')
            .then(r => r.json())
            .then(data => {
                if (data.avatar) setBotInfo(data);
            })
            .catch(() => {});
    }, []);

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 40);
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
                setProfileOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const ctaLink = session ? "/dashboard" : "/auth/signin";
    const inviteLink = "https://discord.com/oauth2/authorize?client_id=1493482964246593556&permissions=8&scope=bot%20applications.commands";
    
    const isHome = pathname === "/";
    const isDashboard = pathname?.startsWith("/dashboard");
    const featuresLink = isHome ? "#features" : "/#features";
    const contactLink = isHome ? "#contact" : "/#contact";

    return (
        <>
            <style dangerouslySetInnerHTML={{ __html: `
                @font-face {
                    font-family: 'Satoshi';
                    src: url('https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/uploads/4aed2f49-a476-436f-bae8-f31aa18f46fa/1767920861040-60c1c779/Satoshi-Variable.woff2') format('woff2');
                    font-weight: 300 900;
                    font-display: swap;
                    font-style: normal;
                }

                :root {
                    --font-satoshi: 'Satoshi', 'Inter', sans-serif;
                }

                .satoshi-font {
                    font-family: var(--font-satoshi);
                }

                .glass-nav {
                    background: rgba(10, 10, 15, 0.8);
                    backdrop-filter: blur(12px);
                    border: 1px solid rgba(255, 255, 255, 0.06);
                }

                /* Hide scrollbar for Chrome, Safari and Opera */
                .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                }
                /* Hide scrollbar for IE, Edge and Firefox */
                .scrollbar-hide {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                }
            `}} />

            {/* Top Navigation */}
            <nav className="fixed top-0 left-0 right-0 z-[100] px-6 md:px-12 py-6 md:py-8 flex items-center justify-between text-sm font-medium tracking-tight satoshi-font">
                <div className="flex items-center gap-10">
                    <a href="/" className="flex items-center gap-3 group">
                        {botInfo.avatar ? (
                            <img 
                                src={botInfo.avatar} 
                                className="w-8 h-8 rounded-lg object-cover border border-white/20 transition-transform group-hover:rotate-12" 
                                alt={botInfo.name} 
                            />
                        ) : (
                            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-black font-extrabold text-xl transition-transform group-hover:rotate-12">
                                E.
                            </div>
                        )}
                        <span className="text-white font-bold tracking-wider hidden sm:inline-block">
                            {botInfo.name}
                        </span>
                    </a>
                    
                    <div className="hidden lg:flex items-center gap-8 text-[#888888]">
                        <a href="/" className="hover:text-white transition-colors">Home</a>
                        <a href="/status" className="hover:text-white transition-colors">Status</a>
                        <a href="/codex" className="hover:text-white transition-colors">Docs</a>
                        <a href={featuresLink} className="hover:text-white transition-colors">Features</a>
                    </div>
                </div>

                <div className="flex items-center gap-6">
                    <a href="https://discord.gg/zzN2vn6bwd" target="_blank" rel="noopener noreferrer" className="hidden md:block text-[#888888] hover:text-white transition-colors">
                        Support Server
                    </a>

                    {session ? (
                        <div className="relative" ref={profileRef}>
                            <button
                                onClick={() => setProfileOpen(!profileOpen)}
                                className="flex items-center gap-2.5 px-3 py-1.5 bg-white/[0.04] border border-white/10 hover:border-white/30 rounded-lg transition-all duration-300 group"
                            >
                                <div className="w-7 h-7 rounded-md overflow-hidden border border-white/20">
                                    <img 
                                        src={session.user?.image || ""} 
                                        alt="" 
                                        className="w-full h-full object-cover"
                                    />
                                </div>
                                <span className="text-white text-xs font-semibold hidden sm:block">
                                    {session.user?.name?.split(' ')[0]}
                                </span>
                                <ChevronDown className={`w-3.5 h-3.5 text-white/40 transition-transform duration-200 ${profileOpen ? 'rotate-180' : ''}`} />
                            </button>

                            {profileOpen && (
                                <div className="absolute right-0 mt-3 w-52 bg-[#0a0a10] border border-white/10 rounded-xl overflow-hidden shadow-2xl">
                                    <div className="p-4 border-b border-white/5">
                                        <p className="text-white text-xs font-bold truncate">{session.user?.name}</p>
                                        <p className="text-white/30 text-[10px] mt-1 truncate">{session.user?.email}</p>
                                    </div>
                                    <div className="p-2">
                                        <button
                                            onClick={() => { setProfileOpen(false); window.location.href = '/dashboard'; }}
                                            className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-medium text-white/50 hover:text-white hover:bg-white/5 rounded-lg transition-all"
                                        >
                                            <User className="w-4 h-4" />
                                            Dashboard
                                        </button>
                                        <button
                                            onClick={() => signOut({ callbackUrl: '/' })}
                                            className="w-full flex items-center gap-3 px-3 py-2.5 text-xs font-medium text-red-400/60 hover:text-red-400 hover:bg-red-400/5 rounded-lg transition-all"
                                        >
                                            <LogOut className="w-4 h-4" />
                                            Sign Out
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    ) : (
                        <a href="/auth/signin" className="px-5 py-2.5 bg-[#111] hover:bg-white hover:text-black border border-[#222] rounded-lg transition-all duration-300">
                            Get started
                        </a>
                    )}
                </div>
            </nav>

            {/* Floating Bottom Navigation — hide on dashboard */}
            {!isDashboard && (
                <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[110] flex items-center gap-1.5 p-1.5 md:p-2 glass-nav rounded-2xl shadow-2xl satoshi-font w-[calc(100%-2rem)] md:w-auto max-w-lg md:max-w-none justify-between md:justify-start">
                    <div className="flex items-center gap-0.5 md:gap-1 pr-2 md:pr-4 border-r border-[#222] overflow-x-auto scrollbar-hide">
                        <a href={ctaLink} className="p-2.5 md:p-3 hover:bg-[#1e293b]/50 rounded-xl transition-all group relative" title="Dashboard">
                            <LayoutGrid className="w-4.5 h-4.5 md:w-5 md:h-5 text-white" />
                        </a>
                        <a href="/status" className="p-2.5 md:p-3 hover:bg-[#1e293b]/50 rounded-xl transition-all group relative" title="Global Status">
                            <Globe className="w-4.5 h-4.5 md:w-5 md:h-5 text-white" />
                        </a>
                        <a href="https://discord.gg/zzN2vn6bwd" target="_blank" rel="noopener noreferrer" className="p-2.5 md:p-3 hover:bg-[#1e293b]/50 rounded-xl transition-all group relative" title="Support Invite">
                            <Link2 className="w-4.5 h-4.5 md:w-5 md:h-5 text-white" />
                        </a>
                        <a href="/codex" className="p-2.5 md:p-3 hover:bg-[#1e293b]/50 rounded-xl transition-all group relative" title="Documentation">
                            <Package className="w-4.5 h-4.5 md:w-5 md:h-5 text-white" />
                        </a>
                        <a href={featuresLink} className="p-2.5 md:p-3 hover:bg-[#1e293b]/50 rounded-xl transition-all group relative" title="Features">
                            <Megaphone className="w-4.5 h-4.5 md:w-5 md:h-5 text-white" />
                        </a>
                    </div>
                    <a href={inviteLink} target="_blank" rel="noopener noreferrer" className="px-5 md:px-6 py-2.5 md:py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] md:text-xs tracking-wide uppercase rounded-xl transition-all whitespace-nowrap">
                        Invite
                    </a>
                </div>
            )}
        </>
    );
}
