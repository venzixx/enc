import React from 'react';
import './GlassSurface.css';

interface GlassSurfaceProps {
  children?: React.ReactNode;
  width?: number | string;
  height?: number | string;
  borderRadius?: number;
  blur?: number;
  backgroundOpacity?: number;
  saturation?: number;
  className?: string;
  style?: React.CSSProperties;
}

const GlassSurface: React.FC<GlassSurfaceProps> = ({
  children,
  width = '100%',
  height = '100%',
  borderRadius = 20,
  blur = 12,
  backgroundOpacity = 0.05,
  saturation = 1.2,
  className = '',
  style = {}
}) => {
  const containerStyle: React.CSSProperties = {
    ...style,
    width: typeof width === 'number' ? `${width}px` : width,
    height: typeof height === 'number' ? `${height}px` : height,
    borderRadius: typeof borderRadius === 'number' ? `${borderRadius}px` : borderRadius,
    backdropFilter: `blur(${blur}px) saturate(${saturation})`,
    WebkitBackdropFilter: `blur(${blur}px) saturate(${saturation})`,
    background: `rgba(255, 255, 255, ${backgroundOpacity})`,
  };

  return (
    <div
      className={`glass-surface-clean ${className}`}
      style={containerStyle}
    >
      <div className="glass-surface-clean__content">{children}</div>
    </div>
  );
};

export default GlassSurface;
