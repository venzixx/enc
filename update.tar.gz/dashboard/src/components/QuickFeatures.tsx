"use client";

import React from "react";
import { motion } from "framer-motion";
import MagicBento from "./MagicBento";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function QuickFeatures() {
  return (
    <section className="py-32 bg-transparent relative">
      <div className="max-w-7xl mx-auto px-8">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-20">
            <div>
              <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">What we offer</p>
              <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60 tracking-tight leading-none font-syne">
                Every tool.<br />One protocol.
              </h2>
            </div>
            <p className="text-white/30 max-w-xs text-sm leading-relaxed">
              Enc Nexus ships with everything you need to run a professional Discord community from day one.
            </p>
          </div>
        </Reveal>

        <div className="w-full max-w-4xl mx-auto">
          <MagicBento />
        </div>
      </div>
    </section>
  );
}
