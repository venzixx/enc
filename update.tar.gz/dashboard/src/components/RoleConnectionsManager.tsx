"use client";

import React, { useState } from 'react';
import { 
  Zap, Plus, Trash2, Shield, Search, Check, 
  ChevronDown, X, ArrowRight, Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';

interface RoleConnection {
  id: string;
  guildId: string;
  triggerRoleId: string;
  connectedRoleId: string;
}

interface Role {
  id: string;
  name: string;
  color: number;
}

interface RoleConnectionsProps {
  guildId: string;
  initialConnections: RoleConnection[];
  roles: Role[];
}

export default function RoleConnectionsManager({ 
  guildId, 
  initialConnections, 
  roles 
}: RoleConnectionsProps) {
  const router = useRouter();
  const [connections, setConnections] = useState<RoleConnection[]>(initialConnections);
  const [triggerRoleId, setTriggerRoleId] = useState<string>('');
  const [selectedConnectedRoleIds, setSelectedConnectedRoleIds] = useState<string[]>([]);
  const [isTriggerOpen, setIsTriggerOpen] = useState(false);
  const [isConnectedOpen, setIsConnectedOpen] = useState(false);
  const [triggerSearch, setTriggerSearch] = useState('');
  const [connectedSearch, setConnectedSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredTriggerRoles = roles.filter(role => 
    role.name.toLowerCase().includes(triggerSearch.toLowerCase())
  );

  const filteredConnectedRoles = roles.filter(role => 
    role.name.toLowerCase().includes(connectedSearch.toLowerCase()) && 
    role.id !== triggerRoleId
  );

  const handleAddConnection = async () => {
    if (!triggerRoleId || selectedConnectedRoleIds.length === 0) return;

    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/roleconnections`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          triggerRoleId,
          connectedRoleIds: selectedConnectedRoleIds
        })
      });

      if (res.ok) {
        // Refresh data
        const newRes = await fetch(`/api/guild/${guildId}/roleconnections`);
        if (newRes.ok) {
          const data = await newRes.json();
          setConnections(data);
        }
        setTriggerRoleId('');
        setSelectedConnectedRoleIds([]);
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  const handleDeleteConnection = async (id: string, tId: string, cId: string) => {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/guild/${guildId}/roleconnections?triggerRoleId=${tId}&connectedRoleId=${cId}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        setConnections(connections.filter(c => c.id !== id));
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    }
    setDeletingId(null);
  };

  const toggleConnectedRole = (roleId: string) => {
    setSelectedConnectedRoleIds(prev => 
      prev.includes(roleId) 
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  // Group connections by trigger role for display
  const groupedConnections = connections.reduce((acc, conn) => {
    if (!acc[conn.triggerRoleId]) {
      acc[conn.triggerRoleId] = [];
    }
    acc[conn.triggerRoleId].push(conn);
    return acc;
  }, {} as Record<string, RoleConnection[]>);

  return (
    <div className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* ── CREATE CONNECTION SECTOR ── */}
      <section className="space-y-8">
        <div className="flex items-center gap-3">
           <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
           <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Establish Link</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Trigger Role Select */}
          <div className="lg:col-span-4 space-y-4">
            <label className="text-[9px] font-bold text-white/10 uppercase tracking-[0.2em] px-1">Trigger Role</label>
            <div className="relative">
              <button 
                onClick={() => setIsTriggerOpen(!isTriggerOpen)}
                className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex items-center justify-between group hover:bg-white/[0.04] transition-all hover:border-white/10"
              >
                <div className="flex items-center gap-4">
                  <Shield className="w-4 h-4 text-white/20" />
                  <span className={`text-xs font-bold uppercase tracking-widest ${triggerRoleId ? 'text-white' : 'text-white/20'}`}>
                    {roles.find(r => r.id === triggerRoleId)?.name || "Select Role"}
                  </span>
                </div>
                <ChevronDown className={`w-4 h-4 text-white/10 transition-transform ${isTriggerOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isTriggerOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                    className="absolute z-50 w-full mt-3 bg-[#0d0d0d] border border-white/10 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
                  >
                    <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-white/20" />
                        <input 
                          autoFocus
                          placeholder="Search roles..."
                          className="w-full bg-white/5 border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-[10px] font-bold text-white uppercase tracking-widest outline-none focus:border-white/10"
                          value={triggerSearch}
                          onChange={(e) => setTriggerSearch(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="max-h-60 overflow-y-auto py-2 scrollbar-hide">
                      {filteredTriggerRoles.map(role => (
                        <button 
                          key={role.id}
                          onClick={() => { setTriggerRoleId(role.id); setIsTriggerOpen(false); }}
                          className="w-full px-5 py-3 flex items-center justify-between hover:bg-white/5 transition-colors group/role"
                        >
                          <span className="text-[10px] font-bold uppercase tracking-widest text-white/40 group-hover/role:text-white transition-colors">{role.name}</span>
                          {triggerRoleId === role.id && <Check className="w-3 h-3 text-white/60" />}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="lg:col-span-1 hidden lg:flex items-center justify-center pt-10 text-white/5">
            <ArrowRight className="w-6 h-6" />
          </div>

          {/* Connected Roles Select */}
          <div className="lg:col-span-5 space-y-4">
            <label className="text-[9px] font-bold text-white/10 uppercase tracking-[0.2em] px-1">Connected Roles</label>
            <div className="relative">
              <button 
                onClick={() => setIsConnectedOpen(!isConnectedOpen)}
                className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl flex items-center justify-between group hover:bg-white/[0.04] transition-all hover:border-white/10"
              >
                <div className="flex items-center gap-4 flex-wrap overflow-hidden">
                  <Zap className="w-4 h-4 text-white/20" />
                  {selectedConnectedRoleIds.length > 0 ? (
                    <div className="flex gap-2 flex-wrap max-h-6 overflow-hidden">
                      {selectedConnectedRoleIds.map(id => (
                        <span key={id} className="text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 bg-white/5 rounded-md text-white/60">
                          {roles.find(r => r.id === id)?.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs font-bold uppercase tracking-widest text-white/20">Select connected roles</span>
                  )}
                </div>
                <ChevronDown className={`w-4 h-4 text-white/10 transition-transform ${isConnectedOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isConnectedOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                    className="absolute z-50 w-full mt-3 bg-[#0d0d0d] border border-white/10 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
                  >
                    <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-white/20" />
                        <input 
                          autoFocus
                          placeholder="Search roles..."
                          className="w-full bg-white/5 border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-[10px] font-bold text-white uppercase tracking-widest outline-none focus:border-white/10"
                          value={connectedSearch}
                          onChange={(e) => setConnectedSearch(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="max-h-60 overflow-y-auto py-2 scrollbar-hide">
                      {filteredConnectedRoles.map(role => {
                        const isSelected = selectedConnectedRoleIds.includes(role.id);
                        return (
                          <button 
                            key={role.id}
                            onClick={() => toggleConnectedRole(role.id)}
                            className="w-full px-5 py-3 flex items-center justify-between hover:bg-white/5 transition-colors group/role"
                          >
                            <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${isSelected ? 'text-white' : 'text-white/40 group-hover/role:text-white/60'}`}>{role.name}</span>
                            {isSelected && <Check className="w-3 h-3 text-white/60" />}
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="lg:col-span-2 pt-8 lg:pt-9">
            <button 
              onClick={handleAddConnection}
              disabled={loading || !triggerRoleId || selectedConnectedRoleIds.length === 0}
              className="w-full bg-white text-black text-[10px] font-bold uppercase tracking-widest px-8 py-5 rounded-2xl hover:bg-zinc-200 transition-all active:scale-[0.98] disabled:opacity-20 disabled:grayscale"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Link Roles"}
            </button>
          </div>
        </div>
      </section>

      {/* ── EXISTING CONNECTIONS SECTOR ── */}
      <section className="space-y-8">
        <div className="flex items-center justify-between">
           <div className="flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
              <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Active Connections</h2>
           </div>
           <div className="text-[9px] font-bold text-white/10 uppercase tracking-[0.2em]">{Object.keys(groupedConnections).length} Triggers Active</div>
        </div>

        {Object.keys(groupedConnections).length === 0 ? (
          <div className="p-20 border border-dashed border-white/5 rounded-[40px] flex flex-col items-center justify-center text-center space-y-4">
             <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl">
               <Zap className="w-6 h-6 text-white/10" />
             </div>
             <p className="text-[10px] font-bold text-white/10 uppercase tracking-widest">No connections established yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {Object.entries(groupedConnections).map(([tRoleId, conns]) => {
              const triggerRole = roles.find(r => r.id === tRoleId);
              if (!triggerRole) return null;

              return (
                <div key={tRoleId} className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] group hover:bg-white/[0.02] transition-all hover:border-white/10">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
                      <div className="flex items-center gap-6">
                         <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center shrink-0">
                            <Shield className="w-5 h-5 text-white/40" />
                         </div>
                         <div className="space-y-1">
                            <h3 className="text-sm font-bold text-white/90 tracking-tight">{triggerRole.name}</h3>
                            <p className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em]">Triggering Role</p>
                         </div>
                      </div>

                      <div className="flex-1 flex flex-wrap gap-3 md:justify-center">
                         {conns.map(conn => {
                            const connectedRole = roles.find(r => r.id === conn.connectedRoleId);
                            if (!connectedRole) return null;
                            const isDeleting = deletingId === conn.id;

                            return (
                               <div 
                                 key={conn.id} 
                                 className="flex items-center gap-3 pl-4 pr-2 py-2 bg-white/5 border border-white/5 rounded-xl group/chip hover:border-white/10 transition-all"
                               >
                                  <span className="text-[10px] font-bold text-white/60 tracking-wider">{connectedRole.name}</span>
                                  <button 
                                    onClick={() => handleDeleteConnection(conn.id, conn.triggerRoleId, conn.connectedRoleId)}
                                    disabled={!!deletingId}
                                    className="p-1 text-white/10 hover:text-red-500 transition-colors disabled:opacity-50"
                                  >
                                    {isDeleting ? <Loader2 className="w-3 h-3 animate-spin" /> : <X className="w-3.5 h-3.5" />}
                                  </button>
                               </div>
                            );
                         })}
                      </div>

                      <div className="flex justify-end">
                         <div className="p-3 bg-white/[0.02] rounded-xl text-[10px] font-bold text-white/10 uppercase tracking-widest border border-white/5">
                            {conns.length} Connected
                         </div>
                      </div>
                   </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
