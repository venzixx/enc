"use client";

import React from 'react';
import {
  LayoutDashboard, ShieldCheck, Activity, Settings,
  Zap, Lock, Shield, MessageSquare, BarChart3, ListTree, Ticket, Sparkles, ShieldAlert, Link2,
  ChevronUp, Check, Image as ImageIcon
} from "lucide-react";
import SidebarItem from "./SidebarItem";
import { useParams, usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

interface GuildEntry {
  id: string;
  name: string;
  icon: string | null;
}

export default function Sidebar() {
  const { guildId } = useParams();
  const pathname = usePathname();
  const router = useRouter();
  const [guildInfo, setGuildInfo] = React.useState<{ name: string; icon: string | null } | null>(null);
  const [allGuilds, setAllGuilds] = React.useState<GuildEntry[]>([]);
  const [switcherOpen, setSwitcherOpen] = React.useState(false);
  const switcherRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (guildId) {
      fetch(`/api/guild/${guildId}/config`)
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          if (data) setGuildInfo({ name: data.name, icon: data.icon });
        });
    }
  }, [guildId]);

  React.useEffect(() => {
    fetch('/api/guilds')
      .then(r => r.ok ? r.json() : [])
      .then(data => setAllGuilds(data))
      .catch(() => {});
  }, []);

  // Close dropdown when clicking outside
  React.useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (switcherRef.current && !switcherRef.current.contains(e.target as Node)) {
        setSwitcherOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const otherGuilds = allGuilds.filter(g => g.id !== guildId);

  return (
    <div className="fixed left-5 top-[6.5rem] bottom-5 w-[17rem] hidden xl:flex flex-col z-30 gap-3">
      {/* Main sidebar panel */}
      <aside
        data-lenis-prevent
        className="flex-1 min-h-0 flex flex-col rounded-[2rem] border border-white/[0.06] bg-white/[0.02] backdrop-blur-2xl shadow-[0_8px_50px_rgba(0,0,0,0.4)] overflow-hidden"
      >
        {/* Ambient glow that blends with background */}
        <div className="absolute -inset-3 -z-10 rounded-[2.5rem] bg-gradient-to-b from-blue-500/[0.04] via-transparent to-purple-500/[0.03] blur-2xl pointer-events-none" />

        <div className="px-7 pt-7 pb-0 flex flex-col gap-2 shrink-0">
          <div className="text-[10px] font-bold text-white/20 tracking-[0.3em] uppercase mb-1">Menu</div>
          <div className="h-px w-6 bg-white/10" />
        </div>

        <nav
          data-lenis-prevent
          className="flex-1 min-h-0 overflow-y-auto px-5 py-6 flex flex-col gap-8 custom-scrollbar overscroll-contain"
        >
          {/* CORE */}
          <div className="flex flex-col gap-1">
            <div className="text-[10px] font-bold text-white/20 tracking-[0.2em] uppercase mb-2 pl-3">Core</div>
            <SidebarItem
              icon={<LayoutDashboard className="w-4 h-4" />}
              label="Analytics"
              href={`/dashboard/${guildId}`}
              active={pathname === `/dashboard/${guildId}`}
            />

            <SidebarItem
              icon={<Ticket className="w-4 h-4" />}
              label="Tickets"
              href={`/dashboard/${guildId}/tickets`}
              active={pathname?.includes('/tickets')}
            />
            <SidebarItem
              icon={<Link2 className="w-4 h-4" />}
              label="Aliases"
              href={`/dashboard/${guildId}/aliases`}
              active={pathname?.includes('/aliases')}
            />
          </div>

          {/* MODERATION */}
          <div className="flex flex-col gap-1">
            <div className="text-[10px] font-bold text-white/20 tracking-[0.2em] uppercase mb-2 pl-3">Moderation</div>
            <SidebarItem
              icon={<Shield className="w-4 h-4" />}
              label="Security"
              href={`/dashboard/${guildId}/security`}
              active={pathname?.includes('/security')}
            />
            <SidebarItem
              icon={<ShieldAlert className="w-4 h-4" />}
              label="Appeals"
              href={`/dashboard/${guildId}/appeals`}
              active={pathname?.includes('/appeals')}
            />
            <SidebarItem
              icon={<Zap className="w-4 h-4" />}
              label="Auto Mod"
              href={`/dashboard/${guildId}/automod`}
              active={pathname?.includes('/automod')}
            />
            <SidebarItem
              icon={<Lock className="w-4 h-4" />}
              label="Permissions"
              href={`/dashboard/${guildId}/permits`}
              active={pathname?.includes('/permits')}
            />
          </div>

          {/* ENGAGEMENT */}
          <div className="flex flex-col gap-1">
            <div className="text-[10px] font-bold text-white/20 tracking-[0.2em] uppercase mb-2 pl-3">Engagement</div>
            <SidebarItem
              icon={<ListTree className="w-4 h-4" />}
              label="Progression"
              href={`/dashboard/${guildId}/levels`}
              active={pathname?.includes('/levels')}
            />
            <SidebarItem
              icon={<Activity className="w-4 h-4" />}
              label="Streaks"
              href={`/dashboard/${guildId}/streaks`}
              active={pathname?.includes('/streaks')}
            />
            <SidebarItem
              icon={<Zap className="w-4 h-4" />}
              label="Role Connections"
              href={`/dashboard/${guildId}/roleconnections`}
              active={pathname?.includes('/roleconnections')}
            />
            <SidebarItem
              icon={<MessageSquare className="w-4 h-4" />}
              label="Messages"
              href={`/dashboard/${guildId}/messages`}
              active={pathname === `/dashboard/${guildId}/messages`}
            />
            <SidebarItem
              icon={<Sparkles className="w-4 h-4" />}
              label="Autoresponder"
              href={`/dashboard/${guildId}/autoresponder`}
              active={pathname?.includes('/autoresponder')}
            />
            <SidebarItem
              icon={<BarChart3 className="w-4 h-4" />}
              label="Polls"
              href={`/dashboard/${guildId}/polls`}
              active={pathname?.includes('/polls')}
            />
          </div>

          {/* SERVER */}
          <div className="flex flex-col gap-1">
            <div className="text-[10px] font-bold text-white/20 tracking-[0.2em] uppercase mb-2 pl-3">Server</div>
            <SidebarItem
              icon={<Activity className="w-4 h-4" />}
              label="Audit Logs"
              href={`/dashboard/${guildId}/logs`}
              active={pathname?.includes('/logs')}
            />
            <SidebarItem
              icon={<Settings className="w-4 h-4" />}
              label="Branding"
              href={`/dashboard/${guildId}/branding`}
              active={pathname?.includes('/branding')}
            />
            <SidebarItem
              icon={<Settings className="w-4 h-4" />}
              label="Settings"
              href={`/dashboard/${guildId}/settings`}
              active={pathname?.includes('/settings')}
            />
            <SidebarItem
              icon={<ImageIcon className="w-4 h-4" />}
              label="Asset Manager"
              href={`/dashboard/${guildId}/assets`}
              active={pathname?.includes('/assets')}
            />
          </div>
        </nav>
      </aside>

      {/* Server Switcher — separate floating card */}
      <div ref={switcherRef} className="relative shrink-0">
        {/* Upward Dropdown */}
        <AnimatePresence>
          {switcherOpen && otherGuilds.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="absolute bottom-full left-0 right-0 mb-2 rounded-2xl border border-white/[0.08] bg-[#0a0a10]/90 backdrop-blur-3xl shadow-[0_-8px_40px_rgba(0,0,0,0.5)] overflow-hidden z-50"
            >
              <div className="px-4 py-3 border-b border-white/[0.05]">
                <div className="text-[9px] font-bold text-white/20 uppercase tracking-[0.3em]">Switch Server</div>
              </div>
              <div
                data-lenis-prevent
                className="max-h-[240px] overflow-y-auto custom-scrollbar overscroll-contain"
              >
                {otherGuilds.map((guild, idx) => (
                  <motion.button
                    key={guild.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.03, duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    onClick={() => {
                      setSwitcherOpen(false);
                      router.push(`/dashboard/${guild.id}`);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/[0.04] transition-all duration-300 group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/5 overflow-hidden flex items-center justify-center shrink-0 group-hover:border-white/15 transition-colors">
                      {guild.icon ? (
                        <img src={guild.icon} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span className="text-[10px] font-bold text-white/20 uppercase">{guild.name.charAt(0)}</span>
                      )}
                    </div>
                    <span className="text-[11px] font-bold text-white/40 truncate group-hover:text-white/80 transition-colors tracking-tight uppercase">
                      {guild.name}
                    </span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Server Card Button */}
        <motion.button
          onClick={() => setSwitcherOpen(!switcherOpen)}
          whileTap={{ scale: 0.97 }}
          className="w-full rounded-2xl border border-white/[0.06] bg-white/[0.02] backdrop-blur-2xl shadow-[0_4px_30px_rgba(0,0,0,0.3)] p-4 group relative overflow-hidden transition-all duration-300 hover:border-white/15 hover:bg-white/[0.04] cursor-pointer text-left"
        >
          {/* Bottom glow */}
          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-2/3 h-8 -z-10 bg-blue-500/[0.05] blur-2xl rounded-full pointer-events-none" />

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/5 overflow-hidden flex items-center justify-center shrink-0">
              {guildInfo?.icon ? (
                <img src={guildInfo.icon} alt="Icon" className="w-full h-full object-cover" />
              ) : (
                <Shield className="w-4 h-4 text-white/20" />
              )}
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <div className="text-[9px] font-bold text-white/15 uppercase tracking-[0.2em] mb-0.5">Server</div>
              <div className="text-[11px] font-bold text-white/80 truncate tracking-tight uppercase">
                {guildInfo?.name || "Loading..."}
              </div>
            </div>
            <motion.div
              animate={{ rotate: switcherOpen ? 180 : 0 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            >
              <ChevronUp className="w-4 h-4 text-white/20 group-hover:text-white/40 transition-colors" />
            </motion.div>
          </div>
        </motion.button>
      </div>
    </div>
  );
}
