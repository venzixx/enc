import { NextAuthOptions } from "next-auth";
import DiscordProvider from "next-auth/providers/discord";

const getDefaultAvatar = (userId: string, discriminator: string) => {
  if (discriminator && discriminator !== "0") {
    return `https://cdn.discordapp.com/embed/avatars/${parseInt(discriminator) % 5}.png`;
  }
  try {
    const idNum = BigInt(userId);
    const index = Number((idNum >> BigInt(22)) % BigInt(6));
    return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
  } catch {
    return `https://cdn.discordapp.com/embed/avatars/0.png`;
  }
};

const getAvatarUrl = (userId: string, avatarHash: string | null, discriminator: string) => {
  if (!avatarHash) {
    return getDefaultAvatar(userId, discriminator);
  }
  const isGif = avatarHash.startsWith("a_");
  const ext = isGif ? "gif" : "png";
  return `https://cdn.discordapp.com/avatars/${userId}/${avatarHash}.${ext}`;
};

export const authOptions: NextAuthOptions = {
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID!,
      clientSecret: process.env.DISCORD_CLIENT_SECRET!,
      allowDangerousEmailAccountLinking: true,
      authorization: {
        params: {
          scope: "identify email guilds",
        },
      },
    }),
  ],
  pages: {
    signIn: "/auth/signin",
  },
  debug: true,
  callbacks: {
    async jwt({ token, account, profile }: any) {
      if (account) {
        token.accessToken = account.access_token;
      }
      if (profile) {
        token.id = profile.id;
        token.picture = getAvatarUrl(profile.id, profile.avatar, profile.discriminator);
        token.lastFetched = Date.now();
      } else if (token.id) {
        // Fetch latest profile via Bot token in the background to ensure avatar remains valid
        const now = Date.now();
        if (!token.lastFetched || now - token.lastFetched > 2 * 60 * 1000) { // 2 minutes cache
          try {
            const res = await fetch(`https://discord.com/api/users/${token.id}`, {
              headers: {
                Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
              },
            });
            if (res.ok) {
              const data = await res.json();
              token.picture = getAvatarUrl(data.id, data.avatar, data.discriminator);
              token.lastFetched = now;
            }
          } catch (err) {
            console.error("Error background fetching Discord user avatar via Bot token:", err);
          }
        }
      }
      return token;
    },
    async session({ session, token }: any) {
      session.accessToken = token.accessToken;
      if (session.user) {
        session.user.id = token.id;
        session.user.image = token.picture; // Always inject the latest profile picture
      }
      return session;
    },
  },
  session: {
    strategy: "jwt",
  },
  cookies: {
    sessionToken: {
      name: `__Secure-next-auth.session-token`,
      options: {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        secure: true,
      },
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
};

