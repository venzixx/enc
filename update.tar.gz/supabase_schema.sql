﻿-- CreateTable
CREATE TABLE "Guild" (
    "id" TEXT NOT NULL,
    "confessionChannel" TEXT,
    "countingChannel" TEXT,
    "countingCurrent" INTEGER NOT NULL DEFAULT 0,
    "countingLastUser" TEXT,
    "countingHighScore" INTEGER NOT NULL DEFAULT 0,
    "logChannelId" TEXT,
    "autoroleId" TEXT,
    "welcomeChannelId" TEXT,
    "welcomeMessage" TEXT,
    "joinDmMessage" TEXT,
    "giveawayDefaultRoleId" TEXT,
    "giveawayDefaultInvites" INTEGER DEFAULT 0,
    "giveawayBypassRoleId" TEXT,
    "verificationChannelId" TEXT,
    "verificationRoleId" TEXT,
    "verificationType" TEXT NOT NULL DEFAULT 'BUTTON',
    "vanityString" TEXT,
    "vanityRoleId" TEXT,
    "birthdayChannelId" TEXT,
    "birthdayPingRoleId" TEXT,
    "levelChannelId" TEXT,
    "prefix" TEXT NOT NULL DEFAULT 'e!',
    "suggestionChannelId" TEXT,
    "antiNukeEnabled" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeBan" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeKick" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeChannel" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeRole" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeBot" BOOLEAN NOT NULL DEFAULT false,
    "antiNukeWebhook" BOOLEAN NOT NULL DEFAULT false,
    "logMessagesEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logChannelsEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logRolesEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logMembersEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logModerationEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logSecurityEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logVoiceEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logAutomodEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logBotEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logInvitesEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logEmojiEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logStickerEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logEventsEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logStageEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logServerEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logThreadsEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logVanityEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logWebhooksEnabled" BOOLEAN NOT NULL DEFAULT true,
    "logChannelMessages" TEXT,
    "logChannelChannels" TEXT,
    "logChannelRoles" TEXT,
    "logChannelMembers" TEXT,
    "logChannelModeration" TEXT,
    "logChannelSecurity" TEXT,
    "logChannelVoice" TEXT,
    "logChannelAutomod" TEXT,
    "logChannelBot" TEXT,
    "logChannelInvites" TEXT,
    "logChannelEmoji" TEXT,
    "logChannelSticker" TEXT,
    "logChannelEvents" TEXT,
    "logChannelStage" TEXT,
    "logChannelServer" TEXT,
    "logChannelThreads" TEXT,
    "logChannelVanity" TEXT,
    "logChannelWebhooks" TEXT,
    "logMode" TEXT NOT NULL DEFAULT 'CORE',
    "logCategoryId" TEXT,
    "music_language" TEXT DEFAULT 'en-US',
    "defaultVolume" INTEGER DEFAULT 100,
    "djMode" BOOLEAN DEFAULT false,
    "setupChannel" TEXT,
    "setupMessage" TEXT,
    "stay247" BOOLEAN DEFAULT false,
    "stay247TextChannel" TEXT,
    "stay247VoiceChannel" TEXT,
    "aiPersonality" TEXT DEFAULT 'CASUAL',
    "aiCustomPrompt" TEXT,
    "aiSearchEnabled" BOOLEAN NOT NULL DEFAULT true,
    "aiEnabled" BOOLEAN NOT NULL DEFAULT true,
    "greeterChannelId" TEXT,
    "greeterMessage" TEXT,
    "greeterTime" INTEGER,
    "starboardChannelId" TEXT,
    "starboardCount" INTEGER,
    "snipeEnabled" BOOLEAN NOT NULL DEFAULT true,
    "backroomRoleId" TEXT,
    "backroomChannelId" TEXT,
    "lockdownEnabled" BOOLEAN NOT NULL DEFAULT false,
    "lockdownMode" TEXT NOT NULL DEFAULT 'PUBLIC',
    "lockdownChannels" TEXT,
    "autoModEnabled" BOOLEAN NOT NULL DEFAULT false,
    "botNickname" TEXT,
    "botBio" TEXT,
    "botAvatar" TEXT,
    "botBanner" TEXT,
    "lastBrandingUpdate" TIMESTAMP(3),
    "leaveChannelId" TEXT,
    "leaveMessage" TEXT,
    "levelingEnabled" BOOLEAN NOT NULL DEFAULT true,
    "xpFormulaCurve" TEXT NOT NULL DEFAULT 'LINEAR',
    "xpFormulaMultiplier" DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    "xpFormulaMaxLevel" INTEGER,
    "xpMessageEnabled" BOOLEAN NOT NULL DEFAULT true,
    "xpMessageMode" TEXT NOT NULL DEFAULT 'RANDOM',
    "xpMessageMin" INTEGER NOT NULL DEFAULT 15,
    "xpMessageMax" INTEGER NOT NULL DEFAULT 25,
    "xpMessageCooldown" INTEGER NOT NULL DEFAULT 60,
    "xpVoiceEnabled" BOOLEAN NOT NULL DEFAULT false,
    "xpVoiceMin" INTEGER NOT NULL DEFAULT 15,
    "xpVoiceMax" INTEGER NOT NULL DEFAULT 40,
    "xpVoiceCooldown" INTEGER NOT NULL DEFAULT 180,
    "xpVoiceMinMembers" INTEGER NOT NULL DEFAULT 2,
    "xpVoiceAntiAfk" BOOLEAN NOT NULL DEFAULT true,
    "xpReactionEnabled" BOOLEAN NOT NULL DEFAULT false,
    "xpReactionAwardType" TEXT NOT NULL DEFAULT 'BOTH',
    "xpReactionMin" INTEGER NOT NULL DEFAULT 5,
    "xpReactionMax" INTEGER NOT NULL DEFAULT 10,
    "xpReactionCooldown" INTEGER NOT NULL DEFAULT 300,
    "levelUpMessageEnabled" BOOLEAN NOT NULL DEFAULT true,
    "levelUpMessage" TEXT DEFAULT 'GG {user.mention}, you just reached level **{user.level}**!',
    "levelUpImageEnabled" BOOLEAN NOT NULL DEFAULT false,
    "levelUpChannelId" TEXT,
    "rankCardChannelId" TEXT,
    "levelUpEmbedData" TEXT,
    "firstPlaceRoleId" TEXT,
    "stackRoleRewards" BOOLEAN NOT NULL DEFAULT true,
    "stackXpBoosters" BOOLEAN NOT NULL DEFAULT true,
    "voteRewardEnabled" BOOLEAN NOT NULL DEFAULT false,
    "effortBoosterEnabled" BOOLEAN NOT NULL DEFAULT false,
    "effortBoosterWords" INTEGER NOT NULL DEFAULT 25,
    "effortBoosterImages" INTEGER NOT NULL DEFAULT 3,
    "effortBoosterPercentage" INTEGER NOT NULL DEFAULT 10,
    "weeklyHighlightsEnabled" BOOLEAN NOT NULL DEFAULT false,
    "weeklyHighlightsChannelId" TEXT,
    "monthlyHighlightsEnabled" BOOLEAN NOT NULL DEFAULT false,
    "monthlyHighlightsChannelId" TEXT,
    "rankCardProgressColor" TEXT DEFAULT '#ffffff',
    "rankCardProgressOpacity" DOUBLE PRECISION DEFAULT 1.0,
    "rankCardBackgroundColor" TEXT DEFAULT '#000000',
    "rankCardFontColor" TEXT DEFAULT '#ffffff',
    "rankCardBackgroundUrl" TEXT,
    "disableXpCommand" BOOLEAN NOT NULL DEFAULT false,
    "disableLeaderboardReset" BOOLEAN NOT NULL DEFAULT false,
    "streaksEnabled" BOOLEAN NOT NULL DEFAULT true,
    "streakChannelId" TEXT,
    "streakMessageMode" TEXT NOT NULL DEFAULT 'TEXT',

    CONSTRAINT "Guild_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommandAlias" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "alias" TEXT NOT NULL,
    "commandName" TEXT NOT NULL,

    CONSTRAINT "CommandAlias_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Appeal" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "userTag" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "appealReason" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "staffId" TEXT,
    "staffReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Appeal_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserConfig" (
    "userId" TEXT NOT NULL,
    "snipeOptOut" BOOLEAN NOT NULL DEFAULT false,
    "timezone" TEXT,

    CONSTRAINT "UserConfig_pkey" PRIMARY KEY ("userId")
);

-- CreateTable
CREATE TABLE "TimezoneSession" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TimezoneSession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GiveawayBlacklist" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "GiveawayBlacklist_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GiveawayBonusEntry" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "entries" INTEGER NOT NULL DEFAULT 1,

    CONSTRAINT "GiveawayBonusEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StarboardMessage" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "originalMessageId" TEXT NOT NULL,
    "starboardMessageId" TEXT NOT NULL,
    "starCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "StarboardMessage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExtraOwner" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "ExtraOwner_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WhitelistedUser" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "WhitelistedUser_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WhitelistedRole" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "WhitelistedRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StickyMessage" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "lastMsgId" TEXT,

    CONSTRAINT "StickyMessage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Story" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "content" TEXT NOT NULL DEFAULT '',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "lastUser" TEXT,

    CONSTRAINT "Story_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Member" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "xp" INTEGER NOT NULL DEFAULT 0,
    "level" INTEGER NOT NULL DEFAULT 0,
    "messages" INTEGER NOT NULL DEFAULT 0,
    "invites" INTEGER NOT NULL DEFAULT 0,
    "lastUsername" TEXT,
    "lastAvatar" TEXT,

    CONSTRAINT "Member_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Channel" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Channel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "IgnoredChannel" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,

    CONSTRAINT "IgnoredChannel_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoResponse" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "trigger" TEXT NOT NULL,
    "response" TEXT NOT NULL,
    "channelId" TEXT,
    "matchType" TEXT NOT NULL DEFAULT 'EXACT',

    CONSTRAINT "AutoResponse_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReactionRole" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "emoji" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "ReactionRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Giveaway" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "prize" TEXT NOT NULL,
    "winnersCount" INTEGER NOT NULL,
    "endTime" TIMESTAMP(3) NOT NULL,
    "reqRoleId" TEXT,
    "reqInvites" INTEGER NOT NULL DEFAULT 0,
    "reqMessageCount" INTEGER NOT NULL DEFAULT 0,
    "reqLevel" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "hostId" TEXT NOT NULL,

    CONSTRAINT "Giveaway_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GiveawayEntry" (
    "id" SERIAL NOT NULL,
    "giveawayId" INTEGER NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "GiveawayEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Birthday" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "day" INTEGER NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER,

    CONSTRAINT "Birthday_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomRole" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "CustomRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DjRole" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "DjRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Playlist" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "guildId" TEXT,

    CONSTRAINT "Playlist_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Track" (
    "id" SERIAL NOT NULL,
    "playlistId" INTEGER NOT NULL,
    "encoded" TEXT NOT NULL,

    CONSTRAINT "Track_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Confession" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "number" INTEGER NOT NULL,
    "userId" TEXT NOT NULL,
    "userTag" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Confession_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Afk" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,
    "reason" TEXT NOT NULL DEFAULT 'AFK',
    "timestamp" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Afk_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AfkMention" (
    "id" SERIAL NOT NULL,
    "afkId" INTEGER NOT NULL,
    "userId" TEXT NOT NULL,
    "userTag" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AfkMention_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketConfig" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "panelId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL DEFAULT 'Click the button below to open a ticket.',
    "categoryId" TEXT,
    "supportRoleId" TEXT,
    "channelId" TEXT,
    "messageId" TEXT,
    "welcomeMessage" TEXT DEFAULT 'Hello {user}, welcome to your support ticket. Our staff will be with you shortly.',
    "isMulti" BOOLEAN NOT NULL DEFAULT false,
    "mentionOnOpen" TEXT,
    "transcriptChannelId" TEXT,
    "useThreads" BOOLEAN NOT NULL DEFAULT false,
    "notificationChannelId" TEXT,
    "openCooldown" INTEGER NOT NULL DEFAULT 0,
    "maxOpenTickets" INTEGER NOT NULL DEFAULT 1,
    "hideCloseButton" BOOLEAN NOT NULL DEFAULT false,
    "hideCloseReasonButton" BOOLEAN NOT NULL DEFAULT false,
    "hideClaimButton" BOOLEAN NOT NULL DEFAULT false,
    "panelColor" TEXT DEFAULT '#9333ea',
    "buttonColor" TEXT DEFAULT 'PRIMARY',
    "buttonText" TEXT DEFAULT 'Create Ticket',
    "buttonEmoji" TEXT DEFAULT '≡ƒÄ½',
    "largeImageUrl" TEXT,
    "smallImageUrl" TEXT,
    "useV2" BOOLEAN NOT NULL DEFAULT false,
    "transcriptEnabled" BOOLEAN NOT NULL DEFAULT true,
    "transcriptDM" BOOLEAN NOT NULL DEFAULT true,
    "useDropdown" BOOLEAN NOT NULL DEFAULT false,
    "embedTitle" TEXT,
    "embedDescription" TEXT,
    "authorName" TEXT,
    "authorIcon" TEXT,
    "footerText" TEXT,
    "footerIcon" TEXT,
    "ticketNameFormat" TEXT DEFAULT 'ticket-{id}',
    "ticketCount" INTEGER NOT NULL DEFAULT 0,
    "welcomeTitle" TEXT,
    "welcomeDescription" TEXT,
    "welcomeColor" TEXT DEFAULT '#9333ea',
    "welcomeAuthorName" TEXT,
    "welcomeAuthorIcon" TEXT,
    "welcomeAuthorUrl" TEXT,
    "welcomeFooterText" TEXT,
    "welcomeFooterIcon" TEXT,
    "welcomeTimestamp" BOOLEAN NOT NULL DEFAULT false,
    "welcomeFields" TEXT,
    "welcomeImage" TEXT,
    "welcomeThumbnail" TEXT,

    CONSTRAINT "TicketConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketPanelOption" (
    "id" SERIAL NOT NULL,
    "panelId" INTEGER NOT NULL,
    "optionId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "categoryId" TEXT,
    "supportRoleId" TEXT,
    "emoji" TEXT,
    "description" TEXT,
    "targetPanelId" TEXT,
    "buttonColor" TEXT NOT NULL DEFAULT 'PRIMARY',

    CONSTRAINT "TicketPanelOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Ticket" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "claimantId" TEXT,
    "panelId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "openedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "number" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "Ticket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VoiceConfig" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "createChannelId" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "panelChannelId" TEXT,
    "panelMessageId" TEXT,

    CONSTRAINT "VoiceConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TempVoice" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "ownerId" TEXT NOT NULL,
    "isLocked" BOOLEAN NOT NULL DEFAULT false,
    "isHidden" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TempVoice_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Suggestion" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "isAnonymous" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Suggestion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SuggestionVote" (
    "id" SERIAL NOT NULL,
    "suggestionId" INTEGER NOT NULL,
    "userId" TEXT NOT NULL,
    "type" TEXT NOT NULL,

    CONSTRAINT "SuggestionVote_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditLog" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "event" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'INFO',
    "executorId" TEXT,
    "executorTag" TEXT,
    "targetId" TEXT,
    "targetName" TEXT,
    "details" TEXT,
    "transcript" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Permit" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'USER',
    "permissions" TEXT NOT NULL DEFAULT '[]',
    "immunity" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "Permit_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoModFilter" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "enabled" BOOLEAN NOT NULL DEFAULT false,
    "threshold" INTEGER,
    "action" TEXT NOT NULL DEFAULT 'DELETE',
    "data" TEXT,

    CONSTRAINT "AutoModFilter_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoModWhitelist" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "type" TEXT NOT NULL,

    CONSTRAINT "AutoModWhitelist_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AntiNukeConfig" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "banHeat" INTEGER NOT NULL DEFAULT 20,
    "kickHeat" INTEGER NOT NULL DEFAULT 15,
    "channelHeat" INTEGER NOT NULL DEFAULT 10,
    "roleHeat" INTEGER NOT NULL DEFAULT 10,
    "webhookHeat" INTEGER NOT NULL DEFAULT 25,
    "decayRate" INTEGER NOT NULL DEFAULT 5,
    "punishment" TEXT NOT NULL DEFAULT 'STRIP_ROLES',

    CONSTRAINT "AntiNukeConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LevelRole" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "level" INTEGER NOT NULL,
    "roleId" TEXT NOT NULL,

    CONSTRAINT "LevelRole_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RoleBooster" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "roleId" TEXT NOT NULL,
    "percentage" INTEGER NOT NULL,

    CONSTRAINT "RoleBooster_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ChannelBooster" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "percentage" INTEGER NOT NULL,

    CONSTRAINT "ChannelBooster_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RoleConnection" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "triggerRoleId" TEXT NOT NULL,
    "connectedRoleId" TEXT NOT NULL,

    CONSTRAINT "RoleConnection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "StreakTier" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "threshold" INTEGER NOT NULL,
    "message" TEXT,
    "embedData" TEXT,
    "imageUrl" TEXT,

    CONSTRAINT "StreakTier_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserStreak" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tierId" INTEGER NOT NULL,
    "currentStreak" INTEGER NOT NULL DEFAULT 0,
    "longestStreak" INTEGER NOT NULL DEFAULT 0,
    "lastActiveDate" TEXT NOT NULL,

    CONSTRAINT "UserStreak_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserDailyActivity" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "messageCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "UserDailyActivity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ChannelDailyActivity" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "messageCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ChannelDailyActivity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReactionDailyActivity" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "reactionCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ReactionDailyActivity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VoiceDailyActivity" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "seconds" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "VoiceDailyActivity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AutoReact" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "trigger" TEXT NOT NULL,
    "emoji" TEXT NOT NULL,

    CONSTRAINT "AutoReact_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ReactLock" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "targetId" TEXT NOT NULL,
    "targetType" TEXT NOT NULL,
    "emoji" TEXT NOT NULL,

    CONSTRAINT "ReactLock_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UwuLock" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "lockType" TEXT NOT NULL DEFAULT 'uwu',

    CONSTRAINT "UwuLock_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DevUser" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "DevUser_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DevMute" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "reason" TEXT NOT NULL DEFAULT 'No reason provided',
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "mutedBy" TEXT NOT NULL,

    CONSTRAINT "DevMute_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ForcedNickname" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "nickname" TEXT NOT NULL,

    CONSTRAINT "ForcedNickname_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SocialAction" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,
    "fromId" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "count" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "SocialAction_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SavedEmbed" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "tag" TEXT NOT NULL,
    "data" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SavedEmbed_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ComponentAction" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "customId" TEXT NOT NULL,
    "logic" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ComponentAction_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Asset" (
    "id" TEXT NOT NULL,
    "guildId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'IMAGE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Asset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Marriage" (
    "id" SERIAL NOT NULL,
    "user1Id" TEXT NOT NULL,
    "user2Id" TEXT NOT NULL,
    "marriedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ring" TEXT,
    "proposerId" TEXT NOT NULL,

    CONSTRAINT "Marriage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FamilyRelation" (
    "id" SERIAL NOT NULL,
    "parentId" TEXT NOT NULL,
    "childId" TEXT NOT NULL,

    CONSTRAINT "FamilyRelation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomReaction" (
    "id" SERIAL NOT NULL,
    "action" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CustomReaction_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserMention" (
    "id" SERIAL NOT NULL,
    "guildId" TEXT NOT NULL,
    "channelId" TEXT NOT NULL,
    "messageId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "authorTag" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "isReply" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserMention_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DevLock" (
    "id" SERIAL NOT NULL,
    "targetId" TEXT NOT NULL,
    "targetType" TEXT NOT NULL,
    "lockType" TEXT NOT NULL,
    "emoji" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DevLock_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "CommandAlias_guildId_alias_key" ON "CommandAlias"("guildId", "alias");

-- CreateIndex
CREATE INDEX "Appeal_guildId_status_idx" ON "Appeal"("guildId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "TimezoneSession_userId_key" ON "TimezoneSession"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "GiveawayBlacklist_guildId_userId_key" ON "GiveawayBlacklist"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "GiveawayBonusEntry_guildId_targetId_key" ON "GiveawayBonusEntry"("guildId", "targetId");

-- CreateIndex
CREATE UNIQUE INDEX "StarboardMessage_originalMessageId_key" ON "StarboardMessage"("originalMessageId");

-- CreateIndex
CREATE UNIQUE INDEX "StarboardMessage_starboardMessageId_key" ON "StarboardMessage"("starboardMessageId");

-- CreateIndex
CREATE UNIQUE INDEX "ExtraOwner_guildId_userId_key" ON "ExtraOwner"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "WhitelistedUser_guildId_userId_key" ON "WhitelistedUser"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "WhitelistedRole_guildId_roleId_key" ON "WhitelistedRole"("guildId", "roleId");

-- CreateIndex
CREATE UNIQUE INDEX "StickyMessage_guildId_channelId_key" ON "StickyMessage"("guildId", "channelId");

-- CreateIndex
CREATE UNIQUE INDEX "Story_guildId_channelId_key" ON "Story"("guildId", "channelId");

-- CreateIndex
CREATE UNIQUE INDEX "Member_guildId_userId_key" ON "Member"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "Giveaway_messageId_key" ON "Giveaway"("messageId");

-- CreateIndex
CREATE UNIQUE INDEX "GiveawayEntry_giveawayId_userId_key" ON "GiveawayEntry"("giveawayId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "Birthday_guildId_userId_key" ON "Birthday"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "CustomRole_guildId_userId_key" ON "CustomRole"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "DjRole_guildId_roleId_key" ON "DjRole"("guildId", "roleId");

-- CreateIndex
CREATE UNIQUE INDEX "Playlist_userId_name_key" ON "Playlist"("userId", "name");

-- CreateIndex
CREATE UNIQUE INDEX "Confession_guildId_number_key" ON "Confession"("guildId", "number");

-- CreateIndex
CREATE UNIQUE INDEX "Afk_userId_key" ON "Afk"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "TicketConfig_guildId_panelId_key" ON "TicketConfig"("guildId", "panelId");

-- CreateIndex
CREATE UNIQUE INDEX "TicketPanelOption_panelId_optionId_key" ON "TicketPanelOption"("panelId", "optionId");

-- CreateIndex
CREATE UNIQUE INDEX "Ticket_channelId_key" ON "Ticket"("channelId");

-- CreateIndex
CREATE UNIQUE INDEX "VoiceConfig_guildId_key" ON "VoiceConfig"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "TempVoice_channelId_key" ON "TempVoice"("channelId");

-- CreateIndex
CREATE UNIQUE INDEX "Suggestion_messageId_key" ON "Suggestion"("messageId");

-- CreateIndex
CREATE UNIQUE INDEX "SuggestionVote_suggestionId_userId_key" ON "SuggestionVote"("suggestionId", "userId");

-- CreateIndex
CREATE INDEX "AuditLog_guildId_executorId_type_idx" ON "AuditLog"("guildId", "executorId", "type");

-- CreateIndex
CREATE UNIQUE INDEX "Permit_guildId_targetId_key" ON "Permit"("guildId", "targetId");

-- CreateIndex
CREATE UNIQUE INDEX "AutoModFilter_guildId_type_key" ON "AutoModFilter"("guildId", "type");

-- CreateIndex
CREATE UNIQUE INDEX "AntiNukeConfig_guildId_key" ON "AntiNukeConfig"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "LevelRole_guildId_level_key" ON "LevelRole"("guildId", "level");

-- CreateIndex
CREATE UNIQUE INDEX "RoleBooster_guildId_roleId_key" ON "RoleBooster"("guildId", "roleId");

-- CreateIndex
CREATE UNIQUE INDEX "ChannelBooster_guildId_channelId_key" ON "ChannelBooster"("guildId", "channelId");

-- CreateIndex
CREATE UNIQUE INDEX "RoleConnection_guildId_triggerRoleId_connectedRoleId_key" ON "RoleConnection"("guildId", "triggerRoleId", "connectedRoleId");

-- CreateIndex
CREATE UNIQUE INDEX "StreakTier_guildId_threshold_key" ON "StreakTier"("guildId", "threshold");

-- CreateIndex
CREATE UNIQUE INDEX "UserStreak_guildId_userId_tierId_key" ON "UserStreak"("guildId", "userId", "tierId");

-- CreateIndex
CREATE UNIQUE INDEX "UserDailyActivity_guildId_userId_date_key" ON "UserDailyActivity"("guildId", "userId", "date");

-- CreateIndex
CREATE UNIQUE INDEX "ChannelDailyActivity_guildId_channelId_date_key" ON "ChannelDailyActivity"("guildId", "channelId", "date");

-- CreateIndex
CREATE UNIQUE INDEX "ReactionDailyActivity_guildId_date_key" ON "ReactionDailyActivity"("guildId", "date");

-- CreateIndex
CREATE UNIQUE INDEX "VoiceDailyActivity_guildId_date_key" ON "VoiceDailyActivity"("guildId", "date");

-- CreateIndex
CREATE UNIQUE INDEX "AutoReact_guildId_trigger_emoji_key" ON "AutoReact"("guildId", "trigger", "emoji");

-- CreateIndex
CREATE UNIQUE INDEX "ReactLock_guildId_targetId_emoji_key" ON "ReactLock"("guildId", "targetId", "emoji");

-- CreateIndex
CREATE UNIQUE INDEX "UwuLock_guildId_userId_key" ON "UwuLock"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "DevUser_userId_key" ON "DevUser"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "DevMute_guildId_userId_key" ON "DevMute"("guildId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "ForcedNickname_guildId_userId_key" ON "ForcedNickname"("guildId", "userId");

-- CreateIndex
CREATE INDEX "SocialAction_userId_action_idx" ON "SocialAction"("userId", "action");

-- CreateIndex
CREATE UNIQUE INDEX "SocialAction_userId_fromId_action_key" ON "SocialAction"("userId", "fromId", "action");

-- CreateIndex
CREATE UNIQUE INDEX "SavedEmbed_guildId_tag_key" ON "SavedEmbed"("guildId", "tag");

-- CreateIndex
CREATE UNIQUE INDEX "ComponentAction_guildId_customId_key" ON "ComponentAction"("guildId", "customId");

-- CreateIndex
CREATE INDEX "Asset_guildId_idx" ON "Asset"("guildId");

-- CreateIndex
CREATE UNIQUE INDEX "Marriage_user1Id_key" ON "Marriage"("user1Id");

-- CreateIndex
CREATE UNIQUE INDEX "Marriage_user2Id_key" ON "Marriage"("user2Id");

-- CreateIndex
CREATE INDEX "FamilyRelation_parentId_idx" ON "FamilyRelation"("parentId");

-- CreateIndex
CREATE INDEX "FamilyRelation_childId_idx" ON "FamilyRelation"("childId");

-- CreateIndex
CREATE UNIQUE INDEX "FamilyRelation_parentId_childId_key" ON "FamilyRelation"("parentId", "childId");

-- CreateIndex
CREATE UNIQUE INDEX "CustomReaction_url_key" ON "CustomReaction"("url");

-- CreateIndex
CREATE INDEX "CustomReaction_action_idx" ON "CustomReaction"("action");

-- CreateIndex
CREATE INDEX "UserMention_userId_createdAt_idx" ON "UserMention"("userId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "DevLock_targetId_key" ON "DevLock"("targetId");

-- AddForeignKey
ALTER TABLE "CommandAlias" ADD CONSTRAINT "CommandAlias_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Appeal" ADD CONSTRAINT "Appeal_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GiveawayBlacklist" ADD CONSTRAINT "GiveawayBlacklist_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GiveawayBonusEntry" ADD CONSTRAINT "GiveawayBonusEntry_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StarboardMessage" ADD CONSTRAINT "StarboardMessage_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExtraOwner" ADD CONSTRAINT "ExtraOwner_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WhitelistedUser" ADD CONSTRAINT "WhitelistedUser_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WhitelistedRole" ADD CONSTRAINT "WhitelistedRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StickyMessage" ADD CONSTRAINT "StickyMessage_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "IgnoredChannel" ADD CONSTRAINT "IgnoredChannel_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoResponse" ADD CONSTRAINT "AutoResponse_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReactionRole" ADD CONSTRAINT "ReactionRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Giveaway" ADD CONSTRAINT "Giveaway_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GiveawayEntry" ADD CONSTRAINT "GiveawayEntry_giveawayId_fkey" FOREIGN KEY ("giveawayId") REFERENCES "Giveaway"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DjRole" ADD CONSTRAINT "DjRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Playlist" ADD CONSTRAINT "Playlist_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Track" ADD CONSTRAINT "Track_playlistId_fkey" FOREIGN KEY ("playlistId") REFERENCES "Playlist"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AfkMention" ADD CONSTRAINT "AfkMention_afkId_fkey" FOREIGN KEY ("afkId") REFERENCES "Afk"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketConfig" ADD CONSTRAINT "TicketConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketPanelOption" ADD CONSTRAINT "TicketPanelOption_panelId_fkey" FOREIGN KEY ("panelId") REFERENCES "TicketConfig"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Ticket" ADD CONSTRAINT "Ticket_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VoiceConfig" ADD CONSTRAINT "VoiceConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Suggestion" ADD CONSTRAINT "Suggestion_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SuggestionVote" ADD CONSTRAINT "SuggestionVote_suggestionId_fkey" FOREIGN KEY ("suggestionId") REFERENCES "Suggestion"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditLog" ADD CONSTRAINT "AuditLog_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Permit" ADD CONSTRAINT "Permit_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoModFilter" ADD CONSTRAINT "AutoModFilter_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoModWhitelist" ADD CONSTRAINT "AutoModWhitelist_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AntiNukeConfig" ADD CONSTRAINT "AntiNukeConfig_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LevelRole" ADD CONSTRAINT "LevelRole_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoleBooster" ADD CONSTRAINT "RoleBooster_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChannelBooster" ADD CONSTRAINT "ChannelBooster_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoleConnection" ADD CONSTRAINT "RoleConnection_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "StreakTier" ADD CONSTRAINT "StreakTier_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserStreak" ADD CONSTRAINT "UserStreak_tierId_fkey" FOREIGN KEY ("tierId") REFERENCES "StreakTier"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserStreak" ADD CONSTRAINT "UserStreak_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserDailyActivity" ADD CONSTRAINT "UserDailyActivity_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChannelDailyActivity" ADD CONSTRAINT "ChannelDailyActivity_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReactionDailyActivity" ADD CONSTRAINT "ReactionDailyActivity_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VoiceDailyActivity" ADD CONSTRAINT "VoiceDailyActivity_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AutoReact" ADD CONSTRAINT "AutoReact_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ReactLock" ADD CONSTRAINT "ReactLock_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UwuLock" ADD CONSTRAINT "UwuLock_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ForcedNickname" ADD CONSTRAINT "ForcedNickname_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Asset" ADD CONSTRAINT "Asset_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild"("id") ON DELETE CASCADE ON UPDATE CASCADE;

