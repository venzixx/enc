import { EmbedBuilder, PermissionFlagsBits, ApplicationCommandOptionType, Role } from 'discord.js';
import { Command, Context } from '../../structures';
import { ExtendedClient } from '../../client';

export default class RoleConnection extends Command {
    constructor(client: ExtendedClient) {
        super(client, {
            name: 'roleconnection',
            description: {
                content: 'Link roles together so that giving one gives the others.',
                usage: 'roleconnection <add/remove/list> <trigger_role> [connected_role]',
                examples: ['roleconnection add @Vip @Premium', 'roleconnection remove @Vip @Premium', 'roleconnection list @Vip']
            },
            category: 'config',
            cooldown: 3,
            slashCommand: true,
            permissions: {
                user: [PermissionFlagsBits.Administrator],
                client: [PermissionFlagsBits.ManageRoles]
            },
            options: [
                {
                    name: 'add',
                    description: 'Connect a role to a trigger role',
                    type: ApplicationCommandOptionType.Subcommand,
                    options: [
                        {
                            name: 'trigger',
                            description: 'The role that triggers the connection',
                            type: ApplicationCommandOptionType.Role,
                            required: true
                        },
                        {
                            name: 'target',
                            description: 'The role to be automatically given',
                            type: ApplicationCommandOptionType.Role,
                            required: true
                        }
                    ]
                },
                {
                    name: 'remove',
                    description: 'Disconnect a role from a trigger role',
                    type: ApplicationCommandOptionType.Subcommand,
                    options: [
                        {
                            name: 'trigger',
                            description: 'The role that triggers the connection',
                            type: ApplicationCommandOptionType.Role,
                            required: true
                        },
                        {
                            name: 'target',
                            description: 'The role to disconnect',
                            type: ApplicationCommandOptionType.Role,
                            required: true
                        }
                    ]
                },
                {
                    name: 'list',
                    description: 'List all role connections or connections for a specific role',
                    type: ApplicationCommandOptionType.Subcommand,
                    options: [
                        {
                            name: 'trigger',
                            description: 'Filter by trigger role',
                            type: ApplicationCommandOptionType.Role,
                            required: false
                        }
                    ]
                }
            ]
        });
    }

    public async run(client: ExtendedClient, ctx: Context, _args: string[]): Promise<any> {
        const sub = ctx.options.getSubcommand();

        if (sub === 'add') {
            const trigger = ctx.options.getRole('trigger') as Role;
            const target = ctx.options.getRole('target') as Role;

            if (trigger.id === target.id) {
                return ctx.reply({ content: `${client.emoji.error} Trigger role and target role cannot be the same.` });
            }

            try {
                await client.prisma.roleConnection.upsert({
                    where: {
                        guildId_triggerRoleId_connectedRoleId: {
                            guildId: ctx.guild.id,
                            triggerRoleId: trigger.id,
                            connectedRoleId: target.id
                        }
                    },
                    update: {},
                    create: {
                        guildId: ctx.guild.id,
                        triggerRoleId: trigger.id,
                        connectedRoleId: target.id
                    }
                });

                const embed = new EmbedBuilder()
                    .setTitle(`${client.emoji.success} Role Connection Added`)
                    .setDescription(`Successfully linked **${trigger.name}** to **${target.name}**.\nWhen a member receives the **${trigger.name}** role, they will also get **${target.name}**.`)
                    .setColor(client.color.main)
                    .setTimestamp();

                await ctx.reply({ embeds: [embed] });
            } catch (error) {
                client.logger.error(error);
                await ctx.reply({ content: `${client.emoji.error} An error occurred while saving the role connection.` });
            }
        } else if (sub === 'remove') {
            const trigger = ctx.options.getRole('trigger') as Role;
            const target = ctx.options.getRole('target') as Role;

            try {
                await client.prisma.roleConnection.delete({
                    where: {
                        guildId_triggerRoleId_connectedRoleId: {
                            guildId: ctx.guild.id,
                            triggerRoleId: trigger.id,
                            connectedRoleId: target.id
                        }
                    }
                });

                const embed = new EmbedBuilder()
                    .setTitle(`${client.emoji.success} Role Connection Removed`)
                    .setDescription(`Successfully unlinked **${trigger.name}** and **${target.name}**.`)
                    .setColor(client.color.main)
                    .setTimestamp();

                await ctx.reply({ embeds: [embed] });
            } catch (error) {
                await ctx.reply({ content: `${client.emoji.error} No such connection found between **${trigger.name}** and **${target.name}**.` });
            }
        } else if (sub === 'list') {
            const triggerFilter = ctx.options.getRole('trigger') as Role | null;

            const connections = await client.prisma.roleConnection.findMany({
                where: {
                    guildId: ctx.guild.id,
                    ...(triggerFilter ? { triggerRoleId: triggerFilter.id } : {})
                }
            });

            if (connections.length === 0) {
                return ctx.reply({ content: `${client.emoji.error} No role connections found${triggerFilter ? ` for **${triggerFilter.name}**` : ''}.` });
            }

            const embed = new EmbedBuilder()
                .setTitle('Role Connections')
                .setColor(client.color.main)
                .setTimestamp();

            const description = connections.map((conn, index) => {
                const tRole = ctx.guild.roles.cache.get(conn.triggerRoleId);
                const cRole = ctx.guild.roles.cache.get(conn.connectedRoleId);
                return `${index + 1}. ${tRole ? `<@&${tRole.id}>` : 'Unknown Role'} → ${cRole ? `<@&${cRole.id}>` : 'Unknown Role'}`;
            }).join('\n');

            embed.setDescription(description);

            await ctx.reply({ embeds: [embed] });
        }
    }
}
