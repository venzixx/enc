import { Message, TextChannel, EmbedBuilder } from 'discord.js';
import { ExtendedClient } from '../client';
import { PermitManager, PermitPermission } from './PermitManager';
import { AuditLogger, AuditLogType, AuditLogStatus } from './AuditLogger';

export class AutoModHandler {
    private static messageCache = new Map<string, { count: number, resetAt: number }>();

    /**
     * Processes a message through all active Auto-Mod filters.
     * @returns True if the message was handled (deleted/punished), False otherwise.
     */
    public static async process(client: ExtendedClient, message: Message): Promise<boolean> {
        if (!message.guild || message.author.bot) return false;

        // 1. Fetch Guild Configuration
        const guildData = await client.prisma.guild.findUnique({ where: { id: message.guildId! } });
        if (!guildData || !guildData.autoModEnabled) return false;

        // 2. Bypass Check (Owner, Immunity, Permit Permission)
        if (await PermitManager.isImmune(client, message.guildId!, message.member!)) return false;
        if (await PermitManager.hasPermission(client, message.guildId!, message.member!, PermitPermission.BYPASS_AUTOMOD)) return false;

        // 2b. AutoModWhitelist Check
        const automodWhitelists = await client.prisma.autoModWhitelist.findMany({
            where: { guildId: message.guildId! }
        });

        if (automodWhitelists.length > 0) {
            const userWhitelisted = automodWhitelists.some(w => w.type === 'USER' && w.targetId === message.author.id);
            if (userWhitelisted) return false;

            const channelWhitelisted = automodWhitelists.some(w => w.type === 'CHANNEL' && w.targetId === message.channelId);
            if (channelWhitelisted) return false;

            if (message.member) {
                const memberRoleIds = message.member.roles.cache.map(r => r.id);
                const hasWhitelistedRole = automodWhitelists.some(w => w.type === 'ROLE' && memberRoleIds.includes(w.targetId));
                if (hasWhitelistedRole) return false;
            }

            const channel = message.channel as TextChannel;
            if (channel.parentId) {
                const categoryWhitelisted = automodWhitelists.some(w => w.type === 'CATEGORY' && w.targetId === channel.parentId);
                if (categoryWhitelisted) return false;
            }
        }

        // 3. Fetch Filters
        const filters = await client.prisma.autoModFilter.findMany({
            where: { guildId: message.guild.id, enabled: true }
        });

        if (filters.length === 0) return false;

        for (const filter of filters) {
            let triggered = false;

            switch (filter.type) {
                case 'WORDS':
                    triggered = this.checkWords(message, filter.data);
                    break;
                case 'LINKS':
                    triggered = this.checkLinks(message, filter.data);
                    break;
                case 'INVITES':
                    triggered = this.checkInvites(message);
                    break;
                case 'SPAM':
                    triggered = this.checkSpam(message, filter.threshold || 5);
                    break;
                case 'MENTIONS':
                    triggered = this.checkMentions(message, filter.threshold || 10);
                    break;
            }

            if (triggered) {
                await this.handleViolation(client, message, filter);
                return true; 
            }
        }

        return false;
    }

    private static checkWords(message: Message, data: string | null): boolean {
        if (!data) return false;
        const blacklisted: string[] = JSON.parse(data);
        const content = message.content.toLowerCase();
        return blacklisted.some(word => content.includes(word.toLowerCase()));
    }

    private static readonly SAFE_DOMAINS = [
        // GIF / Media hosts
        'tenor.com', 'giphy.com', 'imgur.com', 'gfycat.com', 'giphy.org',
        'media.tenor.com', 'media.giphy.com', 'i.imgur.com', 'media1.tenor.com',
        'media.tenor.co', 'tenor.co', 'klipy.com', 'api.klipy.com',
        // Discord CDN
        'cdn.discordapp.com', 'media.discordapp.net', 'images-ext-1.discordapp.net',
        'images-ext-2.discordapp.net', 'discord.com', 'discordapp.com',
        // Social / Video
        'youtube.com', 'youtu.be', 'www.youtube.com', 'm.youtube.com',
        'twitter.com', 'x.com', 'reddit.com', 'www.reddit.com',
        'twitch.tv', 'www.twitch.tv', 'clips.twitch.tv',
        'tiktok.com', 'www.tiktok.com', 'vm.tiktok.com',
        'instagram.com', 'www.instagram.com',
        'facebook.com', 'www.facebook.com',
        'pinterest.com', 'www.pinterest.com',
        // Music
        'spotify.com', 'open.spotify.com',
        'soundcloud.com', 'snd.sc',
        'music.apple.com',
        // Dev / Code
        'github.com', 'gitlab.com', 'stackoverflow.com', 'npmjs.com',
        // Media / Image hosting
        'prnt.sc', 'prntscr.com', 'gyazo.com', 'lightshot.com',
        'steamuserimages-a.akamaihd.net', 'steamcommunity.com',
        'i.redd.it', 'v.redd.it', 'preview.redd.it',
    ];

    private static isGifOrGifDomain(url: string): boolean {
        // Check file extension (.gif, .gifv)
        const pathPart = url.split('?')[0];
        if (pathPart.toLowerCase().endsWith('.gif') || pathPart.toLowerCase().endsWith('.gifv')) {
            return true;
        }
        // Check gif domains
        const gifDomains = ['tenor.com', 'giphy.com', 'klipy.com', 'gfycat.com'];
        try {
            const domain = url.replace(/https?:\/\//i, '').split('/')[0].toLowerCase().replace(/^www\./, '');
            return gifDomains.some(d => domain === d || domain.endsWith('.' + d));
        } catch {
            return false;
        }
    }

    private static checkLinks(message: Message, customWhitelist?: string | null): boolean {
        const content = message.content;
        const urlRegex = /https?:\/\/([^\s/]+)[^\s]*/gi;

        // Merge safe domains with any custom whitelist from filter data
        let safeDomains = [...this.SAFE_DOMAINS];
        if (customWhitelist) {
            try {
                const extra: string[] = JSON.parse(customWhitelist);
                safeDomains.push(...extra);
            } catch { /* ignore parse errors */ }
        }

        let match;
        while ((match = urlRegex.exec(content)) !== null) {
            const fullUrl = match[0];
            // Bypass link check if it is a GIF or from a GIF domain
            if (this.isGifOrGifDomain(fullUrl)) {
                continue;
            }
            const domain = match[1].toLowerCase().replace(/^www\./, '');
            const isSafe = safeDomains.some(safe => {
                const cleanSafe = safe.replace(/^www\./, '');
                return domain === cleanSafe || domain.endsWith('.' + cleanSafe);
            });
            if (!isSafe) return true; // Suspicious/unknown link found
        }
        return false;
    }

    private static checkInvites(message: Message): boolean {
        const inviteRegex = /(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/.+/gi;
        return inviteRegex.test(message.content);
    }

    private static checkSpam(message: Message, threshold: number): boolean {
        const key = `${message.guildId}:${message.author.id}:spam`;
        const now = Date.now();
        const data = this.messageCache.get(key);

        if (!data || now > data.resetAt) {
            this.messageCache.set(key, { count: 1, resetAt: now + 5000 }); // 5s window
            return false;
        }

        data.count++;
        return data.count > threshold;
    }

    private static checkMentions(message: Message, threshold: number): boolean {
        return message.mentions.users.size > threshold || message.mentions.roles.size > threshold;
    }

    private static async handleViolation(client: ExtendedClient, message: Message, filter: any) {
        try {
            if (message.deletable) await message.delete();

            // Notify user
            const channel = message.channel as TextChannel;
            const warning = await channel.send(`${client.emoji.exclamation} <@${message.author.id}>, your message was removed due to our **${filter.type}** filter.`);
            setTimeout(() => warning.delete().catch(() => {}), 5000);

            // Log incident in Data Core and Discord
            await AuditLogger.log(client, message.guild!, {
                type: AuditLogType.AUTOMOD,
                event: `Auto-Mod Filter: ${filter.type}`,
                status: AuditLogStatus.INFO,
                executorId: client.user?.id,
                executorTag: client.user?.tag,
                targetId: message.author.id,
                targetName: message.author.tag,
                details: `Matched ${filter.type} filter in <#${message.channelId}>.\nContent: ${message.content.slice(0, 500)}`,
                color: client.color.yellow
            });
        } catch (err) {
            console.error('[AutoMod] Violation handling failed:', err);
        }
    }
}
