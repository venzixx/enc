'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  ChevronLeft, Save, Sparkles, Hash, Users, Clock, Settings, 
  MessageSquare, Layout, Shield, AlertCircle, Info, Image as ImageIcon,
  CheckCircle2, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function CreateTicketPanel() {
  const { guildId } = useParams();
  const router = useRouter();
  
  const [channels, setChannels] = useState<{id: string, name: string, type: number}[]>([]);
  const [roles, setRoles] = useState<{id: string, name: string}[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    panelId: '',
    name: 'Support',
    description: 'Select a category from the dropdown below to open a ticket.',
    channelId: '',
    categoryId: '',
    mentionOnOpen: [] as string[],
    supportRoleId: '',
    transcriptChannelId: '',
    useThreads: false,
    notificationChannelId: '',
    openCooldown: 0,
    maxOpenTickets: 1,
    hideCloseButton: false,
    hideCloseReasonButton: false,
    hideClaimButton: false,
    panelColor: '#9333ea',
    buttonColor: 'PRIMARY',
    buttonText: 'Create Ticket',
    largeImageUrl: '',
    smallImageUrl: '',
    welcomeMessage: 'Hello {user}, welcome to your support ticket. Our staff will be with you shortly.'
  });

  useEffect(() => {
    if (!guildId) return;
    
    // Fetch channels
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data))
      .catch(console.error);

    // Fetch roles
    fetch(`/api/guild/${guildId}/roles`)
      .then(r => r.json())
      .then(data => setRoles(data))
      .catch(console.error);
  }, [guildId]);

  const handleSave = async () => {
    if (!formData.panelId || !formData.channelId) {
       alert('Panel ID and Panel Channel are required');
       return;
    }
    
    setIsSaving(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/tickets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, isMulti: false })
      });
      if (res.ok) {
        router.push(`/dashboard/${guildId}/tickets`);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <main className="p-6 md:p-10 max-w-[1400px] mx-auto space-y-10 min-h-screen pb-32">
      {/* Navigation Header */}
      <div className="flex items-center justify-between">
         <button 
           onClick={() => router.back()}
           className="group flex items-center gap-2 text-white/40 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest"
         >
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to Panels
         </button>

         <button 
           onClick={handleSave}
           disabled={isSaving}
           className="bg-[#9333ea] hover:bg-[#a855f7] disabled:opacity-50 text-white px-8 py-3 rounded-2xl font-bold text-[11px] uppercase tracking-[0.2em] transition-all flex items-center gap-3 shadow-[0_0_30px_rgba(147,51,234,0.2)]"
         >
            {isSaving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isSaving ? "Deploying..." : "Create Panel"}
         </button>
      </div>

      <header className="space-y-4">
         <div className="flex items-center gap-3 text-[#9333ea] font-bold text-[10px] uppercase tracking-[0.5em]">
            <Sparkles className="w-3.5 h-3.5" /> Single Panel Configuration
         </div>
         <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
            New <span className="text-white/20">Support Node</span>
         </h1>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
         {/* Left Column: Properties */}
         <div className="xl:col-span-7 space-y-8">
            <section className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 backdrop-blur-3xl space-y-10">
               <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#9333ea]/10 rounded-2xl border border-[#9333ea]/20">
                     <Settings className="w-6 h-6 text-[#9333ea]" />
                  </div>
                  <div>
                     <h2 className="text-xl font-bold text-white tracking-tight uppercase italic">Ticket Properties</h2>
                     <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-1">Core logic & routing</p>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Panel ID (System Name)</label>
                     <input 
                       value={formData.panelId}
                       onChange={e => setFormData({...formData, panelId: e.target.value.toLowerCase().replace(/\s+/g, '-')})}
                       placeholder="e.g. general-support"
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 focus:bg-[#9333ea]/5 transition-all"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Panel Channel</label>
                     <SurgicalDropdown 
                       options={channels.filter(c => c.type === 0)}
                       value={formData.channelId}
                       onChange={val => setFormData({...formData, channelId: val})}
                       placeholder="Select Channel"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Ticket Category</label>
                     <SurgicalDropdown 
                       options={channels.filter(c => c.type === 4)}
                       value={formData.categoryId || ''}
                       onChange={val => setFormData({...formData, categoryId: val})}
                       placeholder="Select Category"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Support Team Role</label>
                     <SurgicalDropdown 
                       options={roles}
                       value={formData.supportRoleId || ''}
                       onChange={val => setFormData({...formData, supportRoleId: val})}
                       placeholder="Select Staff Role"
                     />
                  </div>
               </div>

               <div className="pt-6 border-t border-white/5 space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-white/10 transition-all">
                     <div className="flex items-center gap-4">
                        <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400">
                           <Hash className="w-4 h-4" />
                        </div>
                        <div>
                           <div className="text-xs font-bold text-white uppercase tracking-tight">Create Tickets as Threads</div>
                           <div className="text-[9px] font-bold text-white/20 uppercase tracking-widest mt-0.5">Recommended for high volume</div>
                        </div>
                     </div>
                     <button 
                       type="button"
                       onClick={() => setFormData({...formData, useThreads: !formData.useThreads})}
                       className={`w-12 h-6 rounded-full transition-all flex items-center p-1 ${formData.useThreads ? 'bg-[#9333ea]' : 'bg-white/10'}`}
                     >
                        <motion.div 
                          animate={{ x: formData.useThreads ? 24 : 0 }}
                          className="w-4 h-4 rounded-full bg-white shadow-xl" 
                        />
                     </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     {['Close', 'Close Reason', 'Claim'].map((btn) => (
                        <button 
                          key={btn}
                          type="button"
                          onClick={() => {
                             const key = `hide${btn.replace(/\s+/g, '')}Button` as keyof typeof formData;
                             setFormData({...formData, [key]: !formData[key]});
                          }}
                          className={`p-4 rounded-2xl border transition-all text-center space-y-2 ${
                            formData[`hide${btn.replace(/\s+/g, '')}Button` as keyof typeof formData] 
                            ? 'bg-red-500/10 border-red-500/20 text-red-500' 
                            : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500'
                          }`}
                        >
                           <div className="text-[8px] font-black uppercase tracking-[0.2em]">{btn} Button</div>
                           <div className="text-[10px] font-bold">{formData[`hide${btn.replace(/\s+/g, '')}Button` as keyof typeof formData] ? 'HIDDEN' : 'VISIBLE'}</div>
                        </button>
                     ))}
                  </div>
               </div>
            </section>
         </div>

         {/* Right Column: Visuals */}
         <div className="xl:col-span-5 space-y-8">
            <section className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 backdrop-blur-3xl space-y-10">
               <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                     <Layout className="w-6 h-6 text-emerald-500" />
                  </div>
                  <div>
                     <h2 className="text-xl font-bold text-white tracking-tight uppercase italic">Panel Message</h2>
                     <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-1">Embed customization</p>
                  </div>
               </div>

               <div className="space-y-6">
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Panel Title</label>
                     <input 
                       value={formData.name}
                       onChange={e => setFormData({...formData, name: e.target.value})}
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Description / Body</label>
                     <textarea 
                       value={formData.description}
                       onChange={e => setFormData({...formData, description: e.target.value})}
                       rows={4}
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all resize-none"
                     />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6">
                     <div className="space-y-3">
                        <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Accent Color</label>
                        <div className="flex items-center gap-3 bg-white/[0.03] border border-white/5 p-3 rounded-2xl">
                           <input 
                             type="color" 
                             value={formData.panelColor || '#9333ea'}
                             onChange={e => setFormData({...formData, panelColor: e.target.value})}
                             className="w-8 h-8 rounded-lg bg-transparent border-none outline-none cursor-pointer"
                           />
                           <span className="text-xs font-mono font-bold text-white/60">{formData.panelColor}</span>
                        </div>
                     </div>
                     <div className="space-y-3">
                        <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Button Text</label>
                        <input 
                          value={formData.buttonText || ''}
                          onChange={e => setFormData({...formData, buttonText: e.target.value})}
                          className="w-full bg-white/[0.03] border border-white/5 p-3 rounded-2xl text-xs font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all"
                        />
                     </div>
                  </div>
               </div>

               <div className="p-6 bg-white/[0.02] border border-white/5 rounded-[32px] space-y-4">
                  <div className="flex items-center gap-3">
                     <ImageIcon className="w-4 h-4 text-white/20" />
                     <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Media Attachments</span>
                  </div>
                  <input 
                    placeholder="Large Image URL"
                    value={formData.largeImageUrl || ''}
                    onChange={e => setFormData({...formData, largeImageUrl: e.target.value})}
                    className="w-full bg-transparent border-b border-white/5 p-2 text-xs text-white/60 outline-none focus:border-[#9333ea]/50 transition-all"
                  />
                  <input 
                    placeholder="Thumbnail URL"
                    value={formData.smallImageUrl || ''}
                    onChange={e => setFormData({...formData, smallImageUrl: e.target.value})}
                    className="w-full bg-transparent border-b border-white/5 p-2 text-xs text-white/60 outline-none focus:border-[#9333ea]/50 transition-all"
                  />
               </div>
            </section>
         </div>
      </div>

      {/* Save Toast Helper */}
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-[#0a0a0c] border border-white/5 px-8 py-4 rounded-full backdrop-blur-2xl flex items-center gap-6 shadow-[0_20px_50px_rgba(0,0,0,0.5)] z-50"
      >
         <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#9333ea] animate-pulse" />
            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">System Status</span>
         </div>
         <div className="h-4 w-px bg-white/10" />
         <div className="text-[10px] font-bold text-white/80 uppercase tracking-[0.2em]">Ready for deployment</div>
      </motion.div>
    </main>
  );
}
