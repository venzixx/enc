/**
 * Converts a hex color string (e.g., "#FFFFFF") to a decimal number for Discord API.
 */
export function parseColor(hex: string): number {
  if (!hex) return 0;
  return parseInt(hex.replace("#", ""), 16);
}
