"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { Activity, Plus, Trash2, ShieldAlert } from "lucide-react";

interface StreakTier {
  id: number;
  name: string;
  threshold: number;
}

export default function StreaksPage() {
  const { guildId } = useParams();
  const [tiers, setTiers] = useState<StreakTier[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [newName, setNewName] = useState("");
  const [newThreshold, setNewThreshold] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchTiers();
  }, [guildId]);

  const fetchTiers = async () => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`);
      if (res.ok) {
        const data = await res.json();
        setTiers(data);
      }
    } catch (error) {
      console.error(error);
      alert("Failed to load streak tiers");
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    if (!newName || !newThreshold) return;
    setCreating(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName, threshold: parseInt(newThreshold) }),
      });
      if (res.ok) {
        alert("Streak tier created!");
        setNewName("");
        setNewThreshold("");
        fetchTiers();
      } else {
        const text = await res.text();
        alert(text || "Failed to create tier");
      }
    } catch (error) {
      alert("An error occurred");
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier?id=${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        alert("Tier deleted");
        fetchTiers();
      } else {
        alert("Failed to delete tier");
      }
    } catch (error) {
      alert("An error occurred");
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center gap-4 border-b border-white/5 pb-6">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/20 flex items-center justify-center">
          <Activity className="w-6 h-6 text-orange-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Streak Tiers</h1>
          <p className="text-white/50 text-sm mt-1">Configure daily message thresholds for user streaks.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#050510]/30 border border-white/5 rounded-3xl p-6 backdrop-blur-3xl">
            <h2 className="text-lg font-semibold text-white mb-4">Active Tiers</h2>
            
            {loading ? (
              <div className="text-white/40 text-sm">Loading tiers...</div>
            ) : tiers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-4 text-center border border-white/5 rounded-2xl bg-white/[0.01]">
                <Activity className="w-10 h-10 text-white/20 mb-3" />
                <h3 className="text-white font-medium mb-1">No Streak Tiers</h3>
                <p className="text-white/40 text-sm max-w-sm">You haven't configured any streak tiers yet. Add one to start rewarding active members.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tiers.map((tier) => (
                  <div key={tier.id} className="flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center border border-orange-500/20">
                        <Activity className="w-5 h-5 text-orange-400" />
                      </div>
                      <div>
                        <div className="text-white font-medium">{tier.name}</div>
                        <div className="text-white/40 text-xs">{tier.threshold} messages per day required</div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(tier.id)}
                      className="p-2 hover:bg-red-500/10 rounded-xl text-white/20 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-[#050510]/30 border border-white/5 rounded-3xl p-6 backdrop-blur-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 blur-[50px] -mr-16 -mt-16 rounded-full" />
            
            <h2 className="text-lg font-semibold text-white mb-6 relative">Create Tier</h2>
            
            <div className="space-y-4 relative">
              <div>
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2 block">Tier Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Gold Streak"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/50 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2 block">Daily Messages Needed</label>
                <input
                  type="number"
                  min="1"
                  value={newThreshold}
                  onChange={(e) => setNewThreshold(e.target.value)}
                  placeholder="e.g. 100"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-orange-500/50 transition-colors"
                />
              </div>

              <button
                onClick={handleCreate}
                disabled={creating || !newName || !newThreshold}
                className="w-full mt-4 bg-white text-black font-semibold rounded-xl px-4 py-3 text-sm hover:bg-white/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {creating ? "Creating..." : (
                  <>
                    <Plus className="w-4 h-4" />
                    Add Tier
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="bg-orange-500/10 border border-orange-500/20 rounded-3xl p-6">
            <div className="flex gap-3">
              <ShieldAlert className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-orange-400 font-medium text-sm mb-1">How it works</h3>
                <p className="text-orange-400/70 text-xs leading-relaxed">
                  Users automatically maintain streaks by sending the required number of messages each day. If they miss a day, the streak resets to 1. Tiers are stackable, so a user can maintain a Bronze streak while building up to Gold!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
