"use client";

import { useSearchParams } from "next/navigation";
import { useState, Suspense } from "react";
import { AlertCircle, ShieldCheck, ArrowRight, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

function AppealForm() {
    const searchParams = useSearchParams();
    const guildId = searchParams.get("g");
    const userId = searchParams.get("u");
    const type = searchParams.get("t");
    const signature = searchParams.get("s");

    const [reason, setReason] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);

    if (!guildId || !userId || !type || !signature) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-[#131317] text-[#e5e1e7] p-4 font-[Manrope]">
                <div className="bg-[#1b1b1f] p-8 rounded-3xl max-w-md w-full border border-white/5 shadow-2xl">
                    <div className="flex items-center gap-3 text-[#ffb4ab] mb-4">
                        <AlertCircle className="w-6 h-6" />
                        <h2 className="text-xl font-semibold">Invalid Appeal Link</h2>
                    </div>
                    <p className="text-[#cfc2d7] text-sm">
                        This appeal link is missing required parameters or is malformed. Please use the exact link provided by the bot in your direct messages.
                    </p>
                </div>
            </div>
        );
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!reason.trim()) {
            setError("Please provide a reason for your appeal.");
            return;
        }

        setSubmitting(true);
        setError("");

        try {
            const res = await fetch("/api/appeal/submit", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    guildId,
                    userId,
                    type,
                    tag: searchParams.get("tag"),
                    r: searchParams.get("r"),
                    reason,
                    signature
                }),
            });

            const data = await res.json();

            if (!res.ok) {
                setError(data.error || "Failed to submit appeal.");
            } else {
                setSuccess(true);
            }
        } catch (err) {
            setError("An unexpected error occurred. Please try again later.");
        } finally {
            setSubmitting(false);
        }
    };

    if (success) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-[#131317] text-[#e5e1e7] p-4 font-[Manrope]">
                <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-[#1b1b1f] p-8 rounded-[32px] max-w-md w-full border border-[#2a292e] shadow-2xl relative overflow-hidden"
                >
                    <div className="absolute inset-0 bg-gradient-to-br from-[#9333ea]/10 to-transparent pointer-events-none" />
                    
                    <div className="flex flex-col items-center text-center relative z-10">
                        <div className="w-16 h-16 bg-[#1f1f23] rounded-full flex items-center justify-center mb-6 border border-[#2a292e]">
                            <CheckCircle2 className="w-8 h-8 text-[#ddb8ff]" />
                        </div>
                        <h2 className="text-2xl font-bold text-[#e5e1e7] mb-2">Appeal Submitted</h2>
                        <p className="text-[#cfc2d7] text-sm leading-relaxed mb-6">
                            Your appeal has been successfully forwarded to the server moderators. You will receive a direct message with their decision.
                        </p>
                    </div>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="flex min-h-screen items-center justify-center bg-[#131317] text-[#e5e1e7] p-4 font-[Manrope]">
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#1b1b1f] p-8 rounded-[32px] max-w-xl w-full relative"
            >
                {/* Decorative glow */}
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#9333ea] rounded-full blur-[80px] opacity-20 pointer-events-none" />
                
                <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-8">
                        <div className="w-10 h-10 bg-[#2a292e] rounded-full flex items-center justify-center">
                            <ShieldCheck className="w-5 h-5 text-[#ddb8ff]" />
                        </div>
                        <h1 className="text-2xl font-bold text-[#e5e1e7]">Sanction Appeal</h1>
                    </div>

                    <div className="bg-[#2a292e] rounded-[24px] p-5 mb-8">
                        <p className="text-[#cfc2d7] text-sm leading-relaxed">
                            You have been <span className="font-semibold text-[#ddb8ff]">{type.toLowerCase()}ed</span> from the server. 
                            If you believe this was a mistake or you would like to apologize and request another chance, please provide a detailed explanation below.
                        </p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-sm font-medium text-[#e5e1e7] ml-2 flex items-center justify-between">
                                Appeal Reason
                                {error && <span className="text-[#ffb4ab] text-xs">{error}</span>}
                            </label>
                            <textarea
                                value={reason}
                                onChange={(e) => setReason(e.target.value)}
                                placeholder="Explain why you should be unbanned..."
                                className={`w-full h-40 bg-[#0e0e12] text-[#e5e1e7] placeholder-[#cfc2d7]/50 rounded-[24px] p-5 resize-none transition-all duration-200 outline-none
                                    ${error ? 'ring-1 ring-[#ffb4ab]/50' : 'focus:ring-2 focus:ring-[#9333ea]/50'}`}
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={submitting}
                            className="w-full h-14 bg-gradient-to-br from-[#ddb8ff] to-[#9333ea] hover:from-[#e5ccff] hover:to-[#a855f7] 
                                text-[#490080] font-bold rounded-[32px] flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_40px_rgba(208,161,254,0.15)] hover:shadow-[0_0_40px_rgba(208,161,254,0.3)]"
                        >
                            {submitting ? "Submitting..." : (
                                <>
                                    Submit Appeal
                                    <ArrowRight className="w-5 h-5" />
                                </>
                            )}
                        </button>
                    </form>
                </div>
            </motion.div>
        </div>
    );
}

export default function AppealPage() {
    return (
        <Suspense fallback={
            <div className="flex min-h-screen items-center justify-center bg-[#131317]">
                <div className="w-8 h-8 border-4 border-[#9333ea] border-t-transparent rounded-full animate-spin"></div>
            </div>
        }>
            <AppealForm />
        </Suspense>
    );
}
