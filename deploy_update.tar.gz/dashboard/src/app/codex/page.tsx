"use client";

import React from "react";
import dynamic from "next/dynamic";
import Navbar from "@/components/Navbar";
import { motion } from "framer-motion";

// Performance Optimization: Offloading heavy sectors
const Starfield = dynamic(() => import("@/components/Starfield"), { 
  ssr: false,
  loading: () => <div className="fixed inset-0 bg-[#050508]" /> 
});

const Codex = dynamic(() => import("@/components/Codex"), { 
  ssr: false,
  loading: () => (
    <div className="min-h-screen flex items-center justify-center bg-[#050508]">
       <div className="flex flex-col items-center gap-4 text-white/10 italic">
          <div className="w-6 h-6 rounded-full border-2 border-white/5 border-t-white/20 animate-spin" />
          <span className="text-[10px] uppercase tracking-widest font-bold">Loading Documentation...</span>
       </div>
    </div>
  )
});

export default function CodexPage() {
  return (
    <main className="relative min-h-screen bg-[#050508]/0 text-white overflow-hidden font-sans">
      {/* Background Engine */}
      <Starfield />

      {/* Navigation Hub */}
      <Navbar />

      {/* Integrated Metadata Header */}
      <section className="pt-24 pb-4 md:pt-36 md:pb-8 px-6 relative z-10 text-center">
         <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, ease: "easeOut" }}
           className="max-w-[800px] mx-auto"
         >
            <div className="flex items-center justify-center gap-3 mb-6">
               <div className="h-[1px] w-8 md:w-12 bg-white/10" />
               <span className="text-[10px] md:text-[11px] font-bold uppercase tracking-[0.4em] text-white/20">Guides & Documentation</span>
               <div className="h-[1px] w-8 md:w-12 bg-white/10" />
            </div>
            <h1 className="text-5xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-br from-white via-white/80 to-neutral-800 uppercase tracking-tighter mb-8 leading-[0.9]">
              DOCUMENTATION<span className="text-white/10 italic font-medium">.</span>
            </h1>
            <p className="text-[10px] md:text-xs text-white/30 max-w-[450px] mx-auto leading-relaxed font-black uppercase tracking-[0.4em]">
               The complete operational manifest for the Enc Nexus platform. Built for elite communities.
            </p>
         </motion.div>
      </section>

      {/* Main Codex Manifest (Lazy Loaded) */}
      <Codex />
    </main>
  );
}
