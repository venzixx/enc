import React from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function PrivacyPage() {
  return (
    <main className="relative min-h-screen text-white font-sans selection:bg-accent-blue/30 overflow-x-hidden">
      <Navbar />
      
      <div className="pt-40 pb-20 px-6 max-w-4xl mx-auto relative z-10">
        <h1 className="surgical-headline text-5xl mb-4 text-center">Privacy Policy</h1>
        <p className="text-white/40 text-center mb-16 text-sm font-medium tracking-[0.2em] uppercase">Last Updated: April 2026</p>
        
        <div className="glass-panel p-8 md:p-12 space-y-12">
          <section>
            <h2 className="surgical-headline text-2xl mb-4">1. Information We Collect</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>When you use ENC, we may collect and store limited data necessary for the bot to function properly. This may include:</p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-accent-blue/80">
                <li>Discord User IDs</li>
                <li>Server (Guild) IDs</li>
                <li>Channel IDs</li>
                <li>Role IDs</li>
                <li>Message IDs (for moderation/logging purposes)</li>
                <li>Basic server configuration settings</li>
              </ul>
              <p>We do not collect personal information such as email addresses, passwords, or private account details.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">2. How We Use Information</h2>
            <div className="text-white/60 leading-relaxed space-y-2">
              <p>The data collected is used strictly to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-accent-blue/80">
                <li>Provide bot features (moderation, security, logging, automation)</li>
                <li>Store server-specific settings</li>
                <li>Improve bot performance and reliability</li>
                <li>Prevent abuse, spam, and malicious activity</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">3. Data Storage</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>Data is stored securely and only retained as long as necessary. Server configuration data is kept until removed by administrators or the bot is removed. Logs may be stored temporarily for moderation purposes.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">4. Data Sharing</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>We do not sell, trade, or share your data with third parties, except:</p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-accent-blue/80">
                <li>When required by law</li>
                <li>To comply with Discord’s Terms of Service</li>
                <li>To protect the integrity and security of ENC</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">5. User Control & Data Removal</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>Server administrators can remove ENC from their server at any time (which deletes associated server data) or request data deletion by contacting the bot developer.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">6. Security</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>We take reasonable steps to protect stored data, but no system is completely secure. Use the bot at your own discretion.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">7. Changes to This Policy</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>This Privacy Policy may be updated periodically. When significant changes occur, we will notify users through the official ENC support server. Continued use of ENC after updates means you accept the revised policy.</p>
            </div>
          </section>
        </div>
      </div>

      <Footer />
    </main>
  );
}
