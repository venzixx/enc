"use client";

import { useSearchParams } from "next/navigation";
import { useState, Suspense } from "react";
import { AlertCircle, ShieldCheck, ArrowRight, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

function AppealForm() {
    const searchParams = useSearchParams();
    const guildId = searchParams.get("g");
    const userId = searchParams.get("u");
    const type = searchParams.get("t");
    const signature = searchParams.get("s");

    const [reason, setReason] = useState("");
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);

    if (!guildId || !userId || !type || !signature) {
        return (
            <div className="flex min-h-screen items-center justify-center p-6 font-sans">
                <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white/[0.02] backdrop-blur-3xl p-10 rounded-[40px] max-w-md w-full border border-red-500/20 shadow-2xl relative overflow-hidden"
                >
                    <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-transparent pointer-events-none" />
                    <div className="relative z-10 flex flex-col items-center text-center gap-6">
                        <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center border border-red-500/20 shadow-inner">
                            <AlertCircle className="w-8 h-8 text-red-400" />
                        </div>
                        <div className="space-y-2">
                            <h2 className="text-2xl font-black text-white uppercase tracking-tight">Access Restricted</h2>
                            <p className="text-white/30 text-xs font-bold uppercase tracking-[0.2em] leading-relaxed">
                                This neural link is invalid or has expired. Please utilize the original transmission provided via Direct Message.
                            </p>
                        </div>
                    </div>
                </motion.div>
            </div>
        );
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!reason.trim()) {
            setError("Manifest required for transmission.");
            return;
        }

        setSubmitting(true);
        setError("");

        try {
            const res = await fetch("/api/appeal/submit", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    guildId,
                    userId,
                    type,
                    tag: searchParams.get("tag"),
                    r: searchParams.get("r"),
                    reason,
                    signature
                }),
            });

            const data = await res.json();

            if (!res.ok) {
                setError(data.error || "Uplink failed. Retrying...");
            } else {
                setSuccess(true);
            }
        } catch (err) {
            setError("Quantum instability detected. Re-establish link.");
        } finally {
            setSubmitting(false);
        }
    };

    if (success) {
        return (
            <div className="flex min-h-screen items-center justify-center p-6 font-sans">
                <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    className="bg-white/[0.01] backdrop-blur-3xl p-12 rounded-[48px] max-w-md w-full border border-indigo-500/20 shadow-2xl relative overflow-hidden text-center"
                >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent pointer-events-none" />
                    
                    <div className="relative z-10 flex flex-col items-center gap-8">
                        <div className="w-20 h-20 bg-indigo-500/10 rounded-3xl flex items-center justify-center border border-indigo-500/20 shadow-inner group transition-transform hover:scale-110">
                            <CheckCircle2 className="w-10 h-10 text-indigo-400" />
                        </div>
                        <div className="space-y-3">
                            <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Transmission Sent</h2>
                            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.2em] leading-relaxed">
                                Your appeal manifest has been successfully uploaded to the server's security core. Decision pending.
                            </p>
                        </div>
                    </div>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="flex min-h-screen items-center justify-center p-6 font-sans">
            <motion.div 
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="bg-white/[0.01] backdrop-blur-3xl p-10 md:p-14 rounded-[56px] max-w-2xl w-full border border-white/5 shadow-2xl relative overflow-hidden"
            >
                {/* Orbital Accents */}
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" />
                <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-purple-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" />
                
                <div className="relative z-10 space-y-12">
                    <div className="flex flex-col items-center md:items-start gap-6">
                        <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 shadow-inner">
                            <ShieldCheck className="w-7 h-7 text-indigo-400" />
                        </div>
                        <div className="text-center md:text-left space-y-2">
                            <h1 className="text-4xl font-black text-white uppercase tracking-tighter">Sanction Appeal</h1>
                            <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Protocol Node // Unauthenticated Secure Uplink</p>
                        </div>
                    </div>

                    <div className="bg-white/[0.02] border border-white/5 rounded-[32px] p-8 shadow-inner">
                        <p className="text-white/40 text-[11px] font-black uppercase tracking-[0.1em] leading-relaxed">
                            You have been <span className="text-white bg-indigo-500/20 px-2 py-1 rounded-md">{type.toLowerCase()}ed</span> from the server cluster. 
                            Provide your justification below for security review.
                        </p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-10">
                        <div className="space-y-4">
                            <div className="flex items-center justify-between px-2">
                                <label className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Appeal Manifest</label>
                                {error && <motion.span initial={{ x: 10, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="text-red-400 text-[9px] font-black uppercase tracking-widest">{error}</motion.span>}
                            </div>
                            <textarea
                                value={reason}
                                onChange={(e) => setReason(e.target.value)}
                                placeholder="State your case..."
                                className={`w-full h-48 bg-white/[0.02] text-white placeholder-white/5 rounded-[32px] p-8 resize-none transition-all duration-300 outline-none shadow-inner text-sm font-medium
                                    ${error ? 'border border-red-500/30' : 'border border-white/5 focus:border-indigo-500/30 focus:bg-white/[0.03]'}`}
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={submitting}
                            className="w-full h-20 bg-white text-black font-black uppercase tracking-[0.4em] rounded-[32px] flex items-center justify-center gap-4 transition-all duration-500 disabled:opacity-20 disabled:cursor-not-allowed shadow-2xl hover:bg-zinc-200 group text-[11px]"
                        >
                            {submitting ? "Transmitting..." : (
                                <>
                                    Initialize Upload
                                    <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                                </>
                            )}
                        </button>
                    </form>
                </div>
            </motion.div>
        </div>
    );
}

export default function AppealPage() {
    return (
        <Suspense fallback={
            <div className="flex min-h-screen items-center justify-center bg-[#131317]">
                <div className="w-8 h-8 border-4 border-[#9333ea] border-t-transparent rounded-full animate-spin"></div>
            </div>
        }>
            <AppealForm />
        </Suspense>
    );
}
