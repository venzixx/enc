import { getGuildRoles } from "@/lib/discord";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  try {
    const roles = await getGuildRoles(guildId);
    // Filter out @everyone if you want, or managed roles
    const filteredRoles = roles
      .filter(r => r.name !== "@everyone" && (!r.managed || r.tags?.premium_subscriber === null))
      .sort((a, b) => b.position - a.position);

    return NextResponse.json(filteredRoles);
  } catch (error) {
    console.error("[ROLES_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
