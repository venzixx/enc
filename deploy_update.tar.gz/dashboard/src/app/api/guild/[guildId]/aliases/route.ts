import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const aliases = await prisma.commandAlias.findMany({
      where: { guildId }
    });

    return NextResponse.json(aliases);
  } catch (error) {
    console.error("[ALIASES_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { alias, commandName } = await req.json();
    if (!alias || !commandName) return new NextResponse("Missing data", { status: 400 });

    const existing = await prisma.commandAlias.findUnique({
      where: { 
        guildId_alias: {
          guildId,
          alias: alias.toLowerCase().trim()
        }
      }
    });

    if (existing) {
      await prisma.commandAlias.update({
        where: { id: existing.id },
        data: { commandName }
      });
    } else {
      await prisma.commandAlias.create({
        data: {
          guildId,
          alias: alias.toLowerCase().trim(),
          commandName
        }
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[ALIASES_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return new NextResponse("Missing ID", { status: 400 });

    await prisma.commandAlias.delete({
      where: { id: parseInt(id), guildId }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[ALIASES_DELETE]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
