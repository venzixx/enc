import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
    req: Request,
    { params }: { params: Promise<{ guildId: string }> }
) {
    try {
        const { guildId } = await params;
        const session = await getServerSession(authOptions);

        if (!session) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const tiers = await prisma.streakTier.findMany({
            where: { guildId },
            orderBy: { threshold: 'asc' }
        });

        return NextResponse.json(tiers);
    } catch (error) {
        console.error("[STREAKTIER_GET]", error);
        return new NextResponse("Internal Error", { status: 500 });
    }
}

export async function POST(
    req: Request,
    { params }: { params: Promise<{ guildId: string }> }
) {
    try {
        const { guildId } = await params;
        const session = await getServerSession(authOptions);

        if (!session) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const body = await req.json();
        const { name, threshold } = body;

        if (!name || !threshold) {
            return new NextResponse("Missing data", { status: 400 });
        }

        // Check if threshold exists
        const existing = await prisma.streakTier.findUnique({
            where: {
                guildId_threshold: {
                    guildId,
                    threshold: Number(threshold)
                }
            }
        });

        if (existing) {
            return new NextResponse("A tier with this threshold already exists", { status: 400 });
        }

        const tier = await prisma.streakTier.create({
            data: {
                guildId,
                name,
                threshold: Number(threshold)
            }
        });

        return NextResponse.json(tier);
    } catch (error) {
        console.error("[STREAKTIER_POST]", error);
        return new NextResponse("Internal Error", { status: 500 });
    }
}

export async function DELETE(
    req: Request,
    { params }: { params: Promise<{ guildId: string }> }
) {
    try {
        const { guildId } = await params;
        const session = await getServerSession(authOptions);

        if (!session) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const url = new URL(req.url);
        const id = url.searchParams.get("id");

        if (!id) {
            return new NextResponse("Missing id", { status: 400 });
        }

        await prisma.streakTier.delete({
            where: {
                id: Number(id)
            }
        });

        return new NextResponse("Deleted", { status: 200 });
    } catch (error) {
        console.error("[STREAKTIER_DELETE]", error);
        return new NextResponse("Internal Error", { status: 500 });
    }
}

export async function PATCH(
    req: Request,
    { params }: { params: Promise<{ guildId: string }> }
) {
    try {
        const { guildId } = await params;
        const session = await getServerSession(authOptions);

        if (!session) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const body = await req.json();
        const { id, name, threshold, message, embedData, imageUrl } = body;

        if (!id) {
            return new NextResponse("Missing id", { status: 400 });
        }

        // Check if updating threshold to one that already exists
        if (threshold) {
            const existing = await prisma.streakTier.findFirst({
                where: {
                    guildId,
                    threshold: Number(threshold),
                    NOT: { id: Number(id) }
                }
            });
            if (existing) {
                return new NextResponse("A tier with this threshold already exists", { status: 400 });
            }
        }

        const tier = await prisma.streakTier.update({
            where: { id: Number(id) },
            data: {
                name,
                threshold: threshold ? Number(threshold) : undefined,
                message,
                embedData,
                imageUrl
            }
        });

        return NextResponse.json(tier);
    } catch (error) {
        console.error("[STREAKTIER_PATCH]", error);
        return new NextResponse("Internal Error", { status: 500 });
    }
}
