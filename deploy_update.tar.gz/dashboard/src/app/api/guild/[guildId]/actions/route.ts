import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session = await getServerSession(authOptions);
  if (!session) return new NextResponse('Unauthorized', { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const customId = searchParams.get('customId');

    if (customId) {
      const action = await prisma.componentAction.findUnique({
        where: {
          guildId_customId: {
            guildId: guildId,
            customId: customId
          }
        }
      });
      return NextResponse.json(action);
    }

    const actions = await prisma.componentAction.findMany({
      where: { guildId: guildId }
    });
    return NextResponse.json(actions);
  } catch (error) {
    return new NextResponse('Internal Error', { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session = await getServerSession(authOptions);
  if (!session) return new NextResponse('Unauthorized', { status: 401 });

  try {
    const body = await req.json();
    const { customId, logic } = body;

    if (!customId || !logic) {
      return new NextResponse('Missing required fields', { status: 400 });
    }

    const action = await prisma.componentAction.upsert({
      where: {
        guildId_customId: {
          guildId: guildId,
          customId: customId
        }
      },
      update: {
        logic: JSON.stringify(logic)
      },
      create: {
        guildId: guildId,
        customId,
        logic: JSON.stringify(logic)
      }
    });

    return NextResponse.json(action);
  } catch (error) {
    console.error(error);
    return new NextResponse('Internal Error', { status: 500 });
  }
}
