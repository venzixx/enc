import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { unbanUser, createInvite, sendDM, getGuildChannels, getGuild } from "@/lib/discord";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    // List appeals for the guild (Staff view)
    const appeals = await prisma.appeal.findMany({
      where: { guildId },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(appeals);
  } catch (error) {
    console.error("[APPEALS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { type, reason, appealReason } = body;

    const appeal = await prisma.appeal.create({
      data: {
        guildId,
        userId: session.user.id,
        userTag: session.user.name || "Unknown",
        type: type || "BAN",
        reason: reason || "No reason specified",
        appealReason,
      },
    });

    return NextResponse.json(appeal);
  } catch (error) {
    console.error("[APPEALS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { appealId, status, staffReason } = body;

    if (!appealId || !status) {
      return new NextResponse("Missing data", { status: 400 });
    }

    // Update appeal status
    const appeal = await prisma.appeal.update({
      where: { id: Number(appealId) },
      data: {
        status,
        staffId: session.user.id,
        staffReason,
      },
    });

    const guildInfo = await getGuild(guildId);
    const guildName = guildInfo?.name || "the server";

    if (status === "APPROVED") {
      // 1. Unban if it was a ban
      if (appeal.type === "BAN") {
        await unbanUser(guildId, appeal.userId);
      }

      // 2. Generate invite link
      const channels = await getGuildChannels(guildId);
      const textChannel = channels.find(c => c.type === 0); // Find first text channel
      
      let inviteLink = null;
      if (textChannel) {
        inviteLink = await createInvite(textChannel.id);
      }

      // 3. Send DM to user
      await sendDM(appeal.userId, {
        embeds: [{
          title: "<:success:1494693113216634880> Appeal Approved",
          description: `Your appeal for **${guildName}** has been approved.\n\n**Type:** ${appeal.type}\n**Staff Reason:** ${staffReason || "No reason provided."}`,
          color: 0x10B981, // Green
          fields: inviteLink ? [{
            name: "Rejoin the Server",
            value: `[Click here to join](${inviteLink})`
          }] : []
        }]
      });
    } else if (status === "REJECTED") {
      // Send DM to user about rejection
      await sendDM(appeal.userId, {
        embeds: [{
          title: "<:cross:1494693110553509939> Appeal Rejected",
          description: `Your appeal for **${guildName}** has been rejected.\n\n**Type:** ${appeal.type}\n**Staff Reason:** ${staffReason || "No reason provided."}`,
          color: 0xEF4444, // Red
        }]
      });
    }

    return NextResponse.json(appeal);
  } catch (error) {
    console.error("[APPEALS_PATCH]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
