import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { guildId } = await params;

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgoStr = thirtyDaysAgo.toISOString().split('T')[0];
    const sixtyDaysAgoStr = sixtyDaysAgo.toISOString().split('T')[0];

    // 1. Message Stats & Comparison
    const currentMessages = await prisma.userDailyActivity.aggregate({
      where: { guildId, date: { gte: thirtyDaysAgoStr } },
      _sum: { messageCount: true }
    });

    const previousMessages = await prisma.userDailyActivity.aggregate({
      where: { guildId, date: { gte: sixtyDaysAgoStr, lt: thirtyDaysAgoStr } },
      _sum: { messageCount: true }
    });

    const msgCount = currentMessages._sum.messageCount || 0;
    const prevMsgCount = previousMessages._sum.messageCount || 0;
    const msgChange = prevMsgCount === 0 ? 100 : Math.round(((msgCount - prevMsgCount) / prevMsgCount) * 100);

    // 2. Reaction Stats
    const currentReactions = await prisma.reactionDailyActivity.aggregate({
      where: { guildId, date: { gte: thirtyDaysAgoStr } },
      _sum: { reactionCount: true }
    });

    const prevReactions = await prisma.reactionDailyActivity.aggregate({
      where: { guildId, date: { gte: sixtyDaysAgoStr, lt: thirtyDaysAgoStr } },
      _sum: { reactionCount: true }
    });

    const reactCount = currentReactions._sum.reactionCount || 0;
    const prevReactCount = prevReactions._sum.reactionCount || 0;
    const reactChange = prevReactCount === 0 ? 100 : Math.round(((reactCount - prevReactCount) / prevReactCount) * 100);

    // 3. Voice Stats
    const currentVoice = await prisma.voiceDailyActivity.aggregate({
      where: { guildId, date: { gte: thirtyDaysAgoStr } },
      _sum: { seconds: true }
    });

    const prevVoice = await prisma.voiceDailyActivity.aggregate({
      where: { guildId, date: { gte: sixtyDaysAgoStr, lt: thirtyDaysAgoStr } },
      _sum: { seconds: true }
    });

    const voiceSeconds = currentVoice._sum.seconds || 0;
    const prevVoiceSeconds = prevVoice._sum.seconds || 0;
    const voiceChange = prevVoiceSeconds === 0 ? 100 : Math.round(((voiceSeconds - prevVoiceSeconds) / prevVoiceSeconds) * 100);
    const voiceHours = Math.round((voiceSeconds / 3600) * 10) / 10;

    // 4. Graph Data (Last 7 Days)
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const sevenDaysAgoStr = sevenDaysAgo.toISOString().split('T')[0];

    const dailyActivity = await prisma.userDailyActivity.groupBy({
      by: ['date'],
      where: { guildId, date: { gte: sevenDaysAgoStr } },
      _sum: { messageCount: true },
      orderBy: { date: 'asc' }
    });

    // 5. Top Channels
    const topChannels = await prisma.channelDailyActivity.groupBy({
      by: ['channelId'],
      where: { guildId },
      _sum: { messageCount: true },
      orderBy: { _sum: { messageCount: 'desc' } },
      take: 5
    });

    // 6. Top Members (Messages)
    const topMembers = await (prisma.member as any).findMany({
      where: { guildId },
      orderBy: { messages: 'desc' },
      take: 5,
      select: { userId: true, messages: true, lastUsername: true, lastAvatar: true }
    });

    // 7. Get Channel Names
    const channelIds = topChannels.map(c => c.channelId);
    const channels = await (prisma as any).channel.findMany({
      where: { id: { in: channelIds } }
    });

    return NextResponse.json({
      stats: {
        messages: { value: msgCount, change: msgChange },
        reactions: { value: reactCount, change: reactChange },
        voice: { value: voiceHours, change: voiceChange }
      },
      graphData: dailyActivity.map(d => ({
        date: d.date,
        messages: d._sum.messageCount || 0
      })),
      topChannels: topChannels.map(c => ({
        id: c.channelId,
        name: (channels as any[]).find(ch => ch.id === c.channelId)?.name || `NODE_${c.channelId.slice(0, 6)}`,
        count: c._sum.messageCount || 0
      })),
      topMembers: (topMembers as any[]).map(m => ({
        id: m.userId,
        name: m.lastUsername || `ENTITY_${m.userId.slice(-8)}`,
        avatar: m.lastAvatar,
        count: m.messages
      }))
    });
  } catch (error) {
    console.error("Analytics API Error:", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
