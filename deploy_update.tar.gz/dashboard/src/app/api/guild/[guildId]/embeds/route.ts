import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session = await getServerSession(authOptions);
  if (!session) return new NextResponse('Unauthorized', { status: 401 });

  try {
    const embeds = await prisma.savedEmbed.findMany({
      where: { guildId: guildId },
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json(embeds);
  } catch (error) {
    return new NextResponse('Internal Error', { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session = await getServerSession(authOptions);
  if (!session) return new NextResponse('Unauthorized', { status: 401 });

  try {
    const body = await req.json();
    const { name, tag, data } = body;

    if (!name || !tag || !data) {
      return new NextResponse('Missing required fields', { status: 400 });
    }

    // Validate tag format (slug-like)
    const tagRegex = /^[a-zA-Z0-9_]+$/;
    if (!tagRegex.test(tag)) {
      return new NextResponse('Invalid tag format. Use alphanumeric and underscores only.', { status: 400 });
    }

    const embed = await prisma.savedEmbed.upsert({
      where: {
        guildId_tag: {
          guildId: guildId,
          tag: tag
        }
      },
      update: {
        name,
        data: JSON.stringify(data)
      },
      create: {
        guildId: guildId,
        name,
        tag,
        data: JSON.stringify(data)
      }
    });

    return NextResponse.json(embed);
  } catch (error) {
    console.error(error);
    return new NextResponse('Internal Error', { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session = await getServerSession(authOptions);
  if (!session) return new NextResponse('Unauthorized', { status: 401 });

  try {
    const { searchParams } = new URL(req.url);
    const tag = searchParams.get('tag');

    if (!tag) return new NextResponse('Missing tag', { status: 400 });

    await prisma.savedEmbed.delete({
      where: {
        guildId_tag: {
          guildId: guildId,
          tag: tag
        }
      }
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    return new NextResponse('Internal Error', { status: 500 });
  }
}
