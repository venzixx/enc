import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET(
    req: Request,
    { params }: { params: Promise<{ guildId: string }> }
) {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
        return new NextResponse("Unauthorized", { status: 401 });
    }

    try {
        const logs = await prisma.auditLog.findMany({
            where: { guildId },
            orderBy: { createdAt: 'desc' },
            take: 50,
        });

        return NextResponse.json(logs);
    } catch (error) {
        console.error("Failed to fetch audit logs:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}
