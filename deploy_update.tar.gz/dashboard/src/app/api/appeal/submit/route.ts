import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import crypto from "crypto";

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { guildId, userId, type, tag, r, reason, signature } = body;

        if (!guildId || !userId || !type || !reason || !signature) {
            return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
        }

        const data = `${guildId}:${userId}:${type}`;
        const secret = process.env.DISCORD_CLIENT_SECRET || process.env.TOKEN || 'fallback-secret';
        const hmac = crypto.createHmac('sha256', secret);
        hmac.update(data);
        const expectedSignature = hmac.digest('hex');

        if (signature !== expectedSignature) {
            return NextResponse.json({ error: "Invalid signature. This appeal link may be expired or malformed." }, { status: 403 });
        }

        // Check if an appeal already exists for this user/guild
        const existingAppeal = await prisma.appeal.findFirst({
            where: {
                guildId,
                userId,
                status: "PENDING"
            }
        });

        if (existingAppeal) {
            return NextResponse.json({ error: "An appeal is already pending for this sanction." }, { status: 400 });
        }

        // Create the appeal in the database
        const appeal = await prisma.appeal.create({
            data: {
                guildId,
                userId,
                userTag: tag || "Unknown",
                type: type,
                reason: r || "No reason specified",
                appealReason: reason,
                status: "PENDING"
            }
        });

        return NextResponse.json({ success: true, appealId: appeal.id });
    } catch (error) {
        console.error("Appeal submit error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}
