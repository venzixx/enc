import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getUserGuilds, getBotGuilds, hasAdminPermission } from "@/lib/discord";
import { getDiscordAsset } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const session: any = await getServerSession(authOptions);
    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const [userGuilds, botGuilds] = await Promise.all([
      getUserGuilds(session.accessToken || ""),
      getBotGuilds(),
    ]);

    const activeGuilds = userGuilds
      .filter(guild =>
        botGuilds.some(bg => bg.id === guild.id) &&
        (guild.owner || hasAdminPermission(guild.permissions || ""))
      )
      .map(g => ({
        id: g.id,
        name: g.name,
        icon: g.icon ? getDiscordAsset('icon', g.id, g.icon) : null,
      }));

    return NextResponse.json(activeGuilds);
  } catch (error) {
    console.error("[GUILDS_LIST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
