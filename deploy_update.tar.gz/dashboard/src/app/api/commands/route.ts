import { NextRequest, NextResponse } from "next/server";
import { readdirSync, readFileSync } from "fs";
import { join } from "path";

interface CommandInfo {
  name: string;
  category: string;
  description: string;
  usage: string;
  examples: string[];
  aliases?: string[];
  cooldown?: number;
  permissions?: {
    user?: string[];
    client?: string[];
  };
}

/**
 * API Route: /api/commands
 * Dynamically reads and returns all bot commands from src/commands directory
 * Scans command files and extracts metadata
 */
export async function GET(request: NextRequest) {
  try {
    const commandsPath = join(process.cwd(), "..", "src", "commands");
    const commands: CommandInfo[] = [];
    const categories: { [key: string]: CommandInfo[] } = {};

    try {
      // Read all category folders (config, fun, moderation, music, utility)
      const categories_list = readdirSync(commandsPath, { withFileTypes: true })
        .filter((f) => f.isDirectory())
        .map((f) => f.name);

      for (const category of categories_list) {
        const categoryPath = join(commandsPath, category);
        const files = readdirSync(categoryPath).filter((f) =>
          f.endsWith(".ts")
        );

        categories[category] = [];

        for (const file of files) {
          const filePath = join(categoryPath, file);
          try {
            // Read the file content
            const content = readFileSync(filePath, "utf-8");

            // Extract command metadata using regex
            const nameMatch = content.match(/name:\s*["']([^"']+)["']/);
            const descriptionMatch = content.match(
              /description:\s*{[^}]*content:\s*["']([^"']+)["']/
            );
            const usageMatch = content.match(
              /usage:\s*["']([^"']+)["']/
            );
            const cooldownMatch = content.match(/cooldown:\s*(\d+)/);
            const aliasesMatch = content.match(/aliases:\s*\[([^\]]*)\]/);

            // Extract options (subcommands) - looking for the options array
            // This is a bit complex with regex, but we can try to find the block
            const optionsMatch = content.match(/options:\s*\[([\s\S]*?)\]\s*}\s*\)\s*;/);
            const hiddenMatch = content.match(/hidden:\s*true/);
            const slashMatch = content.match(/slashCommand:\s*false/);

            if (nameMatch && !hiddenMatch && !slashMatch) {
              const command: CommandInfo & { subcommands?: any[] } = {
                name: nameMatch[1],
                category,
                description: descriptionMatch
                  ? descriptionMatch[1]
                  : "No description",
                usage: usageMatch ? usageMatch[1] : "",
                examples: [],
                cooldown: cooldownMatch ? parseInt(cooldownMatch[1], 10) : 3,
              };

              // Simple subcommand parsing logic
              // We look for name/description pairs inside the options array
              if (optionsMatch) {
                const optionsContent = optionsMatch[1];
                const subcommands: any[] = [];
                
                // Matches patterns like { name: 'sub', description: 'desc' }
                const subMatchRegex = /{[\s\n]*name:\s*['"]([^'"]+)['"],[\s\n]*description:\s*['"]([^'"]+)['"]/g;
                let m;
                while ((m = subMatchRegex.exec(optionsContent)) !== null) {
                  if (m[1] !== command.name) { // Avoid matching the main command again if nested
                    subcommands.push({
                      name: m[1],
                      description: m[2]
                    });
                  }
                }
                
                if (subcommands.length > 0) {
                  command.subcommands = subcommands;
                }
              }

              // Extract aliases if present
              if (aliasesMatch && aliasesMatch[1]) {
                const aliasStr = aliasesMatch[1];
                command.aliases = aliasStr
                  .split(",")
                  .map((a) => a.trim().replace(/["']/g, ""))
                  .filter(Boolean);
              }

              commands.push(command);
              categories[category]?.push(command);
            }
          } catch (err) {
            console.error(`Error parsing command file ${file}:`, err);
          }
        }
      }

      return NextResponse.json(
        {
          success: true,
          totalCommands: commands.length,
          categories: Object.keys(categories).map((cat) => ({
            name: cat,
            count: categories[cat]?.length || 0,
            commands: categories[cat] || [],
          })),
          allCommands: commands,
          timestamp: new Date().toISOString(),
        },
        {
          status: 200,
          headers: {
            "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600", // Cache for 5 min
          },
        }
      );
    } catch (fsError) {
      console.error("Error reading commands directory:", fsError);
      // Fallback: return hardcoded command list
      return NextResponse.json(
        {
          success: false,
          error: "Could not read commands directory",
          totalCommands: 81,
          categories: [
            { name: "config", count: 19 },
            { name: "fun", count: 5 },
            { name: "moderation", count: 6 },
            { name: "music", count: 30 },
            { name: "utility", count: 21 },
          ],
          timestamp: new Date().toISOString(),
        },
        { status: 200 }
      );
    }
  } catch (error) {
    console.error("API error:", error);
    return NextResponse.json(
      {
        error: "Failed to fetch commands",
        totalCommands: 81,
      },
      { status: 500 }
    );
  }
}
