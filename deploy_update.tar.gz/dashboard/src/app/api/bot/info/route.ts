import { NextResponse } from "next/server";
import { getBotInfo } from "@/lib/discord";
import { getDiscordAsset } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const bot = await getBotInfo();
    
    if (!bot) {
      return new NextResponse("Failed to fetch bot info", { status: 500 });
    }

    return NextResponse.json({
      name: bot.username,
      avatar: bot.avatar 
        ? getDiscordAsset('avatar', bot.id, bot.avatar)
        : `https://cdn.discordapp.com/embed/avatars/${parseInt(bot.discriminator) % 5}.png`
    });
  } catch (error) {
    console.error("[BOT_INFO_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
