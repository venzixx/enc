"use client";

import React, { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import StatsSection from '@/components/StatsSection';
import QuickFeatures from '@/components/QuickFeatures';
import BotCapabilities from '@/components/BotCapabilities';
import HowItWorks from '@/components/HowItWorks';
import FAQ from '@/components/FAQ';
import CTASection from '@/components/CTASection';

// ── NOISE TEXTURE OVERLAY ────────────────────────────────────────────────────
function Noise() {
  return (
    <div
      className="pointer-events-none fixed inset-0 z-[100] opacity-[0.025]"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        backgroundSize: "200px",
      }}
    />
  );
}

export default function LandingPage() {
  const [stats, setStats] = useState({ guilds: 0, users: 0, uptime: 99.9, latency: 45 });

  useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch('/api/bot-stats');
        const data = await res.json();
        setStats(data);
      } catch (err) {
        console.error("Failed to fetch stats:", err);
      }
    }
    fetchStats();
    const interval = setInterval(fetchStats, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main className="relative bg-black/0 min-h-screen text-white font-sans selection:bg-white/30 selection:text-white overflow-x-hidden">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Inter:wght@100..900&family=Syne:wght@400..800&display=swap');
        
        :root {
          --font-dm: "DM Sans", sans-serif;
          --font-syne: "Syne", sans-serif;
        }

        body {
          background-color: #000;
          font-family: var(--font-dm);
          -webkit-font-smoothing: antialiased;
        }

        .surgical-headline {
          font-family: var(--font-syne);
          letter-spacing: -0.04em;
          font-weight: 800;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
          width: 6px;
        }
        ::-webkit-scrollbar-track {
          background: #000;
        }
        ::-webkit-scrollbar-thumb {
          background: #222;
          border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #333;
        }
      `}</style>

      <Noise />
      <Navbar />
      
      <HeroSection stats={stats} />
      <StatsSection stats={stats} />
      <QuickFeatures />
      <BotCapabilities />
      <HowItWorks />
      <FAQ />
      <CTASection />

      <Footer />
    </main>
  );
}
