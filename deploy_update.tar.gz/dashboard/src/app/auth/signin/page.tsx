"use client";

import React from "react";
import { signIn } from "next-auth/react";
import { Shield, Layout, Zap, ArrowRight, Lock } from "lucide-react";
import { motion } from "framer-motion";
import Starfield from "@/components/Starfield";

export default function SignInPage() {
  return (
    <div className="min-h-screen bg-[#050508] relative flex items-center justify-center overflow-hidden font-sans">
      {/* Background Layer */}
      <div className="fixed inset-0 z-0">
        <Starfield />
      </div>

      {/* Dynamic Background Gradients */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none animate-pulse" style={{ animationDelay: '2s' }} />

      <section className="relative z-10 w-full max-w-[360px]! px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative"
        >
          {/* Main Card */}
          <div className="bg-white/[0.03] border border-white/10 backdrop-blur-2xl rounded-[2rem] p-8 md:p-10 shadow-[0_30px_100px_rgba(0,0,0,0.5)] overflow-hidden relative group">
            {/* Top Shine Effect */}
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            
            <div className="flex flex-col items-center">
              {/* Animated Icon Header */}
              <motion.div 
                whileHover={{ rotate: 10, scale: 1.1 }}
                className="relative mb-6"
              >
                <div className="absolute inset-0 bg-blue-500 blur-2xl opacity-20" />
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl relative border border-white/20">
                  <Layout className="w-8 h-8 text-white" />
                </div>
              </motion.div>

              {/* Title Section */}
              <div className="text-center mb-8">
                <motion.h1 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="text-white text-2xl font-bold tracking-tight mb-2"
                >
                  Command Center
                </motion.h1>
                <motion.p 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-white/40 text-xs leading-relaxed max-w-[200px] mx-auto"
                >
                  Authorize your account to manage your instance.
                </motion.p>
              </div>

              {/* Primary Action Button */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="w-full space-y-4"
              >
                <button
                  onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}
                  className="w-full group relative flex items-center justify-center gap-2.5 py-3.5 bg-white text-black font-bold text-sm rounded-xl hover:bg-blue-50 transition-all duration-300 shadow-[0_0_30px_rgba(255,255,255,0.1)] active:scale-[0.98]"
                >
                  <Zap className="w-4 h-4 fill-current" />
                  <span>Log in with Discord</span>
                </button>

                <div className="flex justify-center gap-4 text-white/20 text-[10px] font-medium tracking-widest uppercase">
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-3 h-3" />
                    <span>Secure</span>
                  </div>
                  <div className="w-px h-2.5 bg-white/5 self-center" />
                  <div className="flex items-center gap-1.5">
                    <Lock className="w-3 h-3" />
                    <span>Private</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Footer Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-8 text-center"
          >
            <p className="text-[11px] text-white/20 uppercase tracking-[0.2em] font-medium mb-4">
              Authorized Personnel Only
            </p>
            <div className="flex justify-center gap-6">
              <a href="/" className="text-[10px] text-white/40 hover:text-white transition-colors font-bold uppercase tracking-widest">
                Support
              </a>
              <a href="/" className="text-[10px] text-white/40 hover:text-white transition-colors font-bold uppercase tracking-widest">
                Privacy
              </a>
            </div>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
