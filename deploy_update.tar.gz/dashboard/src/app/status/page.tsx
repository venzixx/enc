"use client";

import React, { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion as m, AnimatePresence } from "framer-motion";
import { 
  Activity, Shield, Zap, Database, 
  Cpu, Globe, CheckCircle2, AlertCircle,
  Clock, RefreshCcw, Server
} from "lucide-react";
import dynamic from "next/dynamic";

const Starfield = dynamic(() => import("@/components/Starfield"), { 
  ssr: false,
  loading: () => <div className="fixed inset-0 bg-[#050508]" /> 
});

interface SystemStatus {
  name: string;
  id: string;
  status: "OPERATIONAL" | "DEGRADED" | "OFFLINE";
  uptime: string;
  latency: string;
  icon: React.ReactNode;
}

export default function StatusPage() {
  const [loading, setLoading] = useState(true);
  const [lastSync, setLastSync] = useState<string>("");

  const systems: SystemStatus[] = [
    { 
      name: "Core Infrastructure", 
      id: "core", 
      status: "OPERATIONAL", 
      uptime: "100%", 
      latency: "12ms",
      icon: <Server className="w-5 h-5" />
    },
    { 
      name: "Discord Bot Service", 
      id: "bot", 
      status: "OPERATIONAL", 
      uptime: "99.9%", 
      latency: "45ms",
      icon: <Zap className="w-5 h-5" />
    },
    { 
      name: "Primary Database", 
      id: "db", 
      status: "OPERATIONAL", 
      uptime: "100%", 
      latency: "4ms",
      icon: <Database className="w-5 h-5" />
    },
    { 
      name: "Lavalink Node (US)", 
      id: "lava-us", 
      status: "OPERATIONAL", 
      uptime: "99.8%", 
      latency: "82ms",
      icon: <Activity className="w-5 h-5" />
    },
    { 
      name: "AI Processing Unit", 
      id: "ai", 
      status: "OPERATIONAL", 
      uptime: "100%", 
      latency: "120ms",
      icon: <Cpu className="w-5 h-5" />
    },
    { 
      name: "Web Dashboard", 
      id: "web", 
      status: "OPERATIONAL", 
      uptime: "100%", 
      latency: "18ms",
      icon: <Globe className="w-5 h-5" />
    },
  ];

  useEffect(() => {
    setLastSync(new Date().toLocaleTimeString());
    const timer = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <main className="relative min-h-screen bg-[#050508]/0 text-white font-sans overflow-x-hidden">
      <Starfield />
      <Navbar />

      <div className="relative z-10 pt-40 pb-32 px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Status Hero */}
          <div className="text-center mb-24">
            <m.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/[0.03] border border-white/10 mb-10 shadow-[0_0_50px_rgba(255,255,255,0.02)]"
            >
              <div className="relative">
                <div className="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_15px_white] animate-pulse" />
                <div className="absolute inset-0 w-2.5 h-2.5 rounded-full bg-white animate-ping opacity-20" />
              </div>
              <span className="text-[11px] font-black uppercase tracking-[0.4em] text-white/80">All Systems Operational</span>
            </m.div>

            <m.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-6xl md:text-8xl font-black uppercase tracking-tighter mb-8 leading-[0.8] text-transparent bg-clip-text bg-gradient-to-b from-white via-white to-neutral-800"
            >
              SYSTEM HEALTH<span className="text-white/10 italic font-medium">.</span>
            </m.h1>

            <m.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="text-white/30 text-[10px] md:text-xs font-black uppercase tracking-[0.6em] max-w-xl mx-auto leading-loose"
            >
              Real-time monitoring of the Enc Nexus core protocols and peripheral service clusters.
            </m.p>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="wait">
              {loading ? (
                <>
                  {[...Array(6)].map((_, i) => (
                    <m.div 
                      key={`skeleton-${i}`}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="bg-white/[0.02] border border-white/[0.05] p-8 rounded-[2.5rem] animate-pulse"
                    >
                      <div className="flex flex-col gap-8">
                        <div className="flex items-center justify-between">
                          <div className="w-12 h-12 rounded-2xl bg-white/5" />
                          <div className="flex flex-col items-end gap-2">
                            <div className="w-12 h-3 bg-white/5 rounded-full" />
                            <div className="w-16 h-5 bg-white/5 rounded-full" />
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div className="w-3/4 h-8 bg-white/5 rounded-lg" />
                          <div className="w-1/3 h-4 bg-white/5 rounded-full" />
                        </div>
                        <div className="pt-6 border-t border-white/[0.03] flex justify-between">
                          <div className="w-20 h-3 bg-white/5 rounded-full" />
                          <div className="w-12 h-4 bg-white/5 rounded-full" />
                        </div>
                      </div>
                    </m.div>
                  ))}
                </>
              ) : (
                systems.map((system, i) => (
                  <m.div
                    key={system.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
                    className="group relative bg-white/[0.02] border border-white/[0.05] p-8 rounded-[2.5rem] hover:bg-white/[0.04] hover:border-white/20 transition-all duration-700"
                  >
                    <div className="flex flex-col gap-8">
                      <div className="flex items-center justify-between">
                        <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-500">
                          {system.icon}
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Uptime</span>
                          <span className="text-sm font-black text-white uppercase tracking-tighter">{system.uptime}</span>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <h3 className="text-xl font-black text-white uppercase tracking-tighter">{system.name}</h3>
                        <div className="flex items-center gap-3">
                          <div className={`w-1.5 h-1.5 rounded-full ${system.status === "OPERATIONAL" ? "bg-white shadow-[0_0_10px_white]" : "bg-red-500 shadow-[0_0_10px_red]"}`} />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">{system.status}</span>
                        </div>
                      </div>

                      <div className="pt-6 border-t border-white/[0.03] flex items-center justify-between">
                         <div className="flex items-center gap-2">
                           <Clock className="w-3 h-3 text-white/10" />
                           <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Latency</span>
                         </div>
                         <span className="text-[11px] font-black text-white/60 tracking-tight">{system.latency}</span>
                      </div>
                    </div>
                  </m.div>
                ))
              )}
            </AnimatePresence>
          </div>

          {/* Sync Status Footer */}
          <m.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-20 flex flex-col md:flex-row items-center justify-between gap-8 p-10 rounded-[3rem] bg-white/[0.02] border border-white/[0.05] relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            
            <div className="flex items-center gap-6">
               <div className="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center text-white/20">
                  <Activity className="w-6 h-6" />
               </div>
               <div className="flex flex-col gap-1">
                  <h4 className="text-sm font-black uppercase tracking-widest text-white">Heartbeat Protocol Active</h4>
                  <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Global monitoring nodes are currently synchronized.</p>
               </div>
            </div>

            <div className="flex items-center gap-4 px-6 py-3 bg-white/5 rounded-2xl border border-white/10">
               <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Last Sync:</span>
               <span className="text-[10px] font-black text-white uppercase tracking-tighter">{lastSync}</span>
            </div>
          </m.div>

        </div>
      </div>

      <Footer />
    </main>
  );
}
