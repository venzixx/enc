import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getUserGuilds, getBotGuilds, hasAdminPermission } from "@/lib/discord";
import { redirect } from "next/navigation";
import DashboardContent from "@/components/DashboardContent";

export default async function DashboardSelector() {
  const session: any = await getServerSession(authOptions);

  if (!session) {
    redirect("/auth/signin");
  }

  const [userGuilds, botGuilds] = await Promise.all([
    getUserGuilds(session.accessToken || ""),
    getBotGuilds(),
  ]);

  // Guilds that have the bot added
  const activeGuilds = userGuilds.filter(guild =>
    botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  ).map(g => ({
    id: g.id,
    name: g.name,
    icon: g.icon,
    banner: g.banner,
    owner: !!g.owner,
    permissions: g.permissions || ""
  }));

  // Guilds that don't have the bot added but user is admin/owner
  const availableGuilds = userGuilds.filter(guild =>
    !botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  ).map(g => ({
    id: g.id,
    name: g.name,
    icon: g.icon,
    banner: g.banner,
    owner: !!g.owner,
    permissions: g.permissions || ""
  }));

  return (
    <DashboardContent 
      session={session}
      activeGuilds={activeGuilds}
      availableGuilds={availableGuilds}
    />
  );
}
