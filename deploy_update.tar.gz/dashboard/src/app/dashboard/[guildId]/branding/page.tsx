"use client";

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import QuoteCard from "@/components/QuoteCard";
import {
  Upload, Image as ImageIcon,
  RefreshCw, Sparkles, User, Save, Activity, Zap, Film, CheckCircle2, AlertCircle, Shield
} from "lucide-react";
import { useParams } from "next/navigation";

function ensureDataUrl(value: string): string {
  if (!value) return value;
  if (value.startsWith('data:')) return value;
  if (value.startsWith('http://') || value.startsWith('https://') || value.startsWith('/')) return value;
  try {
    const bytes = atob(value.slice(0, 16));
    const b = (i: number) => bytes.charCodeAt(i);
    let mime = 'image/png';
    if (b(0) === 0x47 && b(1) === 0x49 && b(2) === 0x46) mime = 'image/gif';
    else if (b(0) === 0xff && b(1) === 0xd8) mime = 'image/jpeg';
    else if (b(0) === 0x89 && b(1) === 0x50) mime = 'image/png';
    else if (b(0) === 0x52 && b(1) === 0x49) mime = 'image/webp';
    return `data:${mime};base64,${value}`;
  } catch {
    return `data:image/png;base64,${value}`;
  }
}

function isGif(src: string | null): boolean {
  if (!src) return false;
  const lower = src.toLowerCase();
  return (
    lower.startsWith('data:image/gif') || 
    lower.includes('.gif') || 
    lower.includes('/a_') || 
    lower.includes('format=gif') ||
    lower.includes('f=gif')
  );
}

type FileType = 'avatar' | 'banner';

interface DropZoneProps {
  label: string;
  preview: string | null;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onFileChange: (file: File, type: FileType) => void;
  type: FileType;
  aspectClass?: string;
}

function DropZone({ label, preview, inputRef, onFileChange, type, aspectClass = 'h-36' }: DropZoneProps) {
  const [dragging, setDragging] = useState(false);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) onFileChange(file, type);
  }, [onFileChange, type]);

  return (
    <div
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      className={`group relative ${aspectClass} rounded-2xl border transition-all cursor-pointer overflow-hidden flex flex-col items-center justify-center
        ${dragging
          ? 'border-white/30 bg-white/[0.06] scale-[1.01]'
          : 'border-white/5 bg-white/[0.02] hover:bg-white/[0.04] hover:border-white/10'
        }`}
    >
      {preview ? (
        <>
          <img src={preview} className="w-full h-full object-cover" alt={label} />
          {/* GIF badge */}
          {isGif(preview) && (
            <span className="absolute top-2 right-2 flex items-center gap-1 bg-black/70 border border-white/10 rounded-md px-2 py-0.5 text-[9px] font-bold text-emerald-400 uppercase tracking-widest backdrop-blur">
              <Film className="w-2.5 h-2.5" /> GIF
            </span>
          )}
          {/* Hover replace overlay */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
            <Upload className="w-5 h-5 text-white/60" />
            <span className="text-[9px] text-white/50 uppercase font-bold tracking-widest">Replace</span>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center gap-3 select-none pointer-events-none">
          <div className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-center">
            <Upload className="w-4 h-4 text-white/20 group-hover:text-white/40 transition-colors" />
          </div>
          <div className="text-center space-y-1">
            <p className="text-[10px] text-white/25 uppercase font-bold tracking-widest">{label}</p>
            <p className="text-[9px] text-white/10 font-medium">PNG · JPG · GIF · WEBP</p>
          </div>
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        accept="image/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFileChange(file, type);
          // Reset so the same file can be re-selected
          e.target.value = '';
        }}
      />
    </div>
  );
}

export default function BrandingPage() {
  const { guildId } = useParams();

  const [nickname, setNickname] = useState('');
  const [bio, setBio] = useState('');
  const [avatarBase64, setAvatarBase64] = useState<string | null>(null);
  const [bannerBase64, setBannerBase64] = useState<string | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!guildId) return;
    fetch(`/api/guild/${guildId}/branding`)
      .then(r => r.json())
      .then(data => {
        if (!data) return;
        setNickname(data.botNickname || data.fallbackNickname || '');
        setBio(data.botBio || '');
        setAvatarPreview(data.botAvatar ? ensureDataUrl(data.botAvatar) : data.fallbackAvatar);
        setBannerPreview(data.botBanner ? ensureDataUrl(data.botBanner) : data.fallbackBanner);
      })
      .catch(() => { });
  }, [guildId]);

  const handleImageFile = useCallback((file: File, type: FileType) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result as string;
      if (type === 'avatar') {
        setAvatarBase64(dataUrl);
        setAvatarPreview(dataUrl);
      } else {
        setBannerBase64(dataUrl);
        setBannerPreview(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  }, []);

  const handleSync = async () => {
    setStatus('loading');
    setErrorMsg('');
    try {
      const response = await fetch(`/api/guild/${guildId}/branding`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname, bio, avatar: avatarBase64, banner: bannerBase64 }),
      });
      if (!response.ok) throw new Error(await response.text());
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3500);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Something went wrong');
      setStatus('error');
      setTimeout(() => setStatus('idle'), 5000);
    }
  };

  const hasChanges = nickname || bio || avatarBase64 || bannerBase64;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      initial="hidden" 
      animate="show" 
      variants={container}
      className="p-8 max-w-6xl mx-auto space-y-10"
    >
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/20 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Bot Branding</h1>
            <p className="text-white/50 text-sm mt-1">Craft your bot's identity and visual presence across Discord.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           {status === 'success' && (
             <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">
                Sync Successful
             </motion.div>
           )}
           <button 
             onClick={handleSync}
             disabled={status === 'loading'}
             className={`px-8 py-3 rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] transition-all flex items-center gap-3 ${status === 'loading' ? 'bg-white/5 text-white/20' : 'bg-white text-black hover:bg-zinc-200'}`}
           >
             {status === 'loading' ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
             {status === 'loading' ? "SYNCING..." : "DEPLOY BRANDING"}
           </button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-12 items-start">
        {/* ── LEFT: CONFIG ── */}
        <div className="xl:col-span-7 space-y-8">

          {/* Profile Details */}
          <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-10 relative overflow-hidden">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 shadow-xl">
                <User className="w-5 h-5 text-white/70" />
              </div>
              <div className="flex flex-col">
                 <h3 className="text-[12px] font-black uppercase tracking-[0.2em] text-white/80">Identity Metadata</h3>
                 <p className="text-[10px] text-white/20 font-medium tracking-wide">Publicly visible profile information</p>
              </div>
            </div>

            <div className="space-y-8">
              <div className="space-y-4">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em] flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  Bot Display Name
                </label>
                <div className="group relative">
                  <input
                    type="text"
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/5 p-5 rounded-2xl text-white/90 font-semibold text-sm outline-none focus:border-white/20 focus:bg-white/[0.05] transition-all placeholder:text-white/10 shadow-inner"
                    placeholder="e.g. Enc Nexus"
                  />
                  <div className="absolute inset-0 rounded-2xl border border-blue-500/0 group-focus-within:border-blue-500/20 pointer-events-none transition-all" />
                </div>
              </div>
              
              <div className="space-y-4">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em] flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                  About Me / Biography
                </label>
                <div className="group relative">
                  <textarea
                    rows={5}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/5 p-6 rounded-2xl text-white/90 font-medium text-sm outline-none focus:border-white/20 focus:bg-white/[0.05] transition-all resize-none placeholder:text-white/10 shadow-inner leading-relaxed"
                    placeholder="Describe your bot's purpose and unique features..."
                  />
                  <div className="absolute inset-0 rounded-2xl border border-purple-500/0 group-focus-within:border-purple-500/20 pointer-events-none transition-all" />
                </div>
              </div>
            </div>
          </motion.section>

           {/* Visual Assets Section */}
           <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-10 group/assets">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                <ImageIcon className="w-5 h-5 text-white/70" />
              </div>
              <div className="flex-1">
                 <h3 className="text-[12px] font-black uppercase tracking-[0.2em] text-white/80">Visual Assets</h3>
                 <p className="text-[10px] text-white/20 font-medium tracking-wide">Brand imagery and animations</p>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/5 border border-emerald-500/10 text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em]">
                <Activity className="w-3.5 h-3.5 animate-pulse" /> Full Fidelity
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 font-mono">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Profile Avatar</label>
                   {isGif(avatarPreview) && <span className="text-[9px] text-emerald-400/80 font-bold tracking-[0.2rem]">ANIMATED</span>}
                </div>
                <DropZone
                  label="Upload Avatar"
                  preview={avatarPreview}
                  inputRef={avatarInputRef}
                  onFileChange={handleImageFile}
                  type="avatar"
                  aspectClass="h-44"
                />
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Server Banner</label>
                   {isGif(bannerPreview) && <span className="text-[9px] text-emerald-400/80 font-bold tracking-[0.2rem]">ANIMATED</span>}
                </div>
                <DropZone
                  label="Upload Banner"
                  preview={bannerPreview}
                  inputRef={bannerInputRef}
                  onFileChange={handleImageFile}
                  type="banner"
                  aspectClass="h-44"
                />
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/5 flex items-start gap-4">
               <div className="p-2 rounded-lg bg-blue-500/10">
                  <Zap className="w-4 h-4 text-blue-400" />
               </div>
               <p className="text-[11px] text-white/30 font-medium leading-relaxed">
                 Enc Nexus supports advanced profile assets. You can use transparent PNGs or loopable GIFs. We recommend <span className="text-white/60">512x512px</span> for avatars and <span className="text-white/60">960x540px</span> for banners.
               </p>
            </div>
          </motion.section>
        </div>

        {/* ── RIGHT: STICKY PREVIEW ── */}
        <div className="xl:col-span-5 space-y-8 xl:sticky xl:top-28">

           {/* Sidebar Status Box */}
           <motion.div variants={item} className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20 p-6 rounded-3xl space-y-4">
              <div className="flex items-center gap-3">
                 <div className="w-8 h-8 rounded-xl bg-blue-500/20 flex items-center justify-center">
                    <Activity className="w-4 h-4 text-blue-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Branding Status</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Profile Sync</span>
                    <span className="text-emerald-400 font-bold">Operational</span>
                 </div>
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Visual Cache</span>
                    <span className="text-white">Full Fidelity</span>
                 </div>
              </div>
           </motion.div>

          {/* Sync Status / Save */}
          <section className="bg-white/[0.01] border border-white/5 p-8 rounded-[40px] space-y-6 shadow-2xl relative overflow-hidden group/save">
             <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/[0.01] to-purple-500/[0.01] opacity-0 group-hover/save:opacity-100 transition-opacity" />
            
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                  <RefreshCw className="w-4 h-4 text-white/40" />
                </div>
                <div className="flex flex-col">
                  <h3 className="text-[11px] font-black uppercase tracking-[0.15em] text-white/60">Sync Control</h3>
                  <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest">Real-time status</p>
                </div>
              </div>
              {hasChanges && <span className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.5)]" />}
            </div>

            <button
              onClick={handleSync}
              disabled={status === 'loading'}
              className="w-full py-5 rounded-2xl bg-white text-black font-black text-[12px] uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 hover:scale-[0.98] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_20px_40px_rgba(255,255,255,0.1)] relative z-10"
            >
              {status === 'loading'
                ? <><RefreshCw className="w-5 h-5 animate-spin" /> Synchronizing...</>
                : <><Save className="w-5 h-5" /> Deploy Branding</>
              }
            </button>

            <AnimatePresence mode="wait">
              {status === 'success' && (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, filter: 'blur(0px)' }}
                  exit={{ opacity: 0 }}
                  className="flex items-center justify-center gap-2 text-[10px] text-emerald-400 font-black uppercase tracking-[0.2em]"
                >
                  <CheckCircle2 className="w-4 h-4" /> Global update successful
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          {/* Discord Mobile/Desktop Switcher Mockup Feel */}
          <div className="space-y-6">
            <div className="flex items-center justify-between px-4">
               <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[11px] font-black text-white/30 uppercase tracking-[0.3em]">Live Rendering</span>
               </div>
               <div className="flex gap-2">
                  <div className="w-6 h-6 rounded-md bg-white/5 border border-white/10 flex items-center justify-center"><Film className="w-3 h-3 text-white/20" /></div>
               </div>
            </div>

            <motion.div 
              layout
              className="relative rounded-[32px] overflow-hidden border border-white/10 shadow-[0_40px_80px_rgba(0,0,0,0.6)] group/pcard"
            >
              {/* Discord Backdrop Blur Layer */}
              <div className="absolute inset-0 bg-[#0b0c0e] backdrop-blur-2xl" />
              
              {/* Profile Card Interior */}
              <div className="relative z-10">
                {/* Banner */}
                <div className="h-40 relative bg-[#232428] overflow-hidden group/banner">
                  {bannerPreview ? (
                    <motion.img
                      initial={{ scale: 1.1, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      src={bannerPreview}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover/banner:scale-110"
                      alt="Banner"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-[#1e1f22] via-[#2b2d31] to-[#1e1f22] animate-pulse" />
                  )}
                  {/* Banner Vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/10" />
                </div>

                <div className="px-8 pb-10 relative">
                  {/* Large Overlapping Avatar */}
                  <div className="relative -mt-16 mb-6 inline-block">
                    <div className="relative w-[120px] h-[120px] rounded-full bg-[#111214] p-2 flex items-center justify-center shadow-2xl transition-transform duration-500 group-hover/pcard:-translate-y-2">
                       <div className="w-full h-full rounded-full overflow-hidden bg-[#2b2d31] flex items-center justify-center relative shadow-inner">
                          {avatarPreview ? (
                            <img
                              src={avatarPreview}
                              className="w-full h-full object-cover"
                              alt="Avatar"
                            />
                          ) : (
                            <Zap size={44} className="text-white/5" />
                          )}
                          
                          {/* Rich Interactive Overlay */}
                          <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover/pcard:opacity-100 transition-opacity pointer-events-none" />
                       </div>
                       
                       {/* Status Indicator with Premium Glow */}
                       <div className="absolute bottom-1 right-2 w-8 h-8 bg-[#111214] rounded-full flex items-center justify-center">
                          <div className="w-5 h-5 bg-[#23a55a] rounded-full shadow-[0_0_15px_rgba(35,165,90,0.5)]" />
                       </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <h3 className="text-white font-black text-2xl tracking-tighter leading-none">
                          {nickname || 'Enc Nexus'}
                        </h3>
                        <div className="flex items-center gap-1.5 px-2 py-1 bg-[#5865F2] text-white text-[10px] font-black uppercase rounded-md shadow-[0_4px_12px_rgba(88,101,242,0.3)]">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>BOT</span>
                        </div>
                      </div>
                      <p className="text-zinc-500 text-[12px] font-bold tracking-widest uppercase flex items-center gap-2">
                        {nickname ? nickname.toLowerCase().replace(/\s+/g, '_') : 'enc_nexus'}
                        <span className="text-white/10">#0000</span>
                      </p>
                    </div>

                    <div className="pt-6 border-t border-white/[0.04] space-y-6">
                      <div className="group/bio">
                        <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] mb-3 group-hover/bio:text-blue-400 transition-colors">Biography</p>
                        <p className="text-zinc-300 text-[14px] leading-relaxed font-normal whitespace-pre-wrap">
                          {bio || 'Identity not yet initialized. Configure the biography module to provide more context about this system.'}
                        </p>
                      </div>

                      <div className="flex items-center justify-between">
                         <div className="space-y-2">
                            <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Operational Since</p>
                            <p className="text-white/60 text-[12px] flex items-center gap-2 font-black tracking-wide">
                              <ImageIcon className="w-3.5 h-3.5 text-blue-400" /> {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                            </p>
                         </div>
                         <div className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/5 flex items-center justify-center">
                            <Shield className="w-5 h-5 text-white/20" />
                         </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <div className="flex items-center justify-center gap-6 py-4 opacity-20 hover:opacity-40 transition-opacity">
               <div className="w-1.5 h-1.5 rounded-full bg-white" />
               <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
               <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
            </div>

            {/* Premium Quote Card Preview */}
            <div className="space-y-8 pt-12 border-t border-white/[0.03]">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-white/40 shadow-inner">
                    <Activity className="w-5 h-5" />
                 </div>
                 <div className="flex flex-col">
                    <h2 className="text-[12px] font-black text-white uppercase tracking-[0.8em] leading-none">Quote Generation</h2>
                    <p className="text-[8px] text-white/10 font-bold uppercase tracking-[0.4em] mt-2">Dynamic canvas image processing</p>
                 </div>
              </div>

              <QuoteCard 
                text="The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle."
                author={nickname || "Enc Nexus"}
                avatar={avatarPreview || "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix"}
                timestamp={new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase()}
              />
              
              <p className="text-[10px] text-center text-white/10 font-medium uppercase tracking-[0.3em]">
                 This preview mimics the output of the <span className="text-white/20">/quote</span> command.
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}