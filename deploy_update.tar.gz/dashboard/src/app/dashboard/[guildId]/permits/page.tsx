import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap, Shield, ShieldCheck, ShieldAlert } from "lucide-react";
import PermitsManager from "@/components/PermitsManager";

export default async function PermitsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const permits = await prisma.permit.findMany({
    where: { guildId },
  });

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-500/20 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Access Control</h1>
            <p className="text-white/50 text-sm mt-1">Manage server permissions and administrative bypass rules.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <ShieldAlert className="w-3.5 h-3.5" /> High Security
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        <div className="xl:col-span-3">
          <PermitsManager guildId={guildId} initialPermits={permits} />
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border border-purple-500/20 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 flex items-center justify-center">
                   <Shield className="w-4 h-4 text-purple-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Permit Status</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Active Permits</span>
                    <span className="text-white font-bold">{permits.length}</span>
                 </div>
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Immunity</span>
                    <span className="text-emerald-400 font-bold">Enabled</span>
                 </div>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Usage Tip</h3>
              <p className="text-[11px] text-white/40 leading-relaxed">
                Grant "Bypass Anti-Nuke" only to extremely trusted admins or other verified bots.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
