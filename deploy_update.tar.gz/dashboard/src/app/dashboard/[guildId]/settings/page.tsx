import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import SettingsClient from "@/components/SettingsClient";

export default async function SettingsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
  });

  if (!guildData) {
    return redirect(`/dashboard/${guildId}`);
  }

  const memberCount = await prisma.member.count({ where: { guildId } });

  return (
    <SettingsClient 
      guildId={guildId} 
      guildData={guildData} 
      memberCount={memberCount} 
    />
  );
}
