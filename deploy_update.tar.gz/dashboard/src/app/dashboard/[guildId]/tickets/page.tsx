'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  Ticket, Plus, Trash2, Layers, Hash, Clock, ArrowRight, Activity, 
  Sparkles, Shield, ChevronRight, AlertCircle, Zap, Headphones, BarChart3
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TicketPanel {
  id: string;
  panelId: string;
  name: string;
  channelId: string;
  isMulti: boolean;
  supportRoleId?: string;
}

export default function TicketsPage() {
  const { guildId } = useParams();
  const router = useRouter();
  const [panels, setPanels] = useState<TicketPanel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!guildId) return;
    
    const fetchPanels = async () => {
      try {
        const res = await fetch(`/api/guild/${guildId}/tickets`);
        if (!res.ok) throw new Error('Failed to fetch panels');
        const data = await res.json();
        setPanels(data);
      } catch (err) {
        setError('Failed to load panels');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPanels();
  }, [guildId]);

  const singlePanels = panels.filter(p => !p.isMulti);
  const multiPanels = panels.filter(p => p.isMulti);
  const quota = singlePanels.length;
  const maxQuota = 3;

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this panel?')) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/tickets/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setPanels(panels.filter(p => p.id !== id));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 24 } }
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-6xl mx-auto space-y-10">
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.03] animate-pulse" />
            <div className="space-y-2">
              <div className="h-6 w-48 bg-white/[0.03] rounded-lg animate-pulse" />
              <div className="h-4 w-64 bg-white/[0.01] rounded-lg animate-pulse" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3 space-y-8">
            <div className="h-64 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
            <div className="h-64 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
          <div className="space-y-6">
            <div className="h-32 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
            <div className="h-32 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      initial="hidden" 
      animate="show" 
      variants={container}
      className="p-8 max-w-6xl mx-auto space-y-10"
    >
      <motion.div variants={item} className="flex items-center gap-4 border-b border-white/5 pb-6">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/20 flex items-center justify-center">
          <Ticket className="w-6 h-6 text-purple-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Ticket Support</h1>
          <p className="text-white/50 text-sm mt-1">Deploy high-performance support panels and multi-channel routing systems.</p>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-8">
          {/* SINGLE PANELS */}
          <motion.section variants={item} className="bg-[#050510]/30 border border-white/5 rounded-3xl overflow-hidden backdrop-blur-3xl shadow-2xl">
             <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-purple-500/10 rounded-lg">
                      <Layers className="w-4 h-4 text-purple-400" />
                   </div>
                   <h2 className="text-sm font-bold text-white uppercase tracking-wider">Standard Panels</h2>
                </div>
                <button 
                  onClick={() => router.push(`/dashboard/${guildId}/tickets/create`)}
                  className="bg-white text-black hover:bg-zinc-200 px-5 py-2 rounded-xl font-bold text-[10px] uppercase tracking-widest transition-all flex items-center gap-2"
                >
                   <Plus className="w-3 h-3" /> New Panel
                </button>
             </div>

             <div className="overflow-x-auto">
                <table className="w-full text-left">
                   <thead>
                      <tr className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] border-b border-white/5">
                         <th className="px-6 py-4">Channel</th>
                         <th className="px-6 py-4">Panel Title</th>
                         <th className="px-6 py-4">Status</th>
                         <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                   </thead>
                   <tbody>
                      {singlePanels.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-8 py-16 text-center">
                             <div className="flex flex-col items-center gap-3 opacity-20">
                                <Ticket className="w-10 h-10" />
                                <p className="text-[10px] font-bold uppercase tracking-widest">No active panels</p>
                             </div>
                          </td>
                        </tr>
                      ) : (
                        singlePanels.map((panel) => (
                          <tr key={panel.id} className="group/row hover:bg-white/[0.02] transition-colors border-b border-white/[0.02] last:border-0">
                             <td className="px-6 py-4">
                                <div className="flex items-center gap-2">
                                   <Hash className="w-3.5 h-3.5 text-purple-400/50" />
                                   <span className="text-xs font-medium text-white/60">#{panel.channelId ? 'support' : 'unlinked'}</span>
                                </div>
                             </td>
                             <td className="px-6 py-4">
                                <span className="text-xs font-semibold text-white/80">{panel.name}</span>
                             </td>
                             <td className="px-6 py-4">
                                <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest bg-emerald-400/10 px-2.5 py-1 rounded-full border border-emerald-400/20">
                                   Online
                                </span>
                             </td>
                             <td className="px-6 py-4 text-right">
                                <div className="flex items-center justify-end gap-4">
                                   <button 
                                     onClick={() => router.push(`/dashboard/${guildId}/tickets/edit/${panel.panelId}`)}
                                     className="text-[10px] font-bold text-white/40 hover:text-white transition-colors"
                                   >
                                      EDIT
                                   </button>
                                   <button 
                                     onClick={() => handleDelete(panel.id)}
                                     className="text-[10px] font-bold text-red-500/40 hover:text-red-500 transition-colors"
                                   >
                                      DELETE
                                   </button>
                                </div>
                             </td>
                          </tr>
                        ))
                      )}
                   </tbody>
                </table>
             </div>
          </motion.section>

          {/* MULTI PANELS */}
          <motion.section variants={item} className="bg-[#050510]/30 border border-white/5 rounded-3xl overflow-hidden backdrop-blur-3xl shadow-2xl">
             <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                <div className="flex items-center gap-3">
                   <div className="p-2 bg-pink-500/10 rounded-lg">
                      <Sparkles className="w-4 h-4 text-pink-400" />
                   </div>
                   <h2 className="text-sm font-bold text-white uppercase tracking-wider">Multi-Panels</h2>
                </div>
                <button 
                  onClick={() => router.push(`/dashboard/${guildId}/tickets/multi/create`)}
                  className="bg-white text-black hover:bg-zinc-200 px-5 py-2 rounded-xl font-bold text-[10px] uppercase tracking-widest transition-all flex items-center gap-2"
                >
                   <Plus className="w-3 h-3" /> New Multi-Panel
                </button>
             </div>

             <div className="overflow-x-auto">
                <table className="w-full text-left">
                   <thead>
                      <tr className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] border-b border-white/5">
                         <th className="px-6 py-4">Panel Title</th>
                         <th className="px-6 py-4">Routing</th>
                         <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                   </thead>
                   <tbody>
                      {multiPanels.length === 0 ? (
                        <tr>
                          <td colSpan={3} className="px-8 py-16 text-center">
                             <div className="flex flex-col items-center gap-3 opacity-20">
                                <Sparkles className="w-10 h-10" />
                                <p className="text-[10px] font-bold uppercase tracking-widest">No multi-panels</p>
                             </div>
                          </td>
                        </tr>
                      ) : (
                        multiPanels.map((panel) => (
                          <tr key={panel.id} className="group/row hover:bg-white/[0.02] transition-colors border-b border-white/[0.02] last:border-0">
                             <td className="px-6 py-4">
                                <span className="text-xs font-semibold text-white/80">{panel.name}</span>
                             </td>
                             <td className="px-6 py-4">
                                <span className="text-[9px] font-bold text-blue-400 uppercase tracking-widest bg-blue-400/10 px-2.5 py-1 rounded-full border border-blue-400/20">
                                   Dynamic
                                </span>
                             </td>
                             <td className="px-6 py-4 text-right">
                                <div className="flex items-center justify-end gap-4">
                                   <button 
                                     onClick={() => router.push(`/dashboard/${guildId}/tickets/multi/edit/${panel.panelId}`)}
                                     className="text-[10px] font-bold text-white/40 hover:text-white transition-colors"
                                   >
                                      EDIT
                                   </button>
                                   <button 
                                     onClick={() => handleDelete(panel.id)}
                                     className="text-[10px] font-bold text-red-500/40 hover:text-red-500 transition-colors"
                                   >
                                      DELETE
                                   </button>
                                </div>
                             </td>
                          </tr>
                        ))
                      )}
                   </tbody>
                </table>
             </div>
          </motion.section>
        </div>

        <div className="space-y-6">
          <motion.div variants={item} className="bg-purple-500/10 border border-purple-500/20 rounded-3xl p-6">
            <div className="flex gap-3">
              <Headphones className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-purple-400 font-medium text-sm mb-1">System Status</h3>
                <div className="mt-2 space-y-3">
                   <div className="flex justify-between items-center">
                      <span className="text-purple-400/60 text-[10px] font-bold uppercase tracking-wider">Response Time</span>
                      <span className="text-purple-400 font-bold text-xs">~0.4s</span>
                   </div>
                   <div className="flex justify-between items-center">
                      <span className="text-purple-400/60 text-[10px] font-bold uppercase tracking-wider">Quota Used</span>
                      <span className="text-purple-400 font-bold text-xs">{quota}/{maxQuota}</span>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
          
          <motion.div variants={item} className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-6">
            <div className="flex gap-3">
              <BarChart3 className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-blue-400 font-medium text-sm mb-1">Efficiency Tip</h3>
                <p className="text-blue-400/70 text-xs leading-relaxed mt-1">
                   Use Multi-Panels to categorize tickets (e.g., Billing, Support, Appeals) to route users to the right staff instantly.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}

