import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

import Navbar from "@/components/Navbar";
import Starfield from "@/components/Starfield";
import Sidebar from "@/components/Sidebar";
import PageTransition from "@/components/PageTransition";

export default async function DashboardLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ guildId: string }>;
}) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  return (
    <div className="min-h-screen bg-background relative selection:bg-indigo-500/30 selection:text-indigo-200">
      <div className="fixed inset-0 z-0">
        <Starfield />
      </div>

      <Navbar />

      <Sidebar />
      <div className="relative z-10 pt-32 px-10 xl:pl-[calc(17rem+4rem)]">
        <main className="flex-1 min-w-0 pb-20">
          <PageTransition>
            {children}
          </PageTransition>
        </main>
      </div>
    </div>
  );
}
