import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { MessageCircle, Gavel, Scale } from "lucide-react";
import AppealsManager from "@/components/AppealsManager";

export const dynamic = "force-dynamic";

export default async function AppealsPage({
  params,
}: {
  params: Promise<{ guildId: string }>;
}) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  // Fetch appeals for this guild
  const appeals = await prisma.appeal.findMany({
    where: { guildId },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-12">
      {/* ── HEADER ── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center shadow-inner">
            <Scale className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight uppercase">Appeal Control</h1>
            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Reviewing sanction reconsideration requests.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-12">
        {/* ── MAIN REVIEW QUEUE ── */}
        <div className="xl:col-span-3">
          <AppealsManager 
            guildId={guildId} 
            initialAppeals={JSON.parse(JSON.stringify(appeals))} 
          />
        </div>
        
        {/* ── SIDEBAR GUIDELINES ── */}
        <div className="xl:col-span-1 space-y-8">
          <div className="flex items-center gap-3 px-1">
             <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]" />
             <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Protocol Matrix</h2>
          </div>

          <div className="bg-white/[0.01] border border-white/5 rounded-[32px] p-8 shadow-inner space-y-8">
            <div className="flex gap-5">
              <Scale className="w-6 h-6 text-indigo-400 shrink-0" />
              <div>
                <h3 className="text-indigo-400 font-black text-[10px] uppercase tracking-[0.2em] mb-2">Neutral Review</h3>
                <p className="text-indigo-400/40 text-[9px] font-bold uppercase tracking-widest leading-relaxed">
                  Evaluate each request against established community standards and user history.
                </p>
              </div>
            </div>

            <div className="flex gap-5 border-t border-white/5 pt-8">
              <Gavel className="w-6 h-6 text-red-400 shrink-0" />
              <div>
                <h3 className="text-red-400 font-black text-[10px] uppercase tracking-[0.2em] mb-2">Direct Impact</h3>
                <p className="text-red-400/40 text-[9px] font-bold uppercase tracking-widest leading-relaxed">
                  Approved appeals execute an automated pardon (unban) across the server cluster.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

