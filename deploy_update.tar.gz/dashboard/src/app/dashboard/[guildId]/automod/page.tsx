import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Shield, Zap, ShieldAlert } from "lucide-react";
import AutoModManager from "@/components/AutoModManager";

export default async function AutoModPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const [filters, guildData] = await Promise.all([
    prisma.autoModFilter.findMany({ where: { guildId } }),
    prisma.guild.findUnique({ where: { id: guildId }, select: { autoModEnabled: true } })
  ]);

  // Ensure default filters exist in UI if not in DB yet
  const defaultTypes = ['SPAM', 'INVITES', 'LINKS', 'MENTIONS', 'MALICIOUS', 'WORDS'];
  const mergedFilters = defaultTypes.map(type => {
    const existing = filters.find((f: any) => f.type === type);
    return existing || { type, enabled: false, data: '[]' };
  });

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center gap-4 border-b border-white/5 pb-6">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/20 flex items-center justify-center">
          <Zap className="w-6 h-6 text-blue-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Auto Mod</h1>
          <p className="text-white/50 text-sm mt-1">Configure automated filters to protect your server from spam and malicious content.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <AutoModManager 
            guildId={guildId} 
            initialFilters={mergedFilters} 
            initialEnabled={guildData?.autoModEnabled ?? false} 
          />
        </div>
        
        <div className="space-y-6">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-3xl p-6">
            <div className="flex gap-3">
              <ShieldAlert className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-blue-400 font-medium text-sm mb-1">How it works</h3>
                <p className="text-blue-400/70 text-xs leading-relaxed">
                  Automod works in real-time. When a message is sent, it is checked against your active filters. If it violates a filter, it is automatically removed and logged.
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-purple-500/10 border border-purple-500/20 rounded-3xl p-6">
            <div className="flex gap-3">
              <Shield className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-purple-400 font-medium text-sm mb-1">Protection Tips</h3>
                <p className="text-purple-400/70 text-xs leading-relaxed">
                  Start with lower sensitivities and gradually increase them. Use the "Blocked Phrases" list for server-specific slang or offensive terms.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

