import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap, Shield } from "lucide-react";
import { getGuildRoles } from "@/lib/discord";
import RoleConnectionsManager from "@/components/RoleConnectionsManager";

export default async function RoleConnectionsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const [connections, roles] = await Promise.all([
    prisma.roleConnection.findMany({ where: { guildId } }),
    getGuildRoles(guildId)
  ]);

  // Filter out @everyone and managed roles if desired, but for connections we might want all
  const filteredRoles = roles.filter(role => role.name !== "@everyone" && !role.managed);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/20 to-amber-500/20 border border-orange-500/20 flex items-center justify-center">
            <Zap className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Neural Role Linking</h1>
            <p className="text-white/50 text-sm mt-1">Establish complex role dependencies and automated inheritance.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Shield className="w-3.5 h-3.5" /> High Entropy
           </div>
        </div>
      </div>

      <RoleConnectionsManager 
        guildId={guildId} 
        initialConnections={connections} 
        roles={filteredRoles} 
      />
    </div>
  );
}
