'use client';

import React from 'react';

export default function Loading() {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-10 relative z-10 animate-in fade-in duration-500">
      {/* Header Skeleton */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-white/[0.03] animate-pulse border border-white/5 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
          </div>
          <div className="space-y-3">
            <div className="h-7 w-56 bg-white/[0.04] rounded-lg animate-pulse relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
            </div>
            <div className="h-4 w-72 bg-white/[0.01] rounded-lg animate-pulse relative overflow-hidden">
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
            </div>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="h-11 w-32 bg-white/[0.02] border border-white/5 rounded-xl animate-pulse" />
          <div className="h-11 w-32 bg-white/[0.02] border border-white/5 rounded-xl animate-pulse" />
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-10">
        <div className="xl:col-span-3 space-y-10">
          {/* Top Banner Skeleton */}
          <div className="h-[200px] w-full bg-white/[0.01] border border-white/5 rounded-[2.5rem] animate-pulse relative overflow-hidden">
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.02] to-transparent -translate-x-full animate-[shimmer_2.5s_infinite]" />
             <div className="absolute top-10 left-10 space-y-4">
                <div className="h-8 w-64 bg-white/5 rounded-lg" />
                <div className="h-4 w-96 bg-white/5 rounded-lg" />
             </div>
          </div>
          
          {/* Stats Grid Skeleton */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-white/[0.01] border border-white/5 rounded-3xl animate-pulse" />
            ))}
          </div>

          {/* Large Content Area */}
          <div className="h-[600px] w-full bg-white/[0.01] border border-white/5 rounded-[2.5rem] animate-pulse relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.02] to-transparent -translate-x-full animate-[shimmer_3s_infinite]" />
            <div className="p-10 space-y-10">
               <div className="h-10 w-1/3 bg-white/5 rounded-xl" />
               <div className="space-y-6">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-16 w-full bg-white/5 rounded-2xl" />
                  ))}
               </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-10">
           {/* Sidebar Widgets */}
           {[...Array(3)].map((_, i) => (
             <div key={i} className={`w-full bg-white/[0.01] border border-white/5 rounded-[2.5rem] animate-pulse ${i === 0 ? 'h-80' : 'h-64'}`} />
           ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes shimmer {
          100% {
            transform: translateX(100%);
          }
        }
      `}</style>
    </div>
  );
}
