'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  UserPlus, UserMinus, Save, Activity, Sparkles, ArrowUpRight, Hash, Type, Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function GreetingsPage() {
  const { guildId } = useParams();
  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  
  const [welcome, setWelcome] = useState({ enabled: true, channelId: '', message: 'Welcome {user} to {server}!' });
  const [leave, setLeave] = useState({ enabled: true, channelId: '', message: '{user} has left the server.' });
  
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });

  useEffect(() => {
    if (!guildId) return;
    setIsLoading(true);
    
    Promise.all([
      fetch(`/api/guild/${guildId}/channels`).then(r => r.json()),
      fetch(`/api/guild/${guildId}/greetings`).then(r => r.json())
    ]).then(([channelData, greetingsData]) => {
      setChannels(channelData);
      if (greetingsData) {
        if (greetingsData.welcome) setWelcome(greetingsData.welcome);
        if (greetingsData.leave) setLeave(greetingsData.leave);
      }
    })
    .catch(console.error)
    .finally(() => setIsLoading(false));
  }, [guildId]);

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMsg({ text: 'Updating greetings...', type: 'info' });
    try {
      const res = await fetch(`/api/guild/${guildId}/greetings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ welcome, leave })
      });
      if (res.ok) setStatusMsg({ text: 'Greetings updated.', type: 'success' });
      else throw new Error();
    } catch {
      setStatusMsg({ text: 'Error: Update failed.', type: 'error' });
    } finally {
      setIsSaving(false);
      setTimeout(() => setStatusMsg({ text: '', type: '' }), 4000);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (isLoading) {
    return (
      <div className="p-8 max-w-6xl mx-auto space-y-10">
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.03] animate-pulse" />
            <div className="space-y-2">
              <div className="h-6 w-48 bg-white/[0.03] rounded-lg animate-pulse" />
              <div className="h-4 w-64 bg-white/[0.01] rounded-lg animate-pulse" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div className="xl:col-span-3 space-y-8">
            <div className="h-64 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
            <div className="h-64 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
          <div className="space-y-10">
            <div className="h-48 w-full bg-white/[0.01] border border-white/5 rounded-[32px] animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Automated Greetings</h1>
            <p className="text-white/50 text-sm mt-1">Configure entry and exit protocols for your community.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> High Fidelity
           </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 xl:grid-cols-4 gap-8"
      >
        <div className="xl:col-span-3 space-y-8">
           {/* WELCOME SECTOR */}
           <motion.section variants={item} className={`p-8 md:p-10 rounded-[32px] border transition-all duration-500 relative overflow-hidden ${welcome.enabled ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-white/[0.01] border-white/5'}`}>
              <div className="flex items-center justify-between relative z-10">
                 <div className="flex items-center gap-5">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border transition-colors ${welcome.enabled ? 'bg-emerald-500/20 border-emerald-500/20 text-emerald-400' : 'bg-white/5 border-white/10 text-white/20'}`}>
                       <UserPlus className="w-5 h-5" />
                    </div>
                    <div>
                       <h2 className="text-lg font-bold text-white tracking-tight">Welcome Protocol</h2>
                       <p className="text-white/40 text-[11px] uppercase font-bold tracking-widest mt-0.5">Member Ingress Notification</p>
                    </div>
                 </div>
                 <button 
                   onClick={() => setWelcome({...welcome, enabled: !welcome.enabled})}
                   className={`w-14 h-7 rounded-full relative transition-all duration-500 ${welcome.enabled ? 'bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]' : 'bg-white/10'}`}
                 >
                    <div className={`absolute top-1 w-5 h-5 rounded-full transition-all duration-500 ${welcome.enabled ? 'left-8 bg-white' : 'left-1 bg-white/20'}`} />
                 </button>
              </div>

              <AnimatePresence>
                {welcome.enabled && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-8 pt-10 relative z-10"
                  >
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-3">
                           <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest px-1">Target Channel</label>
                           <SurgicalDropdown 
                             options={channels} 
                             value={welcome.channelId}
                             onChange={(val) => setWelcome({...welcome, channelId: val})}
                             placeholder="Select Channel"
                           />
                        </div>
                        <div className="space-y-3">
                           <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest px-1">Variable Injection</label>
                           <div className="flex flex-wrap gap-2 pt-2">
                              {['{user}', '{server}', '{count}', '{tag}'].map(tag => (
                                 <span key={tag} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/5 text-[10px] font-bold text-white/40 font-mono tracking-wider">{tag}</span>
                              ))}
                           </div>
                        </div>
                     </div>
                     <div className="space-y-3">
                        <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest px-1">Message Template</label>
                        <textarea 
                         value={welcome.message}
                         onChange={(e) => setWelcome({...welcome, message: e.target.value})}
                         rows={4}
                         className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-[14px] text-white font-medium whitespace-pre-wrap outline-none focus:border-white/10 transition-all resize-none leading-relaxed"
                         placeholder="Welcome {user} to {server}!"
                        />
                     </div>
                  </motion.div>
                )}
              </AnimatePresence>
           </motion.section>

           {/* LEAVE SECTOR */}
           <motion.section variants={item} className={`p-8 md:p-10 rounded-[32px] border transition-all duration-500 relative overflow-hidden ${leave.enabled ? 'bg-red-500/5 border-red-500/20' : 'bg-white/[0.01] border-white/5'}`}>
              <div className="flex items-center justify-between relative z-10">
                 <div className="flex items-center gap-5">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border transition-colors ${leave.enabled ? 'bg-red-500/20 border-red-500/20 text-red-400' : 'bg-white/5 border-white/10 text-white/20'}`}>
                       <UserMinus className="w-5 h-5" />
                    </div>
                    <div>
                       <h2 className="text-lg font-bold text-white tracking-tight">Farewell Protocol</h2>
                       <p className="text-white/40 text-[11px] uppercase font-bold tracking-widest mt-0.5">Member Egress Notification</p>
                    </div>
                 </div>
                 <button 
                   onClick={() => setLeave({...leave, enabled: !leave.enabled})}
                   className={`w-14 h-7 rounded-full relative transition-all duration-500 ${leave.enabled ? 'bg-red-500 shadow-[0_0_20px_rgba(239,68,68,0.3)]' : 'bg-white/10'}`}
                 >
                    <div className={`absolute top-1 w-5 h-5 rounded-full transition-all duration-500 ${leave.enabled ? 'left-8 bg-white' : 'left-1 bg-white/20'}`} />
                 </button>
              </div>

              <AnimatePresence>
                {leave.enabled && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-8 pt-10 relative z-10"
                  >
                     <div className="space-y-3 max-w-md">
                        <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest px-1">Target Channel</label>
                        <SurgicalDropdown 
                          options={channels} 
                          value={leave.channelId}
                          onChange={(val) => setLeave({...leave, channelId: val})}
                          placeholder="Select Channel"
                        />
                     </div>
                     <div className="space-y-3">
                        <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest px-1">Message Template</label>
                        <textarea 
                         value={leave.message}
                         onChange={(e) => setLeave({...leave, message: e.target.value})}
                         rows={4}
                         className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-[14px] text-white font-medium whitespace-pre-wrap outline-none focus:border-white/10 transition-all resize-none leading-relaxed"
                         placeholder="{user} has left the server."
                        />
                     </div>
                  </motion.div>
                )}
              </AnimatePresence>
           </motion.section>

           {/* SAVE TRIGGER */}
           <motion.div variants={item} className="flex justify-end gap-6 pt-4">
              <AnimatePresence>
                {statusMsg.text && (
                  <motion.p initial={{opacity:0, x: 10}} animate={{opacity:1, x: 0}} exit={{opacity:0}} className={`text-[11px] font-bold uppercase tracking-widest self-center ${statusMsg.type === 'error' ? 'text-red-500' : 'text-emerald-500'}`}>
                    {statusMsg.text}
                  </motion.p>
                )}
              </AnimatePresence>
              <button 
                onClick={handleSave}
                disabled={isSaving}
                className="px-10 py-4 rounded-xl bg-white text-black font-bold text-[11px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 hover:bg-zinc-200 shadow-xl"
              >
                 {isSaving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                 {isSaving ? "Syncing..." : "Save Config"}
              </button>
           </motion.div>
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                   <Type className="w-4 h-4 text-cyan-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Live Preview</h3>
              </div>
              <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl space-y-2">
                 <div className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Incoming Member</div>
                 <p className="text-[12px] text-white/60 leading-relaxed italic">
                    "{welcome.message.replace('{user}', '@Username').replace('{server}', 'Dimscord Server')}"
                 </p>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Deployment Info</h3>
              <p className="text-[11px] text-white/40 leading-relaxed">
                Messages are dispatched immediately upon member join/leave events. Embeds can be built in the Messages tab.
              </p>
           </div>
        </div>
      </motion.div>
    </div>
  );
}
