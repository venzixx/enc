import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import AnalyticsClient from "@/components/AnalyticsClient";

export default async function GuildDashboard({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
  });

  if (!guildData) {
    await prisma.guild.create({ data: { id: guildId } });
    return redirect(`/dashboard/${guildId}`);
  }

  return (
    <AnalyticsClient 
      guildId={guildId} 
    />
  );
}
