import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Terminal, Activity, Clock } from "lucide-react";
import LogsFeed from "@/components/LogsFeed";

export default async function AuditLogs({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) {
    redirect("/");
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-zinc-500/20 to-slate-500/20 border border-white/10 flex items-center justify-center">
            <Terminal className="w-6 h-6 text-white/60" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Audit History</h1>
            <p className="text-white/50 text-sm mt-1">Full transparency of server events and administrative actions.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-white/40 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> Monitoring
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        <div className="xl:col-span-3">
          <LogsFeed guildId={guildId} />
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-zinc-500/10 to-slate-500/10 border border-white/5 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center">
                   <Clock className="w-4 h-4 text-white/60" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Log Metrics</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Retention</span>
                    <span className="text-white font-bold">30 Days</span>
                 </div>
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Indexing</span>
                    <span className="text-emerald-400 font-bold">Real-time</span>
                 </div>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Audit Tips</h3>
              <p className="text-[11px] text-white/40 leading-relaxed">
                Use the category filters to quickly narrow down security breaches or permission changes.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
