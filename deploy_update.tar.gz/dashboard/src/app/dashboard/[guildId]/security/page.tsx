import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap, Shield } from "lucide-react";
import SecurityHub from "@/components/SecurityHub";

export default async function SecurityPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
    include: { antiNukeConfig: true }
  });

  if (!guildData) return redirect(`/dashboard`);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-500/20 to-orange-500/20 border border-red-500/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-red-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Security Center</h1>
            <p className="text-white/50 text-sm mt-1">Automated protection and anti-nuke protocols for your server.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 animate-pulse" /> Protection Active
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        <div className="xl:col-span-3">
          <SecurityHub guildId={guildId} initialData={guildData} />
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/20 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-red-500/20 flex items-center justify-center">
                   <Shield className="w-4 h-4 text-red-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Security Hub</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Anti-Nuke</span>
                    <span className="text-emerald-400 font-bold">Armed</span>
                 </div>
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Detection</span>
                    <span className="text-white">Real-time</span>
                 </div>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Security Tips</h3>
              <p className="text-[11px] text-white/40 leading-relaxed">
                Set thresholds low for sensitive actions like channel deletion to prevent mass damage.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
