"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { Activity, Plus, Trash2, ShieldAlert, Shield, Hash, MessageSquare, Image as ImageIcon, Layout, ArrowUpRight, ChevronDown, ChevronUp } from "lucide-react";
import CustomSelect from "@/components/CustomSelect";
import EmbedEditor from "@/components/EmbedEditor";
import { motion, AnimatePresence } from "framer-motion";

interface StreakTier {
  id: number;
  name: string;
  threshold: number;
  message?: string | null;
  embedData?: string | null;
  imageUrl?: string | null;
}

interface Channel {
  id: string;
  name: string;
}

export default function StreaksPage() {
  const { guildId } = useParams();
  const [tiers, setTiers] = useState<StreakTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [channels, setChannels] = useState<Channel[]>([]);
  
  const [enabled, setEnabled] = useState(true);
  const [streakChannelId, setStreakChannelId] = useState<string | null>(null);
  
  const [newName, setNewName] = useState("");
  const [newThreshold, setNewThreshold] = useState("");
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [expandedTier, setExpandedTier] = useState<number | null>(null);
  const [editingTierEmbed, setEditingTierEmbed] = useState<StreakTier | null>(null);

  useEffect(() => {
    fetchData();
  }, [guildId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [tiersRes, configRes, channelsRes] = await Promise.all([
        fetch(`/api/guild/${guildId}/streaktier`),
        fetch(`/api/guild/${guildId}/config`),
        fetch(`/api/guild/${guildId}/channels`)
      ]);

      if (tiersRes.ok) setTiers(await tiersRes.json());
      if (configRes.ok) {
        const config = await configRes.json();
        setEnabled(config.streaksEnabled);
        setStreakChannelId(config.streakChannelId);
      }
      if (channelsRes.ok) {
        const allChannels = await channelsRes.json();
        setChannels(allChannels.filter((c: any) => c.type === 0)); // Only text channels
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const updateSetting = async (field: string, value: any) => {
    setUpdating(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/config`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field, value }),
      });
      if (res.ok) {
        if (field === 'streaksEnabled') setEnabled(value);
        if (field === 'streakChannelId') setStreakChannelId(value);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setUpdating(false);
    }
  };

  const handleCreate = async () => {
    if (!newName || !newThreshold) return;
    setCreating(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName, threshold: parseInt(newThreshold) }),
      });
      if (res.ok) {
        setNewName("");
        setNewThreshold("");
        const data = await fetch(`/api/guild/${guildId}/streaktier`).then(r => r.json());
        setTiers(data);
      } else {
        const text = await res.text();
        alert(text || "Failed to create tier");
      }
    } catch (error) {
      alert("An error occurred");
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier?id=${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        setTiers(tiers.filter(t => t.id !== id));
      } else {
        alert("Failed to delete tier");
      }
    } catch (error) {
      alert("An error occurred");
    }
  };

  const handleUpdateTier = async (id: number, updates: Partial<StreakTier>) => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...updates }),
      });
      if (res.ok) {
        setTiers(tiers.map(t => t.id === id ? { ...t, ...updates } : t));
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return (
      <div className="p-8 max-w-6xl mx-auto space-y-10">
        <div className="flex items-center justify-between border-b border-white/5 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.03] animate-pulse" />
            <div className="space-y-2">
              <div className="h-6 w-48 bg-white/[0.03] rounded-lg animate-pulse" />
              <div className="h-4 w-64 bg-white/[0.01] rounded-lg animate-pulse" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div className="xl:col-span-3 space-y-8">
            <div className="h-[400px] w-full bg-white/[0.01] border border-white/5 rounded-[40px] animate-pulse" />
          </div>
          <div className="space-y-8">
            <div className="h-64 w-full bg-white/[0.01] border border-white/5 rounded-[40px] animate-pulse" />
            <div className="h-96 w-full bg-white/[0.01] border border-white/5 rounded-[40px] animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-12">
      {/* ── HEADER ── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/20 flex items-center justify-center shadow-inner">
            <Activity className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight uppercase">Streak Engine</h1>
            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Activity thresholds and engagement monitoring.</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
           <div className="flex flex-col items-end gap-1">
              <div className="text-[9px] font-black text-white/20 uppercase tracking-[0.2em]">Engine Status</div>
              <div className={`text-[10px] font-black uppercase tracking-widest ${enabled ? 'text-emerald-500' : 'text-red-500'}`}>
                 {enabled ? 'Active' : 'Offline'}
              </div>
           </div>
           <div 
             onClick={() => updateSetting('streaksEnabled', !enabled)}
             className={`w-14 h-7 rounded-full relative cursor-pointer transition-all duration-500 border ${enabled ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}
           >
              <div className={`absolute top-1 w-5 h-5 rounded-full transition-all duration-500 ${enabled ? 'left-8 bg-black' : 'left-1 bg-white/20'}`} />
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-12">
        {/* ── ACTIVE TIERS (MAIN) ── */}
        <div className="xl:col-span-3 space-y-8">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-3">
               <div className={`w-2 h-2 rounded-full shadow-[0_0_10px_rgba(249,115,22,0.5)] ${enabled ? 'bg-orange-500' : 'bg-white/10'}`} />
               <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Operational Tiers</h2>
            </div>
          </div>
          
          <div className={`bg-white/[0.01] border border-white/5 rounded-[40px] p-8 md:p-10 shadow-inner min-h-[400px] transition-all duration-500 ${!enabled ? 'opacity-30 grayscale pointer-events-none' : ''}`}>
            {loading ? (
              <div className="text-white/20 text-[10px] font-black uppercase tracking-[0.2em] py-20 text-center">Synchronizing Data...</div>
            ) : tiers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-24 px-4 text-center">
                <Activity className="w-12 h-12 text-white/5 mb-6" />
                <h3 className="text-white font-black uppercase tracking-widest text-sm mb-2">No Active Tiers</h3>
                <p className="text-white/10 text-[10px] font-bold uppercase tracking-[0.2em] max-w-xs">Initialize a streak protocol to begin engagement tracking.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {tiers.map((tier) => (
                  <div key={tier.id} className="flex flex-col rounded-[32px] bg-white/[0.01] border border-white/5 hover:border-white/10 transition-all group overflow-hidden shadow-inner">
                    <div className="flex items-center justify-between p-8">
                      <div className="flex items-center gap-6">
                        <div className="w-14 h-14 rounded-2xl bg-orange-500/5 flex items-center justify-center border border-orange-500/10 shadow-inner group-hover:scale-110 transition-transform duration-500">
                          <Activity className="w-6 h-6 text-orange-400/40" />
                        </div>
                        <div>
                          <div className="text-white font-black uppercase tracking-tight text-lg">{tier.name}</div>
                          <div className="text-white/20 text-[10px] font-black uppercase tracking-widest mt-1">{tier.threshold} MSG / DAY THRESHOLD</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => setExpandedTier(expandedTier === tier.id ? null : tier.id)}
                          className="p-4 bg-white/5 rounded-2xl text-white/20 hover:text-white transition-all shadow-xl"
                        >
                          {expandedTier === tier.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </button>
                        <button
                          onClick={() => handleDelete(tier.id)}
                          className="p-4 hover:bg-red-500/10 rounded-2xl text-white/10 hover:text-red-400 transition-all shadow-xl"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <AnimatePresence>
                      {expandedTier === tier.id && (
                        <motion.div 
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="px-8 pb-8 space-y-6 overflow-hidden border-t border-white/5 bg-white/[0.005]"
                        >
                          <div className="pt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Custom Message</label>
                              <textarea
                                value={tier.message || ""}
                                onChange={(e) => handleUpdateTier(tier.id, { message: e.target.value })}
                                placeholder="GG {user}, you maintained your {streak} day streak!"
                                className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-4 text-[11px] font-medium text-white/80 focus:outline-none focus:border-white/20 resize-none transition-all leading-relaxed"
                                rows={3}
                              />
                            </div>
                            <div className="space-y-4">
                              <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Image Card URL</label>
                              <input
                                type="text"
                                value={tier.imageUrl || ""}
                                onChange={(e) => handleUpdateTier(tier.id, { imageUrl: e.target.value })}
                                placeholder="https://..."
                                className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-4 text-[11px] font-medium text-white/80 focus:outline-none focus:border-white/20 transition-all"
                              />
                              <button 
                                onClick={() => setEditingTierEmbed(tier)}
                                className="w-full flex items-center justify-between p-4 bg-white/[0.01] border border-white/5 rounded-2xl hover:bg-white/5 transition-all text-left"
                              >
                                <div className="flex items-center gap-3">
                                  <Layout className="w-4 h-4 text-white/40" />
                                  <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">Configure Embed</span>
                                </div>
                                <ArrowUpRight className="w-3 h-3 text-white/20" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── CONTROLS (SIDEBAR) ── */}
        <div className="xl:col-span-1 space-y-8">
          {/* NOTIFICATION SETTINGS */}
          <div className="space-y-6">
             <div className="flex items-center gap-3 px-1">
                <Shield className="w-4 h-4 text-white/20" />
                <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Broadcast</h2>
             </div>
             
             <div className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 shadow-inner space-y-6">
                <CustomSelect
                  label="Streak Notification Channel"
                  options={channels.map(c => ({ id: c.id, name: c.name }))}
                  value={streakChannelId || ""}
                  onChange={(val) => updateSetting('streakChannelId', val)}
                  placeholder="Select a channel"
                />
                <p className="text-[9px] font-bold text-white/10 uppercase tracking-widest px-2 leading-relaxed">
                   Notifications will be broadcasted here when users reach or maintain their daily streak milestones.
                </p>
             </div>
          </div>

          <div className="space-y-8">
            <div className="flex items-center gap-3 px-1">
               <Plus className="w-4 h-4 text-white/20" />
               <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Tier Creation</h2>
            </div>
            
            <div className={`bg-white/[0.01] border border-white/5 rounded-[40px] p-8 shadow-inner space-y-8 transition-all duration-500 ${!enabled ? 'opacity-30 grayscale pointer-events-none' : ''}`}>
              <div className="space-y-4">
                <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Protocol Identifier</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. BRONZE_CORE"
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl px-6 py-4 text-[11px] font-black text-white placeholder-white/5 focus:outline-none focus:border-orange-500/30 transition-all uppercase tracking-widest shadow-inner"
                />
              </div>

              <div className="space-y-4">
                <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Daily Threshold</label>
                <input
                  type="number"
                  min="1"
                  value={newThreshold}
                  onChange={(e) => setNewThreshold(e.target.value)}
                  placeholder="0"
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl px-6 py-4 text-[11px] font-black text-white placeholder-white/5 focus:outline-none focus:border-orange-500/30 transition-all uppercase tracking-widest shadow-inner"
                />
              </div>

              <button
                onClick={handleCreate}
                disabled={creating || !newName || !newThreshold}
                className="w-full bg-white text-black font-black rounded-2xl py-5 text-[10px] uppercase tracking-[0.4em] hover:bg-zinc-200 transition-all disabled:opacity-20 disabled:cursor-not-allowed shadow-xl flex items-center justify-center gap-3"
              >
                {creating ? "Deploying..." : (
                  <>
                    Initialize Tier
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="bg-orange-500/5 border border-orange-500/10 rounded-[32px] p-8 shadow-inner">
            <div className="flex gap-5">
              <ShieldAlert className="w-6 h-6 text-orange-400 shrink-0" />
              <div>
                <h3 className="text-orange-400 font-black text-[10px] uppercase tracking-[0.2em] mb-2">Neural Mechanics</h3>
                <p className="text-orange-400/40 text-[9px] font-bold uppercase tracking-widest leading-relaxed">
                  Tiers are stackable. Users maintain streaks by sending required messages daily. Missed thresholds reset the specific protocol.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
      <EmbedEditor 
        isOpen={!!editingTierEmbed}
        onClose={() => setEditingTierEmbed(null)}
        onSave={(json) => editingTierEmbed && handleUpdateTier(editingTierEmbed.id, { embedData: JSON.stringify(json) })}
        initialData={editingTierEmbed?.embedData ? JSON.parse(editingTierEmbed.embedData) : { title: "Streak Achievement!", description: "GG {user}, you reached a {streak} day streak on {tier}!" }}
        placeholders={['{user}', '{streak}', '{tier}', '{count}']}
        title={`Embed Architect - ${editingTierEmbed?.name}`}
      />
    </div>
