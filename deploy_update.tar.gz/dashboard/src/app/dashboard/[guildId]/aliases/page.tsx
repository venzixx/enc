'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { 
  Plus, Trash2, Command, RefreshCw, Search, 
  Settings2, Zap, Save, X, Activity, Info, Link2, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CustomSelect from '@/components/CustomSelect';

const COMMAND_CATEGORIES = {
  "🛡️ Antinuke & Safety": [
    "antinuke", "antinuke config", "antinuke settings", "antinuke enable", "antinuke disable",
    "automod", "automod config", "whitelist", "whitelist add", "whitelist remove",
    "ignore", "unignore", "lockdown", "unlockdown"
  ],
  "🔨 Moderation": [
    "ban", "kick", "mute", "unmute", "unban", "purge", "purge messages", "purge user",
    "warn", "warn add", "warn remove", "warn list",
    "timeout", "untimeout", "slowmode", "backroom", "unbackroom"
  ],
  "⚙️ Management": [
    "channel", "channel create", "channel nuke", "channel rename", "channel lock", "channel unlock", "channel move", "channel clone",
    "role", "role add", "role remove", "role create", "role delete", "role rename",
    "config", "prefix", "setup", "log-setup", "welcome-setup", "autorole", "autorole add", "autorole remove"
  ],
  "🎵 Music": [
    "play", "stop", "skip", "pause", "resume", "queue", "nowplaying", "volume", "shuffle", "loop", "seek", "replay", "remove", "move", "clearqueue", "lyrics", "join", "leave", "autoplay", "fairplay"
  ],
  "✨ Utility": [
    "afk", "help", "info", "invite", "stats", "whois", "membercount", "ping", "timer", "timediff",
    "embed", "emoji", "emoji add", "emoji delete", "reactionrole", "sticky", "suggest", "poll", "quote"
  ],
  "🏆 Levels & Economy": [
    "level", "leaderboard", "xp", "xp add", "xp remove", "xp reset", "level-setup", "streaks", "streaktier"
  ],
  "🎮 Fun": [
    "tord", "random-quote", "confess", "confess-setup", "birthday", "birthday-setup", "mcstatus", "counting-setup", "starboard-setup"
  ]
};

const BOT_COMMANDS = Object.values(COMMAND_CATEGORIES).flat().sort();

export default function AliasesPage() {
  const { guildId } = useParams();
  const [loading, setLoading] = useState(true);
  const [aliases, setAliases] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  
  const [formData, setFormData] = useState({
    alias: '',
    commandName: ''
  });
  const [editingId, setEditingId] = useState<number | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`/api/guild/${guildId}/aliases`);
      if (res.ok) setAliases(await res.json());
    } catch (error) {
      console.error("Fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [guildId]);

  useEffect(() => {
    if (guildId) fetchData();
  }, [guildId, fetchData]);

  const handleSave = async () => {
    if (!formData.alias || !formData.commandName) return;
    
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/aliases`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        await fetchData();
        setShowModal(false);
        setFormData({ alias: '', commandName: '' });
        setEditingId(null);
      }
    } catch (error) {
      console.error("Save error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this alias?")) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/aliases?id=${id}`, {
        method: 'DELETE'
      });
      if (res.ok) await fetchData();
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  const filtered = aliases.filter(a => 
    a.alias.toLowerCase().includes(search.toLowerCase()) || 
    a.commandName.toLowerCase().includes(search.toLowerCase())
  );

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (loading && aliases.length === 0) {
    return (
      <div className="p-8 max-w-6xl mx-auto space-y-10 animate-pulse">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/5" />
            <div className="space-y-2">
              <div className="w-48 h-8 bg-white/5 rounded-lg" />
              <div className="w-64 h-4 bg-white/5 rounded-full" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          <div className="xl:col-span-3 space-y-8">
             <div className="h-20 bg-white/[0.02] border border-white/5 rounded-[32px]" />
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-[240px] bg-white/[0.01] border border-white/5 rounded-[32px] p-8" />
                ))}
             </div>
          </div>
          <div className="space-y-10">
             <div className="h-40 bg-white/[0.02] border border-white/5 rounded-3xl" />
             <div className="h-40 bg-white/[0.02] border border-white/5 rounded-3xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center">
            <Link2 className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white to-white/40">Command Aliases</h1>
            <p className="text-white/50 text-sm mt-1">Create custom triggers for existing bot commands.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
              </span>
              Manifest Online
           </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 xl:grid-cols-4 gap-8"
      >
        <div className="xl:col-span-3 space-y-8">
           <motion.div variants={item} className="flex flex-col lg:flex-row gap-6 items-center justify-between bg-white/[0.02] border border-white/5 p-6 rounded-[32px]">
             <div className="relative w-full lg:w-[400px]">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                <input 
                  type="text" 
                  placeholder="Filter aliases..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-[13px] text-white outline-none focus:border-white/10 transition-all font-medium"
                />
             </div>

             <button 
               onClick={() => setShowModal(true)}
               className="px-8 py-4 bg-white text-black rounded-xl text-[11px] font-bold uppercase tracking-[0.2em] transition-all hover:bg-zinc-200 shadow-xl flex items-center gap-3 shrink-0"
             >
               <Plus className="w-4 h-4" /> Create Alias
             </button>
           </motion.div>

           <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <AnimatePresence mode="popLayout">
               {filtered.map((a) => (
                 <motion.div 
                   key={a.id}
                   layout
                   initial={{ opacity: 0, scale: 0.98 }}
                   animate={{ opacity: 1, scale: 1 }}
                   exit={{ opacity: 0, scale: 0.95 }}
                   className="bg-white/[0.01] border border-white/5 rounded-[32px] p-8 space-y-8 group hover:bg-white/[0.02] hover:border-white/10 transition-all relative overflow-hidden"
                 >
                    <div className="flex justify-between items-start relative z-10">
                       <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl flex items-center justify-center border bg-indigo-500/10 border-indigo-500/20 text-indigo-400">
                             <Zap className="w-4 h-4" />
                          </div>
                          <div>
                             <h4 className="text-sm font-bold text-white uppercase tracking-wider">Active Mapping</h4>
                             <p className="text-white/20 text-[10px] font-bold tracking-widest uppercase">Protocol Enabled</p>
                          </div>
                       </div>
                        <div className="flex gap-2">
                           <button 
                             onClick={() => handleDelete(a.id)}
                             className="p-2.5 text-white/5 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                           >
                              <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                    </div>

                     <div className="flex items-center justify-between relative z-10 bg-white/5 p-6 rounded-2xl border border-white/5">
                        <div className="space-y-1">
                           <span className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em]">Alias</span>
                           <div className="text-lg font-black text-white">{a.alias}</div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-white/10" />
                        <div className="space-y-1 text-right">
                           <span className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em]">Target</span>
                           <div className="text-lg font-black text-indigo-400">/{a.commandName}</div>
                        </div>
                     </div>
                 </motion.div>
               ))}
             </AnimatePresence>
           </motion.div>

           {filtered.length === 0 && (
             <motion.div variants={item} className="py-32 flex flex-col items-center justify-center gap-6 border-2 border-dashed border-white/5 rounded-[40px]">
                <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center text-white/10">
                   <Command className="w-8 h-8" />
                </div>
                <div className="text-center">
                   <h3 className="text-sm font-bold text-white/20 uppercase tracking-[0.2em]">No aliases defined</h3>
                   <p className="text-[11px] text-white/10 font-bold uppercase tracking-widest mt-1">Start by creating your first custom command trigger.</p>
                </div>
             </motion.div>
           )}
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                   <Info className="w-4 h-4 text-indigo-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Protocol Info</h3>
              </div>
              <div className="space-y-4">
                  <p className="text-[11px] text-white/40 leading-relaxed">
                    Aliases only apply to **Prefix Commands**. They do not affect Slash Commands.
                  </p>
                  <div className="space-y-2 pt-2 border-t border-white/5">
                     <div className="flex justify-between text-[11px]">
                        <span className="text-white/40">Total Aliases</span>
                        <span className="text-white font-bold">{aliases.length}</span>
                     </div>
                  </div>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Usage Example</h3>
              <div className="bg-black/40 p-4 rounded-xl border border-white/5 space-y-2">
                 <div className="text-[10px] text-indigo-400 font-bold">SETTING:</div>
                 <div className="text-[11px] text-white/60">nuke → /channel nuke</div>
                 <div className="text-[10px] text-indigo-400 font-bold mt-2">RESULT:</div>
                 <div className="text-[11px] text-white/60">e!nuke</div>
              </div>
           </div>
        </div>
      </motion.div>

      {/* Create Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 md:p-12">
             <motion.div 
               initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
               onClick={() => {
                  setShowModal(false);
                  setEditingId(null);
                  setFormData({ alias: '', commandName: '' });
               }}
               className="absolute inset-0 bg-black/80 backdrop-blur-xl"
             />
             <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-[#0c0c0c] border border-white/10 rounded-[40px] w-full max-w-xl overflow-visible relative shadow-2xl"
             >
                <div className="flex justify-between items-center px-12 py-10 border-b border-white/5">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5">
                         <Plus className="w-6 h-6 text-white/60" />
                      </div>
                      <div>
                         <h2 className="text-xl font-bold text-white tracking-tight uppercase tracking-[0.2em]">New Alias</h2>
                         <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Map custom trigger to command</p>
                      </div>
                   </div>
                   <button 
                     onClick={() => {
                        setShowModal(false);
                        setEditingId(null);
                        setFormData({ alias: '', commandName: '' });
                     }}
                     className="p-2 hover:bg-white/5 rounded-xl transition-all text-white/20 hover:text-white/60"
                   >
                      <X className="w-5 h-5" />
                   </button>
                </div>

                <div className="p-10 space-y-8">
                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Custom Alias (The Trigger)</label>
                      <div className="relative">
                         <Zap className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                         <input 
                           value={formData.alias}
                           onChange={e => setFormData({...formData, alias: e.target.value.replace(/\s/g, '')})}
                           placeholder="e.g. nuke, silence, boom..."
                           className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-sm text-white outline-none focus:border-white/10 transition-all font-medium"
                         />
                      </div>
                   </div>

                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest block">Original Command (The Target)</label>
                      <CustomSelect
                        options={Object.entries(COMMAND_CATEGORIES).flatMap(([category, commands]) => 
                          commands.map(cmd => ({ id: cmd, name: cmd, category }))
                        )}
                        value={formData.commandName}
                        onChange={(val) => setFormData({ ...formData, commandName: val })}
                        placeholder="Select a command..."
                        prefix="/"
                      />
                   </div>

                   <button 
                     onClick={handleSave}
                     disabled={loading || !formData.alias || !formData.commandName}
                     className="w-full bg-white text-black font-bold py-5 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:hover:scale-100 uppercase tracking-[0.3em] text-[11px]"
                   >
                      {loading ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          Deploy Alias
                        </>
                      )}
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
