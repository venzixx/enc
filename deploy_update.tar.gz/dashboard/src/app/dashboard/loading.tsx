"use client";

import React from "react";
import { motion as m } from "framer-motion";
import Starfield from "@/components/Starfield";
import GridBackground from "@/components/GridBackground";

export default function DashboardLoading() {
  return (
    <main className="relative min-h-screen bg-[#050508] text-white font-sans overflow-x-hidden">
      <Starfield />
      
      <div className="relative z-10 pt-40 pb-32 px-6 md:px-12">
        <div className="max-w-[1400px] mx-auto space-y-24">
          
          {/* Header Skeleton */}
          <div className="flex flex-col items-center text-center space-y-8">
            <div className="w-48 h-10 bg-white/5 rounded-full animate-pulse" />
            <div className="w-full max-w-3xl h-24 bg-white/5 rounded-[2rem] animate-pulse" />
            <div className="w-full max-w-2xl h-16 bg-white/5 rounded-[2rem] animate-pulse" />
          </div>

          {/* Active Nodes Skeleton */}
          <div className="space-y-10">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-2xl bg-white/5 animate-pulse" />
                <div className="w-48 h-6 bg-white/5 rounded-full animate-pulse" />
                <div className="h-px flex-1 bg-white/5" />
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               {[...Array(3)].map((_, i) => (
                 <div key={i} className="h-[280px] rounded-[3rem] border border-white/[0.05] bg-white/[0.02] p-10 flex flex-col justify-end gap-6 animate-pulse">
                    <div className="flex items-center gap-6">
                        <div className="w-20 h-20 rounded-[2rem] bg-white/5" />
                        <div className="flex-1 space-y-3">
                            <div className="w-3/4 h-8 bg-white/5 rounded-lg" />
                            <div className="w-1/2 h-5 bg-white/5 rounded-lg" />
                        </div>
                    </div>
                    <div className="pt-6 border-t border-white/5 flex justify-between">
                        <div className="w-32 h-4 bg-white/5 rounded-full" />
                        <div className="w-10 h-10 rounded-full bg-white/5" />
                    </div>
                 </div>
               ))}
             </div>
          </div>
        </div>
      </div>
    </main>
  );
}
