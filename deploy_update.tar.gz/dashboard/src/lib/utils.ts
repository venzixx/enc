/**
 * Converts a hex color string (e.g., "#FFFFFF") to a decimal number for Discord API.
 */
export function parseColor(hex: string): number {
  if (!hex) return 0;
  return parseInt(hex.replace("#", ""), 16);
}

/**
 * Returns a Discord CDN URL for an asset, using .gif if the hash starts with a_
 */
export function getDiscordAsset(type: 'icon' | 'banner' | 'avatar' | 'guild-avatar' | 'guild-banner', id: string, hash: string | null, size = 1024, userId?: string): string | null {
  if (!hash) return null;
  
  // Discord uses a_ prefix for animated assets. 
  // Forcing .gif extension ensures the CDN returns the animated version.
  const isAnimated = hash.startsWith('a_');
  const ext = isAnimated ? 'gif' : 'webp';
  
  const baseUrl = "https://cdn.discordapp.com";
  
  switch (type) {
    case 'icon':
      return `${baseUrl}/icons/${id}/${hash}.${ext}?size=${size}${isAnimated ? '&format=gif' : ''}`;
    case 'banner':
      return `${baseUrl}/banners/${id}/${hash}.${ext}?size=${size}${isAnimated ? '&format=gif' : ''}`;
    case 'avatar':
      return `${baseUrl}/avatars/${id}/${hash}.${ext}?size=${size}${isAnimated ? '&format=gif' : ''}`;
    case 'guild-avatar':
      return `${baseUrl}/guilds/${id}/users/${userId}/avatars/${hash}.${ext}?size=${size}${isAnimated ? '&format=gif' : ''}`;
    case 'guild-banner':
      return `${baseUrl}/guilds/${id}/users/${userId}/banners/${hash}.${ext}?size=${size}${isAnimated ? '&format=gif' : ''}`;
    default:
      return null;
  }
}
