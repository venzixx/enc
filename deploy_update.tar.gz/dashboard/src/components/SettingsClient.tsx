"use client";

import React from "react";
import { motion } from "framer-motion";
import { Shield, Zap, Users, Activity, Ticket, ExternalLink, Settings, ListTree, Sparkles } from "lucide-react";
import ConsoleSector from "./ConsoleSector";
import LoggingSector from "./LoggingSector";
import Link from "next/link";

interface SettingsClientProps {
  guildId: string;
  guildData: any;
  memberCount: number;
}

export default function SettingsClient({ guildId, guildData, memberCount }: SettingsClientProps) {
  const stats = [
    { label: "Total Members", value: memberCount.toLocaleString(), icon: <Users className="w-5 h-5 text-blue-400" />, color: "bg-blue-500/10 border-blue-500/20" },
    { label: "Active Punishments", value: "0", icon: <Shield className="w-5 h-5 text-red-400" />, color: "bg-red-500/10 border-red-500/20" },
    { label: "System Uptime", value: "99.9%", icon: <Activity className="w-5 h-5 text-emerald-400" />, color: "bg-emerald-500/10 border-emerald-500/20" },
  ];

  const quickActions = [
    { label: "Manage Roles", icon: <Zap className="w-5 h-5" />, href: `/dashboard/${guildId}/roleconnections` },
    { label: "Tickets", icon: <Ticket className="w-5 h-5" />, href: `/dashboard/${guildId}/tickets` },
    { label: "Leveling", icon: <ListTree className="w-5 h-5" />, href: `/dashboard/${guildId}/levels` },
    { label: "Server Settings", icon: <Settings className="w-5 h-5" />, href: `/dashboard/${guildId}/settings` },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 24 } }
  };

  return (
    <motion.div 
      initial="hidden" 
      animate="show" 
      variants={container} 
      className="p-8 max-w-[1600px] mx-auto space-y-12"
    >
      {/* ── HEADER ── */}
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center shadow-inner">
            <Settings className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">System Configurations</h1>
            <p className="text-white/30 text-[10px] font-bold uppercase tracking-[0.3em] mt-1">Manage server protocols and security matrices.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-6 py-3 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 text-indigo-400/60 text-[9px] font-black uppercase tracking-[0.3em] flex items-center gap-2 shadow-inner">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" />
              Link Status: Secured
           </div>
        </div>
      </motion.div>

      {/* ── MAIN GRID (3:1) ── */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-12">
        {/* ── LEFT COLUMN (COL-SPAN-3) ── */}
        <motion.div variants={item} className="xl:col-span-3 space-y-12">
          {/* SECURITY */}
          <section className="space-y-8">
            <div className="flex items-center gap-3 px-1">
              <Shield className="w-4 h-4 text-indigo-400" />
              <h2 className="text-[10px] font-bold text-white uppercase tracking-[0.3em]">Security Control Matrix</h2>
            </div>
            <div className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[40px] shadow-inner">
               <ConsoleSector guildId={guildId} initialData={guildData} />
            </div>
          </section>

          {/* QUICK ACTIONS */}
          <section className="space-y-8">
            <div className="flex items-center gap-3 px-1">
              <Zap className="w-4 h-4 text-emerald-400" />
              <h2 className="text-[10px] font-bold text-white uppercase tracking-[0.3em]">Quick Access Protocols</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {quickActions.map((action, idx) => (
                <Link href={action.href} key={idx} className="h-full">
                  <motion.div 
                    whileHover={{ y: -5 }}
                    className="flex flex-col items-center justify-center gap-4 p-8 rounded-[32px] bg-white/[0.01] border border-white/5 hover:bg-white/[0.02] hover:border-white/10 transition-all cursor-pointer group h-full shadow-inner"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/20 group-hover:text-white group-hover:bg-white/10 transition-all duration-500">
                      {action.icon}
                    </div>
                    <div className="text-[11px] font-black text-white/40 uppercase tracking-[0.2em] group-hover:text-white transition-colors">{action.label}</div>
                  </motion.div>
                </Link>
              ))}
            </div>
          </section>
        </motion.div>
        
        {/* ── RIGHT COLUMN (COL-SPAN-1) ── */}
        <motion.div variants={item} className="xl:col-span-1 space-y-8">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-3">
              <Activity className="w-4 h-4 text-indigo-400" />
              <h2 className="text-[10px] font-bold text-white uppercase tracking-[0.3em]">Logging Control</h2>
            </div>
          </div>
          
          <div className="bg-white/[0.01] border border-white/5 p-8 rounded-[40px] shadow-inner">
             <LoggingSector guildId={guildId} initialData={guildData} />
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
