"use client";

import React, { useState } from 'react';
import { 
  Zap, Plus, Trash2, Shield, Search, Check, 
  ChevronDown, X, ArrowRight, Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter } from 'next/navigation';

interface RoleConnection {
  id: number;
  guildId: string;
  triggerRoleId: string;
  connectedRoleId: string;
}

interface Role {
  id: string;
  name: string;
  color: number;
}

interface RoleConnectionsProps {
  guildId: string;
  initialConnections: RoleConnection[];
  roles: Role[];
}

export default function RoleConnectionsManager({ 
  guildId, 
  initialConnections, 
  roles 
}: RoleConnectionsProps) {
  const router = useRouter();
  const [connections, setConnections] = useState<RoleConnection[]>(initialConnections);
  const [triggerRoleId, setTriggerRoleId] = useState<string>('');
  const [selectedConnectedRoleIds, setSelectedConnectedRoleIds] = useState<string[]>([]);
  const [isTriggerOpen, setIsTriggerOpen] = useState(false);
  const [isConnectedOpen, setIsConnectedOpen] = useState(false);
  const [triggerSearch, setTriggerSearch] = useState('');
  const [connectedSearch, setConnectedSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const filteredTriggerRoles = roles.filter(role => 
    role.name.toLowerCase().includes(triggerSearch.toLowerCase())
  );

  const filteredConnectedRoles = roles.filter(role => 
    role.name.toLowerCase().includes(connectedSearch.toLowerCase()) && 
    role.id !== triggerRoleId
  );

  const handleAddConnection = async () => {
    if (!triggerRoleId || selectedConnectedRoleIds.length === 0) return;

    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/roleconnections`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          triggerRoleId,
          connectedRoleIds: selectedConnectedRoleIds
        })
      });

      if (res.ok) {
        // Refresh data
        const newRes = await fetch(`/api/guild/${guildId}/roleconnections`);
        if (newRes.ok) {
          const data = await newRes.json();
          setConnections(data);
        }
        setTriggerRoleId('');
        setSelectedConnectedRoleIds([]);
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  const handleDeleteConnection = async (id: number, tId: string, cId: string) => {
    setDeletingId(id);
    try {
      const res = await fetch(`/api/guild/${guildId}/roleconnections?triggerRoleId=${tId}&connectedRoleId=${cId}`, {
        method: 'DELETE'
      });

      if (res.ok) {
        setConnections(connections.filter(c => c.id !== id));
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    }
    setDeletingId(null);
  };

  const toggleConnectedRole = (roleId: string) => {
    setSelectedConnectedRoleIds(prev => 
      prev.includes(roleId) 
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  // Group connections by trigger role for display
  const groupedConnections = connections.reduce((acc, conn) => {
    if (!acc[conn.triggerRoleId]) {
      acc[conn.triggerRoleId] = [];
    }
    acc[conn.triggerRoleId].push(conn);
    return acc;
  }, {} as Record<string, RoleConnection[]>);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 xl:grid-cols-4 gap-8"
    >
      <div className="xl:col-span-3 space-y-12">
        {/* ESTABLISH LINK */}
        <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-10">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                <Plus className="w-4 h-4 text-white/40" />
             </div>
             <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Establish Link</h3>
                <p className="text-white/20 text-[10px] font-bold uppercase tracking-widest mt-0.5">Define role dependency manifest</p>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-11 gap-6 items-center">
            {/* Trigger Role Select */}
            <div className="md:col-span-4 space-y-3">
              <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] px-1">Source Trigger</label>
              <div className="relative">
                <button 
                  onClick={() => setIsTriggerOpen(!isTriggerOpen)}
                  className={`w-full border p-4.5 rounded-2xl flex items-center justify-between group transition-all ${triggerRoleId ? 'bg-orange-500/5 border-orange-500/20' : 'bg-white/[0.02] border-white/5'}`}
                >
                  <div className="flex items-center gap-3">
                    <Shield className={`w-4 h-4 ${triggerRoleId ? 'text-orange-400' : 'text-white/20'}`} />
                    <span className={`text-[13px] font-bold uppercase tracking-widest ${triggerRoleId ? 'text-white' : 'text-white/20'}`}>
                      {roles.find(r => r.id === triggerRoleId)?.name || "Select Source"}
                    </span>
                  </div>
                  <ChevronDown className={`w-4 h-4 text-white/10 transition-transform ${isTriggerOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {isTriggerOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                      className="absolute z-50 w-full mt-3 bg-[#0d0d0d] border border-white/10 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
                    >
                      <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-white/20" />
                          <input 
                            autoFocus
                            placeholder="Search roles..."
                            className="w-full bg-white/5 border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-[10px] font-bold text-white uppercase tracking-widest outline-none focus:border-white/10"
                            value={triggerSearch}
                            onChange={(e) => setTriggerSearch(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="max-h-60 overflow-y-auto py-2 scrollbar-hide">
                        {filteredTriggerRoles.map(role => (
                          <button 
                            key={role.id}
                            onClick={() => { setTriggerRoleId(role.id); setIsTriggerOpen(false); }}
                            className="w-full px-5 py-3 flex items-center justify-between hover:bg-white/5 transition-colors group/role"
                          >
                            <span className="text-[10px] font-bold uppercase tracking-widest text-white/40 group-hover/role:text-white transition-colors">{role.name}</span>
                            {triggerRoleId === role.id && <Check className="w-3 h-3 text-white/60" />}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="md:col-span-1 flex justify-center pt-6 text-white/5">
              <ArrowRight className="w-6 h-6 rotate-90 md:rotate-0" />
            </div>

            {/* Connected Roles Select */}
            <div className="md:col-span-4 space-y-3">
              <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] px-1">Target Links</label>
              <div className="relative">
                <button 
                  onClick={() => setIsConnectedOpen(!isConnectedOpen)}
                  className={`w-full border p-4.5 rounded-2xl flex items-center justify-between group transition-all ${selectedConnectedRoleIds.length > 0 ? 'bg-orange-500/5 border-orange-500/20' : 'bg-white/[0.02] border-white/5'}`}
                >
                  <div className="flex items-center gap-3 flex-wrap overflow-hidden">
                    <Zap className={`w-4 h-4 ${selectedConnectedRoleIds.length > 0 ? 'text-orange-400' : 'text-white/20'}`} />
                    {selectedConnectedRoleIds.length > 0 ? (
                      <div className="flex gap-2 flex-wrap max-h-6 overflow-hidden">
                        {selectedConnectedRoleIds.map(id => (
                          <span key={id} className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 bg-orange-500/10 rounded-md text-orange-400">
                            {roles.find(r => r.id === id)?.name}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[13px] font-bold uppercase tracking-widest text-white/20">Select Targets</span>
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-white/10 transition-transform ${isConnectedOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {isConnectedOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                      className="absolute z-50 w-full mt-3 bg-[#0d0d0d] border border-white/10 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
                    >
                      <div className="p-4 border-b border-white/5 bg-white/[0.01]">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-white/20" />
                          <input 
                            autoFocus
                            placeholder="Search roles..."
                            className="w-full bg-white/5 border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-[10px] font-bold text-white uppercase tracking-widest outline-none focus:border-white/10"
                            value={connectedSearch}
                            onChange={(e) => setConnectedSearch(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="max-h-60 overflow-y-auto py-2 scrollbar-hide">
                        {filteredConnectedRoles.map(role => {
                          const isSelected = selectedConnectedRoleIds.includes(role.id);
                          return (
                            <button 
                              key={role.id}
                              onClick={() => toggleConnectedRole(role.id)}
                              className="w-full px-5 py-3 flex items-center justify-between hover:bg-white/5 transition-colors group/role"
                            >
                              <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${isSelected ? 'text-white' : 'text-white/40 group-hover/role:text-white/60'}`}>{role.name}</span>
                              {isSelected && <Check className="w-3 h-3 text-white/60" />}
                            </button>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="md:col-span-2 pt-6">
              <button 
                onClick={handleAddConnection}
                disabled={loading || !triggerRoleId || selectedConnectedRoleIds.length === 0}
                className="w-full bg-white text-black text-[11px] font-black uppercase tracking-[0.2em] px-4 py-5 rounded-2xl hover:bg-zinc-200 transition-all active:scale-[0.98] disabled:opacity-10 shadow-xl"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Link"}
              </button>
            </div>
          </div>
        </motion.section>

        {/* ACTIVE CONNECTIONS */}
        <div className="space-y-6">
           <div className="flex items-center gap-3 px-2">
              <Shield className="w-4 h-4 text-white/20" />
              <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Operational Matrix</h2>
           </div>

           {Object.keys(groupedConnections).length === 0 ? (
             <motion.div variants={item} className="p-32 border border-dashed border-white/5 rounded-[40px] flex flex-col items-center justify-center text-center space-y-6 bg-white/[0.01]">
                <div className="p-5 bg-white/[0.02] border border-white/5 rounded-[24px]">
                  <Zap className="w-8 h-8 text-white/5" />
                </div>
                <div>
                   <h4 className="text-sm font-bold text-white/20 uppercase tracking-widest">Neural Network Idle</h4>
                   <p className="text-[10px] text-white/5 font-bold uppercase tracking-widest mt-1">No role dependencies established</p>
                </div>
             </motion.div>
           ) : (
             <div className="grid grid-cols-1 gap-6">
               <AnimatePresence mode="popLayout">
                 {Object.entries(groupedConnections).map(([tRoleId, conns]) => {
                   const triggerRole = roles.find(r => r.id === tRoleId);
                   if (!triggerRole) return null;

                   return (
                     <motion.div 
                        layout 
                        key={tRoleId} 
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] group hover:bg-white/[0.02] transition-all hover:border-white/10"
                     >
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
                           <div className="flex items-center gap-6 shrink-0">
                              <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center shadow-inner">
                                 <Shield className="w-6 h-6 text-white/20" />
                              </div>
                              <div className="space-y-1">
                                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">{triggerRole.name}</h3>
                                 <p className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em]">Source Protocol</p>
                              </div>
                           </div>

                           <div className="flex-1 flex flex-wrap gap-3 md:justify-center">
                              {conns.map(conn => {
                                 const connectedRole = roles.find(r => r.id === conn.connectedRoleId);
                                 if (!connectedRole) return null;
                                 const isDeleting = deletingId === conn.id;

                                 return (
                                    <div 
                                      key={conn.id} 
                                      className="flex items-center gap-3 pl-4 pr-1.5 py-1.5 bg-orange-500/5 border border-orange-500/10 rounded-xl group/chip hover:border-orange-500/30 transition-all"
                                    >
                                       <span className="text-[11px] font-bold text-orange-400/80 tracking-wider uppercase">{connectedRole.name}</span>
                                       <button 
                                         onClick={() => handleDeleteConnection(conn.id, conn.triggerRoleId, conn.connectedRoleId)}
                                         disabled={!!deletingId}
                                         className="p-1.5 text-white/10 hover:text-red-500 transition-colors disabled:opacity-50"
                                       >
                                         {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-4 h-4" />}
                                       </button>
                                    </div>
                                 );
                              })}
                           </div>

                           <div className="flex justify-end shrink-0">
                              <div className="px-5 py-3 bg-white/[0.02] rounded-xl text-[10px] font-black text-white/20 uppercase tracking-[0.2em] border border-white/5">
                                 {conns.length} Links Active
                              </div>
                           </div>
                        </div>
                     </motion.div>
                   );
                 })}
               </AnimatePresence>
             </div>
           )}
        </div>
      </div>

      <div className="space-y-10">
        <motion.div variants={item} className="bg-gradient-to-br from-orange-500/10 to-amber-500/10 border border-orange-500/20 p-8 rounded-[32px] space-y-6">
           <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-2xl bg-orange-500/20 flex items-center justify-center">
                 <Shield className="w-5 h-5 text-orange-400" />
               </div>
               <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">Network Status</h3>
                  <p className="text-orange-400/60 text-[10px] font-bold uppercase tracking-widest mt-0.5">Established Links</p>
               </div>
            </div>
            <div className="space-y-4">
               <div className="flex justify-between text-[11px] font-bold uppercase tracking-widest">
                  <span className="text-white/20">Total Triggers</span>
                  <span className="text-white">{Object.keys(groupedConnections).length}</span>
               </div>
               <div className="flex justify-between text-[11px] font-bold uppercase tracking-widest">
                  <span className="text-white/20">Total Links</span>
                  <span className="text-white">{connections.length}</span>
               </div>
            </div>
         </motion.div>

         <motion.div variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-[32px] space-y-6">
            <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Deployment Logic</h3>
            <p className="text-[11px] text-white/40 leading-relaxed font-medium">
              Role connections are enforced instantly when a user's roles are modified. Removing a trigger role will automatically purge its associated target roles.
            </p>
         </motion.div>
      </div>
    </motion.div>
  );
}
