"use client";

import React from "react";

export default function Footer() {
  const footerLinks = [
    { name: "Privacy", href: "/privacy" },
    { name: "Terms", href: "/termsofservice" },
    { name: "Docs", href: "/codex" }
  ];

  return (
    <footer className="py-16 border-t border-white/[0.04] bg-black">
      <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <div className="w-6 h-6 rounded-md border border-white/30 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-white" />
          </div>
          <span className="text-white/20 text-[11px] font-bold uppercase tracking-widest">Enc Nexus</span>
        </div>
        <div className="flex gap-8">
          {footerLinks.map(link => (
            <a key={link.name} href={link.href} className="text-white/20 hover:text-white/50 text-[10px] font-bold uppercase tracking-widest transition-colors">
              {link.name}
            </a>
          ))}
        </div>
        <span className="text-white/10 text-[10px] font-bold uppercase tracking-widest">© 2026 Enc Nexus</span>
      </div>
    </footer>
  );
}
