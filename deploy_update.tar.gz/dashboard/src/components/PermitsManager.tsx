"use client";

import React, { useState } from 'react';
import { UserPlus, Shield, ShieldAlert, Trash2, Check, ExternalLink, MoreVertical, ShieldCheck, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface PermitsProps {
  guildId: string;
  initialPermits: any[];
}

const ALL_PERMISSIONS = [
  { id: 'BAN', label: 'Ban Members', color: 'text-red-400' },
  { id: 'KICK', label: 'Kick Members', color: 'text-orange-400' },
  { id: 'MUTE', label: 'Mute Members', color: 'text-yellow-400' },
  { id: 'LOCKDOWN', label: 'Server Lockdown', color: 'text-blue-400' },
  { id: 'MANAGE_CHANNELS', label: 'Manage Channels', color: 'text-emerald-400' },
  { id: 'MANAGE_ROLES', label: 'Manage Roles', color: 'text-purple-400' },
  { id: 'BYPASS_ANTINUKE', label: 'Bypass Anti-Nuke', color: 'text-pink-400' },
  { id: 'BYPASS_AUTOMOD', label: 'Bypass Auto-Mod', color: 'text-cyan-400' },
];

export default function PermitsManager({ guildId, initialPermits }: PermitsProps) {
  const [permits, setPermits] = useState<any[]>(initialPermits);
  const [loading, setLoading] = useState(false);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPermit, setEditingPermit] = useState<any>(null);
  
  // Selection State
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [allRoles, setAllRoles] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);

  const fetchRoles = async () => {
    try {
      const resp = await fetch(`/api/guild/${guildId}/roles`);
      const data = await resp.json();
      setAllRoles(data);
      if (editingPermit?.type === 'ROLE') setResults(data);
    } catch (e) {
      console.error("Failed to fetch roles", e);
    }
  };

  const searchMembers = async (query: string) => {
    if (!query) {
      setResults([]);
      return;
    }
    setSearching(true);
    try {
      const resp = await fetch(`/api/guild/${guildId}/members?query=${encodeURIComponent(query)}`);
      const data = await resp.json();
      setResults(data);
    } catch (e) {}
    setSearching(false);
  };

  // Load roles once when modal opens
  React.useEffect(() => {
    if (isModalOpen) {
      fetchRoles();
    }
  }, [isModalOpen]);

  // Handle Role filtering locally
  React.useEffect(() => {
    if (editingPermit?.type === 'ROLE') {
      if (!searchQuery) {
        setResults(allRoles);
      } else {
        const filtered = allRoles.filter(r => 
          r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
          r.id.includes(searchQuery)
        );
        setResults(filtered);
      }
    }
  }, [searchQuery, allRoles, editingPermit?.type]);

  // Handle User searching with debounce
  React.useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery && editingPermit?.type === 'USER') {
        searchMembers(searchQuery);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery, editingPermit?.type]);

  const getLevel = (permsStr: string) => {
    const list = JSON.parse(permsStr || '[]');
    const count = list.length;
    if (count >= 8) return 6;
    if (count >= 6) return 5;
    if (count >= 4) return 4;
    if (count >= 3) return 3;
    if (count >= 2) return 2;
    if (count >= 1) return 1;
    return 0;
  };

  const handleEdit = (permit: any) => {
    setEditingPermit({
      ...permit,
      permissions: JSON.parse(permit.permissions || '[]')
    });
    setSearchQuery('');
    setResults([]);
    setIsModalOpen(true);
  };

  const handleNew = () => {
    setEditingPermit({ targetId: '', type: 'USER', permissions: [], immunity: false });
    setSearchQuery('');
    setResults([]);
    setIsModalOpen(true);
  };

  const savePermit = async () => {
    if (!editingPermit.targetId) return;
    setLoading(true);
    try {
      const resp = await fetch(`/api/guild/${guildId}/permits`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingPermit)
      });
      if (resp.ok) {
        const saved = await resp.json();
        setPermits(prev => {
          const idx = prev.findIndex(p => p.targetId === saved.targetId);
          if (idx > -1) {
            const next = [...prev];
            next[idx] = saved;
            return next;
          }
          return [...prev, saved];
        });
        setIsModalOpen(false);
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10"
    >
      <motion.div variants={item} className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-8 rounded-3xl">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Active Overrides</h2>
          <p className="text-white/40 text-[11px] uppercase font-bold tracking-widest mt-0.5">Custom Security Bypass Rules</p>
        </div>
        <button onClick={handleNew} className="flex items-center gap-3 bg-white text-black px-8 py-3 rounded-xl text-[11px] font-bold uppercase tracking-widest hover:bg-zinc-200 transition-all">
          <UserPlus className="w-4 h-4" />
          <span>New Permit</span>
        </button>
      </motion.div>

      <motion.div variants={item} className="bg-white/[0.01] border border-white/5 rounded-[32px] overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-white/5 bg-white/[0.01]">
              <th className="p-8 text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">ID / Target</th>
              <th className="p-8 text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Type</th>
              <th className="p-8 text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Permissions</th>
              <th className="p-8 text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Bypass Status</th>
              <th className="p-8 text-[10px] font-bold text-white/20 uppercase tracking-[0.3em] text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/[0.03]">
            {permits.length === 0 && (
              <tr>
                <td colSpan={5} className="p-20 text-center text-white/10 text-sm font-medium">No custom permissions found.</td>
              </tr>
            )}
            {permits.map((permit) => {
              const level = getLevel(permit.permissions);
              return (
                <tr key={permit.id} className="hover:bg-white/[0.01] transition-all group">
                  <td className="p-8">
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-bold text-white/80 font-mono tracking-tight">{permit.targetId}</span>
                      <ExternalLink className="w-3.5 h-3.5 text-white/10 group-hover:text-white/40 transition-colors" />
                    </div>
                  </td>
                  <td className="p-8">
                    <span className={`text-[10px] font-bold px-3 py-1 rounded-full border ${permit.type === 'USER' ? 'border-blue-500/20 text-blue-400 bg-blue-500/5' : 'border-purple-500/20 text-purple-400 bg-purple-500/5'}`}>
                      {permit.type}
                    </span>
                  </td>
                  <td className="p-8">
                    <div className="flex items-center gap-4">
                      <div className="flex gap-1">
                        {[1,2,3,4,5,6].map(i => (
                          <div key={i} className={`w-4 h-1.5 rounded-full ${i <= level ? 'bg-white shadow-[0_0_8px_rgba(255,255,255,0.2)]' : 'bg-white/5'}`} />
                        ))}
                      </div>
                      <span className="text-[11px] font-bold text-white/40">LVL {level}</span>
                    </div>
                  </td>
                  <td className="p-8">
                    {permit.immunity ? (
                      <div className="flex items-center gap-2.5 text-emerald-400">
                        <ShieldAlert className="w-4 h-4" />
                        <span className="text-[10px] font-bold tracking-[0.2em] uppercase">Immune</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2.5 text-white/20">
                        <Shield className="w-4 h-4" />
                        <span className="text-[10px] font-bold tracking-[0.2em] uppercase">Restricted</span>
                      </div>
                    )}
                  </td>
                  <td className="p-8 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => handleEdit(permit)} className="p-2.5 hover:bg-white/5 rounded-xl text-white/20 hover:text-white transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                      <button className="p-2.5 hover:bg-red-500/5 rounded-xl text-white/10 hover:text-red-500 transition-all">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </motion.div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-8 bg-black/80 backdrop-blur-md">
           <div className="w-full max-w-2xl bg-[#0a0a0f] border border-white/5 rounded-[40px] p-12 overflow-y-auto max-h-[90vh] space-y-12">
              <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-extrabold uppercase text-white tracking-tight">Configuration</h2>
                    <p className="text-[11px] font-bold text-white/20 tracking-[0.2em] uppercase">Update permission details</p>
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="text-white/20 hover:text-white transition-colors text-3xl font-light">&times;</button>
              </div>

              {/* Target Selector */}
              <div className="space-y-8">
                <div className="flex gap-4">
                  <button 
                    onClick={() => {
                        setEditingPermit({ ...editingPermit, type: 'USER', targetId: '' });
                        setSearchQuery('');
                        setResults([]);
                    }}
                    className={`flex-1 p-4 rounded-2xl border text-[10px] font-bold tracking-[0.2em] uppercase transition-all ${editingPermit.type === 'USER' ? 'bg-white text-black border-white' : 'bg-white/5 border-white/5 text-white/20'}`}
                  >
                    User
                  </button>
                  <button 
                    onClick={() => {
                        setEditingPermit({ ...editingPermit, type: 'ROLE', targetId: '' });
                        setSearchQuery('');
                        setResults(allRoles);
                    }}
                    className={`flex-1 p-4 rounded-2xl border text-[10px] font-bold tracking-[0.2em] uppercase transition-all ${editingPermit.type === 'ROLE' ? 'bg-white text-black border-white' : 'bg-white/5 border-white/5 text-white/20'}`}
                  >
                    Role
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="relative">
                    <input 
                      type="text"
                      placeholder={editingPermit.type === 'USER' ? "Search users..." : "Search roles..."}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-white/[0.03] border border-white/5 rounded-2xl p-6 text-white text-sm focus:outline-none focus:border-white/20 transition-all"
                    />
                    {searching && <div className="absolute right-6 top-1/2 -translate-y-1/2 text-[10px] text-white/20 font-bold uppercase animate-pulse">Searching...</div>}
                  </div>

                  <div className="bg-white/[0.01] border border-white/5 rounded-2xl p-2 max-h-60 overflow-y-auto space-y-1">
                    {results.length === 0 && (
                      <div className="p-12 text-center text-white/10 text-[10px] font-bold uppercase tracking-widest">No results found</div>
                    )}
                    {results.map((res: any) => {
                       const isSelected = editingPermit.targetId === (res.id || res.user?.id);
                       return (
                        <button 
                          key={res.id || (res.user?.id)}
                          onClick={() => {
                            setEditingPermit({ ...editingPermit, targetId: res.id || res.user.id });
                          }}
                          className={`w-full flex items-center gap-5 p-4 rounded-xl transition-all border ${isSelected ? 'bg-white/[0.05] border-white/20' : 'hover:bg-white/[0.02] border-transparent'}`}
                        >
                          <div 
                            className={`w-10 h-10 rounded-full flex items-center justify-center text-[10px] font-bold ${editingPermit.type === 'USER' ? 'bg-white/10 text-white' : 'bg-white/5'}`}
                            style={editingPermit.type === 'ROLE' ? { borderLeft: `4px solid #${res.color?.toString(16).padStart(6, '0')}` } : {}}
                          >
                            {editingPermit.type === 'USER' ? 'U' : 'R'}
                          </div>
                          <div className="flex-1 text-left">
                            <p className={`text-sm font-bold transition-colors ${isSelected ? 'text-white' : 'text-white/40'}`}>{res.name || res.user.username}</p>
                            <p className="text-[10px] text-white/10 font-mono">{res.id || res.user.id}</p>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-white" />}
                        </button>
                       );
                    })}
                  </div>
                </div>
              </div>

              {/* Immunity Switch */}
              <div className={`p-8 rounded-[32px] border transition-all ${editingPermit.immunity ? 'bg-emerald-500/[0.03] border-emerald-500/20' : 'bg-white/[0.02] border-white/5'}`}>
                <div className="flex justify-between items-center gap-8">
                  <div className="space-y-2">
                    <h4 className={`text-sm font-bold tracking-widest uppercase ${editingPermit.immunity ? 'text-emerald-400' : 'text-white/40'}`}>Full Bypass</h4>
                    <p className="text-[11px] text-white/20 font-medium leading-relaxed">This member or role will bypass all security filters and protection protocols.</p>
                  </div>
                  <div 
                    onClick={() => setEditingPermit({ ...editingPermit, immunity: !editingPermit.immunity })}
                    className={`w-14 h-7 rounded-full relative cursor-pointer transition-all shrink-0 ${editingPermit.immunity ? 'bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)]' : 'bg-white/10'}`}
                  >
                    <div className={`absolute top-1 w-5 h-5 rounded-full transition-all ${editingPermit.immunity ? 'left-8 bg-white' : 'left-1 bg-white/20'}`} />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Permissions Map</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {ALL_PERMISSIONS.map(perm => (
                    <button 
                      key={perm.id}
                      onClick={() => {
                        const current = editingPermit.permissions;
                        const next = current.includes(perm.id) ? current.filter((p: string) => p !== perm.id) : [...current, perm.id];
                        setEditingPermit({ ...editingPermit, permissions: next });
                      }}
                      className={`p-5 rounded-2xl border text-left flex items-center justify-between transition-all ${editingPermit.permissions.includes(perm.id) ? 'bg-white/5 border-white/20' : 'bg-white/[0.01] border-white/5 hover:bg-white/[0.02]'}`}
                    >
                      <span className={`text-[12px] font-bold tracking-tight ${editingPermit.permissions.includes(perm.id) ? 'text-white' : 'text-white/30'}`}>{perm.label}</span>
                      {editingPermit.permissions.includes(perm.id) && <Check className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-6 pt-12 border-t border-white/5">
                <button 
                  onClick={() => setIsModalOpen(false)} 
                  className="text-[11px] font-bold tracking-widest uppercase text-white/20 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button 
                  disabled={loading || !editingPermit.targetId} 
                  onClick={savePermit} 
                  className={`px-10 py-4 rounded-xl text-[11px] font-bold uppercase tracking-widest transition-all ${loading || !editingPermit.targetId ? 'bg-white/5 text-white/10 cursor-not-allowed' : 'bg-white text-black hover:bg-zinc-200'}`}
                >
                  {loading ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
           </div>
        </div>
      )}
    </motion.div>
  );
}
