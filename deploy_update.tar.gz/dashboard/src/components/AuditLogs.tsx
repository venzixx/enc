"use client";

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Terminal, Clock, User, Shield } from "lucide-react";

interface Log {
  id: string;
  event: string;
  executorTag: string;
  createdAt: string;
  status: string;
}

export default function AuditLogs({ guildId }: { guildId: string }) {
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/guild/${guildId}/logs?limit=5`)
      .then(res => res.json())
      .then(data => setLogs(data.logs || []))
      .finally(() => setLoading(false));
  }, [guildId]);

  if (loading) return null;

  return (
    <div className="bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Terminal className="w-4 h-4 text-white/40" />
          <h2 className="text-sm font-semibold text-white">Recent Audit Logs</h2>
        </div>
        <a href={`/dashboard/${guildId}/logs`} className="text-[10px] font-bold text-white/20 uppercase tracking-widest hover:text-white transition-colors">View All</a>
      </div>

      <div className="space-y-3">
        {logs.map((log) => (
          <div key={log.id} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-white/[0.04] flex items-center justify-center">
                <Shield className="w-3.5 h-3.5 text-white/30" />
              </div>
              <div>
                <p className="text-xs font-semibold text-white/80">{log.event}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[9px] text-white/20 flex items-center gap-1"><User className="w-2.5 h-2.5" /> {log.executorTag}</span>
                  <span className="text-[9px] text-white/10">•</span>
                  <span className="text-[9px] text-white/20 flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> {new Date(log.createdAt).toLocaleTimeString()}</span>
                </div>
              </div>
            </div>
            <span className={`text-[8px] font-black tracking-widest uppercase px-2 py-0.5 rounded-md border ${
              log.status === 'CRITICAL' ? 'text-red-400 border-red-400/20 bg-red-400/10' : 'text-blue-400 border-blue-400/20 bg-blue-400/10'
            }`}>
              {log.status}
            </span>
          </div>
        ))}
        {logs.length === 0 && (
          <p className="text-center py-4 text-white/10 text-[10px] font-bold uppercase tracking-widest">No recent events</p>
        )}
      </div>
    </div>
  );
}
