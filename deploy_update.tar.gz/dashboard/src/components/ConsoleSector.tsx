"use client";

import React, { useState } from "react";
import { 
  UserMinus, Trash2, Lock, Bot, Settings, ArrowUpRight, Activity
} from "lucide-react";
import { useRouter } from "next/navigation";

interface ConsoleSectorProps {
  guildId: string;
  initialData: any;
}

export default function ConsoleSector({ guildId, initialData }: ConsoleSectorProps) {
  const [guildData, setGuildData] = useState(initialData);
  const [toggling, setToggling] = useState<string | null>(null);
  const router = useRouter();

  const sections = [
    { id: "levelingEnabled", title: "Leveling", status: guildData.levelingEnabled, icon: <Activity className="w-4 h-4 text-white/40" />, desc: "Reward engagement with XP." },
    { id: "antiNukeBan", title: "Anti-Ban", status: guildData.antiNukeBan, icon: <UserMinus className="w-4 h-4 text-white/40" />, desc: "Prevents mass member banning." },
    { id: "antiNukeKick", title: "Anti-Kick", status: guildData.antiNukeKick, icon: <UserMinus className="w-4 h-4 text-white/40" />, desc: "Prevents mass member kicking." },
    { id: "antiNukeChannel", title: "Channel Guard", status: guildData.antiNukeChannel, icon: <Trash2 className="w-4 h-4 text-white/40" />, desc: "Protects channels from deletion." },
    { id: "antiNukeRole", title: "Role Guard", status: guildData.antiNukeRole, icon: <Lock className="w-4 h-4 text-white/40" />, desc: "Protects roles from deletion." },
    { id: "antiNukeBot", title: "Bot Shield", status: guildData.antiNukeBot, icon: <Bot className="w-4 h-4 text-white/40" />, desc: "Kicks unauthorized bots." },
    { id: "antiNukeWebhook", title: "Webhook Guard", status: guildData.antiNukeWebhook, icon: <Settings className="w-4 h-4 text-white/40" />, desc: "Purges unauthorized webhooks." },
  ];

  const handleToggle = async (id: string, currentStatus: boolean) => {
    try {
      setToggling(id);
      
      const response = await fetch(`/api/guild/${guildId}/config`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field: id, value: !currentStatus }),
      });

      if (!response.ok) throw new Error("Failed to update config");

      const updated = await response.json();
      setGuildData(updated);
      router.refresh(); 
    } catch (error) {
      console.error("Failed to toggle protocol:", error);
    } finally {
      setToggling(null);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sections.map((section, index) => (
        <div key={index} className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] flex flex-col gap-8 group hover:bg-white/[0.02] transition-all relative overflow-hidden shadow-inner">
          {toggling === section.id && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-20 flex items-center justify-center">
               <div className="w-6 h-6 rounded-full border-2 border-white/10 border-t-white animate-spin" />
            </div>
          )}
          
          <div className="flex justify-between items-start">
            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5 group-hover:scale-110 transition-all duration-500 shadow-inner">
               {section.icon}
            </div>
            <div className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border transition-all ${section.status ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-white/5 text-white/20 border-white/5'}`}>
               {section.status ? "Operational" : "Deactivated"}
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xl font-black tracking-tight text-white uppercase">{section.title}</h3>
            <p className="text-[11px] text-white/30 font-bold uppercase tracking-widest leading-relaxed">{section.desc}</p>
          </div>

          <button 
            onClick={() => handleToggle(section.id, !!section.status)}
            disabled={toggling !== null}
            className={`w-full py-4 text-[10px] font-black tracking-[0.3em] uppercase rounded-xl transition-all flex items-center justify-center gap-3 shadow-xl ${section.status ? 'bg-white/5 border border-white/5 hover:bg-white/10 text-white/40' : 'bg-white text-black hover:bg-zinc-200'}`}
          >
            {section.status ? "Deactivate" : "Initialize"}
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
