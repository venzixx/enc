"use client";

import React from "react";
import { motion } from "framer-motion";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}


export default function QuickFeatures() {
  const features = [
    { icon: "⚡", title: "Autoresponder", desc: "Build intelligent response trees that handle queries 24/7 without lifting a finger.", tag: "Automation" },
    { icon: "🛡", title: "Anti-Nuke", desc: "Military-grade server protection. Stop raids, nukes, and hostile takeovers cold.", tag: "Security" },
    { icon: "🎨", title: "Branding Engine", desc: "Custom embeds, color schemes, and messages that make your server unforgettable.", tag: "Customization" },
    { icon: "📊", title: "Deep Analytics", desc: "Real-time dashboards. Understand exactly how your community breathes.", tag: "Intelligence" },
    { icon: "🔐", title: "Role Permissions", desc: "Granular access control. The right powers to the right people, always.", tag: "Control" },
    { icon: "🎟", title: "Ticket System", desc: "Multi-panel routing that gets members to the right staff in seconds.", tag: "Support" },
  ];

  return (
    <section className="py-32 bg-transparent relative">
      <div className="max-w-7xl mx-auto px-8">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-20">
            <div>
              <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">What we offer</p>
              <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/60 tracking-tight leading-none">
                Every tool.<br />One protocol.
              </h2>
            </div>
            <p className="text-white/30 max-w-xs text-sm leading-relaxed">
              Enc Nexus ships with everything you need to run a professional Discord community from day one.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/[0.04] rounded-3xl overflow-hidden border border-white/[0.04]">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.07}>
              <motion.div
                whileHover={{ backgroundColor: "rgba(255,255,255,0.03)" }}
                className="bg-transparent p-8 flex flex-col gap-5 group relative overflow-hidden h-full"
              >
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/[0.03] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                <div className="flex items-start justify-between">
                  <span className="text-3xl">{f.icon}</span>
                  <span className="text-[9px] font-black text-white/20 uppercase tracking-widest border border-white/[0.06] px-2 py-1 rounded-full">{f.tag}</span>
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg mb-2 tracking-tight">{f.title}</h3>
                  <p className="text-white/30 text-sm leading-relaxed">{f.desc}</p>
                </div>
                <div className="mt-auto pt-4 border-t border-white/[0.04] flex items-center justify-between">
                  <span className="text-white text-[11px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Learn more</span>
                  <span className="text-white opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-0 -translate-x-2 duration-300">→</span>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
