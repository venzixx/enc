"use client";

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Preloader() {
  const [loading, setLoading] = useState(true);
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCounter((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setLoading(false), 800);
          return 100;
        }
        return prev + Math.floor(Math.random() * 8) + 2;
      });
    }, 60);

    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          key="preloader"
          initial={{ opacity: 1 }}
          exit={{ 
            y: "-100%",
            transition: { duration: 1, ease: [0.76, 0, 0.24, 1] }
          }}
          className="fixed inset-0 z-[1000] bg-[#000] flex flex-col items-center justify-center overflow-hidden"
        >
          {/* Progress Number - Ultra Big and Stylized */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-[20vw] md:text-[30vw] font-black text-white/[0.02] tracking-tighter leading-none select-none"
              style={{ fontFamily: "'Syne', sans-serif" }}
            >
              {Math.min(counter, 100)}
            </motion.div>
          </div>

          {/* Center Brand Node */}
          <div className="relative z-10 flex flex-col items-center gap-8">
            <div className="relative">
                <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.8 }}
                    className="w-16 h-16 rounded-2xl border border-[#27F3A9]/20 flex items-center justify-center relative overflow-hidden"
                >
                    <div className="w-2 h-2 rounded-full bg-[#27F3A9] shadow-[0_0_15px_#27F3A9]" />
                    <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                        className="absolute inset-0 border-t-2 border-[#27F3A9]/40 rounded-2xl"
                    />
                </motion.div>
            </div>

            <div className="overflow-hidden h-8">
                <motion.h2 
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="text-sm font-black tracking-[0.6em] text-white uppercase"
                    style={{ fontFamily: "'Syne', sans-serif" }}
                >
                    Enc Nexus
                </motion.h2>
            </div>
            
            <div className="flex items-center gap-4 text-white/20 text-[9px] font-black uppercase tracking-[0.4em]">
                <span>Initializing Protocol</span>
                <span className="flex gap-1">
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0 }}>.</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}>.</motion.span>
                    <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }}>.</motion.span>
                </span>
            </div>
          </div>

          {/* Precision Loading Bar */}
          <div className="absolute bottom-0 left-0 w-full h-1 bg-white/[0.03]">
            <motion.div 
                className="h-full bg-[#27F3A9] shadow-[0_0_20px_rgba(39,243,169,0.5)]" 
                style={{ width: `${Math.min(counter, 100)}%`, transition: 'width 0.1s linear' }} 
            />
          </div>
          
          {/* Corner Decals */}
          <div className="absolute top-10 left-10 text-white/10 text-[10px] font-mono tracking-widest uppercase">
            Protocol v4.0.2
          </div>
          <div className="absolute top-10 right-10 text-white/10 text-[10px] font-mono tracking-widest uppercase">
            {new Date().toLocaleTimeString()}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
