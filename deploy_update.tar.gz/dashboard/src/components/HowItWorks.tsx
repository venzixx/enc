"use client";

import React from "react";
import { motion } from "framer-motion";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}


export default function HowItWorks() {
  const steps = [
    { n: "01", title: "Invite the Bot", desc: "Add Enc Nexus to your server in under 30 seconds. No configuration required to get started." },
    { n: "02", title: "Configure Modules", desc: "Use our visual dashboard to set up exactly what you need. Auto Roles, Tickets, Analytics — all modular." },
    { n: "03", title: "Go Live", desc: "Your server is protected, automated, and analytics-ready. Your community runs itself." },
  ];

  return (
    <section className="py-32 bg-transparent relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-8">
        <Reveal>
          <div className="text-center mb-24">
            <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">Process</p>
            <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/50 tracking-tight">
              Three steps.<br />Infinite scale.
            </h2>
          </div>
        </Reveal>

        <div className="relative">
          {/* Connecting line */}
          <div className="absolute top-8 left-[calc(16.67%+1rem)] right-[calc(16.67%+1rem)] h-px bg-gradient-to-r from-white/20 via-white/40 to-white/20 hidden md:block" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {steps.map((s, i) => (
              <Reveal key={s.n} delay={i * 0.15}>
                <div className="flex flex-col items-center md:items-start text-center md:text-left gap-6 group">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl border border-white/20 bg-white/5 flex items-center justify-center group-hover:border-white/40 group-hover:bg-white/10 transition-all duration-500">
                      <span className="text-white font-black text-sm">{s.n}</span>
                    </div>
                    <div className="absolute inset-0 rounded-2xl bg-white/10 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-xl mb-3 tracking-tight">{s.title}</h3>
                    <p className="text-white/30 leading-relaxed text-sm">{s.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
