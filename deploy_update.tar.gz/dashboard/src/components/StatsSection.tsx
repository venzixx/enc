"use client";

import React, { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const start = Date.now();
    const dur = 2000;
    const tick = () => {
      const progress = Math.min((Date.now() - start) / dur, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setVal(Math.floor(eased * to));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, to]);

  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

export default function StatsSection({ stats: liveStats }: { stats: { guilds: number, users: number, uptime: number, latency: number } }) {
  const stats = [
    { value: liveStats.guilds, suffix: liveStats.guilds > 0 ? "+" : "", label: "Discord Servers" },
    { value: liveStats.users, suffix: liveStats.users > 0 ? "+" : "", label: "Members Reached" },
    { value: liveStats.uptime > 0 ? liveStats.uptime : 99.9, suffix: "%", label: "Uptime SLA" },
    { value: liveStats.latency, suffix: "ms", label: "Response Time" },
  ];

  return (
    <section className="py-32 bg-transparent relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/[0.02] to-transparent" />
      <div className="max-w-7xl mx-auto px-8">
        <Reveal>
          <div className="text-center mb-20">
            <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">By the numbers</p>
            <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 tracking-tight">
              Proven at Scale
            </h2>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-white/[0.04] rounded-3xl overflow-hidden border border-white/[0.04]">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.1}>
              <div className="bg-black p-10 flex flex-col gap-3 group hover:bg-white/[0.03] transition-colors duration-500">
                <span className="text-4xl md:text-5xl lg:text-5xl font-bold text-white tracking-tight">
                  <Counter to={s.value} suffix={s.suffix} />
                </span>
                <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">{s.label}</span>
                <div className="w-8 h-px bg-white opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
