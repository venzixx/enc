"use client";

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare, Heart, Mic, Zap, Shield, UserPlus,
  Palette, Users, FileCode, Activity, BarChart3, Radio,
  Cpu, ArrowUpRight, TrendingDown, TrendingUp
} from "lucide-react";
import Link from "next/link";
import AuditLogs from "./AuditLogs";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer
} from "recharts";

interface AnalyticsData {
  stats: {
    messages: { value: number; change: number };
    reactions: { value: number; change: number };
    voice: { value: number; change: number };
  };
  graphData: { date: string; messages: number }[];
  topChannels: { id: string; name?: string; count: number }[];
  topMembers: { id: string; name?: string; avatar?: string; count: number }[];
}

// ── CUSTOM TOOLTIP ──────────────────────────────────────────────────────────
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#12141a] border border-white/10 rounded-xl px-4 py-3 shadow-2xl text-xs">
      <p className="text-white/40 mb-1 uppercase tracking-widest font-semibold">{label}</p>
      <p className="text-white font-bold text-sm">{payload[0].value.toLocaleString()} <span className="text-white/30 font-normal text-xs">messages</span></p>
    </div>
  );
}

// ── SPARKLINE (stat cards) ───────────────────────────────────────────────────
function Sparkline({ data, color }: { data: number[]; color: string }) {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data);
  const range = max - min || 1;
  const allZero = data.every(v => v === 0);

  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = allZero ? 90 : 100 - ((d - min) / range) * 80 - 10;
    return `${x},${y}`;
  });

  const areaPts = `0,100 ${pts.join(" ")} 100,100`;

  return (
    <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
      <defs>
        <linearGradient id={`sg-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={areaPts} fill={`url(#sg-${color.replace("#", "")})`} />
      <polyline
        points={pts.join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// ── STAT CARD ────────────────────────────────────────────────────────────────
function StatCard({ label, value, change, icon, sparkData, accentColor }: {
  label: string; value: number; change: number;
  icon: React.ReactNode; sparkData: number[]; accentColor: string;
}) {
  const isPositive = change >= 0;
  const isZero = change === 0;

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
      className="bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-5 flex flex-col gap-4 relative overflow-hidden"
    >
      {/* top row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-white/30">{icon}</span>
          <span className="text-[11px] font-semibold text-white/30 uppercase tracking-widest">{label}</span>
        </div>
        <span style={{ color: accentColor }} className="opacity-20">
          {icon}
        </span>
      </div>

      {/* value + change */}
      <div className="flex items-end justify-between">
        <span className="text-3xl font-bold text-white tracking-tight">{value.toLocaleString()}</span>
        <span className={`text-xs font-bold flex items-center gap-1 ${isZero ? "text-white/30" : isPositive ? "text-emerald-400" : "text-red-400"
          }`}>
          {!isZero && (isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />)}
          {isZero ? "no change" : `${isPositive ? "+" : ""}${change}%`}
        </span>
      </div>

      {/* sparkline */}
      <div className="h-12 -mx-1">
        <Sparkline data={sparkData} color={accentColor} />
      </div>
    </motion.div>
  );
}

// ── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function AnalyticsClient({ guildId }: { guildId: string }) {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/guild/${guildId}/analytics`)
      .then(res => res.json())
      .then(setData)
      .finally(() => setLoading(false));
  }, [guildId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4">
        <div className="w-8 h-8 rounded-full border-2 border-white/10 border-t-blue-500 animate-spin" />
        <p className="text-[10px] font-semibold text-white/20 uppercase tracking-[0.4em]">Loading Analytics</p>
      </div>
    );
  }

  const quickActions = [
    { label: "Autoresponder", icon: <MessageSquare className="w-4 h-4" />, color: "#a78bfa", href: `/dashboard/${guildId}/autoresponder` },
    { label: "Antinuke", icon: <Shield className="w-4 h-4" />, color: "#f87171", href: `/dashboard/${guildId}/security` },
    { label: "Auto Roles", icon: <UserPlus className="w-4 h-4" />, color: "#60a5fa", href: `/dashboard/${guildId}/roleconnections` },
    { label: "Branding", icon: <Palette className="w-4 h-4" />, color: "#f472b6", href: `/dashboard/${guildId}/branding` },
    { label: "Permissions", icon: <Users className="w-4 h-4" />, color: "#fb923c", href: `/dashboard/${guildId}/permits` },
    { label: "Messages", icon: <FileCode className="w-4 h-4" />, color: "#34d399", href: `/dashboard/${guildId}/messages` },
  ];

  const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.08 } } };
  const item = { hidden: { opacity: 0, y: 16 }, show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 120, damping: 20 } } };

  // Format graph dates for XAxis
  const chartData = (data?.graphData || []).map(d => ({
    ...d,
    label: new Date(d.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
  }));

  return (
    <motion.div
      initial="hidden" animate="show" variants={container}
      className="p-6 lg:p-10 space-y-8 max-w-[1400px] mx-auto pb-24"
      style={{ fontFamily: "'Inter', system-ui, sans-serif" }}
    >

      {/* ── HEADER ── */}
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Analytics</h1>
          <p className="text-sm text-white/30 mt-0.5">Activity overview for your server</p>
        </div>
        <div className="flex items-center gap-2 bg-[#0d0f14] border border-white/[0.06] px-4 py-2 rounded-xl">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[11px] font-semibold text-white/40 uppercase tracking-widest">Live</span>
        </div>
      </motion.div>

      {/* ── STAT CARDS ── */}
      <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          label="Messages" value={data?.stats.messages.value || 0}
          change={data?.stats.messages.change || 0}
          icon={<MessageSquare className="w-4 h-4" />}
          sparkData={data?.graphData.map(d => d.messages) || []}
          accentColor="#6366f1"
        />
        <StatCard
          label="Reactions" value={data?.stats.reactions.value || 0}
          change={data?.stats.reactions.change || 0}
          icon={<Heart className="w-4 h-4" />}
          sparkData={[10, 40, 20, 50, 30, 70, 45]}
          accentColor="#a855f7"
        />
        <StatCard
          label="Voice Hours" value={data?.stats.voice.value || 0}
          change={data?.stats.voice.change || 0}
          icon={<Mic className="w-4 h-4" />}
          sparkData={[30, 20, 40, 35, 50, 45, 60]}
          accentColor="#10b981"
        />
      </motion.div>

      {/* ── CHART + TOP CHANNELS ── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* Area chart */}
        <motion.div variants={item} className="xl:col-span-2 bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-6">
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-white">Message Activity</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Daily messages over the last 7 days</p>
          </div>

          <div className="h-[260px]">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="msgGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="rgba(255,255,255,0.04)" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11, fontWeight: 500 }}
                    axisLine={false} tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }}
                    axisLine={false} tickLine={false}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{ stroke: "rgba(255,255,255,0.08)", strokeWidth: 1 }} />
                  <Area
                    type="monotone" dataKey="messages"
                    stroke="#6366f1" strokeWidth={2}
                    fill="url(#msgGradient)"
                    dot={false} activeDot={{ r: 4, fill: "#6366f1", strokeWidth: 0 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-white/10 text-xs uppercase tracking-widest font-semibold">
                No Data Available
              </div>
            )}
          </div>
        </motion.div>

        {/* Top Channels */}
        <motion.div variants={item} className="bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-6">
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-white">Top Channels</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Most active this week</p>
          </div>

          <div className="space-y-1.5">
            {(data?.topChannels || []).map((ch, idx) => {
              const maxCount = Math.max(...(data?.topChannels.map(c => c.count) || [1]), 1);
              const pct = (ch.count / maxCount) * 100;
              return (
                <div key={idx} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors group">
                  <span className="text-[10px] font-bold text-white/20 w-4 text-center">{idx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-semibold text-white/70 truncate">#{ch.name || ch.id}</span>
                      <span className="text-xs font-bold text-white ml-2">{ch.count.toLocaleString()}</span>
                    </div>
                    <div className="h-0.5 rounded-full bg-white/[0.05] overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ delay: idx * 0.1, duration: 0.6, ease: "easeOut" }}
                        className="h-full rounded-full bg-indigo-500"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* ── AUDIT LOGS ── */}
      <motion.div variants={item}>
        <AuditLogs guildId={guildId} />
      </motion.div>

      {/* ── LOWER ROW: TOP MEMBERS + QUICK ACTIONS ── */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">

        {/* Top Members */}
        <motion.div variants={item} className="bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-6">
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-white">Top Members</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Most messages sent</p>
          </div>

          <div className="space-y-1.5">
            {(data?.topMembers || []).map((m, idx) => (
              <motion.div
                key={idx}
                whileHover={{ x: 2 }}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-white/[0.06] border border-white/[0.06] shrink-0 overflow-hidden flex items-center justify-center">
                  {m.avatar
                    ? <img src={m.avatar} alt="" className="w-full h-full object-cover" />
                    : <span className="text-[10px] font-bold text-white/20">{idx + 1}</span>
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-white/80 truncate">{m.name || m.id}</p>
                  <p className="text-[10px] text-white/30">{m.count.toLocaleString()} msgs</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div variants={item} className="xl:col-span-3 bg-[#0d0f14] border border-white/[0.06] rounded-2xl p-6">
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-white">Quick Access</h2>
            <p className="text-[11px] text-white/30 mt-0.5">Jump to a module</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {quickActions.map((action, idx) => (
              <Link href={action.href} key={idx}>
                <motion.div
                  whileHover={{ y: -2, backgroundColor: "rgba(255,255,255,0.04)" }}
                  whileTap={{ scale: 0.98 }}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] flex items-center gap-3 cursor-pointer transition-colors"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${action.color}18`, color: action.color }}
                  >
                    {action.icon}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white/80">{action.label}</p>
                    <p className="text-[10px] text-white/25 flex items-center gap-0.5 mt-0.5">
                      Open <ArrowUpRight className="w-2.5 h-2.5" />
                    </p>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}