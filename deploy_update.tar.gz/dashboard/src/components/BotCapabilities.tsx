"use client";

import React from "react";
import { motion } from "framer-motion";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, scale: 0.97 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Marquee({ children, speed = 40 }: { children: React.ReactNode; speed?: number }) {
  return (
    <div className="overflow-hidden flex">
      <motion.div
        animate={{ x: [0, "-50%"] }}
        transition={{ duration: speed, repeat: Infinity, ease: "linear" }}
        className="flex shrink-0 gap-6"
      >
        {children}{children}
      </motion.div>
    </div>
  );
}

export default function BotCapabilities() {
  const caps = ["Smart Automod", "Ticket Routing", "Role Automation", "Invite Tracking", "Message Logging", "Custom Embeds", "Reaction Roles", "Timed Punishments", "Backup Systems", "Welcome Flows"];

  return (
    <section className="py-32 bg-transparent relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/[0.015] to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-8 mb-16">
        <Reveal>
          <div className="flex flex-col md:flex-row md:items-end gap-8 justify-between">
            <div>
              <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">Capabilities</p>
              <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/40 tracking-tight leading-none">
                Built to handle<br /><em className="not-italic text-white/30">everything.</em>
              </h2>
            </div>

            <div className="max-w-sm p-6 rounded-3xl border border-white/[0.06] bg-white/[0.02] space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                <span className="text-[10px] text-white font-black uppercase tracking-widest">All systems operational</span>
              </div>
              <p className="text-white/50 text-sm leading-relaxed">Every module is battle-tested across 50,000+ servers. Zero compromises.</p>
            </div>
          </div>
        </Reveal>
      </div>

      <div className="space-y-4">
        <Marquee speed={35}>
          {caps.map(c => (
            <div key={c} className="flex items-center gap-3 shrink-0 border border-white/[0.06] bg-white/[0.02] px-6 py-3 rounded-full">
              <div className="w-1 h-1 rounded-full bg-white" />
              <span className="text-white/60 text-[11px] font-bold uppercase tracking-widest whitespace-nowrap">{c}</span>
            </div>
          ))}
        </Marquee>
        <Marquee speed={50}>
          {[...caps].reverse().map(c => (
            <div key={c} className="flex items-center gap-3 shrink-0 border border-white/[0.06] bg-white/[0.01] px-6 py-3 rounded-full">
              <div className="w-1 h-1 rounded-full bg-white/20" />
              <span className="text-white/30 text-[11px] font-bold uppercase tracking-widest whitespace-nowrap">{c}</span>
            </div>
          ))}
        </Marquee>
      </div>
    </section>
  );
}
