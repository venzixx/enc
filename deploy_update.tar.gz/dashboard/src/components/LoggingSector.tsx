"use client";

import React, { useState, useEffect, useCallback } from "react";
import { 
  MessageSquare, Hash, ShieldAlert, Users, 
  Gavel, ShieldCheck, RefreshCw, 
  Trash2, Terminal, Clock, User, 
  ArrowUpRight, AlertCircle, ChevronDown, Monitor, ListTree, Sparkles, Mic
} from "lucide-react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import CustomSelect from "./CustomSelect";
import MarkdownDisplay from "./MarkdownDisplay";

interface LoggingSectorProps {
  guildId: string;
  initialData: any;
}

export default function LoggingSector({ guildId, initialData }: LoggingSectorProps) {
  const [guildData, setGuildData] = useState(initialData);
  const [logs, setLogs] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [isToggling, setIsToggling] = useState<string | null>(null);
  const [isClearing, setIsClearing] = useState(false);
  const router = useRouter();

  const fetchLogs = useCallback(async () => {
    try {
      const res = await fetch(`/api/guild/${guildId}/logs`);
      if (res.ok) setLogs(await res.json());
    } catch (error) {
      console.error(error);
    }
  }, [guildId]);

  const fetchChannels = useCallback(async () => {
    try {
      const res = await fetch(`/api/guild/${guildId}/channels`);
      if (res.ok) setChannels(await res.json());
    } catch (error) {
      console.error(error);
    }
  }, [guildId]);

  useEffect(() => {
    fetchLogs();
    fetchChannels();
    const interval = setInterval(fetchLogs, 10000);
    return () => clearInterval(interval);
  }, [fetchLogs, fetchChannels]);

  const handleUpdate = async (field: string, value: any) => {
    setIsToggling(field);
    try {
      const res = await fetch(`/api/guild/${guildId}/config`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field, value }),
      });
      if (res.ok) {
        setGuildData((prev: any) => ({ ...prev, [field]: value }));
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsToggling(null);
    }
  };

  const categories = [
    { id: "Messages", title: "Messages", icon: <MessageSquare className="w-3.5 h-3.5" />, desc: "Edits & Deletes", dbField: "logMessagesEnabled", channelField: "logChannelMessages" },
    { id: "Channels", title: "Channels", icon: <Hash className="w-3.5 h-3.5" />, desc: "Channel Changes", dbField: "logChannelsEnabled", channelField: "logChannelChannels" },
    { id: "Roles", title: "Roles", icon: <ShieldAlert className="w-3.5 h-3.5" />, desc: "Permission Shifts", dbField: "logRolesEnabled", channelField: "logChannelRoles" },
    { id: "Members", title: "Members", icon: <Users className="w-3.5 h-3.5" />, desc: "Member Activity", dbField: "logMembersEnabled", channelField: "logChannelMembers" },
    { id: "Moderation", title: "Moderation", icon: <Gavel className="w-3.5 h-3.5" />, desc: "Mod Actions", dbField: "logModerationEnabled", channelField: "logChannelModeration" },
    { id: "Security", title: "Security", icon: <ShieldCheck className="w-3.5 h-3.5" />, desc: "Security Logs", dbField: "logSecurityEnabled", channelField: "logChannelSecurity" },
    { id: "Voice", title: "Voice", icon: <Monitor className="w-3.5 h-3.5" />, desc: "Voice Activity", dbField: "logVoiceEnabled", channelField: "logChannelVoice" },
    { id: "Automod", title: "Automod", icon: <ShieldCheck className="w-3.5 h-3.5" />, desc: "Automod Logs", dbField: "logAutomodEnabled", channelField: "logChannelAutomod" },
    { id: "Bot", title: "Bot", icon: <Terminal className="w-3.5 h-3.5" />, desc: "Bot Logs", dbField: "logBotEnabled", channelField: "logChannelBot" },
    { id: "Invites", title: "Invites", icon: <Users className="w-3.5 h-3.5" />, desc: "Invite Logs", dbField: "logInvitesEnabled", channelField: "logChannelInvites" },
    { id: "Emoji", title: "Emoji", icon: <Sparkles className="w-3.5 h-3.5" />, desc: "Emoji Logs", dbField: "logEmojiEnabled", channelField: "logChannelEmoji" },
    { id: "Sticker", title: "Sticker", icon: <Sparkles className="w-3.5 h-3.5" />, desc: "Sticker Logs", dbField: "logStickerEnabled", channelField: "logChannelSticker" },
    { id: "Events", title: "Events", icon: <Clock className="w-3.5 h-3.5" />, desc: "Event Logs", dbField: "logEventsEnabled", channelField: "logChannelEvents" },
    { id: "Stage", title: "Stage", icon: <Mic className="w-3.5 h-3.5" />, desc: "Stage Logs", dbField: "logStageEnabled", channelField: "logChannelStage" },
    { id: "Server", title: "Server", icon: <ShieldCheck className="w-3.5 h-3.5" />, desc: "Server Logs", dbField: "logServerEnabled", channelField: "logChannelServer" },
    { id: "Threads", title: "Threads", icon: <Hash className="w-3.5 h-3.5" />, desc: "Thread Logs", dbField: "logThreadsEnabled", channelField: "logChannelThreads" },
    { id: "Vanity", title: "Vanity", icon: <Terminal className="w-3.5 h-3.5" />, desc: "Vanity Logs", dbField: "logVanityEnabled", channelField: "logChannelVanity" },
    { id: "Webhooks", title: "Webhooks", icon: <Terminal className="w-3.5 h-3.5" />, desc: "Webhook Logs", dbField: "logWebhooksEnabled", channelField: "logChannelWebhooks" },
  ];

  const categoryOptions = channels.filter(c => c.type === 4); // Filter for category channels

  return (
    <div className="flex flex-col gap-10">
      <div className="space-y-6">
        <div className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl flex flex-col gap-6 shadow-inner">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/5 flex items-center justify-center text-white/40 shadow-inner">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white">Main Core Log</h3>
              <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest">Global audit destination.</p>
            </div>
          </div>

          <CustomSelect
            options={channels}
            value={guildData.logChannelId || ""}
            onChange={(val) => {
              handleUpdate("logChannelId", val);
              if (val) handleUpdate("logCategoryId", null); // Clear category if core is set
            }}
            placeholder="Select core..."
          />
        </div>

        <div className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl flex flex-col gap-6 shadow-inner">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/5 flex items-center justify-center text-white/40 shadow-inner">
              <ListTree className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-white">Logging Category</h3>
              <p className="text-[9px] text-white/20 font-bold uppercase tracking-widest">Automated multi-channel routing.</p>
            </div>
          </div>

          <CustomSelect
            options={categoryOptions}
            value={guildData.logCategoryId || ""}
            onChange={(val) => {
              handleUpdate("logCategoryId", val);
              if (val) handleUpdate("logChannelId", null); // Clear core if category is set
            }}
            placeholder="Select category..."
          />
        </div>
      </div>

      <AnimatePresence>
        {guildData.logCategoryId && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="grid grid-cols-1 gap-4 overflow-hidden"
          >
            {categories.map((cat) => (
              <div key={cat.id} className="bg-white/[0.01] border border-white/5 p-5 rounded-2xl flex flex-col gap-4 group relative overflow-visible transition-all hover:bg-white/[0.02] shadow-inner">
                {isToggling === cat.dbField && (
                  <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px] z-10 flex items-center justify-center">
                    <RefreshCw className="w-3.5 h-3.5 text-white animate-spin" />
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                   <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center border border-white/5 bg-white/5 transition-colors ${guildData[cat.dbField] ? 'text-indigo-400 border-indigo-500/20' : 'text-white/10'}`}>
                        {cat.icon}
                      </div>
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-white/40 group-hover:text-white transition-colors">{cat.title}</h4>
                   </div>
                   <button
                     onClick={() => handleUpdate(cat.dbField, !guildData[cat.dbField])}
                     className={`w-9 h-5 rounded-full relative transition-all duration-300 shadow-xl ${guildData[cat.dbField] ? 'bg-white' : 'bg-white/5'}`}
                   >
                     <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${guildData[cat.dbField] ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
                   </button>
                </div>

                <CustomSelect
                  options={channels}
                  value={guildData[cat.channelField] || ""}
                  onChange={(val) => handleUpdate(cat.channelField, val)}
                  placeholder="System Default"
                />
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white/[0.01] border border-white/5 rounded-[32px] overflow-hidden shadow-inner">
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
            <div className="flex items-center gap-3">
               <Terminal className="w-3.5 h-3.5 text-white/20" />
               <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-white/20">Audit Stream</h3>
            </div>
            <div className="flex items-center gap-2">
               <button onClick={() => fetchLogs()} className="p-1.5 text-white/10 hover:text-white transition-colors"><RefreshCw className="w-3.5 h-3.5" /></button>
            </div>
        </div>

        <div className="flex flex-col divide-y divide-white/[0.02]">
          <AnimatePresence mode="popLayout">
            {logs.length > 0 ? (
              logs.map((log) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="p-5 space-y-3 hover:bg-white/[0.01] transition-all group"
                >
                  <div className="flex items-center justify-between">
                     <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-white/10 group-hover:bg-indigo-500 transition-colors" />
                        <span className="text-[11px] font-black text-white/60 group-hover:text-white transition-colors uppercase tracking-tight">{log.event.toLowerCase().replace(/_/g, ' ')}</span>
                     </div>
                     <span className="text-[8px] font-black text-white/10 uppercase tracking-widest">{formatDistanceToNow(new Date(log.createdAt))}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[9px] text-white/20 font-bold uppercase tracking-widest">
                     <User className="w-3 h-3 opacity-50" /> {log.executorTag || 'SYSTEM'}
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="py-12 flex flex-col items-center justify-center gap-4 text-center">
                  <AlertCircle className="w-5 h-5 text-white/5" />
                  <p className="text-white/10 font-black uppercase tracking-widest text-[9px]">Stream Empty</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
