"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSession, signOut, signIn } from "next-auth/react";
import { usePathname } from "next/navigation";
import { LogOut, User, ChevronDown } from "lucide-react";

export default function Navbar() {
  const { data: session } = useSession();
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [botInfo, setBotInfo] = useState<{ name: string; avatar: string }>({ name: 'Enc Nexus', avatar: '' });

  useEffect(() => {
    fetch('/api/bot/info').then(r => r.json()).then(data => {
      if (data.name) setBotInfo(data);
    }).catch(() => {});
  }, []);
  
  const isHome = pathname === "/";
  
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "/" },
    { name: "Status", href: "/status" },
    { name: "Docs", href: "/codex" }
  ];

  return (
    <motion.nav
      initial={isHome ? { y: -80, opacity: 0 } : { y: 0, opacity: 1 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
      className={`fixed top-8 left-1/2 -translate-x-1/2 z-[100] transition-all duration-700 w-[calc(100%-4rem)] max-w-5xl rounded-full border border-white/[0.08] ${
        scrolled 
        ? "py-3 bg-black/60 backdrop-blur-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)]" 
        : "py-5 bg-white/[0.02] backdrop-blur-md"
      }`}
    >
      <div className="px-8 flex items-center justify-between gap-8">
        {/* Logo Node */}
        <div className="flex items-center gap-5 group cursor-pointer" onClick={() => window.location.href = '/'}>
          <div className="w-12 h-12 rounded-2xl border border-white/30 flex items-center justify-center group-hover:border-white/60 transition-colors duration-500 overflow-hidden relative">
            {botInfo.avatar ? (
              <img src={botInfo.avatar} className="w-full h-full object-cover" alt="" />
            ) : (
              <div className="w-3 h-3 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]" />
            )}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border border-white/10 rounded-2xl"
            />
          </div>
          <div className="flex flex-col justify-center">
            <span className="text-white font-black text-sm tracking-[0.3em] uppercase leading-none">{botInfo.name}</span>
            <div className="h-0 overflow-visible">
              <span className="text-white/40 text-[9px] font-black tracking-[0.2em] uppercase mt-2 opacity-0 group-hover:opacity-100 transition-all duration-500 block whitespace-nowrap">Online</span>
            </div>
          </div>
        </div>

        {/* Center Links */}
        <div className="hidden md:flex items-center gap-12">
          {navLinks.map((link, i) => (
            <motion.a 
              key={link.name} 
              href={link.href}
              initial={isHome ? { opacity: 0, y: -10 } : { opacity: 1, y: 0 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: isHome ? 0.1 * i + 0.5 : 0 }}
              className="text-white/30 hover:text-white text-[10px] font-black uppercase tracking-[0.25em] transition-all duration-300 relative group"
            >
              {link.name}
              <span className="absolute -bottom-2 left-0 w-0 h-[1px] bg-white group-hover:w-full transition-all duration-500" />
            </motion.a>
          ))}
        </div>

        {/* Action Node */}
        <motion.div
            initial={isHome ? { opacity: 0, scale: 0.9 } : { opacity: 1, scale: 1 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: isHome ? 1 : 0 }}
            className="relative"
        >
            {session ? (
              <div className="relative">
                <button
                  onClick={() => setProfileOpen(!profileOpen)}
                  className="flex items-center gap-3 px-4 py-2 bg-white/[0.04] border border-white/10 hover:border-white/40 hover:bg-white/10 rounded-full transition-all duration-500 backdrop-blur-md group"
                >
                  <div className="w-7 h-7 rounded-full overflow-hidden border border-white/20">
                    <img 
                      src={session.user?.image || ""} 
                      alt="" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-white text-[10px] font-black uppercase tracking-widest hidden sm:block">
                    {session.user?.name?.split(' ')[0]}
                  </span>
                  <ChevronDown className={`w-3 h-3 text-white/40 group-hover:text-white transition-transform ${profileOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {profileOpen && (
                    <>
                      <div className="fixed inset-0 z-[-1]" onClick={() => setProfileOpen(false)} />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute right-0 mt-4 w-48 bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl"
                      >
                        <div className="p-4 border-b border-white/5">
                          <p className="text-white text-[10px] font-black uppercase tracking-widest truncate">{session.user?.name}</p>
                          <p className="text-white/30 text-[8px] font-bold uppercase tracking-widest mt-1 truncate">{session.user?.email}</p>
                        </div>
                        <div className="p-2">
                          <button
                            onClick={() => window.location.href = '/dashboard'}
                            className="w-full flex items-center gap-3 px-3 py-2 text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white hover:bg-white/5 rounded-xl transition-all"
                          >
                            <User className="w-3.5 h-3.5" /> Dashboard
                          </button>
                          <button
                            onClick={() => signOut()}
                            className="w-full flex items-center gap-3 px-3 py-2 text-[10px] font-black uppercase tracking-widest text-red-400/60 hover:text-red-400 hover:bg-red-400/5 rounded-xl transition-all"
                          >
                            <LogOut className="w-3.5 h-3.5" /> Logout
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                  onClick={() => window.location.href = '/auth/signin'}
                  className="px-8 py-3 bg-white/[0.04] border border-white/10 hover:border-white/40 hover:bg-white/10 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-full transition-all duration-500 backdrop-blur-md"
              >
                  Sign In
              </button>
            )}
        </motion.div>
      </div>
    </motion.nav>
  );
}
