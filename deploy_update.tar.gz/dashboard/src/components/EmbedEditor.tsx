'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Eye, Code, Sparkles, AlertCircle, Check, Copy, MessageSquare } from 'lucide-react';

interface EmbedEditorProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: any) => void;
    initialData: any;
    title?: string;
    placeholders?: string[];
}

export default function EmbedEditor({ isOpen, onClose, onSave, initialData, title = "Embed Architect", placeholders = [] }: EmbedEditorProps) {
    const [jsonStr, setJsonStr] = useState(JSON.stringify(initialData || { title: "New Embed", description: "Hello {user}!" }, null, 2));
    const [error, setError] = useState<string | null>(null);
    const [previewData, setPreviewData] = useState<any>(initialData || {});
    const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');

    useEffect(() => {
        if (initialData) {
            setJsonStr(JSON.stringify(initialData, null, 2));
            setPreviewData(initialData);
        }
    }, [initialData, isOpen]);

    const handleJsonChange = (val: string) => {
        setJsonStr(val);
        try {
            const parsed = JSON.parse(val);
            setError(null);
            setPreviewData(parsed);
        } catch (e: any) {
            setError(e.message);
        }
    };

    const handleSave = () => {
        try {
            const parsed = JSON.parse(jsonStr);
            onSave(parsed);
            onClose();
        } catch (e) {
            setError("Cannot save invalid JSON.");
        }
    };

    const insertPlaceholder = (p: string) => {
        setJsonStr(prev => {
            // Very simple insertion logic: just append or try to find where the cursor would be (simulated)
            return prev + "\n// Suggested: " + p;
        });
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12">
                    <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/90 backdrop-blur-2xl"
                    />
                    
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 20 }}
                        className="bg-[#0a0a0a] border border-white/10 rounded-[40px] w-full max-w-5xl h-[85vh] flex flex-col overflow-hidden shadow-2xl relative"
                    >
                        {/* Header */}
                        <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                            <div className="flex items-center gap-5">
                                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10">
                                    <Sparkles className="w-5 h-5 text-white/60" />
                                </div>
                                <div>
                                    <h3 className="text-[12px] font-black uppercase tracking-[0.3em] text-white">{title}</h3>
                                    <p className="text-[9px] text-white/20 font-black uppercase tracking-widest mt-1">Advanced JSON configuration and visual telemetry.</p>
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-4">
                                <div className="flex p-1 bg-white/5 rounded-xl border border-white/5">
                                    <button 
                                        onClick={() => setActiveTab('editor')}
                                        className={`px-6 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'editor' ? 'bg-white text-black' : 'text-white/40 hover:text-white'}`}
                                    >
                                        Editor
                                    </button>
                                    <button 
                                        onClick={() => setActiveTab('preview')}
                                        className={`px-6 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'preview' ? 'bg-white text-black' : 'text-white/40 hover:text-white'}`}
                                    >
                                        Preview
                                    </button>
                                </div>
                                <button onClick={onClose} className="p-3 text-white/20 hover:text-white transition-colors bg-white/5 rounded-xl border border-white/5 hover:border-white/10">
                                    <X className="w-5 h-5" />
                                </button>
                            </div>
                        </div>

                        {/* Content */}
                        <div className="flex-1 flex overflow-hidden">
                            {/* Editor Pane */}
                            <div className={`flex-1 flex flex-col border-r border-white/5 transition-all ${activeTab === 'preview' ? 'hidden md:flex' : 'flex'}`}>
                                <div className="flex-1 p-8 overflow-hidden flex flex-col gap-4">
                                    <div className="flex items-center justify-between px-2">
                                        <div className="flex items-center gap-2">
                                            <Code className="w-3.5 h-3.5 text-white/20" />
                                            <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Source JSON</span>
                                        </div>
                                        {error ? (
                                            <div className="flex items-center gap-2 text-red-400 text-[9px] font-black uppercase tracking-widest">
                                                <AlertCircle className="w-3 h-3" /> Syntax Error
                                            </div>
                                        ) : (
                                            <div className="flex items-center gap-2 text-emerald-500 text-[9px] font-black uppercase tracking-widest">
                                                <Check className="w-3 h-3" /> Valid Schema
                                            </div>
                                        )}
                                    </div>
                                    <textarea 
                                        value={jsonStr}
                                        onChange={(e) => handleJsonChange(e.target.value)}
                                        className="flex-1 bg-black/40 border border-white/5 rounded-3xl p-8 text-[12px] font-mono text-emerald-400/80 focus:outline-none focus:border-white/10 resize-none transition-all leading-relaxed shadow-inner scrollbar-hide"
                                        spellCheck={false}
                                    />
                                </div>
                                
                                {/* Placeholder Sidebar/Bar */}
                                <div className="p-6 border-t border-white/5 bg-white/[0.01] flex flex-wrap gap-2">
                                    <span className="text-[8px] font-black text-white/10 uppercase tracking-widest self-center mr-2">Quick Tags:</span>
                                    {placeholders.map(p => (
                                        <button 
                                            key={p}
                                            onClick={() => insertPlaceholder(p)}
                                            className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/5 text-[9px] font-black text-white/40 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest"
                                        >
                                            {p}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Preview Pane */}
                            <div className={`flex-1 bg-[#0d0d0d] flex flex-col transition-all ${activeTab === 'editor' ? 'hidden lg:flex' : 'flex'}`}>
                                <div className="flex-1 p-12 overflow-y-auto space-y-8 scrollbar-hide">
                                    <div className="flex items-center gap-2 px-2">
                                        <Eye className="w-3.5 h-3.5 text-white/20" />
                                        <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Visual Output</span>
                                    </div>

                                    {/* Discord Embed Mockup */}
                                    <div className="flex gap-4 group">
                                        <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex-shrink-0 group-hover:scale-105 transition-transform" />
                                        <div className="flex-1 space-y-3">
                                            <div className="flex items-center gap-2">
                                                <span className="text-[11px] font-black text-white uppercase tracking-tight">Dimscord Bot</span>
                                                <span className="bg-indigo-500 text-white text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase tracking-widest">BOT</span>
                                                <span className="text-[9px] text-white/10 font-bold ml-1 uppercase tracking-widest">Today at 12:00 PM</span>
                                            </div>
                                            
                                            {/* The Embed */}
                                            <div 
                                                className="border-l-[4px] bg-[#1a1a1a] rounded-r-lg p-5 max-w-lg space-y-3 shadow-2xl relative overflow-hidden"
                                                style={{ borderColor: previewData.color || '#5865F2' }}
                                            >
                                                {previewData.author?.name && (
                                                    <div className="flex items-center gap-2">
                                                        {previewData.author.icon_url && <img src={previewData.author.icon_url} className="w-6 h-6 rounded-full" alt="" />}
                                                        <span className="text-[11px] font-black text-white tracking-tight">{previewData.author.name}</span>
                                                    </div>
                                                )}
                                                {previewData.title && <h4 className="text-sm font-black text-white tracking-tight">{previewData.title}</h4>}
                                                {previewData.description && <p className="text-[11px] text-white/70 leading-relaxed font-medium">{previewData.description}</p>}
                                                
                                                {previewData.fields && (
                                                    <div className="grid grid-cols-2 gap-4 mt-2">
                                                        {previewData.fields.map((f: any, i: number) => (
                                                            <div key={i} className={f.inline ? 'col-span-1' : 'col-span-2'}>
                                                                <div className="text-[10px] font-black text-white uppercase tracking-widest mb-1">{f.name}</div>
                                                                <div className="text-[10px] text-white/60 font-medium">{f.value}</div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}

                                                {previewData.image?.url && <img src={previewData.image.url} className="w-full rounded-xl mt-3 border border-white/5 shadow-inner" alt="" />}
                                                
                                                {previewData.footer?.text && (
                                                    <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/5">
                                                        {previewData.footer.icon_url && <img src={previewData.footer.icon_url} className="w-4 h-4 rounded-full opacity-50" alt="" />}
                                                        <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">{previewData.footer.text}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="p-8 border-t border-white/5 flex items-center justify-between bg-white/[0.01]">
                            <div className="flex items-center gap-3">
                                <MessageSquare className="w-4 h-4 text-white/20" />
                                <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em]">Live Synchronization Active</span>
                            </div>
                            <div className="flex items-center gap-4">
                                <button onClick={onClose} className="px-10 py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] text-white/40 hover:text-white transition-all">Cancel</button>
                                <button 
                                    onClick={handleSave}
                                    disabled={!!error}
                                    className="px-12 py-4 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] hover:bg-zinc-200 transition-all shadow-xl shadow-white/5 disabled:opacity-20"
                                >
                                    Stabilize JSON
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
}
