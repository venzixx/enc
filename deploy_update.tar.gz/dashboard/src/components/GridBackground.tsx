"use client";

import React from 'react';

export default function GridBackground() {
  return (
    <div className="fixed inset-0 z-0 pointer-events-none opacity-[0.02]">
      <div 
        className="absolute inset-0" 
        style={{ 
          backgroundImage: `linear-gradient(#FFFFFF 1px, transparent 1px), linear-gradient(90deg, #FFFFFF 1px, transparent 1px)`, 
          backgroundSize: '40px 40px' 
        }} 
      />
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, transparent 0%, #000 100%)'
        }}
      />
    </div>
  );
}
