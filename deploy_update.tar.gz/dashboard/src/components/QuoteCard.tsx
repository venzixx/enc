"use client";

import React from "react";
import { motion as m } from "framer-motion";
import { Quote } from "lucide-react";

interface QuoteCardProps {
    text: string;
    author: string;
    avatar: string;
    timestamp?: string;
}

export default function QuoteCard({ text, author, avatar, timestamp = "MARCH 27, 2024" }: QuoteCardProps) {
    return (
        <m.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative w-full max-w-3xl aspect-[2/1] rounded-[3rem] overflow-hidden bg-[#0c0c0e] border border-white/5 shadow-2xl group"
        >
            {/* Background Texture & Glows */}
            <div className="absolute inset-0 z-0">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white/[0.02] blur-[120px] rounded-full -translate-y-1/2 translate-x-1/3" />
                <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-white/[0.01] blur-[100px] rounded-full translate-y-1/3 -translate-x-1/4" />
                
                {/* Grid Overlay */}
                <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
            </div>

            {/* Quote Ornament */}
            <div className="absolute top-12 left-12 z-10">
                <div className="w-16 h-16 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-center text-white/10 group-hover:text-white/40 transition-colors duration-700">
                    <Quote className="w-8 h-8 rotate-180" />
                </div>
            </div>

            {/* Main Content */}
            <div className="relative z-20 h-full p-16 flex flex-col justify-between">
                <div className="flex-1 flex items-center justify-center pt-8">
                    <p className="text-3xl md:text-4xl font-serif italic text-white/90 text-center leading-relaxed tracking-tight">
                        "{text}"
                    </p>
                </div>

                <div className="pt-12 border-t border-white/[0.03] flex items-center justify-between">
                    <div className="flex items-center gap-6">
                        <div className="relative group/avatar">
                            <div className="absolute -inset-2 bg-white/5 rounded-full blur-xl opacity-0 group-hover/avatar:opacity-100 transition-opacity duration-700" />
                            <img 
                                src={avatar} 
                                className="w-16 h-16 rounded-full border border-white/10 shadow-2xl relative z-10 object-cover" 
                                alt="" 
                            />
                        </div>
                        <div className="flex flex-col gap-1">
                            <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Designated Author</span>
                            <span className="text-lg font-black text-white uppercase tracking-tighter">{author}</span>
                        </div>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                        <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em]">Recorded Node</span>
                        <span className="text-[10px] font-bold text-white/10 uppercase tracking-widest">{timestamp}</span>
                    </div>
                </div>
            </div>

            {/* Technical Border Overlay */}
            <div className="absolute inset-0 border border-white/[0.02] rounded-[3rem] pointer-events-none" />
            <div className="absolute top-0 right-0 p-8">
                <div className="text-[8px] font-black text-white/5 uppercase tracking-[0.5em] vertical-rl">ENCLAVE_FS // 0X82</div>
            </div>
        </m.div>
    );
}
