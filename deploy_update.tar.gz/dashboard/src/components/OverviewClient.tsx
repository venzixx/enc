"use client";

import React from "react";
import { motion } from "framer-motion";
import { Shield, Zap, Users, Activity, Ticket, ExternalLink, Settings, ListTree, Sparkles } from "lucide-react";
import ConsoleSector from "./ConsoleSector";
import LoggingSector from "./LoggingSector";
import Link from "next/link";

interface OverviewClientProps {
  guildId: string;
  guildData: any;
  memberCount: number;
}

export default function OverviewClient({ guildId, guildData, memberCount }: OverviewClientProps) {
  const stats = [
    { label: "Total Members", value: memberCount.toLocaleString(), icon: <Users className="w-5 h-5 text-blue-400" />, color: "bg-blue-500/10 border-blue-500/20" },
    { label: "Active Punishments", value: "0", icon: <Shield className="w-5 h-5 text-red-400" />, color: "bg-red-500/10 border-red-500/20" },
    { label: "System Uptime", value: "99.9%", icon: <Activity className="w-5 h-5 text-emerald-400" />, color: "bg-emerald-500/10 border-emerald-500/20" },
  ];

  const quickActions = [
    { label: "Manage Roles", icon: <Zap className="w-5 h-5" />, href: `/dashboard/${guildId}/roleconnections` },
    { label: "Tickets", icon: <Ticket className="w-5 h-5" />, href: `/dashboard/${guildId}/tickets` },
    { label: "Leveling", icon: <ListTree className="w-5 h-5" />, href: `/dashboard/${guildId}/levels` },
    { label: "Server Settings", icon: <Settings className="w-5 h-5" />, href: `/dashboard/${guildId}/settings` },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 300, damping: 24 } }
  };

  return (
    <motion.div 
      initial="hidden" 
      animate="show" 
      variants={container} 
      className="p-8 max-w-[1600px] mx-auto space-y-12"
    >
      {/* ── HEADER ── */}
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center shadow-inner">
            <Sparkles className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">Operational Nexus</h1>
            <p className="text-white/30 text-[10px] font-bold uppercase tracking-[0.3em] mt-1">Sovereign server status and command protocols.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-6 py-3 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 text-indigo-400/60 text-[9px] font-black uppercase tracking-[0.3em] flex items-center gap-2 shadow-inner">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" />
              Neural Link: Nominal
           </div>
        </div>
      </motion.div>

      {/* ── STATS GRID ── */}
      <motion.div variants={container} className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, idx) => (
          <motion.div 
            key={idx} 
            variants={item} 
            className="group relative overflow-hidden bg-white/[0.01] border border-white/5 p-8 rounded-[32px] hover:bg-white/[0.02] transition-all"
          >
             <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
             <div className="relative flex items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center border border-white/5 shadow-inner group-hover:scale-110 transition-transform duration-500">
                   {stat.icon}
                </div>
                <div>
                  <div className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em] mb-1">{stat.label}</div>
                  <div className="text-3xl font-black text-white tracking-tight">{stat.value}</div>
                </div>
             </div>
          </motion.div>
        ))}
      </motion.div>

      {/* ── QUICK ACTIONS ── */}
      <motion.section variants={item} className="space-y-6">
        <div className="flex items-center gap-3 px-1">
          <Zap className="w-4 h-4 text-white/20" />
          <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Quick Access Protocols</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickActions.map((action, idx) => (
            <Link href={action.href} key={idx} className="h-full">
              <motion.div 
                whileHover={{ y: -5 }}
                className="flex flex-col items-center justify-center gap-4 p-8 rounded-[32px] bg-white/[0.01] border border-white/5 hover:bg-white/[0.02] hover:border-white/10 transition-all cursor-pointer group h-full shadow-inner"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/20 group-hover:text-white group-hover:bg-white/10 transition-all duration-500">
                  {action.icon}
                </div>
                <div className="text-[11px] font-black text-white/40 uppercase tracking-[0.2em] group-hover:text-white transition-colors">{action.label}</div>
              </motion.div>
            </Link>
          ))}
        </div>
      </motion.section>

      {/* ── MAIN GRID (3:1) ── */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-12">
        {/* ── SECURITY MODULES (COL-SPAN-3) ── */}
        <motion.div variants={item} className="xl:col-span-3 space-y-8">
          <div className="flex items-center gap-3 px-1">
            <Shield className="w-4 h-4 text-indigo-400" />
            <h2 className="text-[10px] font-bold text-white uppercase tracking-[0.3em]">Security Control Matrix</h2>
          </div>
          <div className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[40px] shadow-inner">
             <ConsoleSector guildId={guildId} initialData={guildData} />
          </div>
        </motion.div>
        
        {/* ── RECENT ACTIVITY (COL-SPAN-1) ── */}
        <motion.div variants={item} className="xl:col-span-1 space-y-8">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-3">
              <Activity className="w-4 h-4 text-emerald-400" />
              <h2 className="text-[10px] font-bold text-white uppercase tracking-[0.3em]">Audit Pulse</h2>
            </div>
            <Link href={`/dashboard/${guildId}/logs`}>
              <button className="text-[9px] font-black text-white/20 hover:text-indigo-400 transition-all uppercase tracking-[0.2em] flex items-center gap-2">
                All Logs <ExternalLink className="w-3 h-3" />
              </button>
            </Link>
          </div>
          
          <div className="bg-white/[0.01] border border-white/5 p-8 rounded-[40px] shadow-inner">
             <LoggingSector guildId={guildId} initialData={guildData} />
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
