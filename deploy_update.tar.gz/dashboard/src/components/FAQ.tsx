"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);
  const faqs = [
    { q: "Is Enc Nexus free to use?", a: "We offer a generous free tier with core features. Premium plans unlock advanced analytics, more autoresponders, and priority support." },
    { q: "How does the Anti-Nuke system work?", a: "Enc Nexus monitors all admin actions in real-time. The moment suspicious activity is detected — mass bans, channel deletions — it locks down automatically and alerts owners." },
    { q: "Can I migrate from another bot?", a: "Yes. Our migration tool imports configurations from most major bots. Contact support for hands-on migration assistance." },
    { q: "Is there an API available?", a: "A developer API is currently in closed beta. Apply via the dashboard to get early access." },
    { q: "What's the average response time?", a: "Under 500ms globally across all regions. We operate on distributed edge infrastructure." },
  ];

  return (
    <section className="py-32 bg-transparent relative">
      <div className="max-w-3xl mx-auto px-8">
        <Reveal>
          <div className="text-center mb-20">
            <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-4">Questions</p>
            <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/50 tracking-tight">
              Common queries
            </h2>
          </div>
        </Reveal>

        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <Reveal key={i} delay={i * 0.06}>
              <div
                className="border border-white/[0.06] rounded-2xl overflow-hidden group hover:border-white/10 transition-colors cursor-pointer"
                onClick={() => setOpen(open === i ? null : i)}
              >
                <div className="flex items-center justify-between p-6 gap-4">
                  <span className="text-white font-semibold text-sm">{faq.q}</span>
                  <motion.span
                    animate={{ rotate: open === i ? 45 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="text-white text-xl shrink-0 leading-none"
                  >+</motion.span>
                </div>
                <AnimatePresence>
                  {open === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="px-6 pb-6 text-white/40 text-sm leading-relaxed border-t border-white/[0.04] pt-4">{faq.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
