"use client";

import React from "react";
import { motion } from "framer-motion";

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}


export default function CTASection() {
  return (
    <section className="py-40 bg-transparent relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/[0.04] to-transparent pointer-events-none" />

      <div className="max-w-4xl mx-auto px-8 text-center relative z-10">
        <Reveal>
          <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-8">Ready?</p>
          <h2
            className="text-5xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/70 tracking-tight leading-none mb-12"
          >
            Enter the<br />
            <span className="text-white">Nexus.</span>
          </h2>
          <p className="text-white/30 text-lg mb-16 max-w-md mx-auto leading-relaxed">
            Join 50,000+ servers already running on the next-generation protocol.
          </p>
          <motion.button
            whileHover={{ scale: 1.03, boxShadow: "0 0 60px rgba(255,255,255,0.25)" }}
            whileTap={{ scale: 0.97 }}
            onClick={() => window.location.href = `https://discord.com/oauth2/authorize?client_id=${process.env.NEXT_PUBLIC_DISCORD_CLIENT_ID}&permissions=8&scope=bot%20applications.commands`}
            className="px-14 py-5 bg-white text-black font-black text-[12px] tracking-[0.2em] uppercase rounded-full"
          >
            Add to Discord — Free
          </motion.button>
        </Reveal>
      </div>
    </section>
  );
}
