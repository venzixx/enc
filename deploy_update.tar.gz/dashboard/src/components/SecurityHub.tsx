"use client";

import React, { useState } from 'react';
import { Shield, Settings, Info, Save, RotateCcw, Zap, ShieldAlert, ShieldCheck } from 'lucide-react';
import { useRouter } from 'next/navigation';
import CustomSelect from './CustomSelect';
import { motion, AnimatePresence } from 'framer-motion';

interface SecurityProps {
  guildId: string;
  initialData: any;
}

export default function SecurityHub({ guildId, initialData }: SecurityProps) {
  const router = useRouter();
  const [enabled, setEnabled] = useState(initialData.antiNukeEnabled ?? false);
  const [categories, setCategories] = useState({
    antiNukeBan: initialData.antiNukeBan ?? false,
    antiNukeKick: initialData.antiNukeKick ?? false,
    antiNukeChannel: initialData.antiNukeChannel ?? false,
    antiNukeRole: initialData.antiNukeRole ?? false,
    antiNukeBot: initialData.antiNukeBot ?? false,
    antiNukeWebhook: initialData.antiNukeWebhook ?? false,
  });
  const [config, setConfig] = useState(initialData.antiNukeConfig || {
    banHeat: 20,
    kickHeat: 15,
    channelHeat: 10,
    roleHeat: 10,
    webhookHeat: 25,
    decayRate: 5,
    punishment: 'STRIP_ROLES'
  });
  const [loading, setLoading] = useState(false);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/security`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled,
          categories,
          config
        }),
      });
      if (res.ok) {
        router.refresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-10"
    >
      {/* Master Toggle */}
      <motion.div 
        variants={item}
        className={`p-8 rounded-3xl border transition-all duration-500 relative overflow-hidden ${enabled ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/10'}`}
      >
        <div className="flex justify-between items-center relative z-10">
           <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${enabled ? 'bg-emerald-500/20 border-emerald-500/20 text-emerald-400' : 'bg-red-500/20 border-red-500/20 text-red-400'}`}>
                 {enabled ? <ShieldCheck className="w-6 h-6" /> : <ShieldAlert className="w-6 h-6" />}
              </div>
              <div>
                 <h2 className="text-lg font-bold text-white tracking-tight">Security Protocol</h2>
                 <p className="text-white/40 text-[11px] uppercase font-bold tracking-widest mt-0.5">Master Anti-Nuke Control</p>
              </div>
           </div>

           <button 
             onClick={() => setEnabled(!enabled)}
             className={`w-14 h-7 rounded-full relative transition-all duration-500 ${enabled ? 'bg-emerald-500' : 'bg-white/5 border border-white/10'}`}
           >
              <div className={`absolute top-1 w-5 h-5 rounded-full transition-all duration-500 ${enabled ? 'left-8 bg-white shadow-lg' : 'left-1 bg-white/20'}`} />
           </button>
        </div>
      </motion.div>

      {enabled && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-10"
        >
          {/* Category Toggles */}
          <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { id: 'antiNukeBan', label: 'Mass Ban' },
              { id: 'antiNukeKick', label: 'Mass Kick' },
              { id: 'antiNukeChannel', label: 'Channel Nuke' },
              { id: 'antiNukeRole', label: 'Role Nuke' },
              { id: 'antiNukeBot', label: 'Bot Addition' },
              { id: 'antiNukeWebhook', label: 'Webhook Spam' },
            ].map((cat) => (
              <div 
                key={cat.id}
                onClick={() => setCategories({ ...categories, [cat.id]: !categories[cat.id as keyof typeof categories] })}
                className={`p-6 rounded-3xl border transition-all cursor-pointer group ${
                  categories[cat.id as keyof typeof categories] 
                  ? 'bg-white/[0.03] border-white/20' 
                  : 'bg-white/[0.01] border-white/5 hover:border-white/10'
                }`}
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-xl border ${categories[cat.id as keyof typeof categories] ? 'bg-white/10 border-white/20 text-white' : 'bg-white/5 border-white/5 text-white/20'}`}>
                      <Zap className="w-4 h-4" />
                    </div>
                    <span className={`text-xs font-bold uppercase tracking-widest ${categories[cat.id as keyof typeof categories] ? 'text-white' : 'text-white/40'}`}>
                      {cat.label}
                    </span>
                  </div>
                  <div className={`w-8 h-4 rounded-full relative border transition-all ${categories[cat.id as keyof typeof categories] ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}>
                    <div className={`absolute top-0.5 w-2.5 h-2.5 rounded-full transition-all ${categories[cat.id as keyof typeof categories] ? 'right-0.5 bg-black' : 'left-0.5 bg-white/10'}`} />
                  </div>
                </div>
              </div>
            ))}
          </section>

          {/* 1. Sensitivity Configuration Grid */}
          <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10 col-span-1 md:col-span-2">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                  <Settings className="w-5 h-5 text-white/60" />
                </div>
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Sensitivity Settings</h3>
                  <p className="text-sm text-white/20 font-medium">Define how sensitivity points are generated per action.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <SliderItem
                  label="Ban Action"
                  value={config.banHeat ?? 20}
                  onChange={(v: number) => setConfig({ ...config, banHeat: v })}
                  description="Points added per member ban."
                />
                <SliderItem
                  label="Kick Action"
                  value={config.kickHeat ?? 15}
                  onChange={(v: number) => setConfig({ ...config, kickHeat: v })}
                  description="Points added per member kick."
                />
                <SliderItem
                  label="Channel Action"
                  value={config.channelHeat ?? 10}
                  onChange={(v: number) => setConfig({ ...config, channelHeat: v })}
                  description="Points added per channel change."
                />
                <SliderItem
                  label="Role Action"
                  value={config.roleHeat ?? 10}
                  onChange={(v: number) => setConfig({ ...config, roleHeat: v })}
                  description="Points added per role change."
                />
              </div>
            </div>

            {/* 2. Global Recovery & Punishment */}
            <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                  <RotateCcw className="w-5 h-5 text-white/60" />
                </div>
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Recovery Rate</h3>
                  <p className="text-sm text-white/20 font-medium">Speed at which sensitivity points decrease over time.</p>
                </div>
              </div>

              <SliderItem
                label="Decrease Rate"
                value={config.decayRate ?? 5}
                onChange={(v: number) => setConfig({ ...config, decayRate: v })}
                description="Points removed every 10 seconds."
                max={20}
              />
            </div>

            <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
                  <Shield className="w-5 h-5 text-white/60" />
                </div>
                <div>
                  <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Action Threshold</h3>
                  <p className="text-sm text-white/20 font-medium">Automatic action taken when threshold is reached.</p>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Punishment Type</label>
                <CustomSelect
                  options={[
                    { id: "STRIP_ROLES", name: "Remove Roles" },
                    { id: "KICK", name: "Kick Member" },
                    { id: "BAN", name: "Ban Member" },
                  ]}
                  value={config.punishment ?? "STRIP_ROLES"}
                  onChange={(val) => setConfig({ ...config, punishment: val })}
                  placeholder="Select Punishment"
                />
              </div>
            </div>
          </section>
        </motion.div>
      )}

      {/* Save Trigger */}
      <div className="flex justify-end pt-4">
        <button
          onClick={handleSave}
          disabled={loading}
          className={`flex items-center gap-3 px-10 py-4 rounded-xl text-[11px] font-bold uppercase tracking-[0.2em] transition-all ${loading ? 'bg-white/5 text-white/20' : 'bg-white text-black hover:bg-zinc-200'}`}
        >
          {loading ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>Save Changes</span>
        </button>
      </div>
    </motion.div>
  );
}

function SliderItem({ label, value, onChange, description, max = 50 }: any) {
  return (
    <div className="space-y-6 group">
      <div className="flex justify-between items-end gap-4">
        <div className="space-y-1.5 text-left">
          <h4 className="text-[12px] font-bold text-white/80 uppercase tracking-tight">{label}</h4>
          <p className="text-[11px] text-white/20 font-medium">{description}</p>
        </div>
        <span className="text-2xl font-bold tracking-tighter text-white/90">{value}%</span>
      </div>
      <div className="relative h-2.5 bg-white/5 rounded-full overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 bg-white transition-all duration-500 ease-out"
          style={{ width: `${(value / max) * 100}%` }}
        />
        <input
          type="range"
          min="1"
          max={max}
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          className="absolute inset-0 opacity-0 cursor-pointer z-10"
        />
      </div>
    </div>
  );
}
