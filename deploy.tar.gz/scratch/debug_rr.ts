import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
    const rrs = await prisma.reactionRole.findMany();
    console.log('--- Reaction Role Database Entries ---');
    rrs.forEach(rr => {
        console.log(`Msg: ${rr.messageId} | Emoji: ${rr.emoji} | Role: ${rr.roleId}`);
    });
    console.log('--------------------------------------');
}

main().catch(console.error).finally(() => prisma.$disconnect());
