import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

console.log('Available models:', Object.keys(prisma).filter(k => !k.startsWith('_')));

async function test() {
    try {
        console.log('AFK model:', prisma.afk ? 'exists' : 'missing');
        // @ts-ignore
        console.log('AfkMention model:', prisma.afkMention ? 'exists' : 'missing');
    } catch (e) {
        console.error('Error checking models:', e);
    } finally {
        await prisma.$disconnect();
    }
}

test();
