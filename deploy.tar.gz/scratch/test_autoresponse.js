const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();

async function fix() {
  // Get existing data
  const existing = await p.$queryRaw`SELECT id, guildId, trigger, response FROM AutoResponse`;
  console.log('Backup:', existing.length, 'rows');
  
  // Drop and recreate
  await p.$executeRaw`DROP TABLE IF EXISTS AutoResponse`;
  await p.$executeRaw`CREATE TABLE "AutoResponse" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "guildId" TEXT NOT NULL,
    "trigger" TEXT NOT NULL,
    "response" TEXT NOT NULL,
    "channelId" TEXT,
    "matchType" TEXT NOT NULL DEFAULT 'EXACT',
    CONSTRAINT "AutoResponse_guildId_fkey" FOREIGN KEY ("guildId") REFERENCES "Guild" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
  )`;
  
  // Re-insert data
  for (const row of existing) {
    await p.$executeRaw`INSERT INTO AutoResponse (id, guildId, trigger, response, matchType) VALUES (${row.id}, ${row.guildId}, ${row.trigger}, ${row.response}, 'EXACT')`;
  }
  
  // Verify
  const result = await p.$queryRaw`SELECT * FROM AutoResponse LIMIT 1`;
  console.log('Verify:', JSON.stringify(result, null, 2));
  
  await p.$disconnect();
  console.log('Done!');
}

fix().catch(e => { console.error(e); process.exit(1); });
