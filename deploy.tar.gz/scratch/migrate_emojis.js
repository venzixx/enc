const fs = require('fs');
const path = require('path');

// Comprehensive mapping for Literal, Mangled, and Purgeable symbols
const emojiMap = {
    // SUCCESS
    '✅': 'success', 'âœ…': 'success', 'âœ… ': 'success',
    
    // CROSS / CANCEL
    '❌': 'cross', 'â Œ': 'cross', 'âœ˜': 'cross', 'â Œ ': 'cross',
    
    // INFO / EXCLAMATION
    'ℹ️': 'info', 'â„¹ï¸ ': 'info',
    '⚠️': 'exclamation', 'âš ï¸ ': 'exclamation',
    '🚨': 'exclamation', 'ðŸš¨': 'exclamation',
    '❗': 'exclamation', 'â —': 'exclamation',
    
    // SECURITY / MODERATION
    '🛡️': 'shield', 'ðŸ›¡ï¸ ': 'shield',
    '👤': 'user', 'ðŸ‘¤': 'user',
    '🔨': 'hammer', 'ðŸ”¨': 'hammer',
    '⚔️': 'swords', 'âš”ï¸ ': 'swords',
    
    // UTILITY / TIME
    '⏳': 'clock', 'âŒ›': 'clock',
    '⏰': 'clock', 'â °': 'clock',
    '📝': 'edit', 'ðŸ“ ': 'edit', 'ðŸ“  ': 'edit',
    '💬': 'mic', 'ðŸ’¬': 'mic',
    '🎙️': 'mic', 'ðŸŽ¤': 'mic',
    '✨': 'random', 'âœ¨': 'random',
    '🐱': 'cat', 'ðŸ ±': 'cat',
    '👑': 'rank', 'ðŸ‘‘': 'rank',
    
    // MUSIC CONTROLS
    '▶️': 'play', 'â–¶ï¸ ': 'play',
    '⏸️': 'pause', 'â–‹ï¸ ': 'pause',
    '⏭️': 'next', 'â žï¸ ': 'next',
    '⏮️': 'previous', 'â œï¸ ': 'previous',
    '🔀': 'shuffle', 'ðŸ€': 'shuffle',
    '🔁': 'loop', 'ðŸ ': 'loop',
    '🔉': 'voldown', 'ðŸ”¹': 'voldown',
    '🔊': 'volmore', 'ðŸ”º': 'volmore',
    '🎶': 'music', 'ðŸŽ¶': 'music',
    
    // CLEANUP
    '🗑️': 'remove_user', 'ðŸ—‘ï¸ ': 'remove_user',
    '🧹': 'remove_user', 'ðŸ§¹': 'remove_user',
};

function migrateFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let changed = false;

    // 1. Explicit Replacements for mapped clusters
    for (const [char, key] of Object.entries(emojiMap)) {
        // Pattern: .setEmoji('â Œ') -> .setEmoji(client.emoji.cross)
        const emojiSetRegex = new RegExp(`\\.setEmoji\\(['"]${char}['"]\\)`, 'g');
        if (emojiSetRegex.test(content)) {
            content = content.replace(emojiSetRegex, `.setEmoji(client.emoji.${key})`);
            changed = true;
        }

        // Pattern: .setLabel('â Œ Cancel') -> .setLabel(`${client.emoji.cross} Cancel`)
        const labelRegex = new RegExp(`\\.setLabel\\((['"])${char}\\s*(.*?[^\\\\])\\1\\)`, 'g');
        if (labelRegex.test(content)) {
            content = content.replace(labelRegex, (match, quote, rest) => {
                return `.setLabel(\`\${client.emoji.${key}} ${rest}\`)`;
            });
            changed = true;
        }

        // General string/property replacement
        const propertyRegex = new RegExp(`(['"])${char}\\s*(.*?[^\\\\])\\1`, 'g');
        if (propertyRegex.test(content)) {
            content = content.replace(propertyRegex, (match, quote, rest) => {
                return `\`\${client.emoji.${key}} ${rest}\``;
            });
            changed = true;
        }

        // General template literal replacement (if starting with emoji)
        const templateRegex = new RegExp(`\`${char}`, 'g');
        if (templateRegex.test(content)) {
            content = content.replace(templateRegex, `\`\${client.emoji.${key}}`);
            changed = true;
        }
    }

    // 2. Final Aggressive Purge of all non-ASCII characters
    // This removes all other generic symbols and mangled sequences.
    const nonASCIIRegex = /[^\x00-\x7F]+/g;
    if (nonASCIIRegex.test(content)) {
        content = content.replace(nonASCIIRegex, '');
        changed = true;
    }

    if (changed) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Stabilized: ${filePath}`);
    }
}

function processDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            processDir(fullPath);
        } else if (file.endsWith('.ts') || file.endsWith('.js')) {
            migrateFile(fullPath);
        }
    }
}

const targetDirs = [
    path.join(__dirname, '..', 'src', 'commands'),
    path.join(__dirname, '..', 'src', 'events'),
    path.join(__dirname, '..', 'src', 'handlers'),
    path.join(__dirname, '..', 'src', 'utils'),
    path.join(__dirname, '..', 'src', 'components')
];

targetDirs.forEach(dir => {
    if (fs.existsSync(dir)) {
        processDir(dir);
    }
});

console.log('Global Branding Stabilization Manifested.');
