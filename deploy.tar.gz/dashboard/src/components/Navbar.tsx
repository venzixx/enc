"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Shield, BookOpen, Terminal, User, LogOut, Menu, X, Home, Zap, Lock, ShieldAlert, MessageSquare, BarChart3, ListTree, Ticket, Sparkles, Link2 } from "lucide-react";
import { useSession, signOut } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import { useParams } from "next/navigation";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: session } = useSession();
  const pathname = usePathname();
  const params = useParams();
  const guildId = params?.guildId as string;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "/", icon: <Home className="w-4 h-4" /> },
    { name: "Docs", href: "/codex", icon: <BookOpen className="w-4 h-4" /> },
    { name: "Dashboard", href: "/dashboard", icon: <Terminal className="w-4 h-4" /> },
  ];

  const dashboardLinks = guildId ? [
    { name: "General", href: `/dashboard/${guildId}`, icon: <Shield className="w-4 h-4" /> },
    { name: "Branding", href: `/dashboard/${guildId}/branding`, icon: <Sparkles className="w-4 h-4" /> },
    { name: "Aliases", href: `/dashboard/${guildId}/aliases`, icon: <Link2 className="w-4 h-4" /> },
    { name: "Security", href: `/dashboard/${guildId}/security`, icon: <Lock className="w-4 h-4" /> },
    { name: "Logs", href: `/dashboard/${guildId}/logs`, icon: <ListTree className="w-4 h-4" /> },
  ] : [];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-500 bg-[#050508]/80 backdrop-blur-3xl border-b border-white/[0.02] ${isScrolled ? "h-14" : "h-16"
        }`}
    >
      <div className="px-6 h-full flex items-center justify-between relative">

        {/* Minimal Branding */}
        <Link href="/" className="flex items-center gap-2 relative z-[110]">
          <div className="w-7 h-7 bg-white rounded-md flex items-center justify-center">
            <Shield className="w-4 h-4 text-black" strokeWidth={2.5} />
          </div>
          <span className="font-display font-bold tracking-tight text-base text-white uppercase">Enc Nexus</span>
        </Link>

        {/* Minimal Navigation Pill */}
        <div className="hidden md:flex absolute left-1/2 -translate-x-1/2 items-center bg-[#0d0d12] border border-white/5 p-1 rounded-xl">
          {navLinks.map((link) => {
            const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
            return (
              <Link
                key={link.name}
                href={link.href}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-[11px] font-bold tracking-wide transition-all duration-300 ${isActive
                  ? "bg-[#1a1a24] text-white border border-white/5"
                  : "text-white/40 hover:text-white/60"
                  }`}
              >
                {link.name}
              </Link>
            );
          })}
        </div>

        {/* Identity & Actions */}
        <div className="flex items-center gap-4 relative z-[110]">
          {session ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-[11px] font-bold text-white tracking-tight">{session.user?.name}</span>
                <span className="text-[8px] font-medium text-white/20 uppercase tracking-widest">Authenticated</span>
              </div>
              <div className="group relative">
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/5 p-0.5 overflow-hidden transition-all cursor-pointer">
                  {session.user?.image ? (
                    <img src={session.user.image} alt="Identity" className="w-full h-full object-cover rounded-[6px]" />
                  ) : (
                    <div className="w-full h-full bg-zinc-900 flex items-center justify-center text-white/20 font-bold text-[10px]">
                      {session.user?.name?.slice(0, 1) || "U"}
                    </div>
                  )}
                </div>

                <div className="absolute right-0 top-full pt-3 w-40 opacity-0 scale-95 translate-y-2 pointer-events-none group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition-all duration-300">
                  <div className="bg-[#0A0A0F] border border-white/5 rounded-xl p-1 shadow-2xl backdrop-blur-3xl">
                    <button
                      onClick={() => signOut()}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-[10px] font-bold text-red-400/60 hover:text-red-400 hover:bg-red-400/5 transition-all uppercase tracking-wider"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Logout
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <Link href="/api/auth/signin" className="px-5 py-2 bg-white text-black font-bold text-[11px] rounded-lg hover:bg-zinc-200 transition-all uppercase tracking-wider">
              Login
            </Link>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden w-8 h-8 flex items-center justify-center bg-white/5 border border-white/5 rounded-lg text-white"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>

        {/* MOBILE MENU OVERLAY */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 right-0 p-4 md:hidden"
            >
              <div className="bg-[#0A0A0F]/95 backdrop-blur-3xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl max-h-[80vh] overflow-y-auto">
                <div className="p-2 space-y-1">
                  <div className="px-4 py-2 text-[8px] font-black text-white/20 uppercase tracking-[0.3em]">Main Navigation</div>
                  {navLinks.map((link) => {
                    const isActive = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
                    return (
                      <Link
                        key={link.name}
                        href={link.href}
                        onClick={() => setMobileMenuOpen(false)}
                        className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${isActive ? "bg-white/5 text-white border border-white/5" : "text-white/30"
                          }`}
                      >
                        {link.icon}
                        <span className="text-[10px] font-bold uppercase tracking-widest">{link.name}</span>
                      </Link>
                    );
                  })}

                  {guildId && (
                    <>
                      <div className="px-4 pt-4 pb-2 text-[8px] font-black text-white/20 uppercase tracking-[0.3em]">Dashboard</div>
                      {dashboardLinks.map((link) => {
                        const isActive = pathname === link.href;
                        return (
                          <Link
                            key={link.name}
                            href={link.href}
                            onClick={() => setMobileMenuOpen(false)}
                            className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${isActive ? "bg-white/5 text-white border border-white/5" : "text-white/30"
                              }`}
                          >
                            {link.icon}
                            <span className="text-[10px] font-bold uppercase tracking-widest">{link.name}</span>
                          </Link>
                        );
                      })}
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </nav>
  );
}
