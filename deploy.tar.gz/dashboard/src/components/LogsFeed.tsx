"use client";

import React, { useState, useEffect, useCallback } from "react";
import { 
  Shield, Hammer, Music, Cpu, Zap, 
  Search, ChevronDown, Clock, User,
  ArrowUpRight, Activity, Terminal, ShieldCheck,
  AlertTriangle, Filter, LayoutDashboard, Settings, ChevronRight,
  RefreshCw, Layers, Volume2, Globe, Calendar, X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import SidebarItem from "./SidebarItem";
import MarkdownDisplay from "./MarkdownDisplay";

export default function LogsFeed({ guildId }: { guildId: string }) {
  const [activeTab, setActiveTab] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [logs, setLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const fetchLogs = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/guild/${guildId}/logs?type=${activeTab}&query=${searchQuery}&date=${selectedDate}`);
      
      const contentType = response.headers.get("content-type");
      if (!response.ok || !contentType || !contentType.includes("application/json")) {
        const errorText = await response.text();
        throw new Error(errorText || `API Error: ${response.status}`);
      }

      const data = await response.json();
      setLogs(data.logs || []);
      setTotal(data.total || 0);
    } catch (error: any) {
      console.error("Failed to fetch logs:", error);
      setError(error.message || "Failed to manifest audit telemetry.");
    } finally {
      setIsLoading(false);
    }
  }, [guildId, activeTab, searchQuery]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchLogs();
    }, 500); // Debounce search
    return () => clearTimeout(timer);
  }, [fetchLogs]);

  const categories = [
    { name: "All", icon: <Layers className="w-3.5 h-3.5" /> },
    { name: "Security", icon: <ShieldCheck className="w-3.5 h-3.5" /> },
    { name: "AutoMod", icon: <Zap className="w-3.5 h-3.5" /> },
    { name: "Moderation", icon: <Hammer className="w-3.5 h-3.5" /> },
    { name: "Members", icon: <User className="w-3.5 h-3.5" /> },
    { name: "Roles", icon: <Shield className="w-3.5 h-3.5" /> },
    { name: "Channels", icon: <Cpu className="w-3.5 h-3.5" /> },
    { name: "Voice", icon: <Volume2 className="w-3.5 h-3.5" /> },
    { name: "Webhooks", icon: <Globe className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="flex flex-col gap-8">

      {/* Controls Bar */}
      <div className="sticky top-16 z-40 -mx-4 px-4 xl:-mx-8 xl:px-8 py-6 border-y border-white/5 bg-[#050510]/90 backdrop-blur-3xl transition-all duration-300">
          <div className="flex flex-wrap items-center justify-between gap-6 mb-6">
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.name}
                  onClick={() => setActiveTab(cat.name)}
                  className={`px-5 py-2.5 rounded-xl text-[10px] font-bold tracking-[0.1em] uppercase transition-all flex items-center gap-3 border ${
                    activeTab === cat.name 
                      ? "bg-white text-black border-white" 
                      : "text-white/20 hover:text-white/40 hover:bg-white/5 border-transparent"
                  }`}
                >
                  {cat.icon} {cat.name}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <div className="relative group">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/20 group-focus-within:text-white transition-colors" />
                <input 
                  type="date" 
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="bg-white/[0.02] border border-white/5 rounded-xl py-2 pl-11 pr-4 text-[10px] font-bold tracking-widest text-white/60 focus:border-white/20 outline-none transition-all uppercase [color-scheme:dark]"
                />
              </div>
              {selectedDate && (
                <button 
                  onClick={() => setSelectedDate("")}
                  className="w-10 h-10 rounded-xl bg-red-500/5 border border-red-500/10 flex items-center justify-center text-red-500/40 hover:text-red-500 hover:bg-red-500/10 transition-all"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div className="relative group max-w-2xl w-full">
             <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/10 group-focus-within:text-white transition-colors" />
             <input 
              type="text"
              placeholder="Search by User ID, Channel ID, or Keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#0d0d15]/50 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-[13px] font-bold tracking-wide text-white placeholder:text-white/10 focus:border-white/20 outline-none transition-all shadow-inner"
             />
          </div>
      </div>

      <div className="flex flex-col gap-4 min-h-[500px]">
         {isLoading && logs.length === 0 ? (
           <div className="flex-1 flex items-center justify-center py-40">
              <div className="flex flex-col items-center gap-6">
                 <div className="w-16 h-16 rounded-full border-t-2 border-white animate-spin" />
                 <div className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Loading events...</div>
              </div>
           </div>
         ) : (
           <AnimatePresence mode="popLayout" initial={false}>
              {logs.length > 0 ? (
                logs.map((log) => (
                  <LogAccordion key={log.id} log={log} />
                ))
              ) : (
                <motion.div 
                 initial={{ opacity: 0 }} 
                 animate={{ opacity: 1 }}
                 className="p-32 rounded-[32px] border border-dashed border-white/5 flex flex-col items-center justify-center gap-6"
                >
                   <div className="w-16 h-16 rounded-2xl bg-white/[0.02] flex items-center justify-center border border-white/5">
                      <Filter className="w-6 h-6 text-white/10" />
                   </div>
                   <div className="text-center">
                      <div className="text-white/40 font-bold uppercase tracking-widest text-sm mb-2">No logs found</div>
                      <p className="text-white/20 text-xs font-medium">Adjust your filters or search query.</p>
                   </div>
                </motion.div>
              )}
           </AnimatePresence>
         )}
      </div>
    </div>
  );
}

function LogAccordion({ log }: { log: any }) {
  const [isOpen, setIsOpen] = useState(false);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case "CRITICAL": return "text-red-400 bg-red-400/10 border-red-400/20";
      case "MOD": return "text-purple-400 bg-purple-400/10 border-purple-400/20";
      case "SYSTEM": return "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
      default: return "text-blue-400 bg-blue-400/10 border-blue-400/20";
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "SECURITY": return <Shield className="w-4 h-4" />;
      case "MODERATION": return <Hammer className="w-4 h-4" />;
      case "MEMBERS": return <User className="w-4 h-4" />;
      case "ROLES": return <ShieldCheck className="w-4 h-4" />;
      case "CHANNELS": return <Cpu className="w-4 h-4" />;
      case "VOICE": return <Volume2 className="w-4 h-4" />;
      case "WEBHOOKS": return <Globe className="w-4 h-4" />;
      default: return <Terminal className="w-4 h-4" />;
    }
  };

  const timeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diff = now.getTime() - past.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className={`bg-white/[0.01] border border-white/5 rounded-[32px] group cursor-pointer transition-all duration-500 overflow-hidden ${
        isOpen ? "border-white/20 bg-white/[0.02]" : "hover:border-white/10"
      }`}
      onClick={() => setIsOpen(!isOpen)}
    >
      <div className="p-8 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-8">
           <div className={`w-1 h-10 rounded-full transition-all duration-500 ${isOpen ? 'bg-white' : 'bg-white/5'}`} />
           <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-white/[0.02] rounded-2xl flex items-center justify-center border border-white/5 group-hover:bg-white/[0.05] transition-colors">
                 <div className="text-white/30 group-hover:text-white transition-colors">
                    {getIcon(log.type)}
                 </div>
              </div>
              <div className="flex flex-col gap-1.5">
                 <div className="flex items-center gap-3">
                    <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black tracking-[0.2em] border uppercase ${getStatusStyle(log.status)} shadow-sm`}>
                       {log.status}
                    </span>
                    <h4 className="text-xl font-bold uppercase tracking-tight text-white group-hover:text-white transition-colors truncate max-w-sm">
                       {log.event}
                    </h4>
                 </div>
                 <p className="text-[11px] text-white/30 font-medium flex items-center gap-3 uppercase tracking-wider">
                   <span className="flex items-center gap-1.5"><User className="w-3 h-3" /> {log.executorTag || 'System'}</span>
                   <span className="opacity-30 self-center">•</span>
                   <span className="flex items-center gap-1.5"><Clock className="w-3 h-3" /> {timeAgo(log.createdAt)}</span>
                 </p>
              </div>
           </div>
        </div>
        <div className={`transition-all duration-500 ${isOpen ? 'rotate-180 text-white scale-110' : 'text-white/10 group-hover:text-white/30'}`}>
           <ChevronDown className="w-6 h-6" />
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-white/5 bg-black/20"
          >
            <div className="p-10 grid grid-cols-1 md:grid-cols-3 gap-10">
               <div className="flex flex-col gap-3">
                  <div className="text-[9px] font-bold text-white/20 uppercase tracking-[0.3em]">User Identity</div>
                  <div className="bg-white/[0.02] p-6 rounded-2xl border border-white/5 flex flex-col gap-1">
                     <div className="text-[14px] font-bold text-white/80">{log.executorTag || 'System'}</div>
                     <div className="text-[10px] font-mono text-white/20 font-bold tracking-widest uppercase">ID: {log.executorId || 'SYSTEM'}</div>
                  </div>
               </div>
               
               {log.targetName && (
                 <div className="flex flex-col gap-3">
                    <div className="text-[9px] font-bold text-white/20 uppercase tracking-[0.3em]">Target</div>
                    <div className="bg-white/[0.02] p-6 rounded-2xl border border-white/5 flex flex-col gap-1">
                       <div className="text-[14px] font-bold text-white/80">{log.targetName}</div>
                       <div className="text-[10px] font-mono text-white/20 font-bold tracking-widest uppercase">ID: {log.targetId || 'N/A'}</div>
                    </div>
                 </div>
               )}

               <div className="flex flex-col gap-3 col-span-1 md:col-span-1">
                  <div className="text-[9px] font-bold text-white/20 uppercase tracking-[0.3em]">Event Details</div>
                  <div className="bg-white/[0.02] p-6 rounded-2xl border border-white/5 min-h-[80px]">
                     <MarkdownDisplay 
                        content={log.details || "No additional details recorded."} 
                        className="text-[12px] text-white/40 font-medium leading-relaxed"
                     />
                  </div>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
