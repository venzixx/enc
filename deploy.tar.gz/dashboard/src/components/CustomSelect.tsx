"use client";

import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, Search, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Option {
  id: string;
  name: string;
}

interface CustomSelectProps {
  options: Option[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  label?: string;
}

export default function CustomSelect({ 
  options, 
  value, 
  onChange, 
  placeholder = "Select an option",
  className = "",
  label
}: CustomSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find(opt => opt.id === value);
  const filteredOptions = options.filter(opt => 
    opt.name.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className={`relative w-full ${className} ${isOpen ? 'z-[101]' : 'z-auto'}`} ref={containerRef}>
      {label && (
        <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] mb-3 block">
          {label}
        </label>
      )}
      
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white/[0.03] border border-white/5 rounded-xl px-4 py-3 flex items-center justify-between group hover:bg-white/[0.05] transition-all hover:border-white/10"
      >
        <span className={`text-[11px] font-bold uppercase tracking-widest ${selectedOption ? 'text-white/80' : 'text-white/20'}`}>
          {selectedOption ? `# ${selectedOption.name}` : placeholder}
        </span>
        <ChevronDown className={`w-4 h-4 text-white/20 transition-transform duration-300 ${isOpen ? 'rotate-180 text-white/60' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="absolute z-[100] w-full mt-2 bg-[#0c0c0c] border border-white/10 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl"
          >
            <div className="p-3 border-b border-white/5">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/20" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search channels..."
                  className="w-full bg-white/5 border border-white/5 rounded-lg pl-9 pr-4 py-2 text-[10px] font-medium text-white/60 focus:outline-none focus:border-white/20 transition-all"
                  autoFocus
                />
              </div>
            </div>

            <div className="max-h-[240px] overflow-y-auto scrollbar-hide py-2">
              {filteredOptions.length > 0 ? (
                filteredOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      onChange(opt.id);
                      setIsOpen(false);
                      setSearch("");
                    }}
                    className={`w-full px-4 py-3 flex items-center justify-between hover:bg-white/5 transition-colors group/opt ${opt.id === value ? 'bg-white/[0.02]' : ''}`}
                  >
                    <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${opt.id === value ? 'text-white' : 'text-white/40 group-hover/opt:text-white/70'}`}>
                      # {opt.name}
                    </span>
                    {opt.id === value && (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    )}
                  </button>
                ))
              ) : (
                <div className="px-4 py-8 text-center text-[10px] font-bold text-white/10 uppercase tracking-widest">
                  No results found
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
