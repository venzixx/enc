import React from "react";
import Navbar from "@/components/Navbar";

export default function TermsPage() {
  return (
    <main className="relative min-h-screen text-white font-sans selection:bg-accent-blue/30 overflow-x-hidden">
      <Navbar />
      
      <div className="pt-40 pb-20 px-6 max-w-4xl mx-auto relative z-10">
        <h1 className="surgical-headline text-5xl mb-4 text-center">Terms of Service</h1>
        <p className="text-white/40 text-center mb-16 text-sm font-medium tracking-[0.2em] uppercase">Last Updated: April 2026</p>
        
        <div className="glass-panel p-8 md:p-12 space-y-12">
          <section>
            <h2 className="surgical-headline text-2xl mb-4">1. Acceptance of Terms</h2>
            <p className="text-white/60 leading-relaxed">
              By inviting or using ENC, you agree to these Terms of Service. If you do not agree, you must remove the bot from your server.
            </p>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">2. Usage Requirements</h2>
            <div className="text-white/60 leading-relaxed space-y-2">
              <p>You agree to:</p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-accent-blue/80">
                <li>Follow Discord’s Terms of Service and Community Guidelines</li>
                <li>Not misuse the bot for illegal, harmful, or abusive activities</li>
                <li>Not attempt to exploit, reverse engineer, or disrupt ENC</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">3. Bot Functionality</h2>
            <div className="text-white/60 leading-relaxed space-y-4">
              <p>ENC provides features including anti-raid, anti-nuke protection, moderation tools, security systems, and server customization. We do not guarantee the bot will always be error-free or uninterrupted.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">4. Availability</h2>
            <p className="text-white/60 leading-relaxed">
              ENC may go offline for maintenance, updates, or unexpected issues. Maintenance notices will be provided through the official ENC support server.
            </p>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">5. Responsibility</h2>
            <p className="text-white/60 leading-relaxed">
              Server administrators are responsible for how they configure and use the bot. We are not responsible for damages caused by misuse, misconfiguration, or Discord-related issues.
            </p>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">6. Termination</h2>
            <p className="text-white/60 leading-relaxed">
              We reserve the right to restrict or block access to ENC at any time, especially for servers violating these terms.
            </p>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">7. Limitation of Liability</h2>
            <div className="text-white/60 leading-relaxed">
              <p>ENC is provided “as is” without warranties. We are not liable for data loss, server damage, misuse of moderation tools, or any indirect damages.</p>
            </div>
          </section>

          <section>
            <h2 className="surgical-headline text-2xl mb-4">8. Changes to Terms</h2>
            <p className="text-white/60 leading-relaxed">
              These Terms may be updated from time to time. Continued use of ENC after such updates constitutes acceptance of the revised Terms.
            </p>
          </section>
        </div>
      </div>

      <footer className="py-20 border-t border-white/5 text-center text-white/20 text-[10px] font-bold uppercase tracking-[0.5em]">
        &copy; 2026 Enc Nexus // All Protocols Reserved.
      </footer>
    </main>
  );
}
