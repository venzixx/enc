"use client";

import React from "react";
import dynamic from "next/dynamic";
import Navbar from "@/components/Navbar";

// Performance Optimization: Offloading heavy sectors to dynamic imports


import Hero from "@/components/Hero";

const StatsSection = dynamic(() => import("@/components/StatsSection"), { ssr: false });
import QuickFeatures from "@/components/QuickFeatures";
import BotCapabilities from "@/components/BotCapabilities";
const HowItWorks = dynamic(() => import("@/components/HowItWorks"), { ssr: false });
const FAQ = dynamic(() => import("@/components/FAQ"), { ssr: false });

export default function LandingPage() {
  return (
    <main className="relative min-h-screen text-white overflow-hidden font-sans">
      {/* Navigation Hub */}
      <Navbar />

      {/* Hero Sector */}
      <Hero />

      {/* Impact Manifest (Stats) */}
      <StatsSection />

      {/* Feature Manifest */}
      <QuickFeatures />

      {/* Capabilities Sector */}
      <BotCapabilities />

      {/* Instructional Manifest (Process) */}
      <HowItWorks />

      {/* Common Queries (FAQ) */}
      <FAQ />

      {/* Footer / Finality sector could go here */}
      <footer className="py-20 border-t border-white/5 text-center space-y-6">
        <div className="flex justify-center gap-8 text-[10px] font-bold uppercase tracking-[0.3em]">
          <a href="/privacy" className="text-white/40 hover:text-accent-blue transition-colors">Privacy Policy</a>
          <a href="/termsofservice" className="text-white/40 hover:text-accent-blue transition-colors">Terms of Service</a>
        </div>
        <div className="text-white/20 text-[10px] font-bold uppercase tracking-[0.5em]">
          &copy; 2026 Enc Nexus // All Protocols Reserved.
        </div>
      </footer>
    </main>
  );
}
