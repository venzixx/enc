import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import SessionWrapper from "@/components/SessionWrapper";
import Starfield from "@/components/Starfield";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "600", "700"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  weight: ["400", "500", "600"],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["500"],
});

export const metadata = {
  title: "Enc Nexus | Sovereign Administrative Dashboard",
  description: "The peak of guild governance and resource management.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable} dark`}>
      <body className="bg-background text-foreground font-sans min-h-screen antialiased selection:bg-accent-blue/30 selection:text-white relative">
        <Starfield />

        {/* Ambient Light System */}
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-accent-blue/10 blur-[120px] animate-pulse duration-[10s]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[30%] h-[30%] rounded-full bg-accent-blue/5 blur-[100px] animate-pulse duration-[8s]" />
        </div>

        <SessionWrapper>
          <div className="relative z-10">
            {children}
          </div>
        </SessionWrapper>
      </body>
    </html>
  );
}
