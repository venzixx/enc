import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getUserGuilds, getBotGuilds, hasAdminPermission } from "@/lib/discord";
import Link from "next/link";
import {
  ShieldAlert, Settings2, ExternalLink, Zap,
  Plus, ShieldCheck, Lock, Search, LayoutGrid, Activity
} from "lucide-react";
import { redirect } from "next/navigation";
import Starfield from "@/components/Starfield";
import Navbar from "@/components/Navbar";
import { getDiscordAsset } from "@/lib/utils";

export default async function DashboardSelector() {
  const session: any = await getServerSession(authOptions);

  if (!session) {
    redirect("/");
  }

  const [userGuilds, botGuilds] = await Promise.all([
    getUserGuilds(session.accessToken || ""),
    getBotGuilds(),
  ]);

  // Guilds that have the bot added
  const activeGuilds = userGuilds.filter(guild =>
    botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  );

  // Guilds that don't have the bot added but user is admin/owner
  const availableGuilds = userGuilds.filter(guild =>
    !botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  );

  return (
    <div className="min-h-screen bg-background relative flex flex-col pt-16">
      <Starfield />

      <Navbar />

          <main className="relative z-10 max-w-[1400px] mx-auto w-full px-6 py-12 space-y-16">
        
        {/* ── HEADER ── */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-10 border-b border-white/5 pb-10">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center shadow-inner">
               <LayoutGrid className="w-7 h-7 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-white tracking-tight">Infrastructure Core</h1>
              <p className="text-[10px] text-white/30 font-bold uppercase tracking-[0.3em] mt-1">Select an active neural link to begin.</p>
            </div>
          </div>
          
          <div className="relative group w-full md:w-96">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20 group-hover:text-indigo-400 transition-colors" />
            <input 
              type="text" 
              placeholder="SEARCH NODE..." 
              className="w-full bg-white/[0.02] border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-[10px] font-black text-white placeholder:text-white/10 outline-none focus:border-indigo-500/30 transition-all uppercase tracking-widest shadow-inner"
            />
          </div>
        </div>

        {/* ── ACTIVE NODES ── */}
        <section className="space-y-8">
           <div className="flex items-center gap-3">
              <Zap className="w-4 h-4 text-indigo-400" />
              <h2 className="text-[11px] font-black text-white/20 uppercase tracking-[0.4em]">Active Connections</h2>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
             {activeGuilds.map((guild) => (
               <Link 
                 key={guild.id}
                 href={`/dashboard/${guild.id}`}
                 className="group relative h-[220px] rounded-[40px] overflow-hidden border border-white/5 hover:border-indigo-500/30 transition-all duration-700 shadow-2xl"
               >
                 {/* Banner Background */}
                 <div className="absolute inset-0 bg-[#050510] z-0">
                   {guild.banner ? (
                     <img 
                       src={getDiscordAsset('banner', guild.id, guild.banner, 600) || ""}
                       alt="" 
                       className="w-full h-full object-cover opacity-20 group-hover:opacity-40 transition-opacity duration-1000 scale-110 group-hover:scale-100"
                     />
                   ) : (
                     <div className="w-full h-full bg-gradient-to-br from-indigo-500/5 to-purple-500/5 opacity-40" />
                   )}
                   <div className="absolute inset-0 bg-gradient-to-t from-[#050510] via-[#050510]/60 to-transparent" />
                 </div>

                 {/* Content Overlay */}
                 <div className="absolute inset-0 z-10 p-10 flex flex-col justify-end gap-6">
                    <div className="flex items-center gap-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-700">
                       {guild.icon ? (
                         <img 
                          src={getDiscordAsset('icon', guild.id, guild.icon) || ""}
                          className="w-20 h-20 rounded-[24px] border border-white/10 shadow-2xl scale-100 group-hover:scale-110 transition-transform duration-700 object-cover"
                          alt={guild.name}
                         />
                       ) : (
                         <div className="w-20 h-20 rounded-[24px] bg-white/5 border border-white/5 flex items-center justify-center font-black text-2xl text-white/20 uppercase">
                           {guild.name.charAt(0)}
                         </div>
                       )}

                       <div className="flex-1 min-w-0">
                          <h2 className="text-2xl font-black text-white truncate tracking-tighter uppercase mb-1">/{guild.name.toLowerCase()}</h2>
                          <div className="flex items-center gap-3">
                             <span className="px-3 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 text-[8px] font-black uppercase tracking-[0.2em] border border-indigo-500/10">
                                {guild.owner ? "Lead" : "Staff"}
                             </span>
                             <span className="text-[8px] font-black text-white/10 uppercase tracking-widest flex items-center gap-1.5">
                                <Activity className="w-2.5 h-2.5 text-emerald-500" /> Link Active
                             </span>
                          </div>
                       </div>
                    </div>
                 </div>

                 {/* Hover Glow */}
                 <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
               </Link>
             ))}
           </div>
        </section>

        {/* ── DISCONNECTED NODES ── */}
        <section className="pt-12 space-y-10">
           <div className="flex items-center gap-4">
              <div className="h-px flex-1 bg-white/[0.03]" />
              <div className="flex items-center gap-3 px-6">
                 <ShieldAlert className="w-4 h-4 text-white/5" />
                 <span className="text-[10px] font-black text-white/10 uppercase tracking-[0.4em]">Available Integrations</span>
              </div>
              <div className="h-px flex-1 bg-white/[0.03]" />
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {availableGuilds.slice(0, 16).map((guild) => (
                <div key={guild.id} className="bg-white/[0.01] border border-white/5 rounded-[32px] p-6 flex flex-col gap-6 group hover:bg-white/[0.02] hover:border-white/10 transition-all shadow-inner">
                   <div className="flex items-center justify-between">
                      {guild.icon ? (
                        <img 
                        src={getDiscordAsset('icon', guild.id, guild.icon) || ""}
                         className="w-12 h-12 rounded-2xl grayscale group-hover:grayscale-0 transition-all duration-700 border border-white/5"
                         alt={guild.name}
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-xs font-black text-white/10 uppercase">
                          {guild.name.slice(0, 2)}
                        </div>
                      )}
                      
                      <Link 
                       href={`https://discord.com/api/oauth2/authorize?client_id=1493482964246593556&permissions=8&scope=bot%20applications.commands&guild_id=${guild.id}`}
                       target="_blank"
                       className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/20 hover:bg-white hover:text-black transition-all shadow-xl"
                      >
                        <Plus className="w-5 h-5" />
                      </Link>
                   </div>
                   <div className="space-y-1">
                      <h3 className="text-xs font-black text-white/40 truncate group-hover:text-white transition-colors uppercase tracking-tight">{guild.name}</h3>
                      <p className="text-[8px] text-white/5 font-black uppercase tracking-[0.2em]">Deployment Required</p>
                   </div>
                </div>
              ))}
           </div>
        </section>

      </main>

      <footer className="relative z-10 mt-auto py-12 px-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 bg-[#050510]/80 backdrop-blur-3xl">
        <div className="flex items-center gap-4 text-[9px] font-black text-white/10 uppercase tracking-[0.3em]">
          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)] animate-pulse" />
          Quantum Security Grid: Operational
        </div>
        <div className="text-[9px] font-black text-white/10 uppercase tracking-[0.2em] border border-white/5 px-6 py-3 rounded-full">
          Authorized // {session.user.name}
        </div>
      </footer>
    </div>
  );
}
