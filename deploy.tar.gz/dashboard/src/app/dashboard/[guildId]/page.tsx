import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import OverviewClient from "@/components/OverviewClient";

export default async function GuildDashboard({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
  });

  if (!guildData) {
    await prisma.guild.create({ data: { id: guildId } });
    return redirect(`/dashboard/${guildId}`);
  }

  const memberCount = await prisma.member.count({ where: { guildId } });

  return (
    <OverviewClient 
      guildId={guildId} 
      guildData={guildData} 
      memberCount={memberCount} 
    />
  );
}
