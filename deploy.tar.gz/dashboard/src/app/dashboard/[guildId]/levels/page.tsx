'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  Zap, Save, Sparkles, Trophy, TrendingUp, Target, 
  MessageSquare, Mic, Play, Settings2, Image as ImageIcon,
  Bell, ListFilter, Users, Shield, Plus, Trash2, 
  Palette, MousePointer2, ChevronDown, Check, X,
  BarChart3, RefreshCw, Layout, Eye, Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import CustomSelect from '@/components/CustomSelect';

export default function LevelsPage() {
  const { guildId } = useParams();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });
  const [channels, setChannels] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [showRankCardModal, setShowRankCardModal] = useState(false);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  // Guild Data State
  const [data, setData] = useState<any>({
    levelingEnabled: true,
    xpFormulaCurve: 'LINEAR',
    xpFormulaMultiplier: 1.0,
    xpFormulaMaxLevel: null,
    xpMessageEnabled: true,
    xpMessageMode: 'RANDOM',
    xpMessageMin: 15,
    xpMessageMax: 25,
    xpMessageCooldown: 60,
    xpVoiceEnabled: false,
    xpVoiceMin: 15,
    xpVoiceMax: 40,
    xpVoiceCooldown: 180,
    xpVoiceMinMembers: 2,
    xpVoiceAntiAfk: true,
    xpReactionEnabled: false,
    xpReactionAwardType: 'BOTH',
    xpReactionMin: 5,
    xpReactionMax: 10,
    xpReactionCooldown: 300,
    levelUpMessageEnabled: true,
    levelUpMessage: 'GG {user.mention}, you just reached level **{user.level}**!',
    levelUpImageEnabled: false,
    firstPlaceRoleId: null,
    stackRoleRewards: true,
    stackXpBoosters: true,
    voteRewardEnabled: false,
    effortBoosterEnabled: false,
    effortBoosterWords: 25,
    effortBoosterImages: 3,
    effortBoosterPercentage: 10,
    weeklyHighlightsEnabled: false,
    weeklyHighlightsChannelId: null,
    monthlyHighlightsEnabled: false,
    monthlyHighlightsChannelId: null,
    rankCardProgressColor: '#ffffff',
    rankCardProgressOpacity: 1.0,
    rankCardBackgroundColor: '#000000',
    rankCardFontColor: '#ffffff',
    rankCardBackgroundUrl: null,
    disableXpCommand: false,
    disableLeaderboardReset: false,
    levelRoles: [],
    roleBoosters: [],
    channelBoosters: []
  });

  const fetchData = useCallback(async () => {
    try {
      const [levelsRes, rolesRes, channelsRes] = await Promise.all([
        fetch(`/api/guild/${guildId}/levels`),
        fetch(`/api/guild/${guildId}/roles`),
        fetch(`/api/guild/${guildId}/channels`)
      ]);

      if (levelsRes.ok) {
        const levelsData = await levelsRes.json();
        if (levelsData) setData((prev: any) => ({ ...prev, ...levelsData }));
      }

      if (rolesRes.ok) setRoles(await rolesRes.json());
      if (channelsRes.ok) {
        const cData = await channelsRes.json();
        setChannels(Array.isArray(cData) ? cData : (cData.channels || []));
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setLoading(false);
    }
  }, [guildId]);

  useEffect(() => {
    if (guildId) fetchData();
  }, [guildId, fetchData]);

  const handleUpdate = (field: string, value: any) => {
    setData((prev: any) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMsg({ text: 'Syncing progression telemetry...', type: 'info' });
    try {
      const res = await fetch(`/api/guild/${guildId}/levels`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) {
        setStatusMsg({ text: 'Telemetry stabilized.', type: 'success' });
        router.refresh();
      } else throw new Error();
    } catch {
      setStatusMsg({ text: 'Error: Sync failed.', type: 'error' });
    } finally {
      setIsSaving(false);
      setTimeout(() => setStatusMsg({ text: '', type: '' }), 4000);
    }
  };

  const addLevelRole = () => {
    setData((prev: any) => ({
      ...prev,
      levelRoles: [...prev.levelRoles, { level: 1, roleId: roles[0]?.id || '' }]
    }));
  };

  const removeLevelRole = (index: number) => {
    setData((prev: any) => ({
      ...prev,
      levelRoles: prev.levelRoles.filter((_: any, i: number) => i !== index)
    }));
  };

  const addRoleBooster = () => {
    setData((prev: any) => ({
      ...prev,
      roleBoosters: [...prev.roleBoosters, { roleId: roles[0]?.id || '', percentage: 10 }]
    }));
  };

  const removeRoleBooster = (index: number) => {
    setData((prev: any) => ({
      ...prev,
      roleBoosters: prev.roleBoosters.filter((_: any, i: number) => i !== index)
    }));
  };

  const addChannelBooster = () => {
    setData((prev: any) => ({
      ...prev,
      channelBoosters: [...prev.channelBoosters, { channelId: channels[0]?.id || '', percentage: 10 }]
    }));
  };

  const removeChannelBooster = (index: number) => {
    setData((prev: any) => ({
      ...prev,
      channelBoosters: prev.channelBoosters.filter((_: any, i: number) => i !== index)
    }));
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <RefreshCw className="w-8 h-8 text-white/20 animate-spin" />
        <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Initializing Leveling System...</p>
      </div>
    );
  }

  return (
    <main className="p-8 max-w-6xl mx-auto space-y-10 relative z-10">
      <motion.div variants={item} className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-blue-500/20 border border-emerald-500/20 flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Progression System</h1>
            <p className="text-white/50 text-sm mt-1">Configure experience curves, reward tiers, and engagement boosters for your community.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           {statusMsg.text && (
             <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className={`text-[10px] font-bold uppercase tracking-widest ${statusMsg.type === 'error' ? 'text-red-400' : 'text-emerald-400'}`}>
                {statusMsg.text}
             </motion.div>
           )}
           <button 
             onClick={handleSave}
             disabled={isSaving}
             className={`px-8 py-3 rounded-xl font-bold text-[10px] uppercase tracking-[0.2em] transition-all flex items-center gap-3 ${isSaving ? 'bg-white/5 text-white/20' : 'bg-white text-black hover:bg-zinc-200'}`}
           >
             {isSaving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
             {isSaving ? "SAVING..." : "DEPLOY CONFIG"}
           </button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
        <div className="xl:col-span-3 space-y-10">
          
          {/* XP Options Section */}
          <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-10">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-5">
                   <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 shadow-inner">
                      <Zap className="w-5 h-5 text-white/60" />
                   </div>
                   <div className="space-y-1">
                      <h2 className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">XP Options</h2>
                      <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Global engagement settings</p>
                   </div>
                </div>
                <div className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[9px] font-bold uppercase tracking-widest">New Features</div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Formula */}
                <div className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-8">
                   <div className="space-y-1">
                      <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Formula</h3>
                      <p className="text-[9px] text-white/20 font-medium">How XP requirements scale per level.</p>
                   </div>
                   <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Curve</label>
                         <CustomSelect
                           options={[
                             { id: 'LINEAR', name: 'Linear' },
                             { id: 'EXPONENTIAL', name: 'Exp' },
                             { id: 'FLAT', name: 'Flat' }
                           ]}
                           value={data.xpFormulaCurve}
                           onChange={(val) => handleUpdate('xpFormulaCurve', val)}
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Multiplier</label>
                         <input 
                           type="number" step="0.1" min="0.1"
                           value={data.xpFormulaMultiplier}
                           onChange={(e) => handleUpdate('xpFormulaMultiplier', parseFloat(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Max Level</label>
                         <input 
                           type="text" placeholder="None"
                           value={data.xpFormulaMaxLevel || ''}
                           onChange={(e) => handleUpdate('xpFormulaMaxLevel', e.target.value ? parseInt(e.target.value) : null)}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                   </div>
                </div>

                {/* Message XP */}
                <div className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-8 relative overflow-visible">
                   <div className="flex justify-between items-start">
                      <div className="space-y-1">
                         <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Message XP</h3>
                         <p className="text-[9px] text-white/20 font-medium">XP earned from chatting.</p>
                      </div>
                      <button 
                        onClick={() => handleUpdate('xpMessageEnabled', !data.xpMessageEnabled)}
                        className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.xpMessageEnabled ? 'bg-emerald-500' : 'bg-white/5'}`}
                      >
                         <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.xpMessageEnabled ? 'left-5 bg-white' : 'left-1 bg-white/20'}`} />
                      </button>
                   </div>
                   <div className={`grid grid-cols-2 gap-4 transition-opacity ${data.xpMessageEnabled ? 'opacity-100' : 'opacity-20'}`}>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Min XP</label>
                         <input 
                           type="number"
                           value={data.xpMessageMin}
                           onChange={(e) => handleUpdate('xpMessageMin', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Max XP</label>
                         <input 
                           type="number"
                           value={data.xpMessageMax}
                           onChange={(e) => handleUpdate('xpMessageMax', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="col-span-2 space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Cooldown (Seconds)</label>
                         <input 
                           type="number"
                           value={data.xpMessageCooldown}
                           onChange={(e) => handleUpdate('xpMessageCooldown', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                   </div>
                </div>

                {/* Voice XP */}
                <div className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-8">
                   <div className="flex justify-between items-start">
                      <div className="space-y-1">
                         <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Voice XP</h3>
                         <p className="text-[9px] text-white/20 font-medium">XP earned in voice channels.</p>
                      </div>
                      <button 
                        onClick={() => handleUpdate('xpVoiceEnabled', !data.xpVoiceEnabled)}
                        className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.xpVoiceEnabled ? 'bg-emerald-500' : 'bg-white/5'}`}
                      >
                         <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.xpVoiceEnabled ? 'left-5 bg-white' : 'left-1 bg-white/20'}`} />
                      </button>
                   </div>
                   <div className={`grid grid-cols-2 gap-4 transition-opacity ${data.xpVoiceEnabled ? 'opacity-100' : 'opacity-20'}`}>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Min XP</label>
                         <input 
                           type="number"
                           value={data.xpVoiceMin}
                           onChange={(e) => handleUpdate('xpVoiceMin', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Max XP</label>
                         <input 
                           type="number"
                           value={data.xpVoiceMax}
                           onChange={(e) => handleUpdate('xpVoiceMax', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Cooldown</label>
                         <input 
                           type="number"
                           value={data.xpVoiceCooldown}
                           onChange={(e) => handleUpdate('xpVoiceCooldown', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Min Members</label>
                         <input 
                           type="number"
                           value={data.xpVoiceMinMembers}
                           onChange={(e) => handleUpdate('xpVoiceMinMembers', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                   </div>
                </div>

                {/* Reaction XP */}
                <div className="bg-white/[0.01] border border-white/5 p-8 rounded-3xl space-y-8">
                   <div className="flex justify-between items-start">
                      <div className="space-y-1">
                         <div className="flex items-center gap-2">
                           <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Reaction XP</h3>
                           <span className="text-[7px] bg-white text-black px-1.5 py-0.5 rounded font-black">NEW</span>
                         </div>
                         <p className="text-[9px] text-white/20 font-medium">XP from reactions.</p>
                      </div>
                      <button 
                        onClick={() => handleUpdate('xpReactionEnabled', !data.xpReactionEnabled)}
                        className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.xpReactionEnabled ? 'bg-emerald-500' : 'bg-white/5'}`}
                      >
                         <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.xpReactionEnabled ? 'left-5 bg-white' : 'left-1 bg-white/20'}`} />
                      </button>
                   </div>
                   <div className={`grid grid-cols-2 gap-4 transition-opacity ${data.xpReactionEnabled ? 'opacity-100' : 'opacity-20'}`}>
                      <div className="col-span-2 space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Awards</label>
                         <CustomSelect
                           options={[
                             { id: 'BOTH', name: 'Both Sender & Receiver' },
                             { id: 'SENDER', name: 'Sender Only' },
                             { id: 'RECEIVER', name: 'Receiver Only' }
                           ]}
                           value={data.xpReactionAwardType}
                           onChange={(val) => handleUpdate('xpReactionAwardType', val)}
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Min XP</label>
                         <input 
                           type="number"
                           value={data.xpReactionMin}
                           onChange={(e) => handleUpdate('xpReactionMin', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                      <div className="space-y-3">
                         <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Max XP</label>
                         <input 
                           type="number"
                           value={data.xpReactionMax}
                           onChange={(e) => handleUpdate('xpReactionMax', parseInt(e.target.value))}
                           className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20 transition-all"
                         />
                      </div>
                   </div>
                </div>
             </div>
          </motion.section>

          {/* XP Boosters Section */}
          <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-10">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-5">
                   <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10">
                      <Sparkles className="w-5 h-5 text-white/60" />
                   </div>
                   <div className="space-y-1">
                      <h2 className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">XP Boosters</h2>
                      <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Enhance engagement speed</p>
                   </div>
                </div>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white/[0.01] border border-white/5 p-6 rounded-3xl flex items-center justify-between">
                   <div className="space-y-1">
                      <h4 className="text-[10px] font-bold text-white uppercase tracking-widest">Stack Boosters</h4>
                      <p className="text-[8px] text-white/20 font-medium">Apply all active boosts vs only highest</p>
                   </div>
                   <button 
                     onClick={() => handleUpdate('stackXpBoosters', !data.stackXpBoosters)}
                     className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.stackXpBoosters ? 'bg-white' : 'bg-white/5'}`}
                   >
                      <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.stackXpBoosters ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
                   </button>
                </div>

                <div className="bg-white/[0.01] border border-white/5 p-6 rounded-3xl flex items-center justify-between">
                   <div className="space-y-1">
                      <h4 className="text-[10px] font-bold text-white uppercase tracking-widest">Vote Reward</h4>
                      <p className="text-[8px] text-white/20 font-medium">Extra XP for voting on top.gg</p>
                   </div>
                   <button 
                     onClick={() => handleUpdate('voteRewardEnabled', !data.voteRewardEnabled)}
                     className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.voteRewardEnabled ? 'bg-white' : 'bg-white/5'}`}
                   >
                      <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.voteRewardEnabled ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
                   </button>
                </div>
             </div>

             {/* Effort Booster */}
             <div className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] space-y-8">
                <div className="flex justify-between items-start">
                   <div className="space-y-1">
                      <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Effort Booster</h3>
                      <p className="text-[9px] text-white/20 font-medium">Reward detailed messages and media content.</p>
                   </div>
                   <button 
                     onClick={() => handleUpdate('effortBoosterEnabled', !data.effortBoosterEnabled)}
                     className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.effortBoosterEnabled ? 'bg-emerald-500' : 'bg-white/5'}`}
                   >
                      <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.effortBoosterEnabled ? 'left-5 bg-white' : 'left-1 bg-white/20'}`} />
                   </button>
                </div>
                <div className={`grid grid-cols-3 gap-6 transition-opacity ${data.effortBoosterEnabled ? 'opacity-100' : 'opacity-20'}`}>
                   <div className="space-y-3">
                      <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Min Words</label>
                      <input type="number" value={data.effortBoosterWords} onChange={e => handleUpdate('effortBoosterWords', parseInt(e.target.value))} className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20" />
                   </div>
                   <div className="space-y-3">
                      <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Images</label>
                      <input type="number" value={data.effortBoosterImages} onChange={e => handleUpdate('effortBoosterImages', parseInt(e.target.value))} className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20" />
                   </div>
                   <div className="space-y-3">
                      <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest block">Boost %</label>
                      <input type="number" value={data.effortBoosterPercentage} onChange={e => handleUpdate('effortBoosterPercentage', parseInt(e.target.value))} className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none focus:border-white/20" />
                   </div>
                </div>
             </div>

             {/* Role Boosters */}
             <div className="space-y-6">
                <div className="flex items-center justify-between">
                   <div className="space-y-1">
                      <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Role Boosters</h3>
                      <p className="text-[9px] text-white/20 font-medium">Members with these roles earn extra XP.</p>
                   </div>
                   <button onClick={addRoleBooster} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-[9px] font-bold text-white/40 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest">
                      <Plus className="w-3 h-3" /> Add Booster
                   </button>
                </div>
                <div className="space-y-3">
                   {data.roleBoosters.map((rb: any, i: number) => (
                      <div key={i} className="bg-white/[0.01] border border-white/5 p-4 rounded-2xl flex items-center gap-4">
                         <div className="flex-1 grid grid-cols-2 gap-4">
                            <CustomSelect
                              options={roles}
                              value={rb.roleId}
                              onChange={(val) => {
                                const newBoosters = [...data.roleBoosters];
                                newBoosters[i].roleId = val;
                                handleUpdate('roleBoosters', newBoosters);
                              }}
                            />
                            <div className="relative">
                               <input 
                                 type="number" value={rb.percentage}
                                 onChange={(e) => {
                                   const newBoosters = [...data.roleBoosters];
                                   newBoosters[i].percentage = parseInt(e.target.value);
                                   handleUpdate('roleBoosters', newBoosters);
                                 }}
                                 className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none"
                               />
                               <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-white/20">%</span>
                            </div>
                         </div>
                         <button onClick={() => removeRoleBooster(i)} className="p-2 text-white/10 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                   ))}
                </div>
             </div>

             {/* Channel Boosters */}
             <div className="space-y-6">
                <div className="flex items-center justify-between">
                   <div className="space-y-1">
                      <div className="flex items-center gap-2">
                         <h3 className="text-[11px] font-bold text-white/80 uppercase tracking-widest">Channel Boosters</h3>
                         <span className="text-[7px] bg-white text-black px-1.5 py-0.5 rounded font-black">HOT</span>
                      </div>
                      <p className="text-[9px] text-white/20 font-medium">Activity in these channels earns extra XP.</p>
                   </div>
                   <button onClick={addChannelBooster} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-[9px] font-bold text-white/40 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest">
                      <Plus className="w-3 h-3" /> Add Booster
                   </button>
                </div>
                <div className="space-y-3">
                   {data.channelBoosters.map((cb: any, i: number) => (
                      <div key={i} className="bg-white/[0.01] border border-white/5 p-4 rounded-2xl flex items-center gap-4">
                         <div className="flex-1 grid grid-cols-2 gap-4">
                            <CustomSelect
                              options={channels.map(c => ({ id: c.id, name: `# ${c.name}` }))}
                              value={cb.channelId}
                              onChange={(val) => {
                                const newBoosters = [...data.channelBoosters];
                                newBoosters[i].channelId = val;
                                handleUpdate('channelBoosters', newBoosters);
                              }}
                            />
                            <div className="relative">
                               <input 
                                 type="number" value={cb.percentage}
                                 onChange={(e) => {
                                   const newBoosters = [...data.channelBoosters];
                                   newBoosters[i].percentage = parseInt(e.target.value);
                                   handleUpdate('channelBoosters', newBoosters);
                                 }}
                                 className="w-full bg-white/5 border border-white/5 rounded-xl px-3 py-2 text-[10px] font-bold text-white/60 focus:outline-none"
                               />
                               <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-white/20">%</span>
                            </div>
                         </div>
                         <button onClick={() => removeChannelBooster(i)} className="p-2 text-white/10 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                      </div>
                   ))}
                </div>
             </div>
          </motion.section>
        </div>
 
         {/* Right Column: Levelup, Rewards, Management */}
         <div className="space-y-10">
            
            {/* Sidebar Status Box */}
            <motion.div variants={item} className="bg-gradient-to-br from-emerald-500/10 to-blue-500/10 border border-emerald-500/20 p-6 rounded-3xl space-y-4">
               <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                     <TrendingUp className="w-4 h-4 text-emerald-400" />
                  </div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">Progression Status</h3>
               </div>
               <div className="space-y-2">
                  <div className="flex justify-between text-[11px]">
                     <span className="text-white/40">Status</span>
                     <span className="text-emerald-400 font-bold">Synchronized</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                     <span className="text-white/40">Active Modules</span>
                     <span className="text-white">4 Modules</span>
                  </div>
               </div>
            </motion.div>

            {/* Levelup Message Section */}
            <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-8">
              <div className="flex justify-between items-start">
                 <div className="space-y-1">
                    <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white">Levelup Message</h2>
                    <p className="text-[9px] text-white/20 font-medium uppercase tracking-widest">Announcement settings</p>
                 </div>
                 <button 
                   onClick={() => handleUpdate('levelUpMessageEnabled', !data.levelUpMessageEnabled)}
                   className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.levelUpMessageEnabled ? 'bg-white' : 'bg-white/5'}`}
                 >
                    <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.levelUpMessageEnabled ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
                 </button>
              </div>

              <div className={`space-y-6 transition-all ${data.levelUpMessageEnabled ? 'opacity-100 scale-100' : 'opacity-20 scale-95 pointer-events-none'}`}>
                 <div className="space-y-3">
                    <div className="flex items-center justify-between">
                       <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Message Content</label>
                       <div className="flex gap-2">
                          {['{user.mention}', '{user.level}'].map(tag => (
                             <button key={tag} className="text-[8px] font-bold text-white/40 hover:text-white px-1.5 py-0.5 rounded bg-white/5 transition-colors border border-white/5">{tag}</button>
                          ))}
                       </div>
                    </div>
                    <textarea 
                      value={data.levelUpMessage || ''}
                      onChange={(e) => handleUpdate('levelUpMessage', e.target.value)}
                      rows={4}
                      className="w-full bg-white/5 border border-white/5 rounded-2xl p-4 text-[11px] font-medium text-white/80 focus:outline-none focus:border-white/20 resize-none transition-all"
                      placeholder="Type level-up message..."
                    />
                 </div>

                 <div className="flex items-center justify-between p-4 bg-white/[0.01] border border-white/5 rounded-2xl">
                    <div className="flex items-center gap-3">
                       <ImageIcon className="w-4 h-4 text-white/40" />
                       <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">Include Rank Card</span>
                    </div>
                    <button 
                      onClick={() => handleUpdate('levelUpImageEnabled', !data.levelUpImageEnabled)}
                      className={`w-8 h-4 rounded-full relative transition-all ${data.levelUpImageEnabled ? 'bg-emerald-500' : 'bg-white/10'}`}
                    >
                       <div className={`absolute top-0.5 w-3 h-3 rounded-full transition-all ${data.levelUpImageEnabled ? 'left-4.5 bg-white' : 'left-0.5 bg-white/20'}`} />
                    </button>
                 </div>
              </div>
           </motion.section>

           {/* Role Rewards Section */}
           <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-8">
              <div className="flex justify-between items-center">
                 <div className="space-y-1">
                    <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white">Role Rewards</h2>
                    <p className="text-[9px] text-white/20 font-medium uppercase tracking-widest">Milestone achievements</p>
                 </div>
                 <button onClick={addLevelRole} className="p-2 bg-white/5 border border-white/5 rounded-xl text-white/40 hover:text-white hover:bg-white/10 transition-all">
                    <Plus className="w-4 h-4" />
                 </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-white/[0.01] border border-white/5 rounded-2xl">
                 <div className="space-y-0.5">
                    <h4 className="text-[9px] font-bold text-white/80 uppercase tracking-widest">Stack Rewards</h4>
                    <p className="text-[8px] text-white/20 font-medium">Keep previous roles on level up</p>
                 </div>
                 <button 
                   onClick={() => handleUpdate('stackRoleRewards', !data.stackRoleRewards)}
                   className={`w-9 h-5 rounded-full relative transition-all duration-300 ${data.stackRoleRewards ? 'bg-white' : 'bg-white/5'}`}
                 >
                    <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${data.stackRoleRewards ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
                 </button>
              </div>

              <div className="space-y-3">
                 {data.levelRoles.length > 0 ? (
                    data.levelRoles.map((lr: any, i: number) => (
                       <div key={i} className="flex items-center gap-3 bg-white/[0.01] border border-white/5 p-4 rounded-2xl animate-in fade-in slide-in-from-right-2">
                          <div className="w-12">
                             <input 
                               type="number" value={lr.level}
                               onChange={(e) => {
                                 const newRoles = [...data.levelRoles];
                                 newRoles[i].level = parseInt(e.target.value);
                                 handleUpdate('levelRoles', newRoles);
                               }}
                               className="w-full bg-white/5 border border-white/5 rounded-lg px-2 py-1.5 text-[10px] font-bold text-white text-center focus:outline-none"
                             />
                          </div>
                          <div className="flex-1">
                             <CustomSelect 
                               options={roles}
                               value={lr.roleId}
                               onChange={(val) => {
                                 const newRoles = [...data.levelRoles];
                                 newRoles[i].roleId = val;
                                 handleUpdate('levelRoles', newRoles);
                               }}
                               placeholder="Select Role"
                             />
                          </div>
                          <button onClick={() => removeLevelRole(i)} className="p-1.5 text-white/10 hover:text-red-500 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
                       </div>
                    ))
                 ) : (
                    <div className="py-12 flex flex-col items-center justify-center gap-3 border border-dashed border-white/5 rounded-3xl">
                       <p className="text-[9px] font-bold text-white/10 uppercase tracking-[0.2em]">No rewards defined</p>
                    </div>
                 )}
              </div>
           </motion.section>

           {/* Rank Card Customization Section */}
           <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-8 group hover:border-white/10 transition-all">
              <div className="flex items-center gap-5">
                 <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-white/10 transition-colors">
                    <Palette className="w-5 h-5 text-white/60" />
                 </div>
                 <div className="space-y-1">
                    <h2 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white">Rank Card</h2>
                    <p className="text-[9px] text-white/20 font-medium uppercase tracking-widest">Visual branding</p>
                 </div>
              </div>

              <div className="bg-black/40 rounded-3xl p-6 border border-white/5 space-y-6">
                 <div className="aspect-[4/1] bg-white/5 rounded-2xl relative overflow-hidden flex items-center px-6 gap-6">
                    <div className="w-10 h-10 rounded-full bg-white/10 border border-white/10" />
                    <div className="flex-1 space-y-2">
                       <div className="h-2 w-24 bg-white/20 rounded-full" />
                       <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full w-2/3 bg-white/40" style={{ backgroundColor: data.rankCardProgressColor, opacity: data.rankCardProgressOpacity }} />
                       </div>
                    </div>
                 </div>

                 <button 
                   onClick={() => setShowRankCardModal(true)}
                   className="w-full py-4 rounded-2xl bg-white/5 border border-white/5 font-bold text-[10px] uppercase tracking-[0.2em] text-white/40 hover:text-white hover:bg-white/10 transition-all flex items-center justify-center gap-3"
                 >
                    <MousePointer2 className="w-3.5 h-3.5" /> Customize Aesthetics
                 </button>
              </div>
           </motion.section>

           {/* XP Management Section */}
           <motion.section variants={item} className="bg-white/[0.02] border border-white/5 p-8 rounded-3xl space-y-6">
              <h2 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40">XP Management</h2>
              
              <div className="space-y-3">
                 {[
                   { label: 'Disable /xp command', field: 'disableXpCommand' },
                   { label: 'Disable leaderboard reset', field: 'disableLeaderboardReset' }
                 ].map(item => (
                    <div key={item.field} className="flex items-center justify-between p-4 bg-white/[0.01] border border-white/5 rounded-2xl">
                       <span className="text-[9px] font-bold text-white/60 uppercase tracking-widest">{item.label}</span>
                       <button 
                         onClick={() => handleUpdate(item.field, !data[item.field as keyof typeof data])}
                         className={`w-8 h-4 rounded-full relative transition-all ${data[item.field as keyof typeof data] ? 'bg-white' : 'bg-white/10'}`}
                       >
                          <div className={`absolute top-0.5 w-3 h-3 rounded-full transition-all ${data[item.field as keyof typeof data] ? 'left-4.5 bg-black' : 'left-0.5 bg-white/20'}`} />
                       </button>
                    </div>
                 ))}
              </div>
           </motion.section>
        </div>
      </div>

      {/* Rank Card Modal */}
      <AnimatePresence>
        {showRankCardModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 md:p-12">
             <motion.div 
               initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
               onClick={() => setShowRankCardModal(false)}
               className="absolute inset-0 bg-black/80 backdrop-blur-xl"
             />
             <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-[#0c0c0c] border border-white/10 rounded-[40px] w-full max-w-2xl overflow-visible relative shadow-2xl"
             >
                <div className="p-8 border-b border-white/5 flex items-center justify-between">
                   <div className="flex items-center gap-4">
                      <Palette className="w-5 h-5 text-white/40" />
                      <h3 className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">Rank Card Aesthetics</h3>
                   </div>
                   <button onClick={() => setShowRankCardModal(false)} className="p-2 text-white/20 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
                </div>

                <div className="p-10 space-y-12">
                   {/* Preview */}
                   <div className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                         <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Live Preview</span>
                         <span className="text-[9px] font-bold text-white/40 uppercase tracking-widest">800x200</span>
                      </div>
                      <div 
                        className="aspect-[4/1] rounded-[32px] border border-white/10 relative overflow-hidden flex items-center px-10 gap-8"
                        style={{ 
                          backgroundColor: data.rankCardBackgroundColor,
                          backgroundImage: data.rankCardBackgroundUrl ? `url(${data.rankCardBackgroundUrl})` : 'none',
                          backgroundSize: 'cover',
                          backgroundPosition: 'center'
                        }}
                      >
                         <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex-shrink-0" />
                         <div className="flex-1 space-y-3">
                            <div className="flex justify-between items-end">
                               <div className="h-4 w-32 bg-white/20 rounded-lg" style={{ backgroundColor: data.rankCardFontColor + '40' }} />
                               <div className="h-3 w-16 bg-white/20 rounded-lg" style={{ backgroundColor: data.rankCardFontColor + '40' }} />
                            </div>
                            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                               <div 
                                 className="h-full w-3/4 rounded-full" 
                                 style={{ backgroundColor: data.rankCardProgressColor, opacity: data.rankCardProgressOpacity }} 
                               />
                            </div>
                         </div>
                      </div>
                   </div>

                   <div className="grid grid-cols-2 gap-10">
                      <div className="space-y-8">
                         <div className="space-y-4">
                            <label className="text-[9px] font-bold text-white/40 uppercase tracking-widest block">Progress Color</label>
                            <div className="flex items-center gap-4">
                               <input type="color" value={data.rankCardProgressColor} onChange={e => handleUpdate('rankCardProgressColor', e.target.value)} className="w-12 h-12 rounded-xl bg-transparent border-0 cursor-pointer" />
                               <input type="text" value={data.rankCardProgressColor} onChange={e => handleUpdate('rankCardProgressColor', e.target.value)} className="flex-1 bg-white/5 border border-white/5 rounded-xl px-4 py-2 text-[11px] font-bold text-white/80" />
                            </div>
                         </div>
                         <div className="space-y-4">
                            <label className="text-[9px] font-bold text-white/40 uppercase tracking-widest block">Background Color</label>
                            <div className="flex items-center gap-4">
                               <input type="color" value={data.rankCardBackgroundColor} onChange={e => handleUpdate('rankCardBackgroundColor', e.target.value)} className="w-12 h-12 rounded-xl bg-transparent border-0 cursor-pointer" />
                               <input type="text" value={data.rankCardBackgroundColor} onChange={e => handleUpdate('rankCardBackgroundColor', e.target.value)} className="flex-1 bg-white/5 border border-white/5 rounded-xl px-4 py-2 text-[11px] font-bold text-white/80" />
                            </div>
                         </div>
                      </div>

                      <div className="space-y-8">
                         <div className="space-y-4">
                            <label className="text-[9px] font-bold text-white/40 uppercase tracking-widest block">Opacity ({Math.round(data.rankCardProgressOpacity * 100)}%)</label>
                            <input type="range" min="0" max="1" step="0.1" value={data.rankCardProgressOpacity} onChange={e => handleUpdate('rankCardProgressOpacity', parseFloat(e.target.value))} className="w-full h-1.5 bg-white/5 rounded-full appearance-none cursor-pointer accent-white" />
                         </div>
                         <div className="space-y-4">
                            <label className="text-[9px] font-bold text-white/40 uppercase tracking-widest block">Font Color</label>
                            <div className="flex items-center gap-4">
                               <input type="color" value={data.rankCardFontColor} onChange={e => handleUpdate('rankCardFontColor', e.target.value)} className="w-12 h-12 rounded-xl bg-transparent border-0 cursor-pointer" />
                               <input type="text" value={data.rankCardFontColor} onChange={e => handleUpdate('rankCardFontColor', e.target.value)} className="flex-1 bg-white/5 border border-white/5 rounded-xl px-4 py-2 text-[11px] font-bold text-white/80" />
                            </div>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-4 pt-4 border-t border-white/5">
                      <label className="text-[9px] font-bold text-white/40 uppercase tracking-widest block">Background URL (800x200 recommended)</label>
                      <input 
                        type="text" placeholder="https://..."
                        value={data.rankCardBackgroundUrl || ''}
                        onChange={e => handleUpdate('rankCardBackgroundUrl', e.target.value)}
                        className="w-full bg-white/5 border border-white/5 rounded-2xl px-6 py-4 text-[11px] font-medium text-white/80 focus:outline-none focus:border-white/20"
                      />
                   </div>
                </div>

                <div className="p-8 bg-white/[0.01] border-t border-white/5 flex justify-end">
                   <button 
                     onClick={() => setShowRankCardModal(false)}
                     className="px-10 py-4 bg-white text-black rounded-2xl text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-zinc-200 transition-all shadow-xl shadow-white/5"
                   >
                      Confirm Selection
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style jsx global>{`
        input[type="color"]::-webkit-color-swatch-wrapper { padding: 0; }
        input[type="color"]::-webkit-color-swatch { border: none; border-radius: 12px; }
      `}</style>
    </main>
  );
}
