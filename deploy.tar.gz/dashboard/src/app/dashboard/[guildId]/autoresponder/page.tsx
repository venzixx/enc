'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { 
  Sparkles, Plus, Trash2, MessageSquare, 
  RefreshCw, Search, ListFilter, AlertCircle,
  Save, X, Check, Zap, Info, Hash, Globe, User, Settings2, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import MarkdownDisplay from '@/components/MarkdownDisplay';
import CustomSelect from '@/components/CustomSelect';

export default function AutoresponderPage() {
  const { guildId } = useParams();
  const [loading, setLoading] = useState(true);
  const [responders, setResponders] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [search, setSearch] = useState('');
  
  const [formData, setFormData] = useState({
    trigger: '',
    response: '',
    channelId: '',
    matchType: 'EXACT'
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [channels, setChannels] = useState<any[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const [resResponders, resChannels] = await Promise.all([
        fetch(`/api/guild/${guildId}/autoresponder`),
        fetch(`/api/guild/${guildId}/channels`)
      ]);
      
      if (resResponders.ok) setResponders(await resResponders.json());
      if (resChannels.ok) setChannels(await resChannels.json());
    } catch (error) {
      console.error("Fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [guildId]);

  useEffect(() => {
    if (guildId) fetchData();
  }, [guildId, fetchData]);

  const handleSave = async () => {
    let finalData = { ...formData };
    if (formData.matchType === 'MENTION') {
      finalData.trigger = formData.trigger.replace(/\D/g, '');
    }
    if (!finalData.trigger || !finalData.response) return;
    
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/autoresponder`, {
        method: editingId ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...finalData,
          id: editingId
        })
      });

      if (res.ok) {
        await fetchData();
        setShowModal(false);
        setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
        setEditingId(null);
      }
    } catch (error) {
      console.error("Save error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this auto-response?")) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/autoresponder?id=${id}`, {
        method: 'DELETE'
      });
      if (res.ok) await fetchData();
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  const filtered = responders.filter(r => 
    r.trigger.toLowerCase().includes(search.toLowerCase()) || 
    r.response.toLowerCase().includes(search.toLowerCase())
  );

  if (loading && responders.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <RefreshCw className="w-8 h-8 text-white/20 animate-spin" />
        <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Decoding manifest...</p>
      </div>
    );
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (loading && responders.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <RefreshCw className="w-8 h-8 text-white/20 animate-spin" />
        <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Decoding manifest...</p>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/20 flex items-center justify-center">
            <Zap className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Auto-Response Matrix</h1>
            <p className="text-white/50 text-sm mt-1">Configure automated triggers and dynamic response patterns.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> Automation Active
           </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 xl:grid-cols-4 gap-8"
      >
        <div className="xl:col-span-3 space-y-8">
           {/* Controls Bar */}
           <motion.div variants={item} className="flex flex-col lg:flex-row gap-6 items-center justify-between bg-white/[0.02] border border-white/5 p-6 rounded-[32px]">
             <div className="relative w-full lg:w-[400px]">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                <input 
                  type="text" 
                  placeholder="Filter by trigger word..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-[13px] text-white outline-none focus:border-white/10 transition-all font-medium"
                />
             </div>

             <button 
               onClick={() => setShowModal(true)}
               className="px-8 py-4 bg-white text-black rounded-xl text-[11px] font-bold uppercase tracking-[0.2em] transition-all hover:bg-zinc-200 shadow-xl flex items-center gap-3 shrink-0"
             >
               <Plus className="w-4 h-4" /> New Responder
             </button>
           </motion.div>

           {/* Responders Grid */}
           <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <AnimatePresence mode="popLayout">
               {filtered.map((res) => (
                 <motion.div 
                   key={res.id}
                   layout
                   initial={{ opacity: 0, scale: 0.98 }}
                   animate={{ opacity: 1, scale: 1 }}
                   exit={{ opacity: 0, scale: 0.95 }}
                   className="bg-white/[0.01] border border-white/5 rounded-[32px] p-8 space-y-8 group hover:bg-white/[0.02] hover:border-white/10 transition-all relative overflow-hidden"
                 >
                    <div className="flex justify-between items-start relative z-10">
                       <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${res.matchType === 'CONTAINS' ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' : res.matchType === 'MENTION' ? 'bg-purple-500/10 border-purple-500/20 text-purple-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'}`}>
                             {res.matchType === 'CONTAINS' && <Globe className="w-4 h-4" />}
                             {res.matchType === 'MENTION' && <User className="w-4 h-4" />}
                             {(!res.matchType || res.matchType === 'EXACT') && <Zap className="w-4 h-4" />}
                          </div>
                          <div>
                             <h4 className="text-sm font-bold text-white uppercase tracking-wider">{res.matchType || 'EXACT'}</h4>
                             <p className="text-white/20 text-[10px] font-bold tracking-widest uppercase">Matching Strategy</p>
                          </div>
                       </div>
                        <div className="flex gap-2">
                           <button 
                             onClick={() => {
                               setFormData({
                                 trigger: res.trigger,
                                 response: res.response,
                                 channelId: res.channelId || '',
                                 matchType: res.matchType || 'EXACT'
                               });
                               setEditingId(res.id);
                               setShowModal(true);
                             }}
                             className="p-2.5 text-white/5 hover:text-white/40 hover:bg-white/5 rounded-xl transition-all"
                           >
                              <Settings2 className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={() => handleDelete(res.id)}
                             className="p-2.5 text-white/5 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                           >
                              <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                    </div>

                     <div className="space-y-6 relative z-10">
                        <div className="space-y-2">
                           <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Trigger Manifest</span>
                           <div className="bg-white/5 px-5 py-3 rounded-xl border border-white/5">
                              <code className="text-sm font-bold text-white tracking-tight">{res.trigger}</code>
                           </div>
                        </div>

                        <div className="space-y-2">
                           <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Response Content</span>
                           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl relative group/resp">
                              <MarkdownDisplay 
                                 content={res.response} 
                                 className="text-[13px] text-white/40 font-medium leading-relaxed"
                              />
                           </div>
                        </div>
                     </div>
                 </motion.div>
               ))}
             </AnimatePresence>
           </motion.div>

           {filtered.length === 0 && (
             <motion.div variants={item} className="py-32 flex flex-col items-center justify-center gap-6 border-2 border-dashed border-white/5 rounded-[40px]">
                <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center text-white/10">
                   <Sparkles className="w-8 h-8" />
                </div>
                <div className="text-center">
                   <h3 className="text-sm font-bold text-white/20 uppercase tracking-[0.2em]">No responders found</h3>
                   <p className="text-[11px] text-white/10 font-bold uppercase tracking-widest mt-1">Adjust your filter or create a new trigger.</p>
                </div>
             </motion.div>
           )}
        </div>
        
        <div className="space-y-10">
          <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 p-6 rounded-3xl space-y-4">
             <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                   <MessageSquare className="w-4 h-4 text-emerald-400" />
                 </div>
                 <h3 className="text-sm font-bold text-white uppercase tracking-wider">Telemetrics</h3>
              </div>
              <div className="space-y-2">
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Total Rules</span>
                    <span className="text-white font-bold">{responders.length}</span>
                 </div>
                 <div className="flex justify-between text-[11px]">
                    <span className="text-white/40">Latency</span>
                    <span className="text-emerald-400 font-bold">~15ms</span>
                 </div>
              </div>
           </div>

           <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl space-y-4">
              <h3 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Deployment Tip</h3>
              <p className="text-[11px] text-white/40 leading-relaxed">
                Use the "CONTAINS" match strategy for more flexible triggers that catch keywords within larger sentences.
              </p>
           </div>
        </div>
      </motion.div>

      {/* Create Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 md:p-12">
             <motion.div 
               initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
               onClick={() => {
                  setShowModal(false);
                  setEditingId(null);
                  setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
               }}
               className="absolute inset-0 bg-black/80 backdrop-blur-xl"
             />
             <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-[#0c0c0c] border border-white/10 rounded-[40px] w-full max-w-xl overflow-visible relative shadow-2xl"
             >
                <div className="flex justify-between items-center px-12 py-10 border-b border-white/5">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5">
                         {editingId ? <Settings2 className="w-6 h-6 text-white/60" /> : <Plus className="w-6 h-6 text-white/60" />}
                      </div>
                      <div>
                         <h2 className="text-xl font-bold text-white tracking-tight uppercase tracking-[0.2em]">{editingId ? 'Edit Manifest' : 'New Manifest'}</h2>
                         <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Update automation logic</p>
                      </div>
                   </div>
                   <button 
                     onClick={() => {
                        setShowModal(false);
                        setEditingId(null);
                        setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
                     }}
                     className="p-2 hover:bg-white/5 rounded-xl transition-all text-white/20 hover:text-white/60"
                   >
                      <X className="w-5 h-5" />
                   </button>
                </div>

                <div className="p-10 space-y-8">
                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Trigger Expression</label>
                      <div className="relative">
                         <Zap className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                         <input 
                           value={formData.trigger}
                           onChange={e => setFormData({...formData, trigger: e.target.value})}
                           placeholder="e.g. !help, rules..."
                           className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-sm text-white outline-none focus:border-white/10 transition-all font-medium"
                         />
                      </div>
                   </div>

                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex justify-between items-center">
                         Response Payload
                         <span className="text-[8px] opacity-40 font-black">Markdown Active</span>
                      </label>
                      <textarea 
                        value={formData.response}
                        onChange={e => setFormData({...formData, response: e.target.value})}
                        rows={4}
                        placeholder="What should the bot say in return?"
                        className="w-full bg-white/5 border border-white/5 rounded-3xl p-6 text-sm text-white outline-none focus:border-white/10 transition-all resize-none font-medium leading-relaxed"
                      />
                   </div>

                   <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                         <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest text-center block">Logic Type</label>
                         <div className="grid grid-cols-3 gap-2">
                            {[
                              { id: 'EXACT', icon: Zap, label: 'Exact' },
                              { id: 'CONTAINS', icon: Globe, label: 'Inside' },
                              { id: 'MENTION', icon: User, label: 'Ping' }
                            ].map(type => (
                              <button
                                key={type.id}
                                onClick={() => setFormData({ ...formData, matchType: type.id })}
                                className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                                  formData.matchType === type.id 
                                    ? 'bg-white/10 border-white/20 text-white' 
                                    : 'bg-transparent border-white/5 text-white/20 hover:border-white/10'
                                }`}
                              >
                                 <type.icon className="w-4 h-4" />
                                 <span className="text-[9px] font-bold uppercase tracking-tighter">{type.label}</span>
                              </button>
                            ))}
                         </div>
                      </div>

                      <div className="space-y-4">
                         <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest text-center block">Channel Scope</label>
                         <CustomSelect
                           options={channels}
                           value={formData.channelId}
                           onChange={(val) => setFormData({ ...formData, channelId: val })}
                           placeholder="Global (All)"
                         />
                      </div>
                   </div>

                   <button 
                     onClick={handleSave}
                     disabled={loading}
                     className="w-full bg-white text-black font-bold py-5 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:hover:scale-100 uppercase tracking-[0.3em] text-[11px]"
                   >
                      {loading ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          {editingId ? 'Save Changes' : 'Deploy Protocol'}
                        </>
                      )}
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
