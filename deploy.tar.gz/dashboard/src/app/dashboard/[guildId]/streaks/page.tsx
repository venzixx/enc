"use client";

import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { Activity, Plus, Trash2, ShieldAlert } from "lucide-react";

interface StreakTier {
  id: number;
  name: string;
  threshold: number;
}

export default function StreaksPage() {
  const { guildId } = useParams();
  const [tiers, setTiers] = useState<StreakTier[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [newName, setNewName] = useState("");
  const [newThreshold, setNewThreshold] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchTiers();
  }, [guildId]);

  const fetchTiers = async () => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`);
      if (res.ok) {
        const data = await res.json();
        setTiers(data);
      }
    } catch (error) {
      console.error(error);
      alert("Failed to load streak tiers");
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    if (!newName || !newThreshold) return;
    setCreating(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName, threshold: parseInt(newThreshold) }),
      });
      if (res.ok) {
        alert("Streak tier created!");
        setNewName("");
        setNewThreshold("");
        fetchTiers();
      } else {
        const text = await res.text();
        alert(text || "Failed to create tier");
      }
    } catch (error) {
      alert("An error occurred");
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      const res = await fetch(`/api/guild/${guildId}/streaktier?id=${id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        alert("Tier deleted");
        fetchTiers();
      } else {
        alert("Failed to delete tier");
      }
    } catch (error) {
      alert("An error occurred");
    }
  };

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-12">
      {/* ── HEADER ── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-500/20 flex items-center justify-center shadow-inner">
            <Activity className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight uppercase">Streak Engine</h1>
            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Activity thresholds and engagement monitoring.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-12">
        {/* ── ACTIVE TIERS (MAIN) ── */}
        <div className="xl:col-span-3 space-y-8">
          <div className="flex items-center gap-3 px-1">
             <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]" />
             <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Operational Tiers</h2>
          </div>
          
          <div className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 md:p-10 shadow-inner min-h-[400px]">
            {loading ? (
              <div className="text-white/20 text-[10px] font-black uppercase tracking-[0.2em] py-20 text-center">Synchronizing Data...</div>
            ) : tiers.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-24 px-4 text-center">
                <Activity className="w-12 h-12 text-white/5 mb-6" />
                <h3 className="text-white font-black uppercase tracking-widest text-sm mb-2">No Active Tiers</h3>
                <p className="text-white/10 text-[10px] font-bold uppercase tracking-[0.2em] max-w-xs">Initialize a streak protocol to begin engagement tracking.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tiers.map((tier) => (
                  <div key={tier.id} className="flex items-center justify-between p-8 rounded-[32px] bg-white/[0.01] border border-white/5 hover:bg-white/[0.02] hover:border-white/10 transition-all group shadow-inner">
                    <div className="flex items-center gap-6">
                      <div className="w-14 h-14 rounded-2xl bg-orange-500/5 flex items-center justify-center border border-orange-500/10 shadow-inner group-hover:scale-110 transition-transform duration-500">
                        <Activity className="w-6 h-6 text-orange-400/40" />
                      </div>
                      <div>
                        <div className="text-white font-black uppercase tracking-tight text-lg">{tier.name}</div>
                        <div className="text-white/20 text-[10px] font-black uppercase tracking-widest mt-1">{tier.threshold} MSG / DAY THRESHOLD</div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(tier.id)}
                      className="p-4 hover:bg-red-500/10 rounded-2xl text-white/10 hover:text-red-400 transition-all shadow-xl"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── CONTROLS (SIDEBAR) ── */}
        <div className="xl:col-span-1 space-y-8">
          <div className="space-y-8">
            <div className="flex items-center gap-3 px-1">
               <Plus className="w-4 h-4 text-white/20" />
               <h2 className="text-[11px] font-black text-white uppercase tracking-[0.3em]">Tier Creation</h2>
            </div>
            
            <div className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 shadow-inner space-y-8">
              <div className="space-y-4">
                <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Protocol Identifier</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. BRONZE_CORE"
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl px-6 py-4 text-[11px] font-black text-white placeholder-white/5 focus:outline-none focus:border-orange-500/30 transition-all uppercase tracking-widest shadow-inner"
                />
              </div>

              <div className="space-y-4">
                <label className="text-[9px] font-black text-white/20 uppercase tracking-[0.3em] pl-1">Daily Threshold</label>
                <input
                  type="number"
                  min="1"
                  value={newThreshold}
                  onChange={(e) => setNewThreshold(e.target.value)}
                  placeholder="0"
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl px-6 py-4 text-[11px] font-black text-white placeholder-white/5 focus:outline-none focus:border-orange-500/30 transition-all uppercase tracking-widest shadow-inner"
                />
              </div>

              <button
                onClick={handleCreate}
                disabled={creating || !newName || !newThreshold}
                className="w-full bg-white text-black font-black rounded-2xl py-5 text-[10px] uppercase tracking-[0.4em] hover:bg-zinc-200 transition-all disabled:opacity-20 disabled:cursor-not-allowed shadow-xl flex items-center justify-center gap-3"
              >
                {creating ? "Deploying..." : (
                  <>
                    Initialize Tier
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="bg-orange-500/5 border border-orange-500/10 rounded-[32px] p-8 shadow-inner">
            <div className="flex gap-5">
              <ShieldAlert className="w-6 h-6 text-orange-400 shrink-0" />
              <div>
                <h3 className="text-orange-400 font-black text-[10px] uppercase tracking-[0.2em] mb-2">Neural Mechanics</h3>
                <p className="text-orange-400/40 text-[9px] font-bold uppercase tracking-widest leading-relaxed">
                  Tiers are stackable. Users maintain streaks by sending required messages daily. Missed thresholds reset the specific protocol.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
