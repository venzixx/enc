import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

import Navbar from "@/components/Navbar";
import Starfield from "@/components/Starfield";
import Sidebar from "@/components/Sidebar";
import PageTransition from "@/components/PageTransition";

export default async function DashboardLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ guildId: string }>;
}) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden">
      <div className="fixed inset-0 z-0">
        <Starfield />
      </div>

      <Navbar />

      <div className="relative z-10 grid grid-cols-[auto_1fr] min-h-screen pt-16 w-full">
        <div className="hidden xl:block w-64 h-full shrink-0">
          <Sidebar />
        </div>
        <main className="min-w-0 w-full overflow-x-hidden">
          <PageTransition>
            {children}
          </PageTransition>
        </main>
      </div>
    </div>
  );
}
