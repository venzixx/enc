'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  BarChart3, Plus, Trash2, Send, Activity, Sparkles, ArrowUpRight, Hash, Type, ListTree, Archive,
  Settings2, Clock, CheckSquare, Check, Calendar, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function PollsPage() {
  const { guildId } = useParams();
  const [question, setQuestion] = useState('Should we organize a community event next week?');
  const [options, setOptions] = useState(['Yes, count me in', 'Maybe later', 'No, I am busy']);
  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  const [selectedChannel, setSelectedChannel] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });
  
  // Native Poll Features
  const [allowMultiselect, setAllowMultiselect] = useState(false);
  const [duration, setDuration] = useState(24); // hours

  useEffect(() => {
    if (!guildId) return;
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data))
      .catch(console.error);
  }, [guildId]);

  const addOption = () => {
    if (options.length < 10) setOptions([...options, `Option ${options.length + 1}`]);
  };

  const removeOption = (idx: number) => {
    if (options.length > 2) {
      const newOpts = [...options];
      newOpts.splice(idx, 1);
      setOptions(newOpts);
    }
  };

  const updateOption = (idx: number, val: string) => {
    const newOpts = [...options];
    newOpts[idx] = val;
    setOptions(newOpts);
  };

  const handleDispatch = async () => {
    if (!selectedChannel || !question || options.length < 2) return;
    setIsSending(true);
    setStatusMsg({ text: 'Creating native poll...', type: 'info' });
    
    try {
      const payload = {
        poll: {
          question: { text: question },
          answers: options.filter(opt => opt.trim().length > 0).map(opt => ({
            poll_media: { text: opt }
          })),
          allow_multiselect: allowMultiselect,
          duration: duration,
          layout_type: 1
        }
      };

      const res = await fetch(`/api/guild/${guildId}/dispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          channelId: selectedChannel,
          payload
        })
      });

      if (res.ok) {
        setStatusMsg({ text: 'Native poll successfully deployed.', type: 'success' });
        setTimeout(() => setStatusMsg({ text: '', type: '' }), 5000);
      } else {
        const errorData = await res.text();
        throw new Error(errorData || 'Failed to send');
      }
    } catch (err: any) {
      console.error(err);
      setStatusMsg({ text: `Error: ${err.message || 'Could not send poll.'}`, type: 'error' });
    } finally {
      setIsSending(false);
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Poll Engine</h1>
            <p className="text-white/50 text-sm mt-1">Deploy interactive voting protocols to your community.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           <div className="px-4 py-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-500 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> Analytics Active
           </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 xl:grid-cols-4 gap-8"
      >
        <div className="xl:col-span-3 space-y-8">
           {/* CONSTRUCTOR */}
           <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-8">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                    <Type className="w-4 h-4 text-white/60" />
                 </div>
                 <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">Poll Manifest</h3>
                    <p className="text-white/20 text-[10px] font-bold uppercase tracking-widest mt-0.5">Primary Question Content</p>
                 </div>
              </div>
              <textarea 
                 rows={3}
                 value={question}
                 onChange={(e) => setQuestion(e.target.value)}
                 className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white font-medium text-[15px] outline-none focus:border-white/10 transition-all resize-none leading-relaxed"
                 placeholder="Enter your question here..."
              />
           </motion.section>

           <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-8">
              <div className="flex items-center justify-between gap-4">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                       <ListTree className="w-4 h-4 text-white/60" />
                    </div>
                    <div>
                       <h3 className="text-sm font-bold text-white uppercase tracking-wider">Answer Nodes</h3>
                       <p className="text-white/20 text-[10px] font-bold uppercase tracking-widest mt-0.5">Define choice matrix</p>
                    </div>
                 </div>
                 <button onClick={addOption} className="text-[10px] font-bold text-white hover:text-white/60 transition-all uppercase tracking-widest bg-white/5 px-5 py-2.5 rounded-xl border border-white/5">Add Choice</button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                 {options.map((opt, i) => (
                    <motion.div layout key={i} className="flex items-center gap-4 bg-white/[0.02] border border-white/5 p-4 rounded-2xl group transition-all hover:border-white/10">
                       <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[11px] font-bold text-white/20">{i+1}</div>
                       <input 
                          value={opt}
                          onChange={(e) => updateOption(i, e.target.value)}
                          className="flex-1 bg-transparent border-none outline-none text-[14px] text-white/60 focus:text-white transition-colors font-medium"
                       />
                       <button onClick={() => removeOption(i)} className="text-white/10 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 p-2"><Trash2 className="w-4 h-4" /></button>
                    </motion.div>
                 ))}
              </div>
           </motion.section>

           <motion.section variants={item} className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-8">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                    <Settings2 className="w-4 h-4 text-white/60" />
                 </div>
                 <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">Protocol Logic</h3>
                    <p className="text-white/20 text-[10px] font-bold uppercase tracking-widest mt-0.5">Interaction Parameters</p>
                 </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="space-y-4">
                    <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-2">
                       <Clock className="w-4 h-4" /> Persistence Duration
                    </label>
                    <SurgicalDropdown 
                      options={[
                        { id: '1', name: '1 Hour' },
                        { id: '4', name: '4 Hours' },
                        { id: '8', name: '8 Hours' },
                        { id: '24', name: '24 Hours' },
                        { id: '72', name: '3 Days' },
                        { id: '168', name: '1 Week' }
                      ]}
                      value={duration.toString()}
                      onChange={(val) => setDuration(parseInt(val))}
                      placeholder="Select duration"
                    />
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-2">
                       <CheckSquare className="w-4 h-4" /> Multi-Select
                    </label>
                    <button 
                      onClick={() => setAllowMultiselect(!allowMultiselect)}
                      className={`w-full flex items-center justify-between p-4.5 rounded-2xl border transition-all duration-300 ${allowMultiselect ? 'bg-indigo-500/10 border-indigo-500/20 text-white' : 'bg-transparent border-white/5 text-white/30'}`}
                    >
                       <span className="text-[11px] font-bold uppercase tracking-widest pl-2">Enable multiple choices</span>
                       <div className={`w-10 h-5 rounded-full relative transition-colors ${allowMultiselect ? 'bg-indigo-500' : 'bg-white/10'}`}>
                          <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${allowMultiselect ? 'left-6 bg-white' : 'left-1 bg-white/20'}`} />
                       </div>
                    </button>
                 </div>
              </div>
           </motion.section>
        </div>
        
        <div className="space-y-10">
           <motion.section variants={item} className="bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border border-indigo-500/10 p-8 rounded-[32px] space-y-6">
              <SurgicalDropdown 
                label="Target Core"
                options={channels}
                value={selectedChannel}
                onChange={setSelectedChannel}
                placeholder="Select channel..."
              />
              
              <button 
                onClick={handleDispatch}
                disabled={!selectedChannel || isSending}
                className={`w-full py-5 rounded-2xl flex items-center justify-center gap-3 text-[11px] font-bold uppercase tracking-[0.2em] transition-all shadow-xl ${selectedChannel ? 'bg-white text-black hover:bg-zinc-200' : 'bg-white/5 text-white/10 border border-white/5 cursor-not-allowed'}`}
              >
                 {isSending ? <Sparkles className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                 {isSending ? "Syncing..." : "Initiate Poll"}
              </button>

              <AnimatePresence>
                 {statusMsg.text && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`text-[10px] font-bold uppercase tracking-widest text-center ${statusMsg.type === 'error' ? 'text-red-500' : statusMsg.type === 'success' ? 'text-emerald-500' : 'text-indigo-400'}`}
                    >
                       {statusMsg.text}
                    </motion.div>
                 )}
              </AnimatePresence>
           </motion.section>

           <motion.div variants={item} className="space-y-4">
              <div className="flex items-center gap-3 px-2">
                 <Archive className="w-4 h-4 text-white/20" />
                 <span className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Holographic Preview</span>
              </div>

              <div className="bg-[#08090a] rounded-[32px] p-8 border border-white/5 shadow-2xl">
                 <div className="space-y-6">
                    <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 border border-white/10 flex items-center justify-center text-[10px] font-black text-white/60">ENC</div>
                       <div className="flex items-center gap-2">
                          <span className="font-bold text-white/90 text-[13px]">Enc Nexus</span>
                          <span className="bg-[#5865F2] text-[8px] px-1.5 py-0.5 rounded-sm text-white font-bold">BOT</span>
                       </div>
                    </div>

                    <div className="bg-[#1e1f22] rounded-[20px] border border-white/[0.03] p-6 space-y-5">
                       <div className="flex items-start gap-3">
                          <BarChart3 className="w-5 h-5 text-zinc-500 mt-1" />
                          <div className="space-y-1">
                             <h4 className="text-white font-bold text-[14px] leading-tight">{question}</h4>
                             <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">
                                {allowMultiselect ? "Select one or more options" : "Select one option"}
                             </p>
                          </div>
                       </div>

                       <div className="space-y-2.5">
                          {options.filter(o => o.trim()).slice(0, 3).map((opt, i) => (
                             <div key={i} className="rounded-lg border border-white/[0.05] bg-white/[0.02] p-3.5 flex items-center justify-between">
                                <span className="text-[12px] text-zinc-300 font-medium">{opt}</span>
                                <div className="w-4 h-4 rounded-full border border-white/10" />
                             </div>
                          ))}
                          {options.filter(o => o.trim()).length > 3 && (
                             <div className="text-[10px] text-zinc-600 font-bold uppercase text-center py-1">+{options.filter(o => o.trim()).length - 3} more options</div>
                          )}
                       </div>

                       <div className="flex items-center justify-between pt-2 border-t border-white/[0.03]">
                          <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">{duration >= 24 ? `${duration/24}d` : `${duration}h`} left</span>
                          <div className="flex items-center gap-1.5 text-[#5865F2] text-[10px] font-black uppercase tracking-widest">
                             Vote <ChevronRight className="w-3.5 h-3.5" />
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
