# 📐 ENC NEXUS: Sovereign Console

> **Clinical Administrative Suite for the Enc Nexus Ecosystem.**

The Sovereign Console is a high-fidelity governance interface built on **Next.js 16**, designed to provide real-time control over the Vanguard Bot Engine. It adheres to the **Surgical Obsidian** design philosophy, offering a near-zero latency administrative experience.

---

## 🛰️ Core Protocols

### 1. High-Fidelity Governance
- **Real-time Telemetry**: Pulse-monitored server statistics and bot health.
- **Sovereign Settings**: Clinical control over Anti-Nuke, AutoMod, and AI personality cores.
- **Master Codex**: Exhaustive, interactive documentation of all 81+ functional protocols.

### 2. Surgical Design System
- **Obsidian Palette**: Deep Navy-Black transitions with high-intensity spectral accents.
- **Glassmorphism**: 11px radius glass panels with cursor-responsive spotlight engines.
- **Animation**: Procedural ripple depth and alpha-mask transitions powered by Framer Motion.

### 3. Identity & Security
- **OAuth2 Gateway**: Secure Discord authentication with identity matrix injection.
- **Permission Scaling**: Conditional access based on server ownership and administrator clearance.
- **Database Bridge**: Shared Prisma (SQLite) schema for 1:1 synchronization with the bot engine.

---

## 🌑 Initialization Protocol

1. **Synchronize Environment**:
   ```env
   DISCORD_CLIENT_ID="YOUR_ID"
   DISCORD_CLIENT_SECRET="YOUR_SECRET"
   DATABASE_URL="file:../../prisma/dev.db"
   ```
2. **Deploy Dependencies**:
   ```bash
   npm install
   ```
3. **Initialize Console**:
   ```bash
   npm run dev
   ```

---

## 📐 Compliance
- **Division**: Sovereign Console (Nexus Division)
- **Engine**: Next.js 16 (Turbopack)
- **Design**: Surgical Obsidian
- **Status**: Boardroom-Ready
