"use client";

import React, { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";

interface BotStats {
  guilds: number;
  users: number;
  latency: number;
  commands: number;
}

interface Stat {
  value: number;
  label: string;
  suffix?: string;
  icon?: string;
}

function CounterStat({
  value,
  label,
  suffix,
  index,
}: {
  value: number;
  label: string;
  suffix?: string;
  index: number;
}) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    let start = 0;
    const increment = value / 60;
    const timer = setInterval(() => {
      start += increment;
      if (start >= value) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(start));
      }
    }, 30);

    return () => clearInterval(timer);
  }, [isInView, value]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + "k";
    } else if (num >= 100) {
      return num.toFixed(0);
    }
    return num.toString();
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.05 }}
      viewport={{ once: true }}
      className="flex flex-col items-center gap-1 group"
    >
      <div className="text-4xl md:text-5xl font-bold tracking-tight text-white/90 group-hover:text-white transition-colors">
        {formatNumber(displayValue)}
        {suffix && <span className="text-2xl opacity-50 ml-0.5">{suffix}</span>}
      </div>
      <div className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">
        {label}
      </div>
    </motion.div>
  );
}

export default function StatsSection() {
  const [stats, setStats] = useState<BotStats>({
    guilds: 0,
    users: 0,
    latency: 0,
    commands: 81,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("/api/bot-stats", { cache: "no-store" });
        if (response.ok) {
          const data = await response.json();
          setStats({
            guilds: data.guilds || 0,
            users: data.users || 0,
            latency: data.latency || 0,
            commands: data.commands || 81,
          });
        }
      } catch (error) {
        console.error("Failed to fetch bot stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const displayStats: Stat[] = [
    { value: stats.guilds, label: "Servers" },
    { value: stats.users, label: "Users" },
    { value: stats.commands, label: "Commands" },
    { value: stats.latency, label: "Latency", suffix: "ms" },
  ];

  return (
    <section className="py-20 border-y border-white/[0.02] relative">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
        {displayStats.map((stat, idx) => (
          <CounterStat
            key={idx}
            label={stat.label}
            value={stat.value}
            suffix={stat.suffix}
            index={idx}
          />
        ))}
      </div>
    </section>
  );
}
