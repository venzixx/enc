"use client";

import React from 'react';
import {
  LayoutDashboard, ShieldCheck, Activity, Settings,
  Zap, Lock, Shield, MessageSquare, BarChart3, ListTree, Ticket, Sparkles, ShieldAlert
} from "lucide-react";
import SidebarItem from "./SidebarItem";
import { useParams, usePathname } from "next/navigation";

export default function Sidebar() {
  const { guildId } = useParams();
  const pathname = usePathname();
  const [guildInfo, setGuildInfo] = React.useState<{ name: string; icon: string | null } | null>(null);

  React.useEffect(() => {
    if (guildId) {
      fetch(`/api/guild/${guildId}/config`)
        .then(r => r.ok ? r.json() : null)
        .then(data => {
          if (data) setGuildInfo({ name: data.name, icon: data.icon });
        });
    }
  }, [guildId]);

  return (
    <aside className="w-64 border-r border-white/5 p-8 hidden xl:flex flex-col gap-10 bg-[#050510]/30 backdrop-blur-3xl h-screen fixed left-0 top-0 z-50">
      <div className="flex flex-col gap-2">
        <div className="text-[10px] font-bold text-white/20 tracking-[0.3em] uppercase mb-1">Menu</div>
        <div className="h-px w-6 bg-white/10" />
      </div>

      <nav className="flex flex-col gap-1 overflow-y-auto pr-2 scrollbar-hide">
        <SidebarItem
          icon={<LayoutDashboard className="w-4 h-4" />}
          label="Overview"
          href={`/dashboard/${guildId}`}
          active={pathname === `/dashboard/${guildId}`}
        />
        <SidebarItem
          icon={<Shield className="w-4 h-4" />}
          label="Security"
          href={`/dashboard/${guildId}/security`}
          active={pathname?.includes('/security')}
        />
        <SidebarItem
          icon={<Zap className="w-4 h-4" />}
          label="Auto Mod"
          href={`/dashboard/${guildId}/automod`}
          active={pathname?.includes('/automod')}
        />
        <SidebarItem
          icon={<Lock className="w-4 h-4" />}
          label="Permissions"
          href={`/dashboard/${guildId}/permits`}
          active={pathname?.includes('/permits')}
        />
        <SidebarItem
          icon={<Zap className="w-4 h-4" />}
          label="Role Connections"
          href={`/dashboard/${guildId}/roleconnections`}
          active={pathname?.includes('/roleconnections')}
        />
        <SidebarItem
          icon={<MessageSquare className="w-4 h-4" />}
          label="Messages"
          href={`/dashboard/${guildId}/messages`}
          active={pathname === `/dashboard/${guildId}/messages`}
        />
        <SidebarItem
          icon={<Sparkles className="w-4 h-4" />}
          label="Autoresponder"
          href={`/dashboard/${guildId}/autoresponder`}
          active={pathname?.includes('/autoresponder')}
        />
        <SidebarItem
          icon={<BarChart3 className="w-4 h-4" />}
          label="Polls"
          href={`/dashboard/${guildId}/polls`}
          active={pathname?.includes('/polls')}
        />
        <SidebarItem
          icon={<Ticket className="w-4 h-4" />}
          label="Tickets"
          href={`/dashboard/${guildId}/tickets`}
          active={pathname?.includes('/tickets')}
        />
        <SidebarItem
          icon={<Activity className="w-4 h-4" />}
          label="Audit Logs"
          href={`/dashboard/${guildId}/logs`}
          active={pathname?.includes('/logs')}
        />
        <SidebarItem
          icon={<ListTree className="w-4 h-4" />}
          label="Progression"
          href={`/dashboard/${guildId}/levels`}
          active={pathname?.includes('/levels')}
        />
        <SidebarItem
          icon={<Zap className="w-4 h-4" />}
          label="Branding"
          href={`/dashboard/${guildId}/branding`}
          active={pathname?.includes('/branding')}
        />
        <SidebarItem
          icon={<Settings className="w-4 h-4" />}
          label="Settings"
          href={`/dashboard/${guildId}/settings`}
          active={pathname?.includes('/settings')}
        />
        <SidebarItem
          icon={<ShieldAlert className="w-4 h-4" />}
          label="Appeals"
          href={`/dashboard/${guildId}/appeals`}
          active={pathname?.includes('/appeals')}
        />
      </nav>

      <div className="mt-auto bg-white/[0.01] border border-white/5 p-5 rounded-2xl group relative overflow-hidden transition-all hover:border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/5 overflow-hidden flex items-center justify-center shrink-0">
            {guildInfo?.icon ? (
              <img src={guildInfo.icon} alt="Icon" className="w-full h-full object-cover" />
            ) : (
              <Shield className="w-4 h-4 text-white/20" />
            )}
          </div>
          <div className="flex flex-col min-w-0">
            <div className="text-[9px] font-bold text-white/15 uppercase tracking-[0.2em] mb-0.5">Server</div>
            <div className="text-[11px] font-bold text-white/80 truncate tracking-tight uppercase">
              {guildInfo?.name || "Loading..."}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
