"use client";

import React, { useState } from 'react';
import { 
  ShieldAlert, Send, Loader2, 
  CheckCircle2, Info, MessageSquare
} from 'lucide-react';
import { motion } from 'framer-motion';

interface AppealSubmissionProps {
  guildId: string;
  guildName: string;
}

export default function AppealSubmission({ guildId, guildName }: AppealSubmissionProps) {
  const [type, setType] = useState<'BAN' | 'KICK' | 'MUTE'>('BAN');
  const [appealReason, setAppealReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!appealReason) return;

    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/appeals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          reason: "Manual submission from dashboard",
          appealReason
        })
      });

      if (res.ok) {
        setSubmitted(true);
      }
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  if (submitted) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto py-20 px-10 text-center space-y-8 bg-white/[0.01] border border-white/5 rounded-[48px] backdrop-blur-xl"
      >
        <div className="w-24 h-24 bg-emerald-500/10 border border-emerald-500/20 rounded-[32px] flex items-center justify-center mx-auto mb-8">
           <CheckCircle2 className="w-10 h-10 text-emerald-500" />
        </div>
        <div className="space-y-4">
           <h2 className="text-2xl font-bold text-white tracking-tight">Appeal Submitted</h2>
           <p className="text-white/40 text-sm leading-relaxed max-w-md mx-auto">
             Your appeal for **{guildName}** has been successfully recorded. Staff will review it and you will be notified via Direct Message on Discord once a decision is made.
           </p>
        </div>
        <button 
          onClick={() => window.location.reload()}
          className="bg-white/5 border border-white/10 px-8 py-4 rounded-2xl text-[10px] font-bold text-white/60 uppercase tracking-widest hover:bg-white/10 transition-all"
        >
          Submit Another Appeal
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-1000 pb-20">
      
      {/* ── HEADER ── */}
      <section className="text-center space-y-4">
         <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/[0.02] border border-white/5 rounded-full mb-4">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            <span className="text-[9px] font-bold text-white/40 uppercase tracking-[0.2em]">Sanction Review System</span>
         </div>
         <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">Submit Appeal</h1>
         <p className="text-white/20 text-[11px] font-bold uppercase tracking-[0.4em]">Server: {guildName}</p>
      </section>

      {/* ── FORM ── */}
      <section className="bg-white/[0.01] border border-white/5 p-12 rounded-[56px] backdrop-blur-xl space-y-12 relative overflow-hidden group hover:border-white/10 transition-all">
         <div className="absolute top-0 right-0 w-96 h-96 bg-white/[0.02] blur-[100px] -mr-48 -mt-48 rounded-full" />
         
         <div className="space-y-6">
            <div className="flex items-center gap-3">
               <ShieldAlert className="w-4 h-4 text-white/20" />
               <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-[0.3em]">Select Sanction Type</h3>
            </div>
            <div className="grid grid-cols-3 gap-4">
               {['BAN', 'KICK', 'MUTE'].map(t => (
                 <button
                   key={t}
                   onClick={() => setType(t as any)}
                   className={`p-6 rounded-3xl border transition-all text-center space-y-2 ${
                     type === t 
                      ? 'bg-white text-black border-white' 
                      : 'bg-white/[0.02] border-white/5 text-white/20 hover:border-white/10 hover:text-white/40'
                   }`}
                 >
                    <span className="text-xs font-black uppercase tracking-widest">{t}</span>
                 </button>
               ))}
            </div>
         </div>

         <div className="space-y-6">
            <div className="flex items-center gap-3">
               <MessageSquare className="w-4 h-4 text-white/20" />
               <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-[0.3em]">Your Justification</h3>
            </div>
            <div className="relative">
               <textarea 
                 placeholder="Explain why your sanction should be reviewed. Be honest and detailed..."
                 className="w-full bg-white/[0.02] border border-white/5 p-8 rounded-[32px] text-sm text-white/80 outline-none focus:bg-white/[0.04] focus:border-white/10 transition-all min-h-[250px] resize-none leading-relaxed"
                 value={appealReason}
                 onChange={(e) => setAppealReason(e.target.value)}
               />
               <div className="absolute bottom-6 right-8 flex items-center gap-2 text-white/10">
                  <Info className="w-3 h-3" />
                  <span className="text-[8px] font-bold uppercase tracking-widest">Provide as much detail as possible</span>
               </div>
            </div>
         </div>

         <div className="p-8 bg-white/[0.02] border border-white/5 rounded-[32px] space-y-4">
            <h4 className="text-[10px] font-bold text-white/60 uppercase tracking-[0.2em]">Appeal Guidelines</h4>
            <ul className="space-y-2">
               {[
                 "Explain what happened clearly.",
                 "Acknowledge any mistakes made if applicable.",
                 "Staff decisions are final once reviewed.",
                 "Spamming appeals may result in a blacklist."
               ].map((g, i) => (
                 <li key={i} className="flex items-start gap-3">
                    <div className="w-1 h-1 rounded-full bg-white/20 mt-1.5" />
                    <p className="text-[10px] text-white/40 font-medium">{g}</p>
                 </li>
               ))}
            </ul>
         </div>

         <button 
           onClick={handleSubmit}
           disabled={loading || !appealReason}
           className="w-full bg-white text-black py-8 rounded-[32px] flex items-center justify-center gap-4 group/btn hover:bg-zinc-200 transition-all active:scale-[0.99] disabled:opacity-20"
         >
            <span className="text-xs font-black uppercase tracking-[0.4em]">Dispatch Appeal</span>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 transition-transform group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1" />}
         </button>
      </section>
    </div>
  );
}
