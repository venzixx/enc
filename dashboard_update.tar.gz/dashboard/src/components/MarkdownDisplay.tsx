"use client";

import React from "react";

interface MarkdownDisplayProps {
  content: string;
  className?: string;
}

export default function MarkdownDisplay({ content, className = "" }: MarkdownDisplayProps) {
  if (!content) return null;

  // Simple parser for Discord-like markdown
  const parseContent = (text: string) => {
    // Escape HTML first to prevent XSS
    let safeText = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

    // Replace Code Blocks (```code```)
    safeText = safeText.replace(/```([\s\S]+?)```/g, '<pre class="bg-black/40 p-4 rounded-xl font-mono text-xs my-2 border border-white/5 overflow-x-auto text-white/80">$1</pre>');

    // Replace Inline Code (`code`)
    safeText = safeText.replace(/`([^`]+)`/g, '<code class="bg-white/10 px-1.5 py-0.5 rounded font-mono text-[0.9em] text-[#9333ea]">$1</code>');

    // Replace Bold (**bold**)
    safeText = safeText.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-black text-white/90">$1</strong>');

    // Replace Italic (*italic*)
    safeText = safeText.replace(/\*([^*]+)\*/g, '<em class="italic text-white/60">$1</em>');

    // Replace Mentions (<@ID> or <#ID>)
    safeText = safeText.replace(/&lt;@!?(\d+)&gt;/g, '<span class="bg-[#5865F2]/20 text-[#5865F2] px-1 rounded hover:bg-[#5865F2] hover:text-white transition-colors cursor-default font-medium">@user</span>');
    safeText = safeText.replace(/&lt;#(\d+)&gt;/g, '<span class="bg-[#5865F2]/20 text-[#5865F2] px-1 rounded hover:bg-[#5865F2] hover:text-white transition-colors cursor-default font-medium">#channel</span>');

    // Strikethrough (~~text~~)
    safeText = safeText.replace(/~~([^~]+)~~/g, '<del class="opacity-40 line-through">$1</del>');

    // Spoiler (||text||)
    safeText = safeText.replace(/\|\|([^|]+)\|\|/g, '<span class="bg-white/10 text-transparent hover:text-white/90 px-1 rounded transition-all cursor-pointer select-none group-hover:text-white/90">$1</span>');

    // Handle Newlines
    safeText = safeText.replace(/\n/g, '<br />');

    return safeText;
  };

  return (
    <div 
      className={`markdown-content ${className}`}
      dangerouslySetInnerHTML={{ __html: parseContent(content) }}
    />
  );
}
