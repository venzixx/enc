"use client";

import React from "react";
import { motion } from "framer-motion";
import {
  Zap,
  Shield,
  Infinity,
  Smartphone,
  Cloud,
  Lock,
  Sparkles,
  Gauge,
} from "lucide-react";

interface QuickFeature {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const quickFeatures: QuickFeature[] = [
  {
    icon: <Zap className="w-5 h-5" />,
    title: "Fast Responses",
    description: "Built for speed and reliability",
  },
  {
    icon: <Shield className="w-5 h-5" />,
    title: "Secure Controls",
    description: "Advanced protection for your server",
  },
  {
    icon: <Infinity className="w-5 h-5" />,
    title: "99.9% Uptime",
    description: "Reliable infrastructure you can trust",
  },
  {
    icon: <Smartphone className="w-5 h-5" />,
    title: "Mobile Ready",
    description: "Full dashboard access on any device",
  },
  {
    icon: <Cloud className="w-5 h-5" />,
    title: "Cloud Performance",
    description: "Hosted on high-speed global nodes",
  },
  {
    icon: <Lock className="w-5 h-5" />,
    title: "Privacy Focused",
    description: "Your data is encrypted and secure",
  },
  {
    icon: <Sparkles className="w-5 h-5" />,
    title: "Smart Automation",
    description: "Effortless management through AI",
  },
  {
    icon: <Gauge className="w-5 h-5" />,
    title: "Live Analytics",
    description: "Monitor everything in real-time",
  },
];

export default function QuickFeatures() {
  return (
    <section className="py-24 px-6 md:px-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-3xl md:text-4xl font-bold uppercase tracking-tight mb-4 text-white">
            Core Features
          </h2>
          <p className="text-white/30 text-lg max-w-2xl mx-auto font-medium">
            Powerful tools designed for the next generation of communities.
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {quickFeatures.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              viewport={{ once: true, margin: "-50px" }}
              className="group"
            >
              <div className="bg-white/[0.02] border border-white/5 p-8 rounded-[24px] hover:border-white/10 transition-all duration-500 h-full flex flex-col gap-6 relative">
                 <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 group-hover:bg-white group-hover:text-black transition-all">
                   {feature.icon}
                 </div>
                 <div className="space-y-2">
                    <h3 className="font-bold text-lg text-white/80 group-hover:text-white transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-white/20 text-sm leading-relaxed font-medium">
                      {feature.description}
                    </p>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
