"use client";

import React from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Zap, Shield, Activity } from "lucide-react";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function Hero() {
  const headlineVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.2,
      },
    },
  };

  const letterVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  const headline = "ELEVATE YOUR SERVER";

  return (
    <section className="min-h-[90vh] flex flex-col items-center justify-center px-6 text-center relative overflow-hidden py-20 mt-10">
      {/* Decorative Aura - Simplified */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-b from-blue-500/5 via-blue-500/2 to-transparent rounded-full blur-[160px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-6xl relative z-10"
      >
        {/* Status Badge */}
        <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.03] border border-white/5 text-[10px] font-bold text-white/30 uppercase tracking-[0.25em] mb-10 shadow-inner">
          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
          Enc Nexus v3.44 is online
        </div>

        {/* Main Headline */}
        <div className="mb-10">
          <motion.div
            variants={headlineVariants}
            initial="hidden"
            animate="visible"
            className="text-7xl md:text-8xl lg:text-[120px] font-bold leading-[0.9] uppercase tracking-tighter font-sans"
          >
            {headline.split("").map((char, i) => (
              <motion.span
                key={i}
                variants={letterVariants}
                className={char === " " ? "inline-block w-8" : ""}
              >
                {char === " " ? "\u00A0" : char}
              </motion.span>
            ))}
          </motion.div>
        </div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="max-w-xl mx-auto text-lg md:text-xl text-white/40 font-medium leading-relaxed font-sans mb-10 tracking-tight"
        >
          The most powerful tool for server management. Experience complete control over your community with Enc Nexus.
        </motion.p>

        {/* Quick Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-wrap justify-center gap-8 mb-16 text-[11px] font-bold text-white/20 uppercase tracking-widest"
        >
          <div className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5" />
            Fast Responses
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5" />
            Premium Security
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5" />
            Live Monitoring
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button
            onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}
            className="px-10 py-5 bg-white text-black font-bold text-[11px] tracking-[0.2em] uppercase rounded-xl hover:bg-zinc-200 transition-all flex items-center gap-3 group"
          >
            Get Started
            <ArrowUpRight className="w-4 h-4 opacity-30" />
          </button>
          <Link
            href="/docs"
            className="px-10 py-5 bg-white/[0.03] border border-white/5 text-white font-bold text-[11px] tracking-[0.2em] uppercase rounded-xl hover:bg-white/5 hover:border-white/10 transition-all"
          >
            Documentation
          </Link>
        </motion.div>
      </motion.div>
    </section>
  );
}
