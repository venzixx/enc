"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus, HelpCircle } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqItems: FAQItem[] = [
  {
    question: "How do I get started?",
    answer: "You can invite the bot to your server using the invite link. Once added, log in to the dashboard to customize your settings and enable modules.",
  },
  {
    question: "Is the music quality good?",
    answer: "Yes, we provide high-quality audio streaming with low latency and stability, ensuring a great listening experience for your community.",
  },
  {
    question: "Are there any costs?",
    answer: "Our core features are free to use. We offer premium tiers for advanced features, increased limits, and additional customization options.",
  },
  {
    question: "How secure is my data?",
    answer: "We take security seriously. All server data and configurations are encrypted and stored securely to ensure your community's privacy.",
  },
  {
    question: "Is the dashboard mobile-friendly?",
    answer: "Absolutely. The dashboard is designed to be fully responsive, allowing you to manage your server from any device, anywhere.",
  },
];

function FAQAccordion({ item, isOpen, onClick }: { item: FAQItem; isOpen: boolean; onClick: () => void }) {
  return (
    <div className="mb-2">
      <button
        onClick={onClick}
        className={`w-full text-left p-6 md:p-8 rounded-[24px] border transition-all duration-300 flex items-start justify-between gap-4 group ${
          isOpen 
            ? "bg-white/[0.03] border-white/10" 
            : "bg-white/[0.01] border-white/5 hover:border-white/10"
        }`}
      >
        <span className={`font-bold text-lg md:text-xl tracking-tight transition-colors ${
          isOpen ? "text-white" : "text-white/40 group-hover:text-white/60"
        }`}>
          {item.question}
        </span>
        <div className={`mt-1 w-6 h-6 rounded-full flex items-center justify-center border transition-all ${
          isOpen ? "border-white bg-white text-black" : "border-white/10 text-white/20 group-hover:border-white/20"
        }`}>
          {isOpen ? <Minus className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
        </div>
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-8 pt-4 text-white/30 leading-relaxed text-sm font-medium">
              {item.answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 px-6 md:px-12 relative overflow-hidden">
      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold uppercase tracking-tight mb-4 text-white">
            Common Questions
          </h2>
          <p className="text-white/30 text-lg mx-auto font-medium">
            Everything you need to know about using our platform.
          </p>
        </motion.div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqItems.map((item, idx) => (
            <FAQAccordion
              key={idx}
              item={item}
              isOpen={openIndex === idx}
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
