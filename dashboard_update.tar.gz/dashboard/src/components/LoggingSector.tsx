"use client";

import React, { useState, useEffect, useCallback } from "react";
import { 
  MessageSquare, Hash, ShieldAlert, Users, 
  Gavel, ShieldCheck, RefreshCw, 
  Trash2, Terminal, Clock, User, 
  ArrowUpRight, AlertCircle, ChevronDown, Monitor
} from "lucide-react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import CustomSelect from "./CustomSelect";
import MarkdownDisplay from "./MarkdownDisplay";

interface LoggingSectorProps {
  guildId: string;
  initialData: any;
}

export default function LoggingSector({ guildId, initialData }: LoggingSectorProps) {
  const [guildData, setGuildData] = useState(initialData);
  const [logs, setLogs] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [isToggling, setIsToggling] = useState<string | null>(null);
  const [isClearing, setIsClearing] = useState(false);
  const router = useRouter();

  const categories = [
    { id: "Messages", title: "Messages", icon: <MessageSquare className="w-3.5 h-3.5" />, desc: "Edits & Deletes", dbField: "logMessagesEnabled", channelField: "logChannelMessages" },
    { id: "Channels", title: "Channels", icon: <Hash className="w-3.5 h-3.5" />, desc: "Channel Changes", dbField: "logChannelsEnabled", channelField: "logChannelChannels" },
    { id: "Roles", title: "Roles", icon: <ShieldAlert className="w-3.5 h-3.5" />, desc: "Permission Shifts", dbField: "logRolesEnabled", channelField: "logChannelRoles" },
    { id: "Members", title: "Members", icon: <Users className="w-3.5 h-3.5" />, desc: "Member Activity", dbField: "logMembersEnabled", channelField: "logChannelMembers" },
    { id: "Moderation", title: "Moderation", icon: <Gavel className="w-3.5 h-3.5" />, desc: "Mod Actions", dbField: "logModerationEnabled", channelField: "logChannelModeration" },
    { id: "Security", title: "Security", icon: <ShieldCheck className="w-3.5 h-3.5" />, desc: "Security Logs", dbField: "logSecurityEnabled", channelField: "logChannelSecurity" },
    { id: "Voice", title: "Voice", icon: <Monitor className="w-3.5 h-3.5" />, desc: "Voice Activity", dbField: "logVoiceEnabled", channelField: "logChannelVoice" },
  ];

  const fetchLogs = useCallback(async () => {
    try {
      const response = await fetch(`/api/guild/${guildId}/logs?limit=5`);
      if (response.ok) {
        const data = await response.json();
        setLogs(data.logs || []);
      }
    } catch (error) {
      console.error("Failed to fetch logs:", error);
    }
  }, [guildId]);

  const fetchChannels = useCallback(async () => {
    try {
      const response = await fetch(`/api/guild/${guildId}/channels`);
      if (response.ok) {
        const data = await response.json();
        const channelList = Array.isArray(data) ? data : (data.channels || []);
        // Just take the channels as returned by the API (which are already filtered for Text/News/Voice)
        setChannels(channelList);
      }
    } catch (error) {
      console.error("Failed to fetch channels:", error);
    }
  }, [guildId]);

  useEffect(() => {
    fetchLogs();
    fetchChannels();
    const interval = setInterval(fetchLogs, 10000);
    return () => clearInterval(interval);
  }, [fetchLogs, fetchChannels]);

  const handleUpdate = async (field: string, value: any) => {
    if (isToggling) return;
    try {
      setIsToggling(field);
      const response = await fetch(`/api/guild/${guildId}/config`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field, value }),
      });

      if (!response.ok) throw new Error("Failed to update config");

      const updated = await response.json();
      setGuildData(updated);
      router.refresh();
    } catch (error) {
      console.error("Update failed:", error);
    } finally {
      setIsToggling(null);
    }
  };

  const handleClearLogs = async () => {
    if (!confirm("Are you sure you want to clear the entire audit log?")) return;
    try {
      setIsClearing(true);
      const response = await fetch(`/api/guild/${guildId}/logs`, { method: "DELETE" });
      if (response.ok) setLogs([]);
    } catch (error) {
      console.error("Clear failed:", error);
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <div className="flex flex-col gap-10">
      <div className="bg-white/[0.02] border border-white/5 p-6 rounded-[24px] flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center text-white/40">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/80">Main Log Channel</h3>
            <p className="text-[10px] text-white/20 font-medium">Default destination for all system audit logs.</p>
          </div>
        </div>

        <div className="min-w-[240px]">
          <CustomSelect
            options={channels}
            value={guildData.logChannelId || ""}
            onChange={(val) => handleUpdate("logChannelId", val)}
            placeholder="No Channel Selected"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {categories.map((cat) => (
          <div key={cat.id} className="bg-white/[0.02] border border-white/5 p-6 rounded-[24px] flex flex-col gap-6 group relative overflow-hidden transition-all hover:bg-white/[0.03]">
            {isToggling === cat.dbField && (
              <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px] z-10 flex items-center justify-center">
                <RefreshCw className="w-3.5 h-3.5 text-white animate-spin" />
              </div>
            )}
            
            <div className="flex justify-between items-start">
               <div className={`w-10 h-10 rounded-xl flex items-center justify-center border border-white/5 bg-white/5 transition-colors ${guildData[cat.dbField] ? 'text-white border-white/20' : 'text-white/10'}`}>
                 {cat.icon}
               </div>
               <button
                 onClick={() => handleUpdate(cat.dbField, !guildData[cat.dbField])}
                 className={`w-9 h-5 rounded-full relative transition-all duration-300 ${guildData[cat.dbField] ? 'bg-white' : 'bg-white/5'}`}
               >
                 <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${guildData[cat.dbField] ? 'left-5 bg-black' : 'left-1 bg-white/20'}`} />
               </button>
            </div>

            <div className="space-y-1">
              <h4 className="text-[11px] font-bold uppercase tracking-tight text-white/50">{cat.title}</h4>
              <p className="text-[9px] text-white/10 font-bold uppercase tracking-widest truncate">{cat.desc}</p>
            </div>

            <CustomSelect
              options={channels}
              value={guildData[cat.channelField] || ""}
              onChange={(val) => handleUpdate(cat.channelField, val)}
              placeholder="Default Log Channel"
            />
          </div>
        ))}
      </div>

      <div className="bg-white/[0.01] border border-white/5 rounded-[24px] overflow-hidden">
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
            <div className="flex items-center gap-4">
               <Terminal className="w-4 h-4 text-white/40" />
               <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">Recent Audit History</h3>
            </div>
            <div className="flex items-center gap-3">
               <button onClick={() => fetchLogs()} className="p-2 text-white/20 hover:text-white transition-colors"><RefreshCw className="w-4 h-4" /></button>
               <button onClick={handleClearLogs} className="p-2 text-red-500/20 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
            </div>
        </div>

        <div className="flex flex-col divide-y divide-white/[0.03]">
          <AnimatePresence mode="popLayout">
            {logs.length > 0 ? (
              logs.map((log) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="p-5 flex items-center justify-between hover:bg-white/[0.01] transition-all group"
                >
                  <div className="flex items-center gap-5">
                    <div className="w-10 h-10 rounded-xl bg-white/[0.02] flex items-center justify-center border border-white/5 text-white/10 group-hover:bg-white group-hover:text-black transition-all">
                       <Clock className="w-4 h-4" />
                    </div>
                    <div className="space-y-1">
                       <div className="flex items-center gap-3">
                          <span className="text-[13px] font-bold text-white/80 group-hover:text-white transition-colors capitalize">{log.event.toLowerCase().replace(/_/g, ' ')}</span>
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-white/5 text-white/20 uppercase tracking-widest border border-white/5">{log.type}</span>
                       </div>
                       <div className="flex items-center gap-2 text-[10px] text-white/20 font-medium">
                          <User className="w-3 h-3" /> {log.executorTag || 'SYSTEM'} • {formatDistanceToNow(new Date(log.createdAt))} ago
                       </div>
                       {log.details && (
                         <div className="mt-2 bg-white/[0.02] border border-white/5 p-3 rounded-xl max-w-xl">
                            <MarkdownDisplay 
                              content={log.details} 
                              className="text-[11px] text-white/40 font-medium leading-relaxed"
                            />
                         </div>
                       )}
                    </div>
                  </div>
                  <button onClick={() => router.push(`/dashboard/${guildId}/logs`)} className="opacity-0 group-hover:opacity-100 transition-all font-bold text-[10px] text-white/40 hover:text-white uppercase tracking-widest flex items-center gap-2">
                    View Details <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </motion.div>
              ))
            ) : (
              <div className="py-20 flex flex-col items-center justify-center gap-4 text-center">
                  <AlertCircle className="w-6 h-6 text-white/5" />
                  <p className="text-white/10 font-bold uppercase tracking-widest text-[10px]">No recent activity found</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
