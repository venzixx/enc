"use client";

import React, { useState } from 'react';
import { Shield, Settings, Info, Save, RotateCcw, Zap } from 'lucide-react';
import { useRouter } from 'next/navigation';
import CustomSelect from './CustomSelect';

interface SecurityProps {
  guildId: string;
  initialData: any;
}

export default function SecurityHub({ guildId, initialData }: SecurityProps) {
  const router = useRouter();
  const [enabled, setEnabled] = useState(initialData.antiNukeEnabled ?? false);
  const [categories, setCategories] = useState({
    antiNukeBan: initialData.antiNukeBan ?? false,
    antiNukeKick: initialData.antiNukeKick ?? false,
    antiNukeChannel: initialData.antiNukeChannel ?? false,
    antiNukeRole: initialData.antiNukeRole ?? false,
    antiNukeBot: initialData.antiNukeBot ?? false,
    antiNukeWebhook: initialData.antiNukeWebhook ?? false,
  });
  const [config, setConfig] = useState(initialData.antiNukeConfig || {
    banHeat: 20,
    kickHeat: 15,
    channelHeat: 10,
    roleHeat: 10,
    webhookHeat: 25,
    decayRate: 5,
    punishment: 'STRIP_ROLES'
  });
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/security`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled,
          categories,
          config
        }),
      });
      if (res.ok) {
        router.refresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Master Toggle */}
      <div className={`p-10 rounded-[40px] border transition-all duration-500 ${enabled ? 'bg-white/[0.02] border-white/10' : 'bg-red-500/5 border-red-500/10'}`}>
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 text-center md:text-left">
           <div className="space-y-2">
              <div className="flex items-center justify-center md:justify-start gap-4">
                 <Shield className={`w-6 h-6 ${enabled ? 'text-white' : 'text-red-500'}`} />
                 <h2 className="text-2xl font-extrabold uppercase tracking-tight text-white/90 italic">Security Status</h2>
              </div>
              <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Master Anti-Nuke Control</p>
           </div>

           <div 
             onClick={() => setEnabled(!enabled)}
             className={`w-20 h-10 rounded-full relative cursor-pointer transition-all duration-500 border ${enabled ? 'bg-white border-white shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'bg-white/5 border-white/10'}`}
           >
              <div className={`absolute top-1 w-7 h-7 rounded-full transition-all duration-500 ${enabled ? 'left-11 bg-black' : 'left-1 bg-white/20'}`} />
           </div>
        </div>
      </div>

      <div className={`space-y-12 transition-all duration-700 ${!enabled ? 'opacity-30 pointer-events-none grayscale' : ''}`}>
        {/* Category Toggles */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { id: 'antiNukeBan', label: 'Mass Ban', icon: <Zap /> },
            { id: 'antiNukeKick', label: 'Mass Kick', icon: <Zap /> },
            { id: 'antiNukeChannel', label: 'Channel Nuke', icon: <Zap /> },
            { id: 'antiNukeRole', label: 'Role Nuke', icon: <Zap /> },
            { id: 'antiNukeBot', label: 'Bot Addition', icon: <Zap /> },
            { id: 'antiNukeWebhook', label: 'Webhook Spam', icon: <Zap /> },
          ].map((cat) => (
            <div 
              key={cat.id}
              onClick={() => setCategories({ ...categories, [cat.id]: !categories[cat.id as keyof typeof categories] })}
              className={`p-6 rounded-3xl border transition-all cursor-pointer group ${
                categories[cat.id as keyof typeof categories] 
                ? 'bg-white/[0.03] border-white/20' 
                : 'bg-white/[0.01] border-white/5 hover:border-white/10'
              }`}
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-xl border ${categories[cat.id as keyof typeof categories] ? 'bg-white/10 border-white/20 text-white' : 'bg-white/5 border-white/5 text-white/20'}`}>
                    {React.cloneElement(cat.icon as React.ReactElement<any>, { className: 'w-4 h-4' })}
                  </div>
                  <span className={`text-xs font-bold uppercase tracking-widest ${categories[cat.id as keyof typeof categories] ? 'text-white' : 'text-white/40'}`}>
                    {cat.label}
                  </span>
                </div>
                <div className={`w-8 h-4 rounded-full relative border transition-all ${categories[cat.id as keyof typeof categories] ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}>
                   <div className={`absolute top-0.5 w-2.5 h-2.5 rounded-full transition-all ${categories[cat.id as keyof typeof categories] ? 'left-4.5 bg-black' : 'left-0.5 bg-white/10'}`} />
                </div>
              </div>
            </div>
          ))}
        </section>

      {/* 1. Sensitivity Configuration Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10 col-span-1 md:col-span-2">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
              <Settings className="w-5 h-5 text-white/60" />
            </div>
            <div>
              <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Sensitivity Settings</h3>
              <p className="text-sm text-white/20 font-medium">Define how sensitivity points are generated per action.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <SliderItem
              label="Ban Action"
              value={config.banHeat}
              onChange={(v: number) => setConfig({ ...config, banHeat: v })}
              description="Points added per member ban."
            />
            <SliderItem
              label="Kick Action"
              value={config.kickHeat}
              onChange={(v: number) => setConfig({ ...config, kickHeat: v })}
              description="Points added per member kick."
            />
            <SliderItem
              label="Channel Action"
              value={config.channelHeat}
              onChange={(v: number) => setConfig({ ...config, channelHeat: v })}
              description="Points added per channel change."
            />
            <SliderItem
              label="Role Action"
              value={config.roleHeat}
              onChange={(v: number) => setConfig({ ...config, roleHeat: v })}
              description="Points added per role change."
            />
          </div>
        </div>

        {/* 2. Global Recovery & Punishment */}
        <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
              <RotateCcw className="w-5 h-5 text-white/60" />
            </div>
            <div>
              <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Recovery Rate</h3>
              <p className="text-sm text-white/20 font-medium">Speed at which sensitivity points decrease over time.</p>
            </div>
          </div>

          <SliderItem
            label="Decrease Rate"
            value={config.decayRate}
            onChange={(v: number) => setConfig({ ...config, decayRate: v })}
            description="Points removed every 10 seconds."
            max={20}
          />
        </div>

        <div className="bg-white/[0.01] border border-white/5 p-10 rounded-[32px] space-y-10">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
              <Shield className="w-5 h-5 text-white/60" />
            </div>
            <div>
              <h3 className="text-xl font-bold uppercase tracking-tight text-white/90">Action Threshold</h3>
              <p className="text-sm text-white/20 font-medium">Automatic action taken when threshold is reached.</p>
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Punishment Type</label>
            <CustomSelect
              options={[
                { id: "STRIP_ROLES", name: "Remove Roles" },
                { id: "KICK", name: "Kick Member" },
                { id: "BAN", name: "Ban Member" },
              ]}
              value={config.punishment}
              onChange={(val) => setConfig({ ...config, punishment: val })}
              placeholder="Select Punishment"
            />
          </div>
        </div>
      </section>
      </div>

      {/* Save Trigger */}
      <div className="flex justify-end pt-8">
        <button
          onClick={handleSave}
          disabled={loading}
          className="flex items-center gap-3 bg-white text-black px-10 py-4 rounded-2xl text-[11px] font-bold uppercase tracking-widest hover:bg-zinc-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_20px_rgba(255,255,255,0.1)]"
        >
          {loading ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>Save Changes</span>
        </button>
      </div>
    </div>
  );
}

function SliderItem({ label, value, onChange, description, max = 50 }: any) {
  return (
    <div className="space-y-6 group">
      <div className="flex justify-between items-end gap-4">
        <div className="space-y-1.5 text-left">
          <h4 className="text-[12px] font-bold text-white/80 uppercase tracking-tight">{label}</h4>
          <p className="text-[11px] text-white/20 font-medium">{description}</p>
        </div>
        <span className="text-2xl font-bold tracking-tighter text-white/90">{value}%</span>
      </div>
      <div className="relative h-2.5 bg-white/5 rounded-full overflow-hidden">
        <div
          className="absolute inset-y-0 left-0 bg-white transition-all duration-500 ease-out"
          style={{ width: `${(value / max) * 100}%` }}
        />
        <input
          type="range"
          min="1"
          max={max}
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          className="absolute inset-0 opacity-0 cursor-pointer z-10"
        />
      </div>
    </div>
  );
}
