"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Music,
  Shield,
  Users,
  Gamepad2,
  BarChart3,
} from "lucide-react";

interface Capability {
  id: string;
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  description: string;
  features: string[];
  color: string;
}

const capabilities: Capability[] = [
  {
    id: "music",
    icon: <Music className="w-5 h-5" />,
    title: "Music Player",
    subtitle: "Premium Audio Streaming",
    description: "Stream your favorite tracks with high audio quality. Features include advanced queue management and seamless playback.",
    features: ["HQ Audio Streaming", "Queue Management", "Playlist Support", "Audio Effects", "Lyric Display"],
    color: "from-blue-500/10 to-indigo-500/5",
  },
  {
    id: "moderation",
    icon: <Shield className="w-5 h-5" />,
    title: "Security",
    subtitle: "Protection Systems",
    description: "Comprehensive tools to keep your server safe. Advanced anti-nuke, spam filters, and automated moderation.",
    features: ["Anti-Nuke Defense", "Auto-Moderation", "Spam Filters", "Account Verification", "Raid Protection"],
    color: "from-blue-500/10 to-indigo-500/5",
  },
  {
    id: "members",
    icon: <Users className="w-5 h-5" />,
    title: "Management",
    subtitle: "Community Systems",
    description: "Manage your community effortlessly. Auto-roles, verification, and engagement tracking in one place.",
    features: ["Auto-Role Assignment", "Verification", "Profile System", "Welcome Messages", "Activity Tracking"],
    color: "from-blue-500/10 to-indigo-500/5",
  },
  {
    id: "fun",
    icon: <Gamepad2 className="w-5 h-5" />,
    title: "Fun & Games",
    subtitle: "Engagement Tools",
    description: "Keep your community entertained with interactive systems, economy, and fun mini-games.",
    features: ["Games & Trivia", "Economy System", "Confessions", "Polls", "Fun Commands"],
    color: "from-blue-500/10 to-indigo-500/5",
  },
  {
    id: "logging",
    icon: <BarChart3 className="w-5 h-5" />,
    title: "Audit Logs",
    subtitle: "Analytics & Tracking",
    description: "Complete transparency with detailed event tracking. Monitor all server activities with ease.",
    features: ["Event Logging", "Audit Trail", "Analytics", "Data Export", "Real-time Alerts"],
    color: "from-blue-500/10 to-indigo-500/5",
  },
];

export default function BotCapabilities() {
  const [activeTab, setActiveTab] = useState(0);
  const active = capabilities[activeTab];

  return (
    <section className="py-24 px-6 md:px-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold uppercase tracking-tight mb-4 text-white">
            What's Included
          </h2>
          <p className="text-white/30 text-lg max-w-2xl mx-auto font-medium">
            Powerful integrated features that work together to simplify your server management.
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {capabilities.map((cap, idx) => (
            <button
              key={cap.id}
              onClick={() => setActiveTab(idx)}
              className={`px-6 py-4 rounded-xl font-bold text-[10px] tracking-[0.2em] uppercase transition-all flex items-center gap-3 border ${
                activeTab === idx
                  ? "bg-white text-black border-white"
                  : "bg-white/[0.02] border-white/5 text-white/20 hover:text-white/60 hover:border-white/10"
              }`}
            >
              {cap.icon}
              {cap.title}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className={`bg-white/[0.02] border border-white/5 rounded-[32px] p-8 md:p-16 relative overflow-hidden`}
          >
            <div className="grid md:grid-cols-2 gap-16 relative z-10">
              <div className="space-y-8">
                <div className="space-y-4">
                  <div className="text-[10px] font-bold text-blue-500 uppercase tracking-[0.3em]">{active.subtitle}</div>
                  <h3 className="text-4xl md:text-5xl font-extrabold uppercase tracking-tight text-white/90">
                    {active.title}
                  </h3>
                </div>

                <p className="text-white/30 text-lg leading-relaxed font-medium">
                  {active.description}
                </p>

                <div className="grid grid-cols-2 gap-4 pt-10 border-t border-white/[0.05]">
                  {active.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                      <span className="text-white/50 font-bold text-[11px] uppercase tracking-wider">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="hidden md:flex items-center justify-center">
                 <div className="w-full aspect-square bg-gradient-to-br from-blue-500/5 to-transparent rounded-full flex items-center justify-center">
                    <div className="text-white/5 scale-[3]">{active.icon}</div>
                 </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
