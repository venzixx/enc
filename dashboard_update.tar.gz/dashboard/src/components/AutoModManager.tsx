"use client";

import React, { useState } from 'react';
import { ToggleLeft, ToggleRight, Hash, MessageSquare, Link, Users, Save, X, Activity, Shield, AlertTriangle } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface AutoModProps {
  guildId: string;
  initialFilters: any[];
  initialEnabled: boolean;
}

const FILTER_TYPES = [
  { id: 'SPAM', label: 'Anti-Spam', description: 'Prevents rapid-fire message bursts.', icon: <MessageSquare /> },
  { id: 'INVITES', label: 'Invite Blocker', description: 'Blocks discord server invite links.', icon: <Users /> },
  { id: 'LINKS', label: 'Link Filter', description: 'Blocks all external web URLs.', icon: <Link /> },
  { id: 'MENTIONS', label: 'Mention Limit', description: 'Flags messages with excessive pings.', icon: <Hash /> },
  { id: 'MALICIOUS', label: 'Malicious Content', description: 'Blocks known threat/malware links.', icon: <Activity /> },
  { id: 'WORDS', label: 'Blocked Phrases', description: 'Filters custom prohibited terminology.', icon: <Shield /> },
];

export default function AutoModManager({ guildId, initialFilters, initialEnabled }: AutoModProps) {
  const [filters, setFilters] = useState(initialFilters);
  const [blacklistedWords, setBlacklistedWords] = useState<string[]>(JSON.parse(initialFilters.find(f => f.type === 'WORDS')?.data || '[]'));
  const [newWord, setNewWord] = useState('');
  const [enabled, setEnabled] = useState(initialEnabled);
  const [saving, setSaving] = useState(false);

  const toggleFilter = (type: string) => {
    setFilters(filters.map(f => f.type === type ? { ...f, enabled: !f.enabled } : f));
  };

  const isWordsEnabled = filters.find(f => f.type === 'WORDS')?.enabled;

  const handleAddWord = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanWord = newWord.trim().toLowerCase();
    if (cleanWord && !blacklistedWords.includes(cleanWord)) {
      setBlacklistedWords([...blacklistedWords, cleanWord]);
      setNewWord('');
    }
  };

  const removeWord = (word: string) => {
    setBlacklistedWords(blacklistedWords.filter(w => w !== word));
  };

  const saveConfig = async () => {
    setSaving(true);
    try {
      const resp = await fetch(`/api/guild/${guildId}/automod`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled,
          filters,
          blacklistedWords,
        })
      });
      if (resp.ok) {
        // Optional: show success toast
      }
    } catch (e) {
      console.error(e);
    }
    setSaving(false);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Master Toggle */}
      <div className={`p-10 rounded-[32px] border border-white/5 transition-all duration-500 ${enabled ? 'bg-white/[0.02] border-white/10' : 'bg-red-500/5 border-red-500/10'}`}>
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 text-center md:text-left">
           <div className="space-y-2">
              <div className="flex items-center justify-center md:justify-start gap-4">
                 <Shield className={`w-6 h-6 ${enabled ? 'text-white' : 'text-red-500'}`} />
                 <h2 className="text-2xl font-bold uppercase tracking-tight text-white/90">System Status</h2>
              </div>
              <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Master Filter Control</p>
           </div>

           <div 
             onClick={() => setEnabled(!enabled)}
             className={`w-20 h-10 rounded-full relative cursor-pointer transition-all duration-500 border ${enabled ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}
           >
              <div className={`absolute top-1 w-7 h-7 rounded-full transition-all duration-500 ${enabled ? 'left-11 bg-black' : 'left-1 bg-white/20'}`} />
           </div>
        </div>
      </div>

      <div className={`grid grid-cols-1 lg:grid-cols-12 gap-10 transition-all duration-700 ${!enabled ? 'opacity-30 pointer-events-none' : ''}`}>
        
        {/* Left: Filters */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex items-center gap-4 mb-4">
             <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
               <Shield className="w-5 h-5 text-white/60" />
             </div>
             <div>
               <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">Module Filters</h3>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {FILTER_TYPES.map(filter => {
              const isActive = filters.find(f => f.type === filter.id)?.enabled;
              return (
                <div 
                  key={filter.id}
                  onClick={() => toggleFilter(filter.id)}
                  className={`p-8 rounded-[32px] bg-white/[0.01] border border-white/5 cursor-pointer group transition-all ${isActive ? 'border-white/20 bg-white/[0.03]' : 'hover:border-white/10'}`}
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className={`p-2.5 rounded-xl border ${isActive ? 'border-white/20 text-white' : 'border-white/5 text-white/20 group-hover:text-white/40'}`}>
                      {React.cloneElement(filter.icon as React.ReactElement<any>, { className: 'w-5 h-5' })}
                    </div>
                    <div className={`w-10 h-5 rounded-full relative border transition-all ${isActive ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}>
                      <div className={`absolute top-0.5 w-3.5 h-3.5 rounded-full transition-all ${isActive ? 'left-5.5 bg-black' : 'left-0.5 bg-white/10'}`} />
                    </div>
                  </div>
                  <h4 className={`text-[12px] font-bold tracking-tight uppercase ${isActive ? 'text-white' : 'text-white/40'}`}>{filter.label}</h4>
                  <p className="text-[11px] text-white/20 mt-1.5 font-medium leading-relaxed">{filter.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Blacklist */}
        <div className="lg:col-span-4 space-y-8">
          <div className={`bg-white/[0.01] border border-white/5 p-8 rounded-[32px] min-h-[500px] flex flex-col transition-all duration-500 ${!isWordsEnabled ? 'opacity-50 grayscale' : ''}`}>
             <div className="flex justify-between items-center mb-10">
                <h3 className="text-[11px] font-bold text-white/60 tracking-[0.2em] uppercase">Blocked Phrases</h3>
                <div 
                  onClick={() => toggleFilter('WORDS')}
                  className={`w-10 h-5 rounded-full relative cursor-pointer transition-all duration-300 border ${isWordsEnabled ? 'bg-white border-white' : 'bg-white/5 border-white/10'}`}
                >
                   <div className={`absolute top-0.5 w-3.5 h-3.5 rounded-full transition-all duration-300 ${isWordsEnabled ? 'left-5.5 bg-black' : 'left-0.5 bg-white/10'}`} />
                </div>
             </div>
             
             <form onSubmit={handleAddWord} className="relative mb-8">
                <input 
                  type="text" 
                  value={newWord}
                  onChange={(e) => setNewWord(e.target.value)}
                  placeholder="Type a phrase..."
                  className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-white outline-none focus:border-white/20 transition-all font-sans text-xs pr-12"
                />
                <button type="submit" className="absolute right-4 top-4 p-1 hover:text-white transition-colors text-white/20">
                   <Save className="w-5 h-5" />
                </button>
             </form>

             <div className="flex-1 flex flex-wrap gap-2.5 content-start">
               {blacklistedWords.length === 0 && (
                 <div className="w-full h-full flex flex-col items-center justify-center text-center opacity-10 py-10">
                    <div className="text-[10px] font-bold uppercase tracking-widest">List Empty</div>
                 </div>
               )}
               {blacklistedWords.map(word => (
                 <div key={word} className="flex items-center gap-2.5 px-4 py-2 bg-white/5 border border-white/5 rounded-xl group/chip hover:border-white/10 transition-all">
                   <span className="text-[11px] font-bold text-white/60 font-sans">{word}</span>
                   <button onClick={() => removeWord(word)} className="text-white/20 hover:text-red-500 transition-colors">
                     <X className="w-3.5 h-3.5" />
                   </button>
                 </div>
               ))}
             </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-8 border-t border-white/5">
        <button 
          onClick={saveConfig} 
          disabled={saving}
          className={`px-10 py-4 rounded-2xl text-[11px] font-bold uppercase tracking-widest transition-all ${saving ? 'opacity-50 cursor-not-allowed' : 'bg-white text-black hover:bg-zinc-200'}`}
        >
          {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  );
}
