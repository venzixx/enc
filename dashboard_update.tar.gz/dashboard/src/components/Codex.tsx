"use client";

import React, { useState, useEffect } from "react";
import { motion as m, AnimatePresence } from "framer-motion";
import { 
  Search, ChevronRight, Zap, Music, 
  Shield, Users, Gamepad2, 
  Terminal, Info, Settings, Copy,
  Hash, Database, Activity, Cpu, Layers
} from "lucide-react";

interface Command {
  name: string;
  category: string;
  description: string;
  usage: string;
  examples: string[];
  aliases?: string[];
  cooldown?: number;
}

interface CommandCategory {
  name: string;
  count: number;
  commands: Command[];
  icon: React.ReactNode;
  color: string;
}

const categoryIcons: { [key: string]: React.ReactNode } = {
  config: <Zap className="w-5 h-5" />,
  music: <Music className="w-5 h-5" />,
  moderation: <Shield className="w-5 h-5" />,
  utility: <Users className="w-5 h-5" />,
  fun: <Gamepad2 className="w-5 h-5" />,
};

const categoryColors: { [key: string]: string } = {
  config: "from-blue-500/20 to-cyan-500/10",
  music: "from-purple-500/20 to-pink-500/10",
  moderation: "from-red-500/20 to-orange-500/10",
  utility: "from-emerald-500/20 to-teal-500/10",
  fun: "from-amber-500/20 to-yellow-500/10",
};

export default function Codex() {
  const [categories, setCategories] = useState<CommandCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCommands = async () => {
      try {
        const response = await fetch("/api/commands", { cache: "no-store" });
        if (!response.ok) throw new Error("Failed to fetch commands");
        const data = await response.json();

        if (data.categories && Array.isArray(data.categories)) {
          const mappedCategories: CommandCategory[] = data.categories.map((cat: any) => ({
            name: cat.name,
            count: cat.count,
            commands: cat.commands || [],
            icon: categoryIcons[cat.name.toLowerCase()] || <Cpu className="w-5 h-5" />,
            color: categoryColors[cat.name.toLowerCase()] || "from-blue-500/20 to-cyan-500/10",
          }));
          setCategories(mappedCategories);
          setSelectedCategory(mappedCategories[0]?.name || null);
        }
      } catch (error) {
        console.error("Failed to load commands:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCommands();
  }, []);

  const selectedCat = categories.find((c) => c.name === selectedCategory);
  const filteredCommands = selectedCat?.commands.filter(
    (cmd) =>
      cmd.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cmd.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <section className="py-24 px-6 md:px-16 min-h-screen bg-[#050508] relative overflow-hidden font-sans">
      {/* Background Ambient Depth */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] right-[-5%] w-[60%] h-[60%] rounded-full bg-accent-blue/5 blur-[120px] opacity-30 animate-pulse" />
        <div className="absolute bottom-[-5%] left-[-5%] w-[40%] h-[40%] rounded-full bg-purple-500/5 blur-[100px] opacity-20" />
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10 flex flex-col gap-12">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="space-y-4">
             <div className="flex items-center gap-3 text-accent-blue font-mono text-[10px] tracking-[0.4em] uppercase font-bold">
                <Layers className="w-4 h-4" /> Command Manifest v4.0
             </div>
             <h1 className="text-5xl md:text-7xl font-bold text-white font-display tracking-tight leading-[0.9]">
               Documentation <br />
               <span className="text-white/40">& Protocols.</span>
             </h1>
          </div>

          {/* Global Search Bar - Floating Glass */}
          <div className="w-full md:w-[450px] relative group">
            <div className="absolute inset-0 bg-accent-blue/10 blur-2xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-500" />
            <div className="relative flex items-center bg-white/[0.03] backdrop-blur-2xl border border-white/5 rounded-2xl px-6 py-4 transition-all duration-500 group-focus-within:bg-white/[0.05] group-focus-within:border-white/10">
               <Search className="w-5 h-5 text-white/20 group-focus-within:text-accent-blue transition-colors" />
               <input 
                 type="text"
                 placeholder="Search command protocols..."
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 className="w-full bg-transparent border-none outline-none pl-4 text-white placeholder:text-white/20 font-medium text-base"
               />
            </div>
          </div>
        </div>

        {/* Main Interface Layout */}
        <div className="flex flex-col lg:flex-row gap-8 items-start">
          
          {/* Sidebar Navigation */}
          <aside className="w-full lg:w-[320px] flex flex-col gap-3">
             <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/20 mb-2 pl-2">System Sectors</div>
             <div className="flex flex-row lg:flex-col gap-2 overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 scrollbar-hide">
                {categories.map((cat) => (
                  <button
                    key={cat.name}
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`flex-shrink-0 lg:w-full group relative flex items-center gap-4 p-4 rounded-2xl transition-all duration-500 ${
                      selectedCategory === cat.name 
                        ? "bg-white/[0.05] shadow-[0_10px_30px_rgba(0,0,0,0.4)]" 
                        : "hover:bg-white/[0.02]"
                    }`}
                  >
                    {/* Active Indicator Line */}
                    <AnimatePresence>
                      {selectedCategory === cat.name && (
                        <m.div 
                          layoutId="sidebar-active"
                          className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-accent-blue rounded-r-full shadow-[0_0_15px_rgba(0,183,255,0.5)]"
                        />
                      )}
                    </AnimatePresence>

                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-500 ${
                      selectedCategory === cat.name 
                        ? "bg-accent-blue text-black shadow-[0_0_20px_rgba(0,183,255,0.3)]" 
                        : "bg-white/5 text-white/40 group-hover:text-white/60"
                    }`}>
                      {cat.icon}
                    </div>

                    <div className="flex flex-col text-left">
                       <span className={`text-[11px] font-bold uppercase tracking-widest transition-colors ${selectedCategory === cat.name ? "text-white" : "text-white/40 group-hover:text-white/60"}`}>
                         {cat.name}
                       </span>
                       <span className="text-[9px] font-medium text-white/10 uppercase tracking-widest mt-0.5">
                         {cat.count} Operations
                       </span>
                    </div>
                  </button>
                ))}
             </div>
          </aside>

          {/* Content Area */}
          <main className="flex-1 w-full flex flex-col gap-6">
             <div className="flex items-center justify-between px-2">
                <div className="flex items-center gap-3">
                   <div className="w-2 h-2 rounded-full bg-accent-blue animate-pulse" />
                   <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40">
                     Viewing Sector: <span className="text-white">{selectedCategory}</span>
                   </span>
                </div>
                <div className="text-[10px] font-mono text-white/20 uppercase tracking-tighter">
                   Query results: {filteredCommands.length} matches
                </div>
             </div>

             {/* Commands Grid */}
             <div className="grid grid-cols-1 gap-4 pb-20">
                <AnimatePresence>
                   {loading ? (
                     <div className="py-32 flex flex-col items-center gap-6 text-white/10 italic">
                        <m.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                          className="w-12 h-12 rounded-full border-[3px] border-white/5 border-t-accent-blue"
                        />
                        <span className="text-[10px] uppercase tracking-[0.4em] font-bold">Synchronizing Protocols...</span>
                     </div>
                   ) : filteredCommands.length > 0 ? (
                     filteredCommands.map((cmd, idx) => (
                       <CommandItem key={`${cmd.name}-${idx}`} cmd={cmd} idx={idx} />
                     ))
                   ) : (
                     <div className="py-32 text-center flex flex-col items-center gap-4">
                        <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                           <Activity className="w-8 h-8 text-white/10" />
                        </div>
                        <div className="text-white/20 italic text-sm font-medium">No operational matches found in this sector.</div>
                     </div>
                   )}
                </AnimatePresence>
             </div>
          </main>

        </div>
      </div>
    </section>
  );
}

function CommandItem({ cmd, idx }: { cmd: Command, idx: number }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <m.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.6, delay: Math.min(idx * 0.05, 0.4), ease: [0.23, 1, 0.32, 1] }}
      className={`group relative rounded-2xl transition-all duration-700 overflow-hidden border ${
        isOpen 
          ? "bg-white/[0.08] border-white/20 shadow-[0_40px_80px_rgba(0,0,0,0.5)] z-20" 
          : "bg-white/[0.04] border-white/5 hover:border-white/10 hover:bg-white/[0.06]"
      }`}
    >
      <div 
        className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
         <div className="flex items-center gap-6">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-700 ${isOpen ? "bg-accent-blue text-black" : "bg-white/5 text-white/20 group-hover:text-white/40"}`}>
               <Terminal className="w-5 h-5" />
            </div>
            <div className="flex flex-col gap-1">
               <div className="flex items-center gap-3">
                  <h3 className="text-xl font-bold text-white font-display uppercase tracking-tight">
                    /{cmd.name}
                  </h3>
                  {cmd.aliases && cmd.aliases.length > 0 && (
                     <span className="px-2 py-0.5 bg-white/5 rounded text-[8px] font-bold text-white/40 uppercase tracking-widest border border-white/5">
                        {cmd.aliases[0]}
                     </span>
                  )}
               </div>
               <p className={`text-sm transition-all duration-500 max-w-xl ${isOpen ? "text-white/80" : "text-white/30 group-hover:text-white/50"}`}>
                 {cmd.description}
               </p>
            </div>
         </div>

         {/* Meta Metrics */}
         <div className="flex items-center gap-8 pl-12 md:pl-0">
            <div className="flex flex-col gap-1">
               <span className="text-[8px] font-bold text-white/20 uppercase tracking-[0.2em]">Stability</span>
               <div className="flex items-center gap-2">
                  <div className="w-16 h-1 bg-white/5 rounded-full overflow-hidden">
                     <m.div 
                       initial={{ width: 0 }}
                       animate={{ width: "98%" }}
                       className="h-full bg-accent-blue shadow-[0_0_10px_rgba(0,183,255,0.5)]"
                     />
                  </div>
                  <span className="text-[10px] font-mono text-accent-blue font-bold tracking-tighter">98.4%</span>
               </div>
            </div>
            <div className="flex flex-col gap-1">
               <span className="text-[8px] font-bold text-white/20 uppercase tracking-[0.2em]">Latency</span>
               <span className="text-[10px] font-mono text-white/60 font-bold tracking-tighter">~{cmd.cooldown || 3}ms</span>
            </div>
            <div className={`transition-all duration-500 ${isOpen ? "rotate-90 text-accent-blue" : "text-white/10 group-hover:text-white/30"}`}>
               <ChevronRight className="w-5 h-5" />
            </div>
         </div>
      </div>

      <AnimatePresence>
         {isOpen && (
           <m.div
             initial={{ height: 0, opacity: 0 }}
             animate={{ height: "auto", opacity: 1 }}
             exit={{ height: 0, opacity: 0 }}
             transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
             className="border-t border-white/5 bg-black/40 backdrop-blur-2xl"
           >
              <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-12">
                 {/* Left Col: Usage */}
                 <div className="space-y-6">
                    <div className="flex flex-col gap-3">
                       <div className="flex items-center gap-2 text-[9px] font-bold text-accent-blue uppercase tracking-[0.3em]">
                          <Cpu className="w-3.5 h-3.5" /> Operational Syntax
                       </div>
                       <div className="relative group/syntax">
                          <div className="bg-[#080808] p-5 rounded-2xl border border-white/5 font-mono text-sm text-white/80 overflow-x-auto scrollbar-hide">
                             <code>/{cmd.usage}</code>
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(`/${cmd.usage}`); }}
                            className="absolute right-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center opacity-0 group-hover/syntax:opacity-100 transition-all hover:bg-accent-blue hover:text-black shadow-xl"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                       </div>
                    </div>

                    {cmd.examples && cmd.examples.length > 0 && (
                       <div className="flex flex-col gap-3">
                          <div className="flex items-center gap-2 text-[9px] font-bold text-accent-blue uppercase tracking-[0.3em]">
                             <Activity className="w-3.5 h-3.5" /> Interaction Scenarios
                          </div>
                          <div className="grid grid-cols-1 gap-2">
                             {cmd.examples.map((ex, i) => (
                               <div key={i} className="px-4 py-3 bg-white/[0.02] border border-white/5 rounded-xl font-mono text-[11px] text-white/40 hover:text-white/60 transition-colors">
                                 /{ex}
                               </div>
                             ))}
                          </div>
                       </div>
                    )}
                 </div>

                 {/* Right Col: Details */}
                 <div className="space-y-6">
                    <div className="flex flex-col gap-3">
                       <div className="flex items-center gap-2 text-[9px] font-bold text-accent-blue uppercase tracking-[0.3em]">
                          <Info className="w-3.5 h-3.5" /> Technical Notes
                       </div>
                       <div className="p-6 bg-white/[0.02] rounded-2xl border border-white/5 space-y-4">
                          <p className="text-xs text-white/40 leading-relaxed font-medium">
                            This protocol is part of the <span className="text-white/60">{cmd.category}</span> subsystem. 
                            It requires appropriate administrative permissions to execute in restricted channels.
                          </p>
                          <div className="flex items-center gap-4">
                             <div className="flex items-center gap-2 px-3 py-1.5 bg-accent-blue/10 rounded-full border border-accent-blue/20">
                                <span className="w-1.5 h-1.5 rounded-full bg-accent-blue animate-pulse" />
                                <span className="text-[9px] font-bold text-accent-blue uppercase tracking-widest">Verified Logic</span>
                             </div>
                             <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/5">
                                <span className="text-[9px] font-bold text-white/30 uppercase tracking-widest">Global Access</span>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="flex flex-col gap-3">
                       <div className="flex items-center gap-2 text-[9px] font-bold text-accent-blue uppercase tracking-[0.3em]">
                          <Settings className="w-3.5 h-3.5" /> Registry Meta
                       </div>
                       <div className="grid grid-cols-2 gap-3">
                          <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl">
                             <div className="text-[8px] font-bold text-white/20 uppercase tracking-widest mb-1">Response Type</div>
                             <div className="text-[11px] font-bold text-white/80 uppercase">Asynchronous</div>
                          </div>
                          <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl">
                             <div className="text-[8px] font-bold text-white/20 uppercase tracking-widest mb-1">Cooldown</div>
                             <div className="text-[11px] font-bold text-white/80 uppercase">{cmd.cooldown || 3} Seconds</div>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </m.div>
         )}
      </AnimatePresence>
    </m.div>
  );
}
