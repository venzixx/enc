"use client";

import React, { useState } from 'react';
import { 
  ShieldAlert, CheckCircle, XCircle, Search, 
  MessageSquare, User, Loader2
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';

interface Appeal {
  id: number;
  userId: string;
  userTag: string;
  type: string;
  reason: string;
  appealReason: string;
  status: string;
  staffReason?: string;
  createdAt: string;
}

interface AppealsManagerProps {
  guildId: string;
  initialAppeals: Appeal[];
}

export default function AppealsManager({ guildId, initialAppeals }: AppealsManagerProps) {
  const router = useRouter();
  const [appeals, setAppeals] = useState<Appeal[]>(initialAppeals);
  const [filter, setFilter] = useState('PENDING');
  const [search, setSearch] = useState('');
  const [loadingId, setLoadingId] = useState<number | null>(null);
  const [staffReasons, setStaffReasons] = useState<Record<number, string>>({});

  const filteredAppeals = appeals.filter(appeal => {
    const matchesFilter = filter === 'ALL' || appeal.status === filter;
    const matchesSearch = appeal.userTag.toLowerCase().includes(search.toLowerCase()) || 
                         appeal.userId.includes(search);
    return matchesFilter && matchesSearch;
  });

  const handleAction = async (appealId: number, status: 'APPROVED' | 'REJECTED') => {
    setLoadingId(appealId);
    try {
      const res = await fetch(`/api/guild/${guildId}/appeals`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appealId,
          status,
          staffReason: staffReasons[appealId] || ''
        })
      });

      if (res.ok) {
        const updatedAppeal = await res.json();
        setAppeals(prev => prev.map(a => a.id === appealId ? updatedAppeal : a));
        router.refresh();
      }
    } catch (error) {
      console.error(error);
    }
    setLoadingId(null);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* ── FILTERS SECTOR ── */}
      <section className="flex flex-col md:flex-row gap-6 items-end justify-between">
        <div className="flex-1 space-y-4 w-full">
           <div className="flex items-center gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-white/40" />
              <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Review Queue</h2>
           </div>
           <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
              <input 
                placeholder="Search user tag or ID..."
                className="w-full bg-white/[0.02] border border-white/5 p-4 pl-12 rounded-2xl text-xs font-bold text-white uppercase tracking-widest outline-none focus:bg-white/[0.04] transition-all"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
           </div>
        </div>

        <div className="flex gap-2 p-1.5 bg-white/[0.02] border border-white/5 rounded-2xl">
          {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-6 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${
                filter === f ? 'bg-white text-black' : 'text-white/40 hover:text-white/60 hover:bg-white/5'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </section>

      {/* ── APPEALS LIST ── */}
      <section className="space-y-6">
        {filteredAppeals.length === 0 ? (
          <div className="p-32 border border-dashed border-white/5 rounded-[48px] flex flex-col items-center justify-center text-center space-y-6">
             <div className="p-6 bg-white/[0.02] border border-white/5 rounded-3xl">
               <ShieldAlert className="w-8 h-8 text-white/10" />
             </div>
             <p className="text-[11px] font-bold text-white/10 uppercase tracking-[0.3em]">No appeals found in this category</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-8">
            {filteredAppeals.map(appeal => (
              <motion.div 
                layout
                key={appeal.id}
                className="group bg-white/[0.01] border border-white/5 p-10 rounded-[40px] hover:bg-white/[0.02] transition-all hover:border-white/10 relative overflow-hidden"
              >
                <div className={`absolute top-0 right-0 w-64 h-64 blur-[120px] -mr-32 -mt-32 opacity-[0.03] transition-colors pointer-events-none ${
                  appeal.status === 'APPROVED' ? 'bg-emerald-500' : 
                  appeal.status === 'REJECTED' ? 'bg-red-500' : 
                  'bg-white'
                }`} />

                <div className="flex flex-col lg:flex-row gap-12 relative z-10">
                  <div className="lg:w-1/4 space-y-6">
                    <div className="flex items-center gap-5">
                       <div className="w-14 h-14 rounded-[20px] bg-white/5 border border-white/10 flex items-center justify-center">
                          <User className="w-6 h-6 text-white/40" />
                       </div>
                       <div className="space-y-1">
                          <h3 className="text-sm font-bold text-white/90 tracking-tight">{appeal.userTag}</h3>
                          <p className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em]">{appeal.userId}</p>
                       </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                       <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1.5">
                          <p className="text-[8px] font-bold text-white/10 uppercase tracking-widest">Punishment</p>
                          <div className="flex items-center gap-2">
                             <div className={`w-1.5 h-1.5 rounded-full ${
                               appeal.type === 'BAN' ? 'bg-red-500' : 
                               appeal.type === 'MUTE' ? 'bg-yellow-500' : 'bg-blue-500'
                             }`} />
                             <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">{appeal.type}</span>
                          </div>
                       </div>
                       <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1.5">
                          <p className="text-[8px] font-bold text-white/10 uppercase tracking-widest">Date</p>
                          <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">
                            {new Date(appeal.createdAt).toLocaleDateString()}
                          </span>
                       </div>
                    </div>
                  </div>

                  <div className="flex-1 space-y-10">
                     <div className="space-y-4">
                        <div className="flex items-center gap-2 text-white/20">
                           <MessageSquare className="w-3 h-3" />
                           <span className="text-[9px] font-bold uppercase tracking-[0.2em]">Original Reason</span>
                        </div>
                        <p className="text-xs text-white/40 leading-relaxed italic bg-white/[0.01] p-5 rounded-2xl border border-white/5">
                           "{appeal.reason}"
                        </p>
                     </div>

                     <div className="space-y-4">
                        <div className="flex items-center gap-2 text-white/60">
                           <ShieldAlert className="w-3 h-3" />
                           <span className="text-[9px] font-bold uppercase tracking-[0.2em]">User's Justification</span>
                        </div>
                        <p className="text-xs text-white/80 leading-relaxed font-medium">
                           {appeal.appealReason}
                        </p>
                     </div>
                  </div>

                  <div className="lg:w-1/3 space-y-6">
                    {appeal.status === 'PENDING' ? (
                      <div className="space-y-6">
                        <div className="space-y-3">
                           <label className="text-[9px] font-bold text-white/20 uppercase tracking-[0.2em] px-1">Staff Note (Optional)</label>
                           <textarea 
                             placeholder="Provide context for your decision..."
                             className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-3xl text-[11px] text-white/80 outline-none focus:bg-white/[0.04] transition-all min-h-[100px] resize-none"
                             value={staffReasons[appeal.id] || ''}
                             onChange={(e) => setStaffReasons(prev => ({ ...prev, [appeal.id]: e.target.value }))}
                           />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <button 
                             onClick={() => handleAction(appeal.id, 'APPROVED')}
                             disabled={loadingId === appeal.id}
                             className="flex items-center justify-center gap-2 bg-emerald-500/10 border border-emerald-500/20 py-4 rounded-2xl text-[10px] font-bold text-emerald-500 uppercase tracking-[0.2em] hover:bg-emerald-500/20 transition-all disabled:opacity-50"
                           >
                             {loadingId === appeal.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                             Approve
                           </button>
                           <button 
                             onClick={() => handleAction(appeal.id, 'REJECTED')}
                             disabled={loadingId === appeal.id}
                             className="flex items-center justify-center gap-2 bg-red-500/10 border border-red-500/20 py-4 rounded-2xl text-[10px] font-bold text-red-500 uppercase tracking-[0.2em] hover:bg-red-500/20 transition-all disabled:opacity-50"
                           >
                             {loadingId === appeal.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-4 h-4" />}
                             Reject
                           </button>
                        </div>
                      </div>
                    ) : (
                      <div className="h-full flex flex-col justify-center items-center p-8 bg-white/[0.02] border border-white/5 rounded-[32px] space-y-4">
                         <div className={`p-4 rounded-full ${appeal.status === 'APPROVED' ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}>
                            {appeal.status === 'APPROVED' ? 
                              <CheckCircle className="w-6 h-6 text-emerald-500" /> : 
                              <XCircle className="w-6 h-6 text-red-500" />
                            }
                         </div>
                         <div className="text-center space-y-1">
                            <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Outcome</p>
                            <h4 className={`text-xs font-black uppercase tracking-[0.3em] ${appeal.status === 'APPROVED' ? 'text-emerald-500' : 'text-red-500'}`}>
                               {appeal.status}
                            </h4>
                         </div>
                         {appeal.staffReason && (
                           <div className="pt-4 border-t border-white/5 w-full">
                              <p className="text-[9px] font-bold text-white/10 uppercase tracking-widest text-center mb-2">Staff Note</p>
                              <p className="text-[10px] text-white/40 text-center italic">"{appeal.staffReason}"</p>
                           </div>
                         )}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
