"use client";

import React from "react";
import { motion } from "framer-motion";
import { Download, Settings, Zap, ArrowRight } from "lucide-react";

interface Step {
  icon: React.ReactNode;
  number: string;
  title: string;
  description: string;
}

const steps: Step[] = [
  {
    icon: <Download className="w-5 h-5" />,
    number: "01",
    title: "Invite the Bot",
    description: "Connect Enc to your server with one click. Ready to use in seconds.",
  },
  {
    icon: <Settings className="w-5 h-5" />,
    number: "02",
    title: "Configure",
    description: "Customize settings and modules to fit your community's needs.",
  },
  {
    icon: <Zap className="w-5 h-5" />,
    number: "03",
    title: "Interact",
    description: "Launch your chosen features and enjoy a better server experience.",
  },
];

export default function HowItWorks() {
  return (
    <section className="py-24 px-6 md:px-12 relative overflow-hidden">
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-3xl md:text-4xl font-bold uppercase tracking-tight mb-4 text-white">
            How It Works
          </h2>
          <p className="text-white/30 text-lg max-w-2xl mx-auto font-medium">
            Get your server up and running in three simple steps.
          </p>
        </motion.div>

        {/* Steps Container */}
        <div className="grid md:grid-cols-3 gap-6 relative">
          {steps.map((step, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              viewport={{ once: true, margin: "-50px" }}
              className="relative"
            >
              <div className="bg-white/[0.02] border border-white/5 p-10 rounded-[32px] h-full flex flex-col gap-8 relative group hover:border-white/10 transition-all duration-500">
                <div className="flex items-center justify-between">
                   <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-white/40 group-hover:bg-white group-hover:text-black transition-all">
                      {step.icon}
                   </div>
                   <div className="text-[10px] font-bold text-white/5 uppercase tracking-[0.4em]">{step.number}</div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-2xl font-bold text-white/90 group-hover:text-white transition-colors uppercase tracking-tight">
                    {step.title}
                  </h3>
                  <p className="text-white/20 text-sm leading-relaxed font-medium">
                    {step.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button className="px-12 py-4 bg-white text-black font-bold text-[10px] tracking-[0.2em] uppercase rounded-xl hover:bg-white/90 transition-all">
            Get Started
          </button>
          <button className="px-12 py-4 bg-white/5 border border-white/10 text-white font-bold text-[10px] tracking-[0.2em] uppercase rounded-xl hover:bg-white/10 transition-all">
            Documentation
          </button>
        </motion.div>
      </div>
    </section>
  );
}
