"use client";

import React from "react";
import { motion } from "framer-motion";
import { ChevronRight } from "lucide-react";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  id?: string;
  gradient?: string;
}

export default function FeatureCard({
  icon,
  title,
  description,
  id,
  gradient = "from-accent-blue/10 to-transparent",
}: FeatureCardProps) {
  const [isHovered, setIsHovered] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      viewport={{ once: true, margin: "-50px" }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="group relative h-full"
    >
      {/* Card Background Gradient - animated */}
      <div
        className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none`}
      />

      {/* Main Card */}
      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.4 }}
        className="surgical-glass backdrop-blur-xl p-8 md:p-10 flex flex-col gap-8 group/card rounded-2xl border border-white/5 group-hover:border-white/15 transition-all duration-500 relative h-full overflow-hidden"
      >
        {/* Glow Effect on Hover */}
        {isHovered && (
          <div className="absolute inset-0 rounded-2xl bg-radial-glow opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
            <div className="absolute -inset-1 bg-gradient-to-r from-accent-blue/20 via-transparent to-transparent rounded-2xl blur-3xl" />
          </div>
        )}

        {/* Icon Section */}
        <div className="flex justify-between items-start relative z-10">
          <motion.div
            whileHover={{ scale: 1.15 }}
            transition={{ duration: 0.3 }}
            className="w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-accent-blue/10 to-white/5 rounded-xl md:rounded-2xl border border-white/5 flex items-center justify-center group-hover:border-accent-blue/30 transition-all duration-500 group-hover:shadow-[0_0_30px_rgba(0,118,255,0.15)]"
          >
            <div className="text-accent-blue group-hover:scale-110 transition-transform duration-500">
              {icon}
            </div>
          </motion.div>
          {id && (
            <span className="text-[8px] md:text-[9px] font-mono font-bold text-white/20 group-hover:text-accent-blue transition-colors duration-500 uppercase tracking-widest">
              {id}
            </span>
          )}
        </div>

        {/* Title and Description */}
        <div className="flex flex-col gap-3 relative z-10">
          <h3 className="font-display font-bold text-lg md:text-2xl uppercase tracking-tight text-white group-hover:text-white transition-all duration-500">
            {title}
          </h3>
          <p className="text-sm md:text-[15px] text-white/40 font-medium leading-relaxed line-clamp-3 group-hover:text-white/60 transition-colors duration-500">
            {description}
          </p>
        </div>

        {/* Footer with Link */}
        <div className="pt-6 md:pt-8 border-t border-white/5 mt-auto flex items-center justify-between text-white/20 group-hover:text-accent-blue transition-colors duration-500 relative z-10">
          <span className="text-[9px] font-bold uppercase tracking-widest">Learn More</span>
          <motion.div
            animate={{ x: isHovered ? 4 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronRight className="w-4 h-4" />
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
}
