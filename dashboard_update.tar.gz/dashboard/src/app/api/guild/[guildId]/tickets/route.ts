import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const configs = await prisma.ticketConfig.findMany({
      where: { guildId }
    });

    return NextResponse.json(configs);
  } catch (error) {
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const body = await req.json();
    const { 
      panelId, name, description, categoryId, supportRoleId, channelId, 
      isMulti, options, ...rest 
    } = body;

    const dataToSave = {
      name,
      description,
      categoryId,
      supportRoleId,
      channelId,
      isMulti: !!isMulti,
      ...rest,
      welcomeFields: rest.welcomeFields ? JSON.stringify(rest.welcomeFields) : null
    };

    // First, upsert the main config
    const upsertedConfig = await prisma.ticketConfig.upsert({
      where: {
        guildId_panelId: { guildId, panelId }
      },
      update: dataToSave,
      create: {
        guildId,
        panelId,
        ...dataToSave
      },
    });

    // Handle options if it's a multi-panel
    if (isMulti && options) {
       // Clear old options
       await prisma.ticketPanelOption.deleteMany({
          where: { panelId: upsertedConfig.id }
       });

       // Create new options
       await prisma.ticketPanelOption.createMany({
          data: options.map((opt: any) => ({
             panelId: upsertedConfig.id,
             optionId: opt.optionId,
             label: opt.label,
             categoryId: opt.categoryId || categoryId,
             supportRoleId: opt.supportRoleId || supportRoleId,
             emoji: opt.emoji,
             description: opt.description,
             targetPanelId: opt.targetPanelId
          }))
       });
    }

    // Deployment logic
    if (channelId) {
      const colorInt = parseInt(body.panelColor?.replace('#', '') || '9333ea', 16);
      
      const components = isMulti 
        ? [{
            type: 1,
            components: body.useDropdown 
              ? [{
                  type: 3,
                  custom_id: `ticket_select:${panelId}`,
                  options: options.map((opt: any) => ({
                    label: opt.label,
                    value: opt.optionId,
                    description: opt.description,
                    emoji: opt.emoji ? { name: opt.emoji } : undefined
                  })),
                  placeholder: "Select a category..."
                }]
              : options.map((opt: any) => ({
                  type: 2,
                  style: 1,
                  label: opt.label,
                  custom_id: `ticket_open:${opt.optionId}`,
                  emoji: opt.emoji ? { name: opt.emoji } : undefined
                })).slice(0, 5) // Discord limit
          }]
        : [{
            type: 1,
            components: [{
              type: 2,
              style: 1,
              label: body.buttonText || "Open Ticket",
              custom_id: `ticket_open:${panelId}`,
              emoji: { name: "🎫" }
            }]
          }];

      const discordResponse = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
        method: "POST",
        headers: {
          Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          embeds: [{
            title: body.embedTitle || name,
            description: body.embedDescription || description,
            color: colorInt,
            image: body.largeImageUrl ? { url: body.largeImageUrl } : undefined,
            thumbnail: body.smallImageUrl ? { url: body.smallImageUrl } : undefined,
            author: body.authorName ? { name: body.authorName, icon_url: body.authorIcon } : undefined,
            footer: body.footerText ? { text: body.footerText, icon_url: body.footerIcon } : undefined,
          }],
          components
        }),
      });

      if (discordResponse.ok) {
        const msg = await discordResponse.json();
        await prisma.ticketConfig.update({
          where: { id: upsertedConfig.id },
          data: { messageId: msg.id }
        });
      }
    }

    return NextResponse.json({ success: true, config: upsertedConfig });

  } catch (error) {
    console.error("[TICKETS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
