import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ guildId: string, id: string }> }
) {
  try {
    const { guildId, id } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    // Delete the ticket config
    await prisma.ticketConfig.delete({
      where: {
        id: parseInt(id),
        guildId: guildId
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[TICKET_DELETE]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
