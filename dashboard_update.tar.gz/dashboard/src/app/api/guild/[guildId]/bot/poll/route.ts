import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session || !session.accessToken) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { channelId, question, options } = body;

    if (!channelId || !question || !options || !Array.isArray(options)) {
      return new NextResponse("Missing required fields", { status: 400 });
    }

    // Dispatch a native Discord Poll (v10)
    // Note: This requires the bot to have permission to send polls in the channel.
    const discordResponse = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        poll: {
          question: { text: question },
          answers: options.map((opt: string, idx: number) => ({
            answer_id: idx + 1,
            poll_media: { text: opt }
          })),
          allow_multiselect: false,
          layout_type: 1 // DEFAULT
        }
      }),
    });

    if (!discordResponse.ok) {
      const errorData = await discordResponse.json();
      // Fallback to simple Embed Poll if native polls fail (e.g. permission or older guild)
      console.warn("Native poll dispatch failed, verify permissions:", errorData);
      return new NextResponse(errorData.message || "Discord Poll Dispatch Failure", { status: discordResponse.status });
    }

    return NextResponse.json({ success: true, message: "Poll cluster deployed successfully." });

  } catch (error) {
    console.error("[POLL_DISPATCH_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
