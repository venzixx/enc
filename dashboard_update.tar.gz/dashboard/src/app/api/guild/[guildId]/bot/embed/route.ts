import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session || !session.accessToken) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { channelId, embed } = body;

    if (!channelId || !embed) {
      return new NextResponse("Missing required fields", { status: 400 });
    }

    // Dispatch to Discord API
    const discordResponse = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [embed],
      }),
    });

    if (!discordResponse.ok) {
      const errorData = await discordResponse.json();
      return new NextResponse(errorData.message || "Discord Dispatch Failure", { status: discordResponse.status });
    }

    return NextResponse.json({ success: true, message: "Protocol payload dispatched successfully." });

  } catch (error) {
    console.error("[EMBED_DISPATCH_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
