import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const body = await req.json();
  const { filters, blacklistedWords, action, enabled } = body;

  try {
    // 1. Update Global Master Switch
    if (typeof enabled === 'boolean') {
      await prisma.guild.update({
        where: { id: guildId },
        data: { autoModEnabled: enabled }
      });
    }

    // 2. Process all filters (including WORDS)
    if (filters) {
      for (const filter of filters) {
        const updateData: any = { enabled: filter.enabled };
        
        // Specific payload updates for WORDS
        if (filter.type === 'WORDS') {
          if (blacklistedWords) updateData.data = JSON.stringify(blacklistedWords);
          if (action) updateData.action = action;
        }

        await prisma.autoModFilter.upsert({
          where: { guildId_type: { guildId, type: filter.type } },
          update: updateData,
          create: { 
            guildId, 
            type: filter.type, 
            enabled: filter.enabled,
            data: filter.type === 'WORDS' ? JSON.stringify(blacklistedWords || []) : undefined,
            action: filter.type === 'WORDS' ? (action || 'DELETE') : undefined,
          }
        });
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[AUTOMOD_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
