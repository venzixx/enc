import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getGuild } from "@/lib/discord";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session || !session.accessToken) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { nickname, bio, avatar, banner } = body;

    const guildConfig = await prisma.guild.findUnique({
      where: { id: guildId },
      select: { lastBrandingUpdate: true }
    });

    if (guildConfig?.lastBrandingUpdate) {
      const now = new Date();
      const lastUpdate = new Date(guildConfig.lastBrandingUpdate);
      const diffMinutes = Math.floor((now.getTime() - lastUpdate.getTime()) / 1000 / 60);

      if (diffMinutes < 15) {
        return new NextResponse(`Sync Lock Active: ${15 - diffMinutes}m remaining.`, { status: 429 });
      }
    }

    const discordResponse = await fetch(`https://discord.com/api/v10/guilds/${guildId}/members/@me`, {
      method: "PATCH",
      headers: {
        Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        nick: nickname || undefined,
        avatar: avatar || undefined,
        banner: banner || undefined,
      }),
    });

    if (!discordResponse.ok) {
      const errorData = await discordResponse.json();
      return new NextResponse(errorData.message || "Discord API Failure", { status: discordResponse.status });
    }

    const updatedMember = await discordResponse.json();

    const updatedGuild = await prisma.guild.update({
      where: { id: guildId },
      data: {
        botNickname: nickname || null,
        botBio: bio || null,
        botAvatar: updatedMember.avatar ? `https://cdn.discordapp.com/guilds/${guildId}/users/${updatedMember.user.id}/avatars/${updatedMember.avatar}.png` : null,
        botBanner: updatedMember.banner ? `https://cdn.discordapp.com/guilds/${guildId}/users/${updatedMember.user.id}/banners/${updatedMember.banner}.png` : null,
        lastBrandingUpdate: new Date()
      },
    });

    return NextResponse.json({ success: true, guild: updatedGuild });

  } catch (error) {
    console.error("[BRANDING_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const guild = await prisma.guild.findUnique({
      where: { id: guildId },
      select: {
        botNickname: true,
        botBio: true,
        botAvatar: true,
        botBanner: true,
        lastBrandingUpdate: true
      }
    });

    // Fetch Live Bot Data for fallback
    let liveAvatar: string | null = null;
    let liveBanner: string | null = null;
    let liveNickname: string | null = null;

    try {
      const botResponse = await fetch("https://discord.com/api/v10/users/@me", {
        headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` }
      });
      const botData = await botResponse.json();
      
      const memberResponse = await fetch(`https://discord.com/api/v10/guilds/${guildId}/members/${botData.id}`, {
        headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` }
      });
      const memberData = await memberResponse.json();

      if (botData.avatar) {
        liveAvatar = `https://cdn.discordapp.com/avatars/${botData.id}/${botData.avatar}.png?size=512`;
      }
      if (botData.banner) {
        liveBanner = `https://cdn.discordapp.com/banners/${botData.id}/${botData.banner}.png?size=600`;
      }

      // Member specific overrides
      if (memberData.avatar) {
        liveAvatar = `https://cdn.discordapp.com/guilds/${guildId}/users/${botData.id}/avatars/${memberData.avatar}.png?size=512`;
      }
      if (memberData.banner) {
        liveBanner = `https://cdn.discordapp.com/guilds/${guildId}/users/${botData.id}/banners/${memberData.banner}.png?size=600`;
      }
      if (memberData.nick) {
        liveNickname = memberData.nick;
      }
    } catch (err) {
      console.error("Failed to fetch live bot data:", err);
    }

    return NextResponse.json({
      ...guild,
      fallbackAvatar: liveAvatar,
      fallbackBanner: liveBanner,
      fallbackNickname: liveNickname
    });
  } catch (error) {
    return new NextResponse("Internal Error", { status: 500 });
  }
}
