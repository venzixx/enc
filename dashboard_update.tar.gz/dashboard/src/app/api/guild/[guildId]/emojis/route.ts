import { getGuildEmojis } from "@/lib/discord";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  try {
    const emojis = await getGuildEmojis(guildId);
    return NextResponse.json(emojis);
  } catch (error) {
    console.error("[EMOJIS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
