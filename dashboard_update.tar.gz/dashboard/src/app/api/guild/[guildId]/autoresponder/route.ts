import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const responders = await prisma.autoResponse.findMany({
      where: { guildId }
    });

    return NextResponse.json(responders);
  } catch (error) {
    console.error("[AUTORESPONDER_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { trigger, response, channelId, matchType } = await req.json();
    
    // Logic: Find by trigger, channelId AND matchType to update, or create new
    const existing = await prisma.autoResponse.findFirst({
        where: { 
            guildId, 
            trigger: trigger.toLowerCase().trim(),
            channelId: channelId || null,
            matchType: matchType || "EXACT"
        }
    });

    if (existing) {
        await prisma.autoResponse.update({
            where: { id: existing.id },
            data: { response }
        });
    } else {
        await prisma.autoResponse.create({
            data: {
                guildId,
                trigger: trigger.toLowerCase().trim(),
                response,
                channelId: channelId || null,
                matchType: matchType || "EXACT"
            }
        });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[AUTORESPONDER_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { id, trigger, response, channelId, matchType } = await req.json();
    if (!id) return new NextResponse("Missing ID", { status: 400 });

    await prisma.autoResponse.update({
      where: { id: parseInt(id), guildId },
      data: {
        trigger: trigger.toLowerCase().trim(),
        response,
        channelId: channelId || null,
        matchType: matchType || "EXACT"
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[AUTORESPONDER_PATCH]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return new NextResponse("Missing ID", { status: 400 });

    await prisma.autoResponse.delete({
      where: { id: parseInt(id), guildId }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[AUTORESPONDER_DELETE]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
