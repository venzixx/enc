import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const guild = await prisma.guild.findUnique({
      where: { id: guildId },
      select: {
        leaveChannelId: true,
        leaveMessage: true,
        // Since we combined greetings, we might need a join Channel ID too if it's not already there.
        // For now using what we added to the schema.
      }
    });

    return NextResponse.json(guild);
  } catch (error) {
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const body = await req.json();
    const { leaveChannelId, leaveMessage } = body;

    const updatedGuild = await prisma.guild.update({
      where: { id: guildId },
      data: {
        leaveChannelId: leaveChannelId || null,
        leaveMessage: leaveMessage || null,
      },
    });

    return NextResponse.json({ success: true, guild: updatedGuild });

  } catch (error) {
    console.error("[GREETINGS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
