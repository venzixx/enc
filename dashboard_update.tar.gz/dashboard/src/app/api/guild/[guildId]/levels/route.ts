import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const guild = await prisma.guild.findUnique({
      where: { id: guildId },
      include: {
        levelRoles: {
          select: {
            level: true,
            roleId: true
          }
        },
        roleBoosters: true,
        channelBoosters: true
      }
    });

    return NextResponse.json(guild);
  } catch (error) {
    console.error("[LEVELS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    
    // We update everything in one go
    const updatedGuild = await prisma.$transaction(async (tx) => {
      // 1. Update basic guild config
      const { levelRoles, roleBoosters, channelBoosters, ...config } = body;
      
      const guild = await tx.guild.update({
        where: { id: guildId },
        data: config,
      });

      // 2. Sync level roles
      if (levelRoles && Array.isArray(levelRoles)) {
        await tx.levelRole.deleteMany({ where: { guildId } });
        if (levelRoles.length > 0) {
          await tx.levelRole.createMany({
            data: levelRoles.map((lr: any) => ({
              guildId,
              level: parseInt(lr.level),
              roleId: lr.roleId
            }))
          });
        }
      }

      // 3. Sync role boosters
      if (roleBoosters && Array.isArray(roleBoosters)) {
        await tx.roleBooster.deleteMany({ where: { guildId } });
        if (roleBoosters.length > 0) {
          await tx.roleBooster.createMany({
            data: roleBoosters.map((rb: any) => ({
              guildId,
              roleId: rb.roleId,
              percentage: parseInt(rb.percentage)
            }))
          });
        }
      }

      // 4. Sync channel boosters
      if (channelBoosters && Array.isArray(channelBoosters)) {
        await tx.channelBooster.deleteMany({ where: { guildId } });
        if (channelBoosters.length > 0) {
          await tx.channelBooster.createMany({
            data: channelBoosters.map((cb: any) => ({
              guildId,
              channelId: cb.channelId,
              percentage: parseInt(cb.percentage)
            }))
          });
        }
      }

      return guild;
    });

    return NextResponse.json({ success: true, guild: updatedGuild });

  } catch (error) {
    console.error("[LEVELS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
