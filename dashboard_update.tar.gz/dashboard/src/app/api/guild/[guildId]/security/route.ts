import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const body = await req.json();
  const { enabled, categories, config: configData } = body;

  try {
    // 1. Update Guild level toggles
    await prisma.guild.update({
      where: { id: guildId },
      data: {
        antiNukeEnabled: enabled,
        ...categories
      }
    });

    // 2. Update/Create AntiNukeConfig
    const config = await prisma.antiNukeConfig.upsert({
      where: { guildId },
      update: {
        ...configData
      },
      create: {
        guildId,
        ...configData
      }
    });

    return NextResponse.json({ success: true, config });
  } catch (error) {
    console.error("[SECURITY_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
