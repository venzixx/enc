import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getGuild } from "@/lib/discord";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { field, value } = body;

    const updatedGuild = await prisma.guild.update({
      where: { id: guildId },
      data: { [field]: value },
    });

    return NextResponse.json(updatedGuild);
  } catch (error) {
    console.error("[GUILD_CONFIG_PATCH]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const [guild, discordGuild] = await Promise.all([
      prisma.guild.findUnique({
        where: { id: guildId },
        include: { 
          antiNukeConfig: true,
          autoModFilters: true
        }
      }),
      getGuild(guildId)
    ]);

    return NextResponse.json({
      ...guild,
      name: discordGuild?.name || "Unknown Server",
      icon: discordGuild?.icon 
        ? `https://cdn.discordapp.com/icons/${guildId}/${discordGuild.icon}.png` 
        : null
    });
  } catch (error) {
    console.error("[GUILD_CONFIG_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
