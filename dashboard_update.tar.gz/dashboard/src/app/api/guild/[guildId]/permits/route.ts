import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const body = await req.json();
  const { targetId, type, permissions, immunity } = body;

  try {
    const permit = await prisma.permit.upsert({
      where: { 
        guildId_targetId: { guildId, targetId } 
      },
      update: {
        permissions: JSON.stringify(permissions),
        immunity,
        type
      },
      create: {
        guildId,
        targetId,
        type,
        permissions: JSON.stringify(permissions),
        immunity
      }
    });

    return NextResponse.json(permit);
  } catch (error) {
    console.error("[PERMITS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
