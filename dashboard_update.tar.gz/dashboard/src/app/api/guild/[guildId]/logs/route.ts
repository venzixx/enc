import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const query = searchParams.get("query") || "";
    const type = searchParams.get("type") || "All";
    const date = searchParams.get("date");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    // Architect the Search Manifest
    const where: any = {
      guildId: guildId,
    };

    if (type !== "All") {
      where.type = type.toUpperCase();
    }

    if (date) {
      const start = new Date(date);
      start.setHours(0, 0, 0, 0);
      const end = new Date(date);
      end.setHours(23, 59, 59, 999);
      
      where.createdAt = {
        gte: start,
        lte: end
      };
    }

    if (query) {
      where.OR = [
        { executorId: { contains: query } },
        { executorTag: { contains: query } },
        { targetId: { contains: query } },
        { targetName: { contains: query } },
        { event: { contains: query } },
        { details: { contains: query } }
      ];
    }

    const logs = await prisma.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: limit,
      skip: offset,
    });

    const total = await prisma.auditLog.count({ where });

    console.log(`[LOGS_TRACE] Manifested ${logs.length} logs for guild ${guildId} (Total: ${total})`);

    return NextResponse.json({
      logs,
      total,
      hasMore: offset + limit < total
    });
  } catch (error) {
    console.error("[LOGS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { guildId } = await params;

    await prisma.auditLog.deleteMany({
      where: { guildId },
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("Failed to clear logs:", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
