import { sendDiscordMessage } from "@/lib/discord";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  try {
    const body = await req.json();
    const { channelId, payload } = body;

    if (!channelId || !payload) {
      return new NextResponse("Missing channelId or payload", { status: 400 });
    }

    const success = await sendDiscordMessage(channelId, payload);
    
    if (success) {
      return NextResponse.json({ success: true });
    } else {
      return new NextResponse("Failed to dispatch message", { status: 500 });
    }
  } catch (error) {
    console.error("[DISPATCH_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
