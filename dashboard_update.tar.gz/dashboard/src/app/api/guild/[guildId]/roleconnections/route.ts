import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const connections = await prisma.roleConnection.findMany({
      where: { guildId }
    });

    return NextResponse.json(connections);
  } catch (error) {
    console.error("[ROLE_CONNECTIONS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const body = await req.json();
    const { triggerRoleId, connectedRoleIds } = body;

    if (!triggerRoleId || !Array.isArray(connectedRoleIds)) {
      return new NextResponse("Invalid Request", { status: 400 });
    }

    // Create connections for each connected role
    const data = connectedRoleIds.map((connectedRoleId: string) => ({
      guildId,
      triggerRoleId,
      connectedRoleId
    }));

    // Use createMany if supported, or multiple upserts
    // For simplicity and since we want to avoid duplicates:
    await Promise.all(data.map((item: any) => 
      prisma.roleConnection.upsert({
        where: {
          guildId_triggerRoleId_connectedRoleId: {
            guildId: item.guildId,
            triggerRoleId: item.triggerRoleId,
            connectedRoleId: item.connectedRoleId
          }
        },
        update: {},
        create: item
      })
    ));

    return new NextResponse("Success", { status: 200 });
  } catch (error) {
    console.error("[ROLE_CONNECTIONS_POST]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  try {
    const { guildId } = await params;
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const triggerRoleId = searchParams.get("triggerRoleId");
    const connectedRoleId = searchParams.get("connectedRoleId");

    if (!triggerRoleId || !connectedRoleId) {
      return new NextResponse("Missing parameters", { status: 400 });
    }

    await prisma.roleConnection.delete({
      where: {
        guildId_triggerRoleId_connectedRoleId: {
          guildId,
          triggerRoleId,
          connectedRoleId
        }
      }
    });

    return new NextResponse("Success", { status: 200 });
  } catch (error) {
    console.error("[ROLE_CONNECTIONS_DELETE]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
