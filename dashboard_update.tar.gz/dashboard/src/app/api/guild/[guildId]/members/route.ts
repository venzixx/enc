import { searchGuildMembers } from "@/lib/discord";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ guildId: string }> }
) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) return new NextResponse("Unauthorized", { status: 401 });

  const { searchParams } = new URL(req.url);
  const query = searchParams.get("query");

  if (!query) return NextResponse.json([]);

  try {
    const members = await searchGuildMembers(guildId, query);
    return NextResponse.json(members);
  } catch (error) {
    console.error("[MEMBERS_SEARCH_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
