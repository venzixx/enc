import { NextRequest, NextResponse } from "next/server";

/**
 * API Route: /api/bot-stats
 * Fetches real bot statistics from Discord
 * 
 * Returns:
 * - guilds: number of servers the bot is in
 * - users: total members across all servers
 * - latency: bot's current latency in ms
 * - uptime: bot's uptime in ms
 * - commands: total number of commands
 */

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    // Get bot stats from environment or stored metrics
    // In a real setup, you'd connect to your bot's process or use a webhook/IPC
    
    // For now, return placeholder that can be updated by the bot
    const stats = {
      guilds: parseInt(process.env.BOT_GUILDS || "0") || 0,
      users: parseInt(process.env.BOT_USERS || "0") || 0,
      latency: parseInt(process.env.BOT_LATENCY || "0") || 0,
      uptime: parseInt(process.env.BOT_UPTIME || "0") || 0,
      commands: 81, // Total number of commands in your bot
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(stats, {
      status: 200,
      headers: {
        "Cache-Control": "no-store, max-age=0", // No caching for fresh data
      },
    });
  } catch (error) {
    console.error("Failed to fetch bot stats:", error);
    return NextResponse.json(
      {
        error: "Failed to fetch bot statistics",
        guilds: 0,
        users: 0,
        latency: 0,
        commands: 81,
      },
      { status: 500 }
    );
  }
}
