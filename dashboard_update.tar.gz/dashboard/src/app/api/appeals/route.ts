import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(req: Request) {
  try {
    const session: any = await getServerSession(authOptions);

    if (!session) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    // List all appeals by the current user
    const appeals = await prisma.appeal.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(appeals);
  } catch (error) {
    console.error("[MY_APPEALS_GET]", error);
    return new NextResponse("Internal Error", { status: 500 });
  }
}
