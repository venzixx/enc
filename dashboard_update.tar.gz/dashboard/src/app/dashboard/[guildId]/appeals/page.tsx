import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import AppealsManager from "@/components/AppealsManager";

export const dynamic = "force-dynamic";

export default async function AppealsPage({
  params,
}: {
  params: Promise<{ guildId: string }>;
}) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  // Fetch appeals for this guild
  const appeals = await prisma.appeal.findMany({
    where: { guildId },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-10 max-w-7xl mx-auto space-y-10 pb-32">
      <div className="space-y-4">
         <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">Appeals Management</h1>
         <p className="text-white/20 text-xs font-bold uppercase tracking-[0.4em]">Review and process user sanction review requests</p>
      </div>

      <AppealsManager 
        guildId={guildId} 
        initialAppeals={JSON.parse(JSON.stringify(appeals))} 
      />
    </div>
  );
}
