import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getGuild } from "@/lib/discord";
import AppealSubmission from "@/components/AppealSubmission";

export const dynamic = "force-dynamic";

export default async function SubmitAppealPage({
  params,
}: {
  params: Promise<{ guildId: string }>;
}) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guild = await getGuild(guildId);

  return (
    <div className="p-10 max-w-7xl mx-auto space-y-10 pb-32">
      <AppealSubmission 
        guildId={guildId} 
        guildName={guild?.name || "the server"} 
      />
    </div>
  );
}
