import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap } from "lucide-react";
import SecurityHub from "@/components/SecurityHub";

export default async function SecurityPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
    include: { antiNukeConfig: true }
  });

  if (!guildData) return redirect(`/dashboard`);

  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-12">
      <header className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
          <Zap className="w-3 h-3" /> Security Settings
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Security</h1>
        <p className="text-sm text-white/30 max-w-2xl font-medium leading-relaxed">
          Configure anti-nuke thresholds and automated protection protocols for your server.
        </p>
      </header>

      <SecurityHub guildId={guildId} initialData={guildData} />
    </main>
  );
}
