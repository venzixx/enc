'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  BarChart3, Plus, Trash2, Send, Activity, Sparkles, ArrowUpRight, Hash, Type, ListTree, Archive,
  Settings2, Clock, CheckSquare, Check, Calendar, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function PollsPage() {
  const { guildId } = useParams();
  const [question, setQuestion] = useState('Should we organize a community event next week?');
  const [options, setOptions] = useState(['Yes, count me in', 'Maybe later', 'No, I am busy']);
  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  const [selectedChannel, setSelectedChannel] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });
  
  // Native Poll Features
  const [allowMultiselect, setAllowMultiselect] = useState(false);
  const [duration, setDuration] = useState(24); // hours

  useEffect(() => {
    if (!guildId) return;
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data))
      .catch(console.error);
  }, [guildId]);

  const addOption = () => {
    if (options.length < 10) setOptions([...options, `Option ${options.length + 1}`]);
  };

  const removeOption = (idx: number) => {
    if (options.length > 2) {
      const newOpts = [...options];
      newOpts.splice(idx, 1);
      setOptions(newOpts);
    }
  };

  const updateOption = (idx: number, val: string) => {
    const newOpts = [...options];
    newOpts[idx] = val;
    setOptions(newOpts);
  };

  const handleDispatch = async () => {
    if (!selectedChannel || !question || options.length < 2) return;
    setIsSending(true);
    setStatusMsg({ text: 'Creating native poll...', type: 'info' });
    
    try {
      const payload = {
        poll: {
          question: { text: question },
          answers: options.filter(opt => opt.trim().length > 0).map(opt => ({
            poll_media: { text: opt }
          })),
          allow_multiselect: allowMultiselect,
          duration: duration,
          layout_type: 1
        }
      };

      const res = await fetch(`/api/guild/${guildId}/dispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          channelId: selectedChannel,
          payload
        })
      });

      if (res.ok) {
        setStatusMsg({ text: 'Native poll successfully deployed.', type: 'success' });
        setTimeout(() => setStatusMsg({ text: '', type: '' }), 5000);
      } else {
        const errorData = await res.text();
        throw new Error(errorData || 'Failed to send');
      }
    } catch (err: any) {
      console.error(err);
      setStatusMsg({ text: `Error: ${err.message || 'Could not send poll.'}`, type: 'error' });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-12">
      <header className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
          <BarChart3 className="w-3 h-3" /> Community Engagement
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Polls</h1>
        <p className="text-sm text-white/30 max-w-md font-medium leading-relaxed">
          Create interactive polls to gather feedback from your community members.
        </p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10 items-start">
        {/* ── CONSTRUCTOR ── */}
        <div className="xl:col-span-7 space-y-8">
           <section className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] space-y-8">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                    <Type className="w-4 h-4 text-white/60" />
                 </div>
                 <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">Poll Question</h3>
              </div>
              <div className="space-y-4">
                 <textarea 
                    rows={3}
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-2xl text-white/80 font-medium text-sm outline-none focus:border-white/20 transition-all resize-none"
                    placeholder="Enter your question here..."
                 />
              </div>
           </section>

           <section className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] space-y-8">
              <div className="flex items-center justify-between gap-4">
                 <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                       <ListTree className="w-4 h-4 text-white/60" />
                    </div>
                    <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">Options</h3>
                 </div>
                 <button onClick={addOption} className="text-[10px] font-bold text-white hover:text-white/60 transition-all uppercase tracking-widest bg-white/5 px-4 py-2 rounded-xl border border-white/5">Add Option</button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                 {options.map((opt, i) => (
                    <div key={i} className="flex items-center gap-4 bg-white/[0.02] border border-white/5 p-4 rounded-2xl group transition-all hover:border-white/10">
                       <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[10px] font-bold text-white/20">{i+1}</div>
                       <input 
                          value={opt}
                          onChange={(e) => updateOption(i, e.target.value)}
                          className="flex-1 bg-transparent border-none outline-none text-sm text-white/60 focus:text-white transition-colors font-medium"
                       />
                       <button onClick={() => removeOption(i)} className="text-white/10 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 p-2"><Trash2 className="w-4 h-4" /></button>
                    </div>
                 ))}
              </div>
           </section>

           <section className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] space-y-8">
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
                    <Settings2 className="w-4 h-4 text-white/60" />
                 </div>
                 <h3 className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/60">Poll Configuration</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div className="space-y-4">
                    <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-2">
                       <Clock className="w-3 h-3" /> Expiration Period
                    </label>
                    <SurgicalDropdown 
                      options={[
                        { id: '1', name: '1 Hour' },
                        { id: '4', name: '4 Hours' },
                        { id: '8', name: '8 Hours' },
                        { id: '24', name: '24 Hours' },
                        { id: '72', name: '3 Days' },
                        { id: '168', name: '1 Week' }
                      ]}
                      value={duration.toString()}
                      onChange={(val) => setDuration(parseInt(val))}
                      placeholder="Select duration"
                    />
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex items-center gap-2">
                       <CheckSquare className="w-3 h-3" /> Interaction Mode
                    </label>
                    <div 
                      onClick={() => setAllowMultiselect(!allowMultiselect)}
                      className={`flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all ${allowMultiselect ? 'bg-white/5 border-white/20 text-white' : 'bg-transparent border-white/5 text-white/30'}`}
                    >
                       <span className="text-[11px] font-bold uppercase tracking-widest">Multiple Choices</span>
                       {allowMultiselect ? <Check className="w-4 h-4 text-emerald-400" /> : <div className="w-4 h-4 border border-white/10 rounded-md" />}
                    </div>
                 </div>
              </div>
           </section>
        </div>

        {/* ── DISPATCH & PREVIEW ── */}
        <div className="xl:col-span-5 space-y-10">
           <section className="bg-white/[0.01] border border-white/5 p-8 rounded-[32px] space-y-8">
              <SurgicalDropdown 
                label="Target Channel"
                options={channels}
                value={selectedChannel}
                onChange={setSelectedChannel}
                placeholder="Select a channel..."
                icon={<Hash className="w-3 h-3" />}
              />
              
              <button 
                onClick={handleDispatch}
                disabled={!selectedChannel || isSending}
                className={`w-full py-5 rounded-2xl flex items-center justify-center gap-3 text-[11px] font-bold uppercase tracking-[0.2em] transition-all shadow-xl ${selectedChannel ? 'bg-white text-black hover:bg-zinc-200' : 'bg-white/5 text-white/10 border border-white/5 cursor-not-allowed'}`}
              >
                 {isSending ? <Sparkles className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                 {isSending ? "Processing..." : "Create Poll"}
              </button>

              <AnimatePresence>
                 {statusMsg.text && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className={`text-[10px] font-bold uppercase tracking-widest text-center ${statusMsg.type === 'error' ? 'text-red-500' : statusMsg.type === 'success' ? 'text-emerald-500' : 'text-blue-400'}`}
                    >
                       {statusMsg.text}
                    </motion.div>
                 )}
              </AnimatePresence>
           </section>

           <div className="space-y-4">
              <div className="flex items-center justify-between px-2">
                 <span className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">Preview</span>
                 <Archive className="w-3.5 h-3.5 text-white/10" />
              </div>

              <div className="bg-[#111214] rounded-[24px] p-6 border border-white/5">
                 <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-zinc-800 shrink-0 border border-white/5 flex items-center justify-center text-[10px] font-black text-white/40 uppercase">ENC</div>
                    <div className="flex-1 min-w-0">
                       <div className="flex items-center gap-2 mb-4">
                          <span className="font-bold text-white text-[14px]">Enc Nexus</span>
                          <span className="bg-[#5865F2] text-[9px] px-1.5 py-0.5 rounded-sm text-white font-bold h-fit">BOT</span>
                       </div>

                       {/* Native Poll UI Mockup */}
                       <div className="bg-[#1e1f22] rounded-xl border border-white/[0.03] p-5 space-y-5 overflow-hidden">
                          <div className="flex items-start gap-3">
                             <BarChart3 className="w-5 h-5 text-zinc-500 mt-1" />
                             <div className="space-y-1">
                                <h4 className="text-white font-bold text-[15px] leading-tight">{question}</h4>
                                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
                                   {allowMultiselect ? "Select one or more options" : "Select one option"}
                                </p>
                             </div>
                          </div>

                          <div className="space-y-2">
                             {options.filter(o => o.trim()).map((opt, i) => (
                                <div key={i} className="relative group overflow-hidden rounded-md border border-white/[0.05] bg-white/[0.02] p-3 flex items-center justify-between hover:bg-white/[0.04] transition-all cursor-pointer">
                                   <span className="text-[13px] text-zinc-300 font-medium relative z-10">{opt}</span>
                                   <div className="w-4 h-4 rounded-full border border-white/10 group-hover:border-white/30 relative z-10" />
                                </div>
                             ))}
                          </div>

                          <div className="flex items-center justify-between pt-2">
                             <span className="text-[11px] text-zinc-500 font-bold uppercase tracking-widest">0 votes · Expires in {duration >= 24 ? `${duration/24}d` : `${duration}h`}</span>
                             <div className="flex items-center gap-1.5 text-[#5865F2] text-[11px] font-bold uppercase tracking-widest group cursor-pointer hover:text-white transition-colors">
                                Vote <ChevronRight className="w-3.5 h-3.5" />
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </main>
  );
}
