import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap } from "lucide-react";
import { getGuildRoles } from "@/lib/discord";
import RoleConnectionsManager from "@/components/RoleConnectionsManager";

export default async function RoleConnectionsPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const [connections, roles] = await Promise.all([
    prisma.roleConnection.findMany({ where: { guildId } }),
    getGuildRoles(guildId)
  ]);

  // Filter out @everyone and managed roles if desired, but for connections we might want all
  const filteredRoles = roles.filter(role => role.name !== "@everyone" && !role.managed);

  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-12">
      <header className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-700">
          <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
            <Zap className="w-3 h-3" /> Utility Modules
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Role Connections</h1>
          <p className="text-sm text-white/30 max-w-2xl font-medium leading-relaxed">
            Link roles together so that when a member receives a specific role, they automatically get the connected roles as well.
          </p>
      </header>

      <RoleConnectionsManager 
        guildId={guildId} 
        initialConnections={connections} 
        roles={filteredRoles} 
      />
    </main>
  );
}
