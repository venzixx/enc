import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import LogsFeed from "@/components/LogsFeed";

export default async function AuditLogs({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) {
    redirect("/");
  }

  return (
    <main className="p-8 md:p-16 uppercase font-sans">
      <LogsFeed guildId={guildId} />
    </main>
  );
}
