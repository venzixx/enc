import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import {
  Shield, Zap, Users, Activity, ExternalLink
} from "lucide-react";
import ConsoleSector from "@/components/ConsoleSector";
import LoggingSector from "@/components/LoggingSector";

export default async function GuildDashboard({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const guildData = await prisma.guild.findUnique({
    where: { id: guildId },
  });

  if (!guildData) {
    await prisma.guild.create({ data: { id: guildId } });
    return redirect(`/dashboard/${guildId}`);
  }

  const memberCount = await prisma.member.count({ where: { guildId } });

  const stats = [
    { label: "Bans", value: "0", icon: <Shield className="w-3 h-3" /> },
    { label: "Members", value: memberCount.toLocaleString(), icon: <Users className="w-3 h-3" /> },
    { label: "Uptime", value: "99.9%", icon: <Activity className="w-3 h-3" /> },
  ];

  return (
    <div className="p-4 md:p-6 space-y-12">
      {/* ── HEADER ── */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-10">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
            <Zap className="w-3 h-3" /> Overview
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Dashboard</h1>
          <p className="text-sm text-white/30 max-w-md font-medium leading-relaxed">
            Monitor your server statistics and manage core security modules in real-time.
          </p>
        </div>

        <div className="flex flex-wrap gap-12">
          {stats.map((stat, idx) => (
            <div key={idx} className="flex flex-col gap-1.5 group/stat">
              <div className="flex items-center gap-2 text-[10px] font-bold text-white/10 uppercase tracking-[0.2em] group-hover/stat:text-white/20 transition-colors">
                {stat.icon}
                <span>{stat.label}</span>
              </div>
              <div className="text-2xl font-bold text-white/80 tracking-tight">
                {stat.value}
              </div>
            </div>
          ))}
        </div>
      </header>

      <div className="space-y-16">
        <div>
           <div className="flex items-center gap-3 mb-8">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Security Modules</h2>
           </div>
           <ConsoleSector guildId={guildId} initialData={guildData} />
        </div>
        
        <div className="pt-8 border-t border-white/[0.03]">
           <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                 <div className="w-2 h-2 rounded-full bg-emerald-500" />
                 <h2 className="text-[10px] font-bold text-white/20 uppercase tracking-[0.4em]">Recent Activity</h2>
              </div>
              <button className="text-[10px] font-bold text-white/10 hover:text-white/40 transition-all uppercase tracking-widest flex items-center gap-2">View Full Logs <ExternalLink className="w-3 h-3" /></button>
           </div>
           <LoggingSector guildId={guildId} initialData={guildData} />
        </div>
      </div>
    </div>
  );
}
