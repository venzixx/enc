'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  Plus, Trash2, Code, Type, Palette, Layout, Sparkles, 
  Hash, Send, FileText, Eye, Copy, Download, User as UserIcon,
  MessageSquare, Settings, Info, Calendar, Clock, Smile, ExternalLink,
  MousePointer2, ListFilter, ShieldCheck, ChevronRight, Activity, Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';
import { parseColor } from '@/lib/utils';

interface EmbedField {
  name: string;
  value: string;
  inline: boolean;
}

interface ButtonData {
  style: 'PRIMARY' | 'SECONDARY' | 'SUCCESS' | 'DANGER' | 'LINK';
  label: string;
  url?: string;
  custom_id?: string;
  emoji?: string;
  disabled: boolean;
}

interface SelectOption {
  label: string;
  value: string;
  description?: string;
  emoji?: string;
  default: boolean;
}

interface SelectMenu {
  custom_id: string;
  placeholder: string;
  options: SelectOption[];
  disabled: boolean;
}

interface EmbedData {
  content: string;
  title: string;
  description: string;
  url: string;
  color: string;
  timestamp: boolean;
  footer: { text: string; icon_url: string; };
  thumbnail: { url: string; };
  image: { url: string; };
  author: { name: string; url: string; icon_url: string; };
  fields: EmbedField[];
  buttons: ButtonData[];
  selectMenus: SelectMenu[];
  ephemeral: boolean;
  isV2: boolean;
}

const TABS = ['Body', 'Author', 'Footer', 'Images', 'Fields', 'Buttons', 'Select', 'Extras'];

const BUTTON_STYLES = [
  { id: 'PRIMARY', label: 'Blurple', color: 'bg-[#5865F2]' },
  { id: 'SECONDARY', label: 'Grey', color: 'bg-[#4e5058]' },
  { id: 'SUCCESS', label: 'Green', color: 'bg-[#248046]' },
  { id: 'DANGER', label: 'Red', color: 'bg-[#da373c]' },
  { id: 'LINK', label: 'Link', color: 'bg-zinc-700' },
];

const VARIABLES = [
  { group: 'User', items: [
    { name: '{user}', desc: 'User#Tag' },
    { name: '{user.id}', desc: 'User ID' },
    { name: '{user.name}', desc: 'Username' },
    { name: '{user.mention}', desc: 'User mention' },
  ]},
  { group: 'Server', items: [
    { name: '{server}', desc: 'Server Name' },
    { name: '{server.id}', desc: 'Server ID' },
    { name: '{server.member_count}', desc: 'Member Count' },
  ]},
];

export default function MessagesPage() {
  const { guildId } = useParams();
  const [activeTab, setActiveTab] = useState('Body');
  const [embed, setEmbed] = useState<EmbedData>({
    content: '',
    title: '',
    description: '',
    url: '',
    color: '#ffffff',
    timestamp: false,
    footer: { text: '', icon_url: '' },
    thumbnail: { url: '' },
    image: { url: '' },
    author: { name: '', url: '', icon_url: '' },
    fields: [],
    buttons: [],
    selectMenus: [],
    ephemeral: false,
    isV2: false
  });

  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  const [emojis, setEmojis] = useState<{id: string, name: string, animated: boolean}[]>([]);
  const [selectedChannel, setSelectedChannel] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });

  useEffect(() => {
    if (!guildId) return;
    
    // Fetch Channels
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data.filter((c: any) => c.type === 0 || c.type === 5)))
      .catch(console.error);

    // Fetch Emojis
    fetch(`/api/guild/${guildId}/emojis`)
      .then(r => r.json())
      .then(data => setEmojis(data))
      .catch(console.error);
  }, [guildId]);

  const addField = () => {
    if (embed.fields.length < 25) {
      setEmbed({ ...embed, fields: [...embed.fields, { name: '', value: '', inline: false }] });
    }
  };

  const removeField = (index: number) => {
    const newFields = [...embed.fields];
    newFields.splice(index, 1);
    setEmbed({ ...embed, fields: newFields });
  };

  const addButton = () => {
    if (embed.buttons.length < 5) {
      setEmbed({ ...embed, buttons: [...embed.buttons, { style: 'PRIMARY', label: 'New Button', custom_id: `btn_${Date.now()}`, disabled: false }] });
    }
  };

  const removeButton = (index: number) => {
    const newButtons = [...embed.buttons];
    newButtons.splice(index, 1);
    setEmbed({ ...embed, buttons: newButtons });
  };

  const updateField = (index: number, key: string, value: any) => {
    const newFields = [...embed.fields];
    (newFields[index] as any)[key] = value;
    setEmbed({ ...embed, fields: newFields });
  };

  const addSelectMenu = () => {
    if (embed.selectMenus.length < 1) {
      setEmbed({ ...embed, selectMenus: [{ custom_id: `select_${Date.now()}`, placeholder: 'Select an option...', options: [], disabled: false }] });
    }
  };

  const addSelectOption = (menuIdx: number) => {
    const newMenus = [...embed.selectMenus];
    if (newMenus[menuIdx].options.length < 25) {
      newMenus[menuIdx].options.push({ label: 'Option', value: 'value', default: false });
      setEmbed({ ...embed, selectMenus: newMenus });
    }
  };

  const handleDispatch = async () => {
    if (!selectedChannel) return;
    setIsSending(true);
    setStatusMsg({ text: 'Dispatching message...', type: 'info' });
    
    try {
      const colorInt = parseColor(embed.color);
      
      // Standard Payload
      let finalPayload: any = {
        content: embed.content || undefined,
        embeds: [],
        components: []
      };

      if (!embed.isV2) {
        // --- V1 Standard Embed ---
        const cleanEmbed = {
          title: embed.title || undefined,
          description: embed.description || undefined,
          url: embed.url || undefined,
          color: colorInt,
          fields: embed.fields.length > 0 ? embed.fields : undefined,
          image: embed.image.url ? { url: embed.image.url } : undefined,
          thumbnail: embed.thumbnail.url ? { url: embed.thumbnail.url } : undefined,
          author: embed.author.name ? embed.author : undefined,
          footer: embed.footer.text ? embed.footer : undefined,
          timestamp: embed.timestamp ? new Date().toISOString() : undefined
        };
        finalPayload.embeds = [cleanEmbed];
      } else {
        // --- V2 Container Layout (Type 17) ---
        const banner = embed.image.url;
        const thumbnail = embed.thumbnail.url;
        const primaryContent = (embed.title ? `### ${embed.title}\n` : "") + (embed.description || "");

        const container: any = {
          type: 17,
          accent_color: colorInt,
          components: []
        };

        if (banner) {
          container.components.push({
            type: 12,
            items: [{ media: { url: banner } }]
          });
        }

        if (thumbnail) {
          container.components.push({
            type: 9,
            components: [{ type: 10, content: primaryContent || "\u200b" }],
            accessory: { type: 11, media: { url: thumbnail } }
          });
        } else if (primaryContent) {
          container.components.push({ type: 10, content: primaryContent });
        }

        if (embed.fields.length > 0) {
          container.components.push({
            type: 10,
            content: embed.fields.map(f => `**${f.name}**: ${f.value}`).join("\n")
          });
        }

        if (embed.footer.text) {
          container.components.push({ type: 10, content: `-# ${embed.footer.text}` });
        }

        finalPayload.components.push(container);
        finalPayload.flags = embed.ephemeral ? (1 << 6 | 1 << 12) : (1 << 12); // Ephemeral | IsComponentsV2
      }

      // --- Map Components (Buttons & Selects) ---
      // For V1, these go in standard ActionRows. For V2, they can stay in the same container or separate rows.
      // V2Helper puts them in the same container. I'll follow that for V2.
      
      const componentRows: any[] = [];
      
      // Buttons (Max 5 per row)
      if (embed.buttons.length > 0) {
        for (let i = 0; i < embed.buttons.length; i += 5) {
          const chunk = embed.buttons.slice(i, i + 5);
          const row = {
            type: 1,
            components: chunk.map(btn => {
              const discordBtn: any = {
                type: 2,
                style: btn.style === 'PRIMARY' ? 1 : 
                       btn.style === 'SECONDARY' ? 2 : 
                       btn.style === 'SUCCESS' ? 3 : 
                       btn.style === 'DANGER' ? 4 : 5,
                label: btn.label,
                disabled: btn.disabled
              };
              
              if (btn.style === 'LINK') discordBtn.url = btn.url;
              else discordBtn.custom_id = btn.custom_id;

              if (btn.emoji) {
                const match = btn.emoji.match(/<a?:(\w+):(\d+)>/);
                if (match) discordBtn.emoji = { name: match[1], id: match[2], animated: btn.emoji.startsWith('<a:') };
                else discordBtn.emoji = { name: btn.emoji };
              }
              
              return discordBtn;
            })
          };
          
          if (embed.isV2) (finalPayload.components[0] as any).components.push(row);
          else componentRows.push(row);
        }
      }

      // Select Menu (1 per row)
      if (embed.selectMenus.length > 0) {
        embed.selectMenus.forEach(menu => {
          const row = {
            type: 1,
            components: [{
              type: 3,
              custom_id: menu.custom_id,
              placeholder: menu.placeholder,
              disabled: menu.disabled,
              options: menu.options.map(opt => {
                const discordOpt: any = {
                  label: opt.label,
                  value: opt.value,
                  description: opt.description,
                  default: opt.default
                };
                if (opt.emoji) {
                   const match = opt.emoji.match(/<a?:(\w+):(\d+)>/);
                   if (match) discordOpt.emoji = { name: match[1], id: match[2], animated: opt.emoji.startsWith('<a:') };
                   else discordOpt.emoji = { name: opt.emoji };
                }
                return discordOpt;
              })
            }]
          };
          if (embed.isV2) (finalPayload.components[0] as any).components.push(row);
          else componentRows.push(row);
        });
      }

      if (!embed.isV2) {
        finalPayload.components = componentRows;
        if (embed.ephemeral) finalPayload.flags = 1 << 6; // Ephemeral
      }

      const res = await fetch(`/api/guild/${guildId}/dispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          channelId: selectedChannel,
          payload: finalPayload
        })
      });

      if (res.ok) {
        setStatusMsg({ text: 'Message delivered successfully.', type: 'success' });
        setTimeout(() => setStatusMsg({ text: '', type: '' }), 5000);
      } else {
        throw new Error('Delivery failed');
      }
    } catch (err) {
      console.error(err);
      setStatusMsg({ text: 'Error: Message delivery failed.', type: 'error' });
    } finally {
      setIsSending(false);
    }
  };

  const copyScript = () => {
    const script = JSON.stringify({
      content: embed.content,
      embeds: [{
        title: embed.title,
        description: embed.description,
        color: parseInt(embed.color.replace('#', ''), 16),
        footer: embed.footer.text ? embed.footer : undefined,
        author: embed.author.name ? embed.author : undefined,
        image: embed.image.url ? embed.image : undefined,
        thumbnail: embed.thumbnail.url ? embed.thumbnail : undefined,
        fields: embed.fields.length ? embed.fields : undefined,
        timestamp: embed.timestamp ? new Date().toISOString() : undefined
      }]
    }, null, 2);
    navigator.clipboard.writeText(script);
    setStatusMsg({ text: 'Script copied to clipboard', type: 'success' });
    setTimeout(() => setStatusMsg({ text: '', type: '' }), 3000);
  };

  return (
    <main className="min-h-screen bg-[#050508] p-8 md:p-12 max-w-[1700px] mx-auto space-y-12 animate-in fade-in duration-1000">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
             <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
             <span className="text-[10px] font-bold text-white/40 uppercase tracking-[0.4em]">Communications</span>
          </div>
          <h1 className="text-5xl font-black text-white uppercase tracking-tighter leading-none">Embed Builder</h1>
          <p className="text-sm text-white/30 font-medium max-w-xl">
             Design and dispatch high-fidelity interactive messages to your community channels.
          </p>
        </div>
        
        <div className="flex items-center gap-4">
           <button 
             onClick={copyScript}
             className="px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-bold text-white/60 hover:text-white hover:bg-white/10 uppercase tracking-widest transition-all flex items-center gap-2"
           >
             <Code className="w-4 h-4" /> Copy JSON
           </button>
           <button 
             onClick={handleDispatch}
             disabled={!selectedChannel || isSending}
             className={`px-10 py-4 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all flex items-center gap-3 shadow-2xl ${
               selectedChannel 
                 ? 'bg-white text-black hover:bg-zinc-200 shadow-[0_0_40px_rgba(255,255,255,0.05)]' 
                 : 'bg-white/5 text-white/10 cursor-not-allowed border border-white/5'
             }`}
           >
              {isSending ? <Sparkles className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {isSending ? "Processing..." : "Dispatch"}
           </button>
        </div>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-12 items-start">
        {/* Left Column: Editor */}
        <div className="space-y-10">
           <section className="bg-white/[0.01] border border-white/5 rounded-[32px] overflow-hidden shadow-2xl">
              <div className="px-10 py-8 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
                 <div className="flex items-center gap-4">
                    <div className="p-2.5 bg-white/5 rounded-xl border border-white/10">
                       <Layout className="w-4 h-4 text-white/60" />
                    </div>
                    <span className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">Visual Composer</span>
                 </div>
              </div>

              <div className="p-10 space-y-10">
                 {/* Select Channel */}
                 <SurgicalDropdown 
                    label="Destination Channel"
                    options={channels}
                    value={selectedChannel}
                    onChange={setSelectedChannel}
                    placeholder="Choose a channel for dispatch..."
                    icon={<Hash className="w-3.5 h-3.5" />}
                 />

                 {/* Message Content */}
                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Plain Content</label>
                       <span className="text-[10px] text-white/10 font-bold tracking-widest">{embed.content.length}/2000</span>
                    </div>
                    <textarea 
                       className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-[14px] text-white placeholder:text-white/5 outline-none focus:border-white/10 transition-all resize-none min-h-[140px] font-medium"
                       placeholder="Message content above the embed..."
                       value={embed.content}
                       onChange={(e) => setEmbed({...embed, content: e.target.value})}
                    />
                 </div>

                 {/* Tab Navigation */}
                 <div className="flex flex-wrap gap-4 pb-6 border-b border-white/5">
                    {TABS.map(tab => (
                       <button 
                         key={tab} 
                         onClick={() => setActiveTab(tab)}
                         className={`px-6 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${
                           activeTab === tab 
                             ? 'bg-white text-black' 
                             : 'text-white/20 hover:text-white/40 hover:bg-white/5'
                         }`}
                       >
                          {tab}
                       </button>
                    ))}
                 </div>

                 {/* Tab Content Area */}
                 <div className="min-h-[450px]">
                    <AnimatePresence mode="wait">
                       <motion.div
                         key={activeTab}
                         initial={{ opacity: 0, x: -10 }}
                         animate={{ opacity: 1, x: 0 }}
                         exit={{ opacity: 0, x: 10 }}
                         transition={{ duration: 0.2 }}
                         className="space-y-6"
                       >
                          {activeTab === 'Body' && (
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                <div className="space-y-8">
                                   <div className="space-y-3">
                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Embed Title</label>
                                      <input 
                                        type="text" value={embed.title} onChange={(e) => setEmbed({...embed, title: e.target.value})}
                                        className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none focus:border-white/10 font-medium"
                                        placeholder="Enter title..."
                                      />
                                   </div>
                                   <div className="space-y-3">
                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Embed URL</label>
                                      <input 
                                        type="text" value={embed.url} onChange={(e) => setEmbed({...embed, url: e.target.value})}
                                        className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none focus:border-white/10 font-medium"
                                        placeholder="https://..."
                                      />
                                   </div>
                                </div>
                                <div className="space-y-8">
                                   <div className="space-y-4">
                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Accent Color</label>
                                      <div className="flex gap-4">
                                         <input type="color" value={embed.color} onChange={(e) => setEmbed({...embed, color: e.target.value})} className="bg-transparent border-none w-14 h-14 cursor-pointer rounded-2xl overflow-hidden" />
                                         <input type="text" value={embed.color} onChange={(e) => setEmbed({...embed, color: e.target.value})} className="flex-1 bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-xs font-bold text-white/40 tracking-[0.2em] outline-none" />
                                      </div>
                                   </div>
                                   <div className="pt-6 border-t border-white/5">
                                      <button 
                                        onClick={() => setEmbed({...embed, timestamp: !embed.timestamp})}
                                        className="w-full flex items-center justify-between p-5 bg-white/[0.01] border border-white/5 rounded-2xl hover:bg-white/[0.03] transition-all"
                                      >
                                         <span className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Include Timestamp</span>
                                         <div className={`w-10 h-5 rounded-full relative transition-all ${embed.timestamp ? 'bg-white' : 'bg-white/10'}`}>
                                            <div className={`absolute top-1 w-3 h-3 rounded-full transition-all ${embed.timestamp ? 'right-1 bg-black' : 'left-1 bg-white/40'}`} />
                                         </div>
                                      </button>
                                   </div>
                                </div>
                                <div className="md:col-span-2 space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Description</label>
                                   <textarea 
                                      value={embed.description} onChange={(e) => setEmbed({...embed, description: e.target.value})}
                                      className="w-full bg-white/[0.02] border border-white/5 p-6 rounded-3xl text-[14px] text-white outline-none focus:border-white/10 min-h-[180px] resize-none font-medium leading-relaxed"
                                      placeholder="Main embed text goes here..."
                                   />
                                </div>
                             </div>
                          )}

                          {activeTab === 'Author' && (
                             <div className="space-y-8 max-w-2xl">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                   <div className="space-y-3">
                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Author Name</label>
                                      <input type="text" value={embed.author.name} onChange={(e) => setEmbed({...embed, author: {...embed.author, name: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none" />
                                   </div>
                                   <div className="space-y-3">
                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Author URL</label>
                                      <input type="text" value={embed.author.url} onChange={(e) => setEmbed({...embed, author: {...embed.author, url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none" />
                                   </div>
                                </div>
                                <div className="space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Author Icon URL</label>
                                   <input type="text" value={embed.author.icon_url} onChange={(e) => setEmbed({...embed, author: {...embed.author, icon_url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none" />
                                </div>
                             </div>
                          )}

                          {activeTab === 'Footer' && (
                             <div className="space-y-8 max-w-2xl">
                                <div className="space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Footer Text</label>
                                   <input type="text" value={embed.footer.text} onChange={(e) => setEmbed({...embed, footer: {...embed.footer, text: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none" />
                                </div>
                                <div className="space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Footer Icon URL</label>
                                   <input type="text" value={embed.footer.icon_url} onChange={(e) => setEmbed({...embed, footer: {...embed.footer, icon_url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none" />
                                </div>
                             </div>
                          )}

                          {activeTab === 'Images' && (
                             <div className="space-y-10 max-w-2xl">
                                <div className="space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Main Image URL</label>
                                   <input type="text" value={embed.image.url} onChange={(e) => setEmbed({...embed, image: {url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none focus:border-white/10 font-medium" placeholder="https://..." />
                                </div>
                                <div className="space-y-3">
                                   <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Thumbnail URL</label>
                                   <input type="text" value={embed.thumbnail.url} onChange={(e) => setEmbed({...embed, thumbnail: {url: e.target.value}})} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-[14px] text-white outline-none focus:border-white/10 font-medium" placeholder="https://..." />
                                </div>
                             </div>
                          )}

                          {activeTab === 'Fields' && (
                             <div className="space-y-8">
                                <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                   <div className="space-y-1">
                                      <h4 className="text-[11px] font-bold uppercase text-white/60 tracking-widest">Structural Components</h4>
                                      <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Organize complex information grids</p>
                                   </div>
                                   <button 
                                     onClick={addField}
                                     className="px-6 py-2.5 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl"
                                   >
                                      Add Field
                                   </button>
                                </div>
                                <div className="grid grid-cols-1 gap-6 max-h-[450px] overflow-y-auto pr-2 custom-scrollbar">
                                   {embed.fields.map((field, i) => (
                                      <div key={i} className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-6 relative group border-t-4 border-t-white/10">
                                         <button onClick={() => removeField(i)} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Field Name</label>
                                               <input type="text" value={field.name} onChange={(e) => updateField(i, 'name', e.target.value)} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-sm text-white outline-none focus:border-white/10" />
                                            </div>
                                            <div className="flex items-end pb-1">
                                               <button 
                                                 onClick={() => updateField(i, 'inline', !field.inline)}
                                                 className={`flex items-center gap-3 px-6 py-3.5 rounded-xl border transition-all text-[10px] font-bold uppercase tracking-widest ${field.inline ? 'bg-white/10 border-white/20 text-white shadow-inner' : 'bg-transparent border-white/5 text-white/20'}`}
                                               >
                                                  {field.inline ? <Check className="w-3.5 h-3.5" /> : <div className="w-3.5 h-3.5 border border-white/20 rounded-sm" />}
                                                  Inline Layout
                                               </button>
                                            </div>
                                         </div>
                                         <div className="space-y-3">
                                            <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Field Value</label>
                                            <textarea value={field.value} onChange={(e) => updateField(i, 'value', e.target.value)} className="w-full bg-white/[0.02] border border-white/5 p-5 rounded-2xl text-sm text-white outline-none resize-none min-h-[120px] focus:border-white/10" />
                                         </div>
                                      </div>
                                   ))}
                                </div>
                             </div>
                          )}

                          {activeTab === 'Buttons' && (
                             <div className="space-y-8">
                                <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                   <div className="space-y-1">
                                      <h4 className="text-[11px] font-bold uppercase text-white/60 tracking-widest">Interactive Triggers</h4>
                                      <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Add functional buttons to your message</p>
                                   </div>
                                   <button 
                                     onClick={addButton}
                                     className="px-6 py-2.5 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl"
                                   >
                                      Add Button
                                   </button>
                                </div>
                                <div className="grid grid-cols-1 gap-6 max-h-[450px] overflow-y-auto pr-2 custom-scrollbar">
                                   {embed.buttons.map((btn, i) => (
                                      <div key={i} className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-8 relative group border-l-4 border-l-white/10">
                                         <button onClick={() => removeButton(i)} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                         <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                            <div className="space-y-6">
                                               <div className="space-y-3">
                                                  <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Button Label</label>
                                                  <input type="text" value={btn.label} onChange={(e) => {
                                                     const nb = [...embed.buttons]; nb[i].label = e.target.value; setEmbed({...embed, buttons: nb});
                                                  }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-sm text-white outline-none focus:border-white/10" />
                                               </div>
                                               <div className="space-y-3">
                                                  <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">{btn.style === 'LINK' ? 'Destination URL' : 'Custom Action ID'}</label>
                                                  <input type="text" placeholder={btn.style === 'LINK' ? 'https://...' : 'action_01'} value={btn.style === 'LINK' ? btn.url : btn.custom_id} onChange={(e) => {
                                                     const nb = [...embed.buttons]; 
                                                     if (btn.style === 'LINK') nb[i].url = e.target.value;
                                                     else nb[i].custom_id = e.target.value;
                                                     setEmbed({...embed, buttons: nb});
                                                  }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs font-mono text-white/60 outline-none focus:border-white/10" />
                                               </div>
                                            </div>
                                            <div className="space-y-6">
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                   <div className="space-y-3">
                                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Emoji (Name or {"<:name:id>"})</label>
                                                      <input type="text" value={btn.emoji || ''} onChange={(e) => {
                                                         const nb = [...embed.buttons]; nb[i].emoji = e.target.value; setEmbed({...embed, buttons: nb});
                                                      }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs text-white outline-none focus:border-white/10" placeholder="🔍 Emoji code..." />
                                                   </div>
                                                   <div className="space-y-3">
                                                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Interface Style</label>
                                                      <div className="grid grid-cols-5 gap-3">
                                                         {BUTTON_STYLES.map(s => (
                                                            <button 
                                                              key={s.id} 
                                                              onClick={() => {
                                                                 const nb = [...embed.buttons]; nb[i].style = s.id as any; setEmbed({...embed, buttons: nb});
                                                              }}
                                                              className={`h-11 rounded-xl transition-all border shrink-0 flex items-center justify-center ${btn.style === s.id ? 'bg-white/10 border-white/30 scale-105' : 'bg-transparent border-white/5 opacity-40 hover:opacity-100 hover:bg-white/5'}`}
                                                            >
                                                               <div className={`w-3.5 h-3.5 rounded-full ${s.color} shadow-lg`} />
                                                            </button>
                                                         ))}
                                                      </div>
                                                   </div>
                                                </div>
                                            </div>
                                         </div>
                                      </div>
                                   ))}
                                </div>
                             </div>
                          )}

                          {activeTab === 'Select' && (
                             <div className="space-y-8">
                                <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-6 rounded-2xl">
                                   <div className="space-y-1">
                                      <h4 className="text-[11px] font-bold uppercase text-white/60 tracking-widest">Selection Matrix</h4>
                                      <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Drop-down menus for multi-choice responses</p>
                                   </div>
                                   {embed.selectMenus.length === 0 && (
                                     <button 
                                       onClick={addSelectMenu}
                                       className="px-6 py-2.5 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all shadow-xl"
                                     >
                                        Add Menu
                                     </button>
                                   )}
                                </div>
                                <div className="space-y-6">
                                   {embed.selectMenus.map((menu, mIdx) => (
                                      <div key={mIdx} className="p-8 bg-white/[0.01] border border-white/5 rounded-[32px] space-y-10 relative group border-l-4 border-l-white/10">
                                         <button onClick={() => {
                                            const nm = [...embed.selectMenus]; nm.splice(mIdx, 1); setEmbed({...embed, selectMenus: nm});
                                         }} className="absolute top-6 right-6 p-2 text-white/10 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                         
                                         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Placeholder Text</label>
                                               <input value={menu.placeholder} onChange={(e) => {
                                                  const nm = [...embed.selectMenus]; nm[mIdx].placeholder = e.target.value; setEmbed({...embed, selectMenus: nm});
                                               }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-sm text-white outline-none focus:border-white/10" />
                                            </div>
                                            <div className="space-y-3">
                                               <label className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Action Identifier</label>
                                               <input value={menu.custom_id} onChange={(e) => {
                                                  const nm = [...embed.selectMenus]; nm[mIdx].custom_id = e.target.value; setEmbed({...embed, selectMenus: nm});
                                               }} className="w-full bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs font-mono text-white/60 outline-none focus:border-white/10" />
                                            </div>
                                         </div>

                                         <div className="space-y-6 pt-10 border-t border-white/5">
                                            <div className="flex justify-between items-center bg-white/[0.02] p-4 rounded-2xl border border-white/5">
                                               <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Response Options</span>
                                               <button onClick={() => addSelectOption(mIdx)} className="text-[9px] font-bold text-white hover:text-white/60 uppercase tracking-widest transition-all">+ Add Option</button>
                                            </div>
                                            <div className="grid grid-cols-1 gap-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                                               {menu.options.map((opt, oIdx) => (
                                                  <div key={oIdx} className="flex gap-4 items-center bg-white/[0.01] p-4 rounded-xl border border-white/5 group/opt">
                                                     <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-[10px] font-mono text-white/20">{oIdx + 1}</div>
                                                     <input value={opt.label} onChange={(e) => {
                                                        const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].label = e.target.value; setEmbed({...embed, selectMenus: nm});
                                                     }} placeholder="Label" className="flex-1 bg-transparent border-none outline-none text-xs text-white" />
                                                     <input value={opt.emoji || ''} onChange={(e) => {
                                                        const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].emoji = e.target.value; setEmbed({...embed, selectMenus: nm});
                                                     }} placeholder="Emoji" className="w-24 bg-white/5 px-4 py-2 rounded-xl text-[10px] font-mono text-white/40 outline-none border border-white/5" />
                                                     <input value={opt.value} onChange={(e) => {
                                                        const nm = [...embed.selectMenus]; nm[mIdx].options[oIdx].value = e.target.value; setEmbed({...embed, selectMenus: nm});
                                                     }} placeholder="Value" className="w-24 bg-white/5 px-4 py-2 rounded-xl text-[10px] font-mono text-white/40 outline-none border border-white/5" />
                                                     <button onClick={() => {
                                                        const nm = [...embed.selectMenus]; nm[mIdx].options.splice(oIdx, 1); setEmbed({...embed, selectMenus: nm});
                                                     }} className="text-white/10 hover:text-red-500 transition-all opacity-0 group-hover/opt:opacity-100"><Trash2 className="w-4 h-4" /></button>
                                                  </div>
                                               ))}
                                            </div>
                                         </div>
                                      </div>
                                   ))}
                                </div>
                             </div>
                          )}

                          {activeTab === 'Extras' && (
                             <div className="space-y-8 max-w-2xl">
                                <div 
                                   onClick={() => setEmbed({...embed, ephemeral: !embed.ephemeral})}
                                   className={`p-10 rounded-[32px] border transition-all cursor-pointer ${embed.ephemeral ? 'bg-white/[0.03] border-white/30 shadow-2xl' : 'bg-white/[0.01] border-white/5 hover:bg-white/[0.02]'}`}
                                >
                                   <div className="flex justify-between items-center gap-10">
                                      <div className="space-y-2">
                                         <h4 className={`text-[12px] font-bold uppercase tracking-[0.2em] transition-colors ${embed.ephemeral ? 'text-white' : 'text-white/40'}`}>Privacy Protocol (Ephemeral)</h4>
                                         <p className="text-[11px] text-white/20 font-medium leading-relaxed uppercase tracking-widest max-w-sm">The resulting message will only be visible to the user who triggered the dispatch command.</p>
                                      </div>
                                      <div className={`w-14 h-7 rounded-full relative transition-all shadow-xl ${embed.ephemeral ? 'bg-white' : 'bg-white/10'}`}>
                                         <div className={`absolute top-1 w-5 h-5 rounded-full transition-all ${embed.ephemeral ? 'right-1 bg-black shadow-lg' : 'left-1 bg-white/40'}`} />
                                      </div>
                                   </div>
                                </div>

                                <div 
                                   onClick={() => setEmbed({...embed, isV2: !embed.isV2})}
                                   className={`p-10 rounded-[32px] border transition-all cursor-pointer ${embed.isV2 ? 'bg-white/[0.03] border-white/30 shadow-2xl' : 'bg-white/[0.01] border-white/5 hover:bg-white/[0.02]'}`}
                                >
                                   <div className="flex justify-between items-center gap-10">
                                      <div className="space-y-2">
                                         <h4 className={`text-[12px] font-bold uppercase tracking-[0.2em] transition-colors ${embed.isV2 ? 'text-white' : 'text-white/40'}`}>V2 High-Fidelity Engine (CV2)</h4>
                                         <p className="text-[11px] text-white/20 font-medium leading-relaxed uppercase tracking-widest max-w-sm">Utilizes experimental Section containers (Type 17) for a more modern, native application-like appearance.</p>
                                      </div>
                                      <div className={`w-14 h-7 rounded-full relative transition-all shadow-xl ${embed.isV2 ? 'bg-white' : 'bg-white/10'}`}>
                                         <div className={`absolute top-1 w-5 h-5 rounded-full transition-all ${embed.isV2 ? 'right-1 bg-black shadow-lg' : 'left-1 bg-white/40'}`} />
                                      </div>
                                   </div>
                                </div>
                             </div>
                          )}
                       </motion.div>
                    </AnimatePresence>
                 </div>

                 {/* Variables Grid */}
                 <div className="pt-10 border-t border-white/5 space-y-6">
                    <div className="flex items-center gap-4">
                       <div className="w-8 h-[1px] bg-white/5" />
                       <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/20">Data Injections</span>
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                       {VARIABLES.flatMap(g => g.items).map(v => (
                          <div 
                            key={v.name} 
                            onClick={() => {
                               navigator.clipboard.writeText(v.name);
                               setStatusMsg({ text: `Copied ${v.name} to clipboard`, type: 'info' });
                               setTimeout(() => setStatusMsg({ text: '', type: '' }), 2000);
                            }}
                            className="group bg-white/[0.01] border border-white/5 p-4 rounded-2xl hover:bg-white/[0.03] hover:border-white/10 transition-all cursor-copy overflow-hidden relative shadow-sm"
                          >
                             <div className="text-[12px] font-bold text-white/80 group-hover:text-white transition-colors">{v.name}</div>
                             <div className="text-[9px] text-white/10 group-hover:text-white/20 font-black uppercase tracking-widest mt-1">{v.desc}</div>
                             <div className="absolute top-1/2 right-4 -translate-y-1/2 opacity-0 group-hover:opacity-20 transition-all rotate-12 scale-150">
                                <Code className="w-8 h-8" />
                             </div>
                          </div>
                       ))}
                    </div>
                 </div>
              </div>
           </section>
        </div>

        {/* Right Column: Preview (Sticky) */}
        <div className="xl:sticky xl:top-12 space-y-8 animate-in fade-in slide-in-from-right-4 duration-1000 delay-200">
           <div className="flex items-center justify-between px-6">
              <div className="flex items-center gap-4">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)] animate-pulse" />
                 <span className="text-[10px] font-bold text-white/40 uppercase tracking-[0.4em]">Live Matrix Projection</span>
              </div>
              <Activity className="w-4 h-4 text-white/10" />
           </div>

           <div className="bg-[#111214] rounded-[48px] p-12 border border-white/5 shadow-[0_60px_100px_rgba(0,0,0,0.6)] backdrop-blur-xl relative overflow-hidden group/preview">
              <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent opacity-0 group-hover/preview:opacity-100 transition-opacity duration-1000" />
              <div className="flex gap-6 relative z-10">
                 <div className="w-14 h-14 rounded-full bg-[#5865F2] shrink-0 flex items-center justify-center text-white/90 font-black text-[14px] shadow-2xl border-4 border-[#111214] relative">
                    ENC
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 rounded-full border-[3px] border-[#111214]" />
                 </div>
                 <div className="flex-1 min-w-0 space-y-5">
                    <div className="flex items-center gap-3">
                       <span className="font-bold text-white text-[16px] tracking-tight">Enc Nexus</span>
                       <span className="bg-[#5865F2] text-[9px] px-2 py-0.5 rounded-[4px] text-white font-black h-fit tracking-tighter uppercase shadow-lg">Bot</span>
                       <span className="text-[11px] text-white/20 font-medium">Today at {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    {embed.content && (
                       <p className="text-[15px] text-[#dbdee1] leading-relaxed whitespace-pre-wrap selection:bg-white/20">{embed.content}</p>
                    )}

                    <div className="flex relative items-stretch group/embed max-w-[520px]">
                       <div className="w-[4px] shrink-0 rounded-l-[4px]" style={{ backgroundColor: embed.color }} />
                       <div className="flex-1 bg-[#1e1f22] rounded-r-[4px] p-5 pr-14 pb-6 space-y-4 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.5)] relative overflow-hidden border border-white/[0.02]">
                          {embed.author.name && (
                             <div className="flex items-center gap-3">
                                {embed.author.icon_url && <img src={embed.author.icon_url} className="w-6 h-6 rounded-full object-cover shadow-2xl ring-1 ring-white/10" alt="" />}
                                <span className={`text-[14px] font-bold tracking-tight hover:underline cursor-pointer transition-colors ${embed.author.url ? 'text-[#00a8fc]' : 'text-white'}`}>{embed.author.name}</span>
                             </div>
                          )}

                          {embed.title && (
                             <h3 className={`text-[17px] font-bold leading-tight tracking-tight ${embed.url ? 'text-[#00a8fc] hover:underline cursor-pointer' : 'text-white'}`}>{embed.title}</h3>
                          )}

                          {embed.description && (
                             <p className="text-[14px] text-[#dbdee1] font-medium leading-relaxed whitespace-pre-wrap selection:bg-white/10">{embed.description}</p>
                          )}

                          {embed.fields.length > 0 && (
                             <div className="grid grid-cols-12 gap-y-5 gap-x-4 pt-3">
                                {embed.fields.map((f, i) => (
                                   <div key={i} className={`${f.inline ? 'col-span-4' : 'col-span-12'} space-y-1.5`}>
                                      <div className="text-[14px] font-bold text-white tracking-tight">{f.name || '\u200b'}</div>
                                      <div className="text-[14px] text-[#dbdee1] font-medium whitespace-pre-wrap leading-relaxed">{f.value || '\u200b'}</div>
                                   </div>
                                ))}
                             </div>
                          )}

                          {embed.image.url && (
                             <div className="mt-4 rounded-[12px] overflow-hidden border border-white/5 shadow-2xl bg-black/20">
                                <img src={embed.image.url} className="w-full object-cover max-h-[400px] hover:scale-[1.02] transition-transform duration-700" alt="" />
                             </div>
                          )}

                          {embed.thumbnail.url && (
                             <div className="absolute top-5 right-5 w-20 h-20 rounded-[12px] overflow-hidden border border-white/5 shadow-2xl shrink-0 group-hover/embed:rotate-1 transition-transform duration-700">
                                <img src={embed.thumbnail.url} className="w-full h-full object-cover" alt="" />
                             </div>
                          )}

                          {(embed.footer.text || embed.timestamp) && (
                             <div className="flex items-center gap-3 pt-3 border-t border-white/[0.03]">
                                {embed.footer.icon_url && <img src={embed.footer.icon_url} className="w-5 h-5 rounded-full object-cover grayscale opacity-50" alt="" />}
                                <div className="text-[11px] text-white/20 font-black uppercase tracking-widest flex items-center gap-2">
                                   {embed.footer.text}
                                   {embed.footer.text && embed.timestamp && <span className="w-1 h-1 rounded-full bg-white/10" />}
                                   {embed.timestamp && `Today at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                                </div>
                             </div>
                          )}
                       </div>
                    </div>

                    {/* Interactive Preview Items */}
                    <div className="space-y-3 max-w-[520px]">
                       {embed.selectMenus.map((m, i) => (
                          <div key={i} className="bg-[#2b2d31] border border-black/20 rounded-[4px] p-3 flex justify-between items-center text-[#dbdee1] text-[14px] select-none hover:bg-[#35373c] transition-all cursor-pointer group shadow-sm border-b-[2px]">
                             <span className="font-medium">{m.placeholder}</span>
                             <ChevronRight className="w-4 h-4 opacity-20 group-hover:rotate-90 group-hover:opacity-60 transition-all" />
                          </div>
                       ))}
                       {embed.buttons.length > 0 && (
                          <div className="flex flex-wrap gap-2 pt-1">
                             {embed.buttons.map((b, i) => (
                                <div key={i} className={`px-4 py-2 rounded-[3px] text-white font-bold text-[14px] flex items-center gap-2 shadow-lg transition-all hover:brightness-125 active:scale-[0.98] cursor-pointer select-none ${
                                   b.style === 'PRIMARY' ? 'bg-[#5865F2]' : 
                                   b.style === 'SECONDARY' ? 'bg-[#4e5058]' :
                                   b.style === 'SUCCESS' ? 'bg-[#248046]' :
                                   b.style === 'DANGER' ? 'bg-[#da373c]' : 'bg-[#4e5058]'
                                }`}>
                                   {b.style === 'LINK' && <ExternalLink className="w-3.5 h-3.5 opacity-60" />}
                                   {b.emoji && (
                                      <span className="shrink-0">
                                         {b.emoji.match(/<a?:\w+:\d+>/) ? (
                                            <img 
                                               src={`https://cdn.discordapp.com/emojis/${b.emoji.match(/\d+/)?.[0]}.${b.emoji.startsWith('<a:') ? 'gif' : 'webp'}?size=44`} 
                                               className="w-4 h-4 object-contain" 
                                               alt="" 
                                            />
                                         ) : b.emoji}
                                      </span>
                                   )}
                                   {b.label}
                                </div>
                             ))}
                          </div>
                       )}
                    </div>
                 </div>
              </div>
           </div>

           <div className="p-10 bg-white/[0.01] border border-white/5 rounded-[40px] space-y-6 backdrop-blur-sm shadow-2xl">
              <div className="flex items-center gap-4 text-white/20">
                 <Sparkles className="w-4 h-4" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Composer Telemetry</span>
              </div>
              <div className="grid grid-cols-2 gap-6">
                 <div className="p-5 bg-white/[0.02] border border-white/5 rounded-[24px] space-y-2">
                    <div className="text-[10px] font-black text-white/10 uppercase tracking-widest">Payload Weight</div>
                    <div className="text-[14px] font-black text-white uppercase tracking-tighter">~0.85 KB</div>
                 </div>
                 <div className="p-5 bg-white/[0.02] border border-white/5 rounded-[24px] space-y-2">
                    <div className="text-[10px] font-black text-white/10 uppercase tracking-widest">Components</div>
                    <div className="text-[14px] font-black text-white uppercase tracking-tighter">{embed.fields.length + embed.buttons.length + embed.selectMenus.length} / 50</div>
                 </div>
              </div>
           </div>
        </div>
      </div>

      {/* Persistence Notifications */}
      <AnimatePresence>
         {statusMsg.text && (
            <motion.div 
               initial={{ opacity: 0, scale: 0.95 }} 
               animate={{ opacity: 1, scale: 1 }} 
               exit={{ opacity: 0, scale: 0.95 }}
               className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[2000]"
            >
               <div className={`px-10 py-5 rounded-3xl border backdrop-blur-3xl shadow-[0_40px_80px_rgba(0,0,0,0.4)] flex items-center gap-5 ${
                  statusMsg.type === 'error' ? 'bg-red-500/10 border-red-500/20 text-red-500' : 
                  statusMsg.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' : 
                  'bg-white/5 border-white/10 text-white'
               }`}>
                  {statusMsg.type === 'success' ? <ShieldCheck className="w-5 h-5 shadow-emerald-500" /> : <Info className="w-5 h-5" />}
                  <span className="text-[11px] font-black uppercase tracking-[0.2em]">{statusMsg.text}</span>
               </div>
            </motion.div>
         )}
      </AnimatePresence>
    </main>
  );
}
