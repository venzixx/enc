'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { 
  UserPlus, UserMinus, Save, Activity, Sparkles, ArrowUpRight, Hash, Type, Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function GreetingsPage() {
  const { guildId } = useParams();
  const [channels, setChannels] = useState<{id: string, name: string}[]>([]);
  
  const [welcome, setWelcome] = useState({ enabled: true, channelId: '', message: 'Welcome {user} to {server}!' });
  const [leave, setLeave] = useState({ enabled: true, channelId: '', message: '{user} has left the server.' });
  
  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState({ text: '', type: '' });

  useEffect(() => {
    if (!guildId) return;
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data))
      .catch(console.error);

    fetch(`/api/guild/${guildId}/greetings`)
      .then(r => r.json())
      .then(data => {
        if (data) {
          if (data.welcome) setWelcome(data.welcome);
          if (data.leave) setLeave(data.leave);
        }
      })
      .catch(() => {});
  }, [guildId]);

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMsg({ text: 'Updating greetings...', type: 'info' });
    try {
      const res = await fetch(`/api/guild/${guildId}/greetings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ welcome, leave })
      });
      if (res.ok) setStatusMsg({ text: 'Greetings updated.', type: 'success' });
      else throw new Error();
    } catch {
      setStatusMsg({ text: 'Error: Update failed.', type: 'error' });
    } finally {
      setIsSaving(false);
      setTimeout(() => setStatusMsg({ text: '', type: '' }), 4000);
    }
  };

  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-12">
      <header className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-700">
        <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
          <Activity className="w-3 h-3" /> Greetings & Farewells
        </div>
        <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Greetings</h1>
        <p className="text-sm text-white/30 max-w-2xl font-medium leading-relaxed">
          Customize automated messages for new members and those who depart from your server.
        </p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10 items-start">
        
        {/* WELCOME SECTOR */}
        <section className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-8 hover:border-white/10 transition-all group">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-5">
                 <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-white/10 transition-colors">
                    <UserPlus className="w-5 h-5 text-white/60" />
                 </div>
                 <h2 className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">Welcome Messages</h2>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                 <input 
                  type="checkbox" 
                  checked={welcome.enabled}
                  onChange={(e) => setWelcome({...welcome, enabled: e.target.checked})}
                  className="sr-only peer" 
                 />
                 <div className="w-11 h-6 bg-white/10 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white/40 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white peer-checked:after:bg-black"></div>
              </label>
           </div>

           <div className={`space-y-6 transition-all duration-500 ${welcome.enabled ? 'opacity-100 scale-100' : 'opacity-20 scale-[0.98] pointer-events-none grayscale'}`}>
              <div className="space-y-3">
                 <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest px-1">Destination Channel</label>
                 <SurgicalDropdown 
                   options={channels} 
                   value={welcome.channelId}
                   onChange={(val) => setWelcome({...welcome, channelId: val})}
                   placeholder="Select Channel"
                 />
              </div>
              <div className="space-y-3">
                 <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest px-1">Message Template</label>
                 <textarea 
                  value={welcome.message}
                  onChange={(e) => setWelcome({...welcome, message: e.target.value})}
                  rows={4}
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-5 text-[13px] text-white/60 font-medium whitespace-pre-wrap outline-none focus:border-white/10 transition-all resize-none"
                  placeholder="Welcome {user} to {server}!"
                 />
                 <div className="flex flex-wrap gap-2">
                    {['{user}', '{server}', '{count}', '{tag}'].map(tag => (
                       <span key={tag} className="px-2.5 py-1 rounded-md bg-white/5 border border-white/5 text-[9px] font-bold text-white/20 uppercase tracking-widest">{tag}</span>
                    ))}
                 </div>
              </div>
           </div>
        </section>

        {/* LEAVE SECTOR */}
        <section className="bg-white/[0.01] border border-white/5 p-8 md:p-10 rounded-[32px] space-y-8 hover:border-white/10 transition-all group">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-5">
                 <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10 group-hover:bg-white/10 transition-colors">
                    <UserMinus className="w-5 h-5 text-white/60" />
                 </div>
                 <h2 className="text-[12px] font-bold uppercase tracking-[0.2em] text-white">Leave Messages</h2>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                 <input 
                  type="checkbox" 
                  checked={leave.enabled}
                  onChange={(e) => setLeave({...leave, enabled: e.target.checked})}
                  className="sr-only peer" 
                 />
                 <div className="w-11 h-6 bg-white/10 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white/40 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-white peer-checked:after:bg-black"></div>
              </label>
           </div>

           <div className={`space-y-6 transition-all duration-500 ${leave.enabled ? 'opacity-100 scale-100' : 'opacity-20 scale-[0.98] pointer-events-none grayscale'}`}>
              <div className="space-y-3">
                 <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest px-1">Destination Channel</label>
                 <SurgicalDropdown 
                   options={channels} 
                   value={leave.channelId}
                   onChange={(val) => setLeave({...leave, channelId: val})}
                   placeholder="Select Channel"
                 />
              </div>
              <div className="space-y-3">
                 <label className="text-[9px] font-bold text-white/20 uppercase tracking-widest px-1">Message Template</label>
                 <textarea 
                  value={leave.message}
                  onChange={(e) => setLeave({...leave, message: e.target.value})}
                  rows={4}
                  className="w-full bg-white/[0.02] border border-white/5 rounded-2xl p-5 text-[13px] text-white/60 font-medium whitespace-pre-wrap outline-none focus:border-white/10 transition-all resize-none"
                  placeholder="{user} has left the server."
                 />
              </div>
           </div>
        </section>

        {/* GLOBAL SAVE */}
        <div className="xl:col-span-12 flex flex-col items-center gap-6 pt-8">
            <button 
              onClick={handleSave}
              disabled={isSaving}
              className="w-full max-w-sm py-5 rounded-2xl bg-white text-black font-bold text-[11px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 hover:bg-zinc-200"
            >
               {isSaving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
               {isSaving ? "Saving..." : "Save Greetings"}
            </button>
            <AnimatePresence>
               {statusMsg.text && (
                 <motion.p initial={{opacity:0, y: 5}} animate={{opacity:1, y: 0}} exit={{opacity:0}} className={`text-[10px] font-bold uppercase tracking-widest text-center ${statusMsg.type === 'error' ? 'text-red-500' : 'text-emerald-500'}`}>
                   {statusMsg.text}
                 </motion.p>
               )}
            </AnimatePresence>
        </div>

      </div>
    </main>
  );
}
