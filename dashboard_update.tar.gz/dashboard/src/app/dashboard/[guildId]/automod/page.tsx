import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Zap } from "lucide-react";
import AutoModManager from "@/components/AutoModManager";

export default async function AutoModPage({ params }: { params: Promise<{ guildId: string }> }) {
  const { guildId } = await params;
  const session: any = await getServerSession(authOptions);

  if (!session) redirect("/");

  const [filters, guildData] = await Promise.all([
    prisma.autoModFilter.findMany({ where: { guildId } }),
    prisma.guild.findUnique({ where: { id: guildId }, select: { autoModEnabled: true } })
  ]);

  // Ensure default filters exist in UI if not in DB yet
  const defaultTypes = ['SPAM', 'INVITES', 'LINKS', 'MENTIONS', 'MALICIOUS', 'WORDS'];
  const mergedFilters = defaultTypes.map(type => {
    const existing = filters.find((f: any) => f.type === type);
    return existing || { type, enabled: false, data: '[]' };
  });
  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-12">
      <header className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-700">
          <div className="flex items-center gap-2 text-white/20 font-bold text-[10px] uppercase tracking-[0.3em]">
            <Zap className="w-3 h-3" /> Spam Filtering
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight uppercase text-white/90">Auto Mod</h1>
          <p className="text-sm text-white/30 max-w-2xl font-medium leading-relaxed">
            Configure automated filters to protect your server from spam, malicious links, and unwanted content.
          </p>
      </header>

      <AutoModManager guildId={guildId} initialFilters={mergedFilters} initialEnabled={guildData?.autoModEnabled ?? false} />
    </main>
  );
}
