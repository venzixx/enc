'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { 
  Sparkles, Plus, Trash2, MessageSquare, 
  RefreshCw, Search, ListFilter, AlertCircle,
  Save, X, Check, Zap, Info, Hash, Globe, User, Settings2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import MarkdownDisplay from '@/components/MarkdownDisplay';
import CustomSelect from '@/components/CustomSelect';

export default function AutoresponderPage() {
  const { guildId } = useParams();
  const [loading, setLoading] = useState(true);
  const [responders, setResponders] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [search, setSearch] = useState('');
  
  const [formData, setFormData] = useState({
    trigger: '',
    response: '',
    channelId: '',
    matchType: 'EXACT'
  });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [channels, setChannels] = useState<any[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const [resResponders, resChannels] = await Promise.all([
        fetch(`/api/guild/${guildId}/autoresponder`),
        fetch(`/api/guild/${guildId}/channels`)
      ]);
      
      if (resResponders.ok) setResponders(await resResponders.json());
      if (resChannels.ok) setChannels(await resChannels.json());
    } catch (error) {
      console.error("Fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [guildId]);

  useEffect(() => {
    if (guildId) fetchData();
  }, [guildId, fetchData]);

  const handleSave = async () => {
    let finalData = { ...formData };
    if (formData.matchType === 'MENTION') {
      finalData.trigger = formData.trigger.replace(/\D/g, '');
    }
    if (!finalData.trigger || !finalData.response) return;
    
    setLoading(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/autoresponder`, {
        method: editingId ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...finalData,
          id: editingId
        })
      });

      if (res.ok) {
        await fetchData();
        setShowModal(false);
        setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
        setEditingId(null);
      }
    } catch (error) {
      console.error("Save error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this auto-response?")) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/autoresponder?id=${id}`, {
        method: 'DELETE'
      });
      if (res.ok) await fetchData();
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  const filtered = responders.filter(r => 
    r.trigger.toLowerCase().includes(search.toLowerCase()) || 
    r.response.toLowerCase().includes(search.toLowerCase())
  );

  if (loading && responders.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <RefreshCw className="w-8 h-8 text-white/20 animate-spin" />
        <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Decoding manifest...</p>
      </div>
    );
  }

  return (
    <main className="p-8 md:p-12 max-w-[1400px] mx-auto space-y-16 animate-in fade-in duration-700">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
             <span className="text-[10px] font-bold text-white/40 uppercase tracking-[0.4em]">Automation</span>
          </div>
          <h1 className="text-5xl font-black text-white uppercase tracking-tighter leading-none">Autoresponder</h1>
          <p className="text-sm text-white/30 font-medium max-w-xl">
             Configure automated message triggers to streamline community interaction and support.
          </p>
        </div>
        
        <button 
          onClick={() => setShowModal(true)}
          className="px-10 py-4 bg-white text-black rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all hover:bg-zinc-200 shadow-2xl flex items-center gap-3"
        >
          <Plus className="w-4 h-4" /> Create Responder
        </button>
      </header>

      {/* Stats & Filter Bar */}
      <div className="flex flex-col lg:flex-row gap-6 items-center justify-between bg-white/[0.02] border border-white/5 p-6 rounded-[32px]">
        <div className="flex items-center gap-8 px-4">
          <div className="flex flex-col gap-1">
             <span className="text-[10px] font-bold text-white/10 uppercase tracking-widest">Active Manifests</span>
             <span className="text-xl font-bold text-white/80">{responders.length}</span>
          </div>
          <div className="h-8 w-px bg-white/5" />
          <div className="flex flex-col gap-1">
             <span className="text-[10px] font-bold text-white/10 uppercase tracking-widest">Global Status</span>
             <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> Operational
             </span>
          </div>
        </div>

        <div className="relative w-full lg:w-[400px]">
           <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
           <input 
             type="text" 
             placeholder="Search triggers or responses..."
             value={search}
             onChange={(e) => setSearch(e.target.value)}
             className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-sm text-white outline-none focus:border-white/10 transition-all font-medium"
           />
        </div>
      </div>

      {/* Responders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filtered.map((res, i) => (
            <motion.div 
              key={res.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white/[0.02] border border-white/5 rounded-[32px] p-8 space-y-8 group hover:bg-white/[0.03] hover:border-white/10 transition-all relative overflow-hidden"
            >
               {/* Background Glow */}
               <div className="absolute -top-24 -right-24 w-48 h-48 bg-white/[0.02] blur-[80px] rounded-full pointer-events-none group-hover:bg-white/[0.04] transition-colors" />

               <div className="flex justify-between items-start relative z-10">
                  <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-white/40">
                     <MessageSquare className="w-5 h-5" />
                  </div>
                   <div className="flex gap-2 relative z-10">
                      <button 
                        onClick={() => {
                          setFormData({
                            trigger: res.trigger,
                            response: res.response,
                            channelId: res.channelId || '',
                            matchType: res.matchType || 'EXACT'
                          });
                          setEditingId(res.id);
                          setShowModal(true);
                        }}
                        className="p-2 text-white/5 hover:text-white/60 hover:bg-white/5 rounded-lg transition-all"
                      >
                         <Settings2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(res.id)}
                        className="p-2 text-white/5 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                      >
                         <Trash2 className="w-4 h-4" />
                      </button>
                   </div>
               </div>

                <div className="space-y-6 relative z-10">
                   <div className="flex items-center gap-4">
                      <div className="space-y-2 flex-1">
                         <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Trigger</span>
                         <div className="bg-white/5 px-4 py-2.5 rounded-xl border border-white/5 flex items-center gap-2">
                            {res.matchType === 'CONTAINS' && <Globe className="w-3 h-3 text-blue-400" />}
                            {res.matchType === 'MENTION' && <User className="w-3 h-3 text-purple-400" />}
                            {(!res.matchType || res.matchType === 'EXACT') && <Zap className="w-3 h-3 text-emerald-400" />}
                            <code className="text-[13px] font-bold text-white/80 tracking-tight">{res.trigger}</code>
                         </div>
                      </div>
                      {res.channelId && (
                        <div className="space-y-2">
                           <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Channel</span>
                           <div className="bg-white/5 px-4 py-2.5 rounded-xl border border-white/5 text-[11px] font-bold text-white/40">
                              #{channels.find(c => c.id === res.channelId)?.name || 'Deleted'}
                           </div>
                        </div>
                      )}
                   </div>

                   <div className="space-y-2">
                      <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Response</span>
                      <div className="bg-white/[0.03] border border-white/5 p-6 rounded-2xl relative group/resp">
                         <div className="absolute top-0 left-0 w-1 h-full bg-[#9333ea]/20 rounded-l-2xl group-hover/resp:bg-[#9333ea]/50 transition-colors" />
                         <MarkdownDisplay 
                            content={res.response} 
                            className="text-sm text-white/50 font-medium leading-relaxed"
                         />
                      </div>
                      {res.response.match(/\.(jpeg|jpg|gif|png|webp)(\?.*)?$/i) && (
                        <div className="mt-4 rounded-[24px] overflow-hidden border border-white/5 bg-white/5">
                           <img src={res.response} alt="Response Visual" className="w-full max-h-[300px] object-contain opacity-60 hover:opacity-100 transition-opacity p-2" />
                        </div>
                      )}
                   </div>
                </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="col-span-full py-32 flex flex-col items-center justify-center gap-6 border-2 border-dashed border-white/5 rounded-[40px]">
             <div className="w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center text-white/10">
                <Sparkles className="w-8 h-8" />
             </div>
             <div className="text-center space-y-1">
                <h3 className="text-sm font-bold text-white/20 uppercase tracking-[0.2em]">No matches found</h3>
                <p className="text-[10px] text-white/5 font-bold uppercase tracking-widest">Adjust filters or create a new responder</p>
             </div>
          </div>
        )}
      </div>

      {/* Create Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 md:p-12">
             <motion.div 
               initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
               onClick={() => {
                  setShowModal(false);
                  setEditingId(null);
                  setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
               }}
               className="absolute inset-0 bg-black/80 backdrop-blur-xl"
             />
             <motion.div 
               initial={{ opacity: 0, scale: 0.9, y: 20 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               exit={{ opacity: 0, scale: 0.9, y: 20 }}
               className="bg-[#0c0c0c] border border-white/10 rounded-[40px] w-full max-w-xl overflow-hidden relative shadow-2xl"
             >
                <div className="flex justify-between items-center px-12 py-10 border-b border-white/5">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5">
                         {editingId ? <Settings2 className="w-6 h-6 text-white/60" /> : <Plus className="w-6 h-6 text-white/60" />}
                      </div>
                      <div>
                         <h2 className="text-xl font-bold text-white tracking-tight uppercase tracking-[0.2em]">{editingId ? 'Edit Responder' : 'Create Responder'}</h2>
                         <p className="text-[10px] text-white/20 font-medium uppercase tracking-widest">Configure your automation engine</p>
                      </div>
                   </div>
                   <button 
                     onClick={() => {
                        setShowModal(false);
                        setEditingId(null);
                        setFormData({ trigger: '', response: '', channelId: '', matchType: 'EXACT' });
                     }}
                     className="p-2 hover:bg-white/5 rounded-xl transition-all text-white/20 hover:text-white/60"
                   >
                      <X className="w-5 h-5" />
                   </button>
                </div>

                <div className="p-10 space-y-8">
                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Trigger Word / Phrase</label>
                      <div className="relative">
                         <Zap className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
                         <input 
                           value={formData.trigger}
                           onChange={e => setFormData({...formData, trigger: e.target.value})}
                           placeholder="e.g. !help, rules, discord"
                           className="w-full bg-white/5 border border-white/5 rounded-2xl pl-12 pr-6 py-4 text-sm text-white outline-none focus:border-white/10 transition-all font-medium"
                         />
                      </div>
                   </div>

                   <div className="space-y-4">
                      <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest flex justify-between items-center">
                         Bot Response
                         <span className="text-[8px] opacity-40 font-black">Markdown Supported</span>
                      </label>
                      <textarea 
                        value={formData.response}
                        onChange={e => setFormData({...formData, response: e.target.value})}
                        rows={4}
                        placeholder="What should the bot say in return?"
                        className="w-full bg-white/5 border border-white/5 rounded-3xl p-6 text-sm text-white outline-none focus:border-white/10 transition-all resize-none font-medium leading-relaxed"
                      />
                      {formData.response && (
                        <div className="p-6 bg-white/[0.02] border border-white/5 rounded-2xl space-y-2">
                           <span className="text-[8px] font-bold text-white/10 uppercase tracking-widest">Live Preview</span>
                           <MarkdownDisplay 
                             content={formData.response} 
                             className="text-sm text-white/50 font-medium leading-relaxed"
                           />
                        </div>
                      )}
                   </div>

                   <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                         <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest text-center block">Match Strategy</label>
                         <div className="grid grid-cols-3 gap-2">
                            {[
                              { id: 'EXACT', icon: Zap, label: 'Exact' },
                              { id: 'CONTAINS', icon: Globe, label: 'Inside' },
                              { id: 'MENTION', icon: User, label: 'Ping' }
                            ].map(type => (
                              <button
                                key={type.id}
                                onClick={() => setFormData({ ...formData, matchType: type.id })}
                                className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                                  formData.matchType === type.id 
                                    ? 'bg-white/10 border-white/20 text-white' 
                                    : 'bg-transparent border-white/5 text-white/20 hover:border-white/10'
                                }`}
                              >
                                 <type.icon className="w-4 h-4" />
                                 <span className="text-[9px] font-bold uppercase tracking-tighter">{type.label}</span>
                              </button>
                            ))}
                         </div>
                      </div>

                      <div className="space-y-4">
                         <label className="text-[10px] font-bold text-white/20 uppercase tracking-widest text-center block">Restrict Channel</label>
                         <CustomSelect
                           options={channels}
                           value={formData.channelId}
                           onChange={(val) => setFormData({ ...formData, channelId: val })}
                           placeholder="Global (All)"
                         />
                      </div>
                   </div>

                   <div className="bg-white/[0.02] border border-white/5 p-6 rounded-2xl flex items-start gap-4">
                      <Info className="w-4 h-4 text-white/20 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                         <p className="text-[10px] text-white/20 font-medium leading-relaxed uppercase tracking-widest">
                            {formData.matchType === 'EXACT' && 'Triggers when the message is EXACTLY the same as the trigger word.'}
                            {formData.matchType === 'CONTAINS' && 'Triggers if the message CONTAINS the trigger word anywhere inside it.'}
                            {formData.matchType === 'MENTION' && 'Provide the exact User ID in the trigger. The bot will respond whenever that user is pinged.'}
                         </p>
                         <p className="text-[10px] text-white/10 font-medium leading-relaxed uppercase tracking-tighter italic">
                            Pro-tip: Paste a GIF URL in the response to show it!
                         </p>
                      </div>
                   </div>

                   <button 
                     onClick={handleSave}
                     disabled={loading}
                     className="w-full bg-white text-black font-bold py-6 rounded-3xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:hover:scale-100 uppercase tracking-[0.3em] text-xs"
                   >
                      {loading ? (
                        <RefreshCw className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <Save className="w-4 h-4" />
                          {editingId ? 'Update Responder' : 'Deploy Responder'}
                        </>
                      )}
                   </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </main>
  );
}
