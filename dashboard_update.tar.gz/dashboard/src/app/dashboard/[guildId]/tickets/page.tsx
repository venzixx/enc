'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  Ticket, Plus, Trash2, Layers, Hash, Clock, ArrowRight, Activity, 
  Sparkles, Shield, ChevronRight, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TicketPanel {
  id: string;
  panelId: string;
  name: string;
  channelId: string;
  isMulti: boolean;
  supportRoleId?: string;
}

export default function TicketsPage() {
  const { guildId } = useParams();
  const router = useRouter();
  const [panels, setPanels] = useState<TicketPanel[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!guildId) return;
    
    const fetchPanels = async () => {
      try {
        const res = await fetch(`/api/guild/${guildId}/tickets`);
        if (!res.ok) throw new Error('Failed to fetch panels');
        const data = await res.json();
        setPanels(data);
      } catch (err) {
        setError('Failed to load panels');
      } finally {
        setIsLoading(false);
      }
    };

    fetchPanels();
  }, [guildId]);

  const singlePanels = panels.filter(p => !p.isMulti);
  const multiPanels = panels.filter(p => p.isMulti);
  const quota = singlePanels.length;
  const maxQuota = 3;

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this panel?')) return;
    try {
      const res = await fetch(`/api/guild/${guildId}/tickets/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setPanels(panels.filter(p => p.id !== id));
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <main className="p-6 md:p-10 max-w-[1600px] mx-auto space-y-10 min-h-screen pb-20">
      {/* Header Section */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-[#9333ea] font-bold text-[10px] uppercase tracking-[0.4em]">
            <div className="w-1.5 h-1.5 rounded-full bg-[#9333ea] animate-pulse" />
            Ticket Management
          </div>
          <h1 className="text-5xl font-black tracking-tighter text-white uppercase italic">
            Command <span className="text-white/20">Center</span>
          </h1>
          <p className="text-white/40 text-sm font-medium max-w-md leading-relaxed">
            Deploy high-performance support panels and multi-channel routing systems.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-white/[0.03] border border-white/5 p-2 rounded-2xl backdrop-blur-xl">
           <div className="px-4 py-2 border-r border-white/5">
              <div className="text-[9px] font-bold text-white/20 uppercase tracking-widest mb-0.5">Active Guild</div>
              <div className="text-xs font-bold text-white/80 flex items-center gap-2">
                 <Shield className="w-3 h-3 text-[#9333ea]" /> {guildId}
              </div>
           </div>
           <div className="px-6 py-2">
              <div className="text-[9px] font-bold text-white/20 uppercase tracking-widest mb-0.5">Response Time</div>
              <div className="text-xs font-bold text-emerald-400">~0.4s Instant</div>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* SINGLE PANELS CARD */}
        <section className="bg-[#0a0a0f] border border-white/5 rounded-[32px] overflow-hidden group hover:border-[#9333ea]/20 transition-all duration-500 shadow-2xl">
           <div className="p-8 border-b border-white/5 flex items-center justify-between">
              <div className="space-y-4">
                 <h2 className="text-xl font-bold text-white tracking-tight">Ticket Panels</h2>
                 <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold text-white/30 uppercase tracking-widest">
                       Your panel quota: {quota} / {maxQuota}
                    </span>
                 </div>
              </div>
              <button 
                onClick={() => router.push(`/dashboard/${guildId}/tickets/create`)}
                className="bg-[#9333ea] hover:bg-[#a855f7] text-white px-8 py-3 rounded-xl font-bold text-[11px] uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(147,51,234,0.3)] flex items-center gap-2"
              >
                 <Plus className="w-4 h-4" /> New Panel
              </button>
           </div>

           <div className="p-4">
              <table className="w-full text-left">
                 <thead>
                    <tr className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] border-b border-white/5">
                       <th className="px-6 py-4">Channel</th>
                       <th className="px-6 py-4">Panel Title</th>
                       <th className="px-6 py-4">Support Hours</th>
                       <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                 </thead>
                 <tbody>
                    {singlePanels.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-8 py-20 text-center">
                           <div className="flex flex-col items-center gap-4 opacity-10">
                              <Ticket className="w-12 h-12" />
                              <p className="text-[11px] font-bold uppercase tracking-widest">No active panels</p>
                           </div>
                        </td>
                      </tr>
                    ) : (
                      singlePanels.map((panel) => (
                        <tr key={panel.id} className="group/row hover:bg-white/[0.02] transition-colors border-b border-white/[0.02] last:border-0">
                           <td className="px-6 py-5">
                              <div className="flex items-center gap-3">
                                 <Hash className="w-4 h-4 text-[#9333ea]/50" />
                                 <span className="text-xs font-bold text-white/60">
                                    #{panel.channelId ? 'channel' : 'unlinked'}
                                 </span>
                              </div>
                           </td>
                           <td className="px-6 py-5">
                              <span className="text-xs font-bold text-white uppercase tracking-tight">{panel.name}</span>
                           </td>
                           <td className="px-6 py-5">
                              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                                 24/7 Active
                              </span>
                           </td>
                           <td className="px-6 py-5 text-right">
                              <div className="flex items-center justify-end gap-3">
                                 <button 
                                   onClick={() => router.push(`/dashboard/${guildId}/tickets/edit/${panel.panelId}`)}
                                   className="text-[10px] font-bold text-white/40 hover:text-white uppercase tracking-widest transition-colors"
                                 >
                                    Edit
                                 </button>
                                 <button 
                                   onClick={() => handleDelete(panel.id)}
                                   className="text-[10px] font-bold text-red-500/40 hover:text-red-500 uppercase tracking-widest transition-colors"
                                 >
                                    Delete
                                 </button>
                              </div>
                           </td>
                        </tr>
                      ))
                    )}
                 </tbody>
              </table>
           </div>
        </section>

        {/* MULTI PANELS CARD */}
        <section className="bg-[#0a0a0f] border border-white/5 rounded-[32px] overflow-hidden group hover:border-[#9333ea]/20 transition-all duration-500 shadow-2xl">
           <div className="p-8 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white tracking-tight">Multi-Panels</h2>
              <button 
                onClick={() => router.push(`/dashboard/${guildId}/tickets/multi/create`)}
                className="bg-[#9333ea] hover:bg-[#a855f7] text-white px-8 py-3 rounded-xl font-bold text-[11px] uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(147,51,234,0.3)] flex items-center gap-2"
              >
                 <Plus className="w-4 h-4" /> New Multi-Panel
              </button>
           </div>

           <div className="p-4">
              <table className="w-full text-left">
                 <thead>
                    <tr className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em] border-b border-white/5">
                       <th className="px-6 py-4">Panel Title</th>
                       <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                 </thead>
                 <tbody>
                    {multiPanels.length === 0 ? (
                      <tr>
                        <td colSpan={2} className="px-8 py-20 text-center">
                           <div className="flex flex-col items-center gap-4 opacity-10">
                              <Layers className="w-12 h-12" />
                              <p className="text-[11px] font-bold uppercase tracking-widest">No multi-panels</p>
                           </div>
                        </td>
                      </tr>
                    ) : (
                      multiPanels.map((panel) => (
                        <tr key={panel.id} className="group/row hover:bg-white/[0.02] transition-colors border-b border-white/[0.02] last:border-0">
                           <td className="px-6 py-5">
                              <span className="text-xs font-bold text-white uppercase tracking-tight">{panel.name}</span>
                           </td>
                           <td className="px-6 py-5 text-right">
                              <div className="flex items-center justify-end gap-3">
                                 <button 
                                   onClick={() => router.push(`/dashboard/${guildId}/tickets/multi/edit/${panel.panelId}`)}
                                   className="text-[10px] font-bold text-white/40 hover:text-white uppercase tracking-widest transition-colors"
                                 >
                                    Edit
                                 </button>
                                 <button 
                                   onClick={() => handleDelete(panel.id)}
                                   className="text-[10px] font-bold text-red-500/40 hover:text-red-500 uppercase tracking-widest transition-colors"
                                 >
                                    Delete
                                 </button>
                              </div>
                           </td>
                        </tr>
                      ))
                    )}
                 </tbody>
              </table>
           </div>
        </section>
      </div>

      {/* Background Glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
         <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-[#9333ea]/5 blur-[120px] rounded-full" />
         <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-[#9333ea]/5 blur-[120px] rounded-full" />
      </div>
    </main>
  );
}
