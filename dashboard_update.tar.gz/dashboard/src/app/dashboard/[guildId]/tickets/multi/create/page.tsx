'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { 
  ChevronLeft, Save, Sparkles, Layers, Hash, Settings, 
  Layout, Info, CheckCircle2, AlertCircle, Plus, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SurgicalDropdown from '@/components/SurgicalDropdown';

export default function CreateMultiPanel() {
  const { guildId } = useParams();
  const router = useRouter();
  
  const [channels, setChannels] = useState<{id: string, name: string, type: number}[]>([]);
  const [availablePanels, setAvailablePanels] = useState<{panelId: string, name: string}[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    panelId: '',
    name: 'Multi Support',
    description: 'Select a category below to get help.',
    channelId: '',
    useDropdown: false,
    selectedPanels: [] as string[],
    panelColor: '#9333ea',
    embedTitle: '',
    embedDescription: '',
    authorName: '',
    footerText: '',
    // Advanced Customization
    ticketNameFormat: 'ticket-{id}-{panel}',
    welcomeTitle: '',
    welcomeDescription: 'Thank you for contacting support.\nPlease describe your issue and wait for a response.',
    welcomeColor: '#9333ea',
    welcomeAuthorName: '',
    welcomeAuthorIcon: '',
    welcomeAuthorUrl: '',
    welcomeImage: '',
    welcomeThumbnail: '',
    welcomeFooterText: '',
    welcomeFooterIcon: '',
    welcomeTimestamp: false,
    welcomeFields: [] as { name: string, value: string, inline: boolean }[]
  });

  useEffect(() => {
    if (!guildId) return;
    
    // Fetch channels
    fetch(`/api/guild/${guildId}/channels`)
      .then(r => r.json())
      .then(data => setChannels(data))
      .catch(console.error);

    // Fetch existing single panels
    fetch(`/api/guild/${guildId}/tickets`)
      .then(r => r.json())
      .then(data => {
         // Filter out multi-panels to avoid circular nesting
         setAvailablePanels(data.filter((p: any) => !p.isMulti));
      })
      .catch(console.error);
  }, [guildId]);

  const handleSave = async () => {
    if (!formData.panelId || !formData.channelId || formData.selectedPanels.length < 2) {
       alert('Panel ID, Channel, and at least 2 panels are required');
       return;
    }
    
    setIsSaving(true);
    try {
      const res = await fetch(`/api/guild/${guildId}/tickets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
           ...formData, 
           isMulti: true,
           options: formData.selectedPanels.map(pId => ({
              optionId: pId,
              label: availablePanels.find(p => p.panelId === pId)?.name || 'Panel',
              targetPanelId: pId
           }))
        })
      });
      if (res.ok) {
        router.push(`/dashboard/${guildId}/tickets`);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const togglePanel = (pId: string) => {
     if (formData.selectedPanels.includes(pId)) {
        setFormData({...formData, selectedPanels: formData.selectedPanels.filter(id => id !== pId)});
     } else {
        setFormData({...formData, selectedPanels: [...formData.selectedPanels, pId]});
     }
  };

  return (
    <main className="p-6 md:p-10 max-w-[1400px] mx-auto space-y-10 min-h-screen pb-32">
      <div className="flex items-center justify-between">
         <button 
           onClick={() => router.back()}
           className="group flex items-center gap-2 text-white/40 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest"
         >
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            Back to Panels
         </button>

         <button 
           onClick={handleSave}
           disabled={isSaving}
           className="bg-[#9333ea] hover:bg-[#a855f7] disabled:opacity-50 text-white px-8 py-3 rounded-2xl font-bold text-[11px] uppercase tracking-[0.2em] transition-all flex items-center gap-3"
         >
            {isSaving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isSaving ? "Deploying..." : "Create Multi-Panel"}
         </button>
      </div>

      <header className="space-y-4">
         <div className="flex items-center gap-3 text-[#9333ea] font-bold text-[10px] uppercase tracking-[0.5em]">
            <Layers className="w-3.5 h-3.5" /> Advanced Multi-Panel Routing
         </div>
         <h1 className="text-4xl font-black text-white uppercase italic tracking-tighter">
            Combined <span className="text-white/20">System</span>
         </h1>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
         <div className="xl:col-span-7 space-y-8">
            <section className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 backdrop-blur-3xl space-y-10">
               <div className="flex items-center gap-4">
                  <div className="p-3 bg-[#9333ea]/10 rounded-2xl border border-[#9333ea]/20">
                     <Settings className="w-6 h-6 text-[#9333ea]" />
                  </div>
                  <div>
                     <h2 className="text-xl font-bold text-white tracking-tight uppercase italic">Multi-Panel Properties</h2>
                     <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-1">Routing & Logic</p>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">System ID</label>
                     <input 
                       value={formData.panelId}
                       onChange={e => setFormData({...formData, panelId: e.target.value.toLowerCase().replace(/\s+/g, '-')})}
                       placeholder="e.g. support-hub"
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Panel Channel</label>
                     <SurgicalDropdown 
                       options={channels.filter(c => c.type === 0)}
                       value={formData.channelId}
                       onChange={val => setFormData({...formData, channelId: val})}
                       placeholder="Select Channel"
                     />
                  </div>
               </div>

               <div className="space-y-6 pt-6 border-t border-white/5">
                  <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Select Panels to Include</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     {availablePanels.length === 0 ? (
                        <div className="col-span-2 p-8 text-center bg-white/[0.02] rounded-3xl border border-dashed border-white/10">
                           <p className="text-xs font-bold text-white/20 uppercase tracking-widest">No single panels available to group</p>
                        </div>
                     ) : (
                        availablePanels.map((panel) => (
                           <button 
                             key={panel.panelId}
                             onClick={() => togglePanel(panel.panelId)}
                             className={`p-4 rounded-2xl border transition-all flex items-center justify-between group ${
                               formData.selectedPanels.includes(panel.panelId)
                               ? 'bg-[#9333ea]/10 border-[#9333ea]/30 text-white'
                               : 'bg-white/[0.02] border-white/5 text-white/40 hover:border-white/10'
                             }`}
                           >
                              <div className="flex items-center gap-3">
                                 <div className={`p-2 rounded-xl transition-all ${formData.selectedPanels.includes(panel.panelId) ? 'bg-[#9333ea] text-white' : 'bg-white/5 text-white/20'}`}>
                                    <Hash className="w-3.5 h-3.5" />
                                 </div>
                                 <span className="text-xs font-bold uppercase tracking-tight">{panel.name}</span>
                              </div>
                              {formData.selectedPanels.includes(panel.panelId) && <CheckCircle2 className="w-4 h-4 text-[#9333ea]" />}
                           </button>
                        ))
                     )}
                  </div>
               </div>

               <div className="flex items-center justify-between p-6 rounded-3xl bg-white/[0.02] border border-white/5">
                  <div className="flex items-center gap-4">
                     <Layout className="w-5 h-5 text-white/20" />
                     <div>
                        <div className="text-xs font-bold text-white uppercase tracking-tight">Use Dropdown Menu</div>
                        <div className="text-[9px] font-bold text-white/20 uppercase tracking-widest mt-0.5">Use a select menu instead of buttons</div>
                     </div>
                  </div>
                  <button 
                    onClick={() => setFormData({...formData, useDropdown: !formData.useDropdown})}
                    className={`w-12 h-6 rounded-full transition-all flex items-center p-1 ${formData.useDropdown ? 'bg-[#9333ea]' : 'bg-white/10'}`}
                  >
                     <motion.div 
                       animate={{ x: formData.useDropdown ? 24 : 0 }}
                       className="w-4 h-4 rounded-full bg-white" 
                     />
                  </button>
               </div>
            </section>
         </div>

         <div className="xl:col-span-5 space-y-8">
            <section className="bg-white/[0.01] border border-white/5 rounded-[40px] p-8 backdrop-blur-3xl space-y-8">
               <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20">
                     <Layout className="w-6 h-6 text-emerald-500" />
                  </div>
                  <div>
                     <h2 className="text-xl font-bold text-white tracking-tight uppercase italic">Main Embed</h2>
                     <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest mt-1">Multi-Panel Header</p>
                  </div>
               </div>

               <div className="space-y-6">
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Header Title</label>
                     <input 
                       value={formData.name}
                       onChange={e => setFormData({...formData, name: e.target.value})}
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all"
                     />
                  </div>
                  <div className="space-y-3">
                     <label className="text-[10px] font-black text-white/30 uppercase tracking-[0.2em] ml-2">Main Description</label>
                     <textarea 
                       value={formData.description}
                       onChange={e => setFormData({...formData, description: e.target.value})}
                       rows={4}
                       className="w-full bg-white/[0.03] border border-white/5 p-4 rounded-2xl text-sm font-bold text-white outline-none focus:border-[#9333ea]/50 transition-all resize-none"
                     />
                  </div>
               </div>
            </section>
         </div>
      </div>
    </main>
  );
}
