import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getUserGuilds, getBotGuilds, hasAdminPermission } from "@/lib/discord";
import Link from "next/link";
import {
  ShieldAlert, Settings2, ExternalLink, Zap,
  Plus, ShieldCheck, Lock, Search, LayoutGrid
} from "lucide-react";
import { redirect } from "next/navigation";
import Starfield from "@/components/Starfield";
import Navbar from "@/components/Navbar";

export default async function DashboardSelector() {
  const session: any = await getServerSession(authOptions);

  if (!session) {
    redirect("/");
  }

  const [userGuilds, botGuilds] = await Promise.all([
    getUserGuilds(session.accessToken || ""),
    getBotGuilds(),
  ]);

  // Guilds that have the bot added
  const activeGuilds = userGuilds.filter(guild =>
    botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  );

  // Guilds that don't have the bot added but user is admin/owner
  const availableGuilds = userGuilds.filter(guild =>
    !botGuilds.some(botGuild => botGuild.id === guild.id) &&
    (guild.owner || hasAdminPermission(guild.permissions || ""))
  );

  return (
    <div className="min-h-screen bg-background relative flex flex-col pt-16">
      <Starfield />

      <Navbar />

      <main className="relative z-10 max-w-[1200px] mx-auto w-full px-6 py-12 space-y-16">
        
        {/* Header Area */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight text-white">Your Servers</h1>
            <p className="text-sm text-white/30 font-medium">{activeGuilds.length} servers active</p>
          </div>
          
          <div className="relative group w-full md:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20 group-hover:text-white/40 transition-colors" />
            <input 
              type="text" 
              placeholder="Search..." 
              className="w-full bg-white/[0.03] border border-white/5 rounded-xl py-3 pl-11 pr-4 text-sm text-white placeholder:text-white/10 outline-none focus:border-white/10 transition-all"
            />
          </div>
        </div>

        {/* Active Servers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {activeGuilds.map((guild) => (
            <Link 
              key={guild.id}
              href={`/dashboard/${guild.id}`}
              className="group block h-[180px] rounded-[24px] overflow-hidden border border-white/5 hover:border-white/10 transition-all duration-500 relative"
            >
              {/* Banner Background */}
              <div className="absolute inset-0 bg-zinc-900 z-0">
                {guild.banner ? (
                  <img 
                    src={`https://cdn.discordapp.com/banners/${guild.id}/${guild.banner}.png?size=600`}
                    alt="" 
                    className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-opacity duration-700"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-indigo-500/10 to-purple-500/10 opacity-40" />
                )}
                {/* Vignette overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              </div>

              {/* Content Overlay */}
              <div className="absolute inset-0 z-10 p-8 flex items-center gap-6">
                 {guild.icon ? (
                   <img 
                    src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`}
                    className="w-16 h-16 rounded-full border-4 border-white/5 shadow-2xl scale-100 group-hover:scale-105 transition-transform duration-500"
                    alt={guild.name}
                   />
                 ) : (
                   <div className="w-16 h-16 rounded-full bg-white/5 border-4 border-white/5 flex items-center justify-center font-bold text-xl text-white/40">
                     {guild.name.charAt(0)}
                   </div>
                 )}

                 <div className="flex-1 min-w-0">
                    <h2 className="text-xl font-bold text-white truncate mb-1">/{guild.name.toLowerCase()}</h2>
                    <span className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">{guild.owner ? "Owner" : "Manager"}</span>
                 </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Add to Server Section */}
        <div className="pt-8">
           <div className="flex items-center gap-4 mb-8">
              <div className="h-px flex-1 bg-white/[0.03]" />
              <span className="text-[10px] font-bold text-white/10 uppercase tracking-[0.3em]">Add Enc Nexus to a Server</span>
              <div className="h-px flex-1 bg-white/[0.03]" />
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {availableGuilds.slice(0, 12).map((guild) => (
                <div key={guild.id} className="bg-white/[0.02] border border-white/5 rounded-[20px] p-5 flex items-center gap-4 group hover:bg-white/[0.04] transition-all">
                   {guild.icon ? (
                     <img 
                      src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`}
                      className="w-11 h-11 rounded-full grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500"
                      alt={guild.name}
                     />
                   ) : (
                     <div className="w-11 h-11 rounded-full bg-white/5 flex items-center justify-center text-sm font-bold text-white/10 uppercase">
                       {guild.name.slice(0, 2)}
                     </div>
                   )}
                   <div className="flex-1 min-w-0 pr-2">
                      <h3 className="text-sm font-bold text-white/50 truncate group-hover:text-white transition-colors">{guild.name}</h3>
                      <p className="text-[10px] text-white/10 font-bold uppercase tracking-wider">Bot not added</p>
                   </div>
                   <Link 
                    href={`https://discord.com/api/oauth2/authorize?client_id=1493482964246593556&permissions=8&scope=bot%20applications.commands&guild_id=${guild.id}`}
                    target="_blank"
                    className="p-3 bg-white/5 rounded-xl hover:bg-white text-white/40 hover:text-black transition-all"
                   >
                     <Plus className="w-4 h-4" />
                   </Link>
                </div>
              ))}
           </div>
        </div>

      </main>

      <footer className="relative z-10 mt-auto py-12 px-8 border-t border-white/[0.02] flex flex-col md:flex-row justify-between items-center gap-6 bg-black/40 backdrop-blur-3xl">
        <div className="flex items-center gap-3 text-[10px] font-bold text-white/10 uppercase tracking-widest">
          <ShieldCheck className="w-4 h-4 text-emerald-500/40" /> Secure Encryption Active
        </div>
        <div className="text-[10px] font-bold text-white/5 uppercase tracking-widest">
          Enc Nexus // Authorized by {session.user.name}
        </div>
      </footer>
    </div>
  );
}
