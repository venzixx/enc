import { ModalSubmitInteraction, EmbedBuilder } from "discord.js";
import { ExtendedClient } from "../../client";

export default {
    name: "appeal_submit",
    run: async (interaction: ModalSubmitInteraction) => {
        const client = interaction.client as ExtendedClient;
        const parts = interaction.customId.split("_");
        const guildId = parts[2];
        const type = parts[3];
        const appealReason = interaction.fields.getTextInputValue("appeal_reason");

        try {
            await interaction.deferReply({ ephemeral: true });

            // Fetch guild to get its name (since interaction is in DM, interaction.guild is null)
            const guild = await client.guilds.fetch(guildId).catch(() => null);
            if (!guild) {
                return await interaction.editReply({ content: "I couldn't find the server you are appealing for." });
            }

            // Save to database
            await client.prisma.appeal.create({
                data: {
                    guildId: guildId,
                    userId: interaction.user.id,
                    userTag: interaction.user.tag,
                    type: type,
                    reason: "Automated appeal submission", // We don't have the original reason here, but it's in the DB if staff logged it
                    appealReason: appealReason,
                    status: "PENDING"
                }
            });

            const successEmbed = new EmbedBuilder()
                .setTitle("✅ Appeal Submitted")
                .setDescription(`Your appeal for **${guild.name}** has been successfully submitted and is now pending review by the staff.`)
                .addFields({ name: "Explanation", value: appealReason })
                .setColor(client.color.green)
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // Optional: Log to staff channel if configured?
            // For now, it will show up in the dashboard.
            
        } catch (error) {
            console.error("Error in appeal_submit:", error);
            await interaction.editReply({ content: "There was an error processing your appeal. Please try again later." });
        }
    }
};
