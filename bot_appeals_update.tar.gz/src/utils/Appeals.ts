import { 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    EmbedBuilder, 
    User, 
    Guild 
} from "discord.js";
import { ExtendedClient } from "../client";

export class Appeals {
    public static async sendAppealDM(
        client: ExtendedClient, 
        user: User, 
        guild: Guild, 
        type: "BAN" | "KICK" | "MUTE", 
        reason: string
    ) {
        try {
            const embed = new EmbedBuilder()
                .setTitle(`🚨 Sanction Notification: ${guild.name}`)
                .setDescription(`You have been **${type.toLowerCase()}ed** from **${guild.name}**.`)
                .addFields(
                    { name: "Type", value: type, inline: true },
                    { name: "Reason", value: reason || "No reason provided", inline: true }
                )
                .setColor(client.color.red)
                .setFooter({ text: "You can appeal this sanction by clicking the button below." })
                .setTimestamp();

            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder()
                    .setCustomId(`appeal_init_${guild.id}_${type}`)
                    .setLabel("Appeal Sanction")
                    .setEmoji("📜")
                    .setStyle(ButtonStyle.Primary)
            );

            await user.send({ embeds: [embed], components: [row] }).catch(() => {
                console.log(`Could not send DM to ${user.tag} for appeal.`);
            });
        } catch (error) {
            console.error("Error in sendAppealDM:", error);
        }
    }
}
